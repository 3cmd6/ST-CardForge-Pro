/**
 * @file contracts.js
 * @description ST-CardForge Pro 接口宪法
 *
 *   本文件是整个拓展的核心约束文件。
 *   所有模块的函数签名、事件名、数据结构均以此为准，不得私自修改。
 *   如需变更，必须同步更新版本号并在 CHANGELOG 中记录。
 *
 * @version 1.0.0
 * @author   YourName
 * @license  MIT
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════
// § 1  版本信息
// ═══════════════════════════════════════════════════════════════════

/** 拓展当前版本，与 manifest.json 保持一致 */
export const VERSION = '1.0.0';

/** contracts.js 自身版本，独立追踪接口变更 */
export const CONTRACT_VERSION = '1.0.0';


// ═══════════════════════════════════════════════════════════════════
// § 2  事件名枚举
//       规则：cardforge : 模块名 : 动作
//       所有模块只能使用此处定义的事件名，严禁硬编码字符串
// ═══════════════════════════════════════════════════════════════════

/**
 * 全局事件枚举
 * @enum {string}
 */
export const EVENTS = Object.freeze({

    // ── 角色卡模块 ──────────────────────────────────────────────
    /** 角色卡任意字段发生变化（整卡级通知） */
    CARD_UPDATED:               'cardforge:card:updated',
    /** 单个字段发生变化，payload: { field, oldValue, newValue } */
    CARD_FIELD_CHANGED:         'cardforge:card:field:changed',
    /** 角色卡被重置为空 */
    CARD_RESET:                 'cardforge:card:reset',
    /** 草稿已自动保存，payload: { draftId, timestamp } */
    CARD_DRAFT_SAVED:           'cardforge:card:draft:saved',
    /** AI 一键全生成开始 */
    CARD_GENERATE_STARTED:      'cardforge:card:generate:started',
    /** AI 一键全生成完成，payload: { cardData } */
    CARD_GENERATE_DONE:         'cardforge:card:generate:done',

    // ── 世界书模块 ──────────────────────────────────────────────
    /** 世界书条目集合发生变化（整体级通知） */
    WB_UPDATED:                 'cardforge:wb:updated',
    /** 新增条目，payload: { entry } */
    WB_ENTRY_ADDED:             'cardforge:wb:entry:added',
    /** 删除条目，payload: { uid } */
    WB_ENTRY_REMOVED:           'cardforge:wb:entry:removed',
    /** 更新条目，payload: { uid, changes } */
    WB_ENTRY_UPDATED:           'cardforge:wb:entry:updated',
    /** 批量生成开始 */
    WB_GENERATE_STARTED:        'cardforge:wb:generate:started',
    /** 批量生成完成，payload: { entries } */
    WB_GENERATE_DONE:           'cardforge:wb:generate:done',

    // ── 开场白模块 ──────────────────────────────────────────────
    /** 开场白生成完成，payload: { first_mes, alternate_greetings } */
    GREETING_GENERATED:         'cardforge:greeting:generated',
    /** 用户选定某条开场白，payload: { index, content } */
    GREETING_SELECTED:          'cardforge:greeting:selected',

    // ── STscript 锻造模块 ────────────────────────────────────────
    /** 脚本生成完成，payload: { script } */
    SCRIPT_GENERATED:           'cardforge:script:generated',
    /** 脚本通过语法校验，payload: { script } */
    SCRIPT_VALIDATED:           'cardforge:script:validated',
    /** QR Set 生成完成，payload: { qrSet } */
    SCRIPT_QRSET_READY:         'cardforge:script:qrset:ready',

    // ── RPG 状态追踪模块 ─────────────────────────────────────────
    /** 某项属性值发生变化，payload: { key, oldValue, newValue, reason } */
    RPG_STAT_CHANGED:           'cardforge:rpg:stat:changed',
    /** 全部属性重置，payload: { stats } */
    RPG_STAT_RESET:             'cardforge:rpg:stat:reset',
    /** 属性历史记录更新，payload: { key, entry } */
    RPG_HISTORY_UPDATED:        'cardforge:rpg:history:updated',
    /** 自动扫描消息开始，payload: { message } */
    RPG_SCAN_STARTED:           'cardforge:rpg:scan:started',
    /** 自动扫描消息完成，payload: { changes } */
    RPG_SCAN_DONE:              'cardforge:rpg:scan:done',

    // ── 剧情分支模块 ─────────────────────────────────────────────
    /** 某分支节点被触发，payload: { nodeId, node } */
    BRANCH_TRIGGERED:           'cardforge:branch:triggered',
    /** 分支树结构发生变化，payload: { tree } */
    BRANCH_TREE_UPDATED:        'cardforge:branch:tree:updated',
    /** 某结局条件被触发，payload: { endingId, node } */
    BRANCH_ENDING_TRIGGERED:    'cardforge:branch:ending:triggered',

    // ── 正则锻造模块 ─────────────────────────────────────────────
    /** 正则规则被应用，payload: { ruleId, input, output } */
    REGEX_APPLIED:              'cardforge:regex:applied',
    /** 正则沙盒测试完成，payload: { result } */
    REGEX_TESTED:               'cardforge:regex:tested',
    /** 规则列表发生变化，payload: { rules } */
    REGEX_RULES_UPDATED:        'cardforge:regex:rules:updated',

    // ── 字段增强模块 ─────────────────────────────────────────────
    /** 增强任务开始，payload: { fieldName, mode } */
    FIELD_ENHANCE_STARTED:      'cardforge:field:enhance:started',
    /** 增强任务完成，payload: { fieldName, original, enhanced, mode } */
    FIELD_ENHANCED:             'cardforge:field:enhanced',
    /** 用户回滚到历史版本，payload: { fieldName, versionId } */
    FIELD_REVERTED:             'cardforge:field:reverted',

    // ── 导出模块 ─────────────────────────────────────────────────
    /** 导出任务开始，payload: { format } */
    EXPORT_STARTED:             'cardforge:export:started',
    /** 导出完成，payload: { format, filename } */
    EXPORT_READY:               'cardforge:export:ready',
    /** 导出失败，payload: { format, error } */
    EXPORT_FAILED:              'cardforge:export:failed',
    /** 导入完成，payload: { cardData, source } */
    IMPORT_DONE:                'cardforge:import:done',

    // ── 全局系统事件 ─────────────────────────────────────────────
    /** 全局错误，payload: { module, method, error, context } */
    ERROR:                      'cardforge:error',
    /** 加载状态开始，payload: { message } */
    LOADING_START:              'cardforge:loading:start',
    /** 加载状态结束 */
    LOADING_END:                'cardforge:loading:end',
    /** 加载进度更新，payload: { progress, message } */
    LOADING_PROGRESS:           'cardforge:loading:progress',
    /** 设置发生变化，payload: { key, oldValue, newValue } */
    SETTINGS_CHANGED:           'cardforge:settings:changed',
    /** 某模块初始化完成，payload: { moduleId } */
    MODULE_READY:               'cardforge:module:ready',
    /** 所有模块初始化完成 */
    ALL_MODULES_READY:          'cardforge:all:modules:ready',
    /** 撤销操作，payload: { description } */
    UNDO:                       'cardforge:undo',
    /** 重做操作，payload: { description } */
    REDO:                       'cardforge:redo',
});


// ═══════════════════════════════════════════════════════════════════
// § 3  核心数据结构 Schema
// ═══════════════════════════════════════════════════════════════════

/**
 * 角色卡数据结构（CCv3）
 * 所有模块读写角色卡数据时必须使用此结构
 *
 * @typedef  {Object}   CardData
 * @property {string}   spec                          - 固定值 'chara_card_v3'
 * @property {string}   spec_version                  - 固定值 '3.0'
 * @property {Object}   data                          - 实际数据体
 * @property {string}   data.name                     - 角色名称（必填）
 * @property {string}   data.description              - 角色描述
 * @property {string}   data.personality              - 性格摘要
 * @property {string}   data.scenario                 - 场景设定
 * @property {string}   data.first_mes                - 主开场白
 * @property {string}   data.mes_example              - 示例对话
 * @property {string}   data.system_prompt            - 系统提示词
 * @property {string}   data.post_history_instructions- 历史后指令
 * @property {string[]} data.alternate_greetings      - 备用开场白列表
 * @property {string[]} data.tags                     - 标签列表
 * @property {string}   data.creator                  - 创作者
 * @property {string}   data.character_version        - 角色版本号
 * @property {string}   data.creator_notes            - 创作者备注
 * @property {Object}   data.extensions               - 扩展字段
 * @property {Object}   data.extensions.cardforge     - 本拓展私有数据
 */
export const CARD_DATA_SCHEMA = Object.freeze({
    spec:         'chara_card_v3',
    spec_version: '3.0',
    data: {
        name:                       '',
        description:                '',
        personality:                '',
        scenario:                   '',
        first_mes:                  '',
        mes_example:                '',
        system_prompt:              '',
        post_history_instructions:  '',
        alternate_greetings:        [],
        tags:                       [],
        creator:                    '',
        character_version:          '',
        creator_notes:              '',
        extensions: {
            cardforge: {
                version:    VERSION,
                stats:      {},         // RPG 属性当前值快照
                branches:   [],         // 分支树 JSON
                worldbook:  null,       // 关联世界书 JSON
                regex:      [],         // 关联正则规则列表
                meta: {
                    created_at:     null,   // ISO 8601 时间戳
                    updated_at:     null,
                    session_count:  0,      // 累计聊天次数（由 ST 事件更新）
                    word_count:     0,      // description 字数
                    token_estimate: 0,      // 整卡 Token 估算
                }
            }
        }
    }
});

/**
 * 世界书条目结构
 *
 * @typedef  {Object}   WorldBookEntry
 * @property {number}   uid               - 唯一编号（自增）
 * @property {string[]} keys              - 主触发关键词
 * @property {string[]} secondary_keys    - 次级关键词（与主词 AND 关系）
 * @property {string}   content           - 注入到 prompt 的内容
 * @property {boolean}  enabled           - 是否启用
 * @property {number}   insertion_order   - 插入优先级（数字越小越靠前）
 * @property {number}   priority          - 同优先级时的排序权重
 * @property {string}   position          - 插入位置
 * @property {number}   depth             - 扫描深度（扫描最近 N 条消息）
 * @property {boolean}  selective         - 是否启用次级关键词过滤
 * @property {boolean}  constant          - 是否为常驻条目（不需触发）
 * @property {string}   category          - 分类标签
 * @property {Object}   extensions        - 保留字段
 */
export const WB_ENTRY_SCHEMA = Object.freeze({
    uid:                0,
    keys:               [],
    secondary_keys:     [],
    content:            '',
    enabled:            true,
    insertion_order:    100,
    priority:           10,
    position:           'before_char',  // 'before_char' | 'after_char' | 'chat'
    depth:              4,
    selective:          false,
    constant:           false,
    category:           '',
    extensions:         {}
});

/**
 * RPG 属性定义结构
 *
 * @typedef  {Object}   StatDef
 * @property {string}   key        - 在 STscript 变量中的键名，如 'player_hp'
 * @property {string}   label      - 界面显示名，如 '❤️ HP'
 * @property {string}   type       - 数据类型
 * @property {number}   min        - 最小值（type=number/percent 时有效）
 * @property {number}   max        - 最大值
 * @property {number}   current    - 当前值
 * @property {string}   color      - 进度条颜色（CSS 颜色值）
 * @property {boolean}  visible    - 是否在状态条中显示
 * @property {boolean}  trackable  - 是否允许 AI 自动追踪变化
 */
export const STAT_DEF_SCHEMA = Object.freeze({
    key:        '',
    label:      '',
    type:       'number',       // 'number' | 'percent' | 'enum' | 'boolean'
    min:        0,
    max:        100,
    current:    100,
    color:      '#7b68ee',
    visible:    true,
    trackable:  true,
});

/**
 * 剧情分支节点结构
 *
 * @typedef  {Object}       BranchNode
 * @property {string}       id              - 节点唯一 ID（UUID v4）
 * @property {string}       label           - 节点标签（显示用）
 * @property {string}       type            - 节点类型
 * @property {Object|null}  condition       - 触发条件（null 表示无条件）
 * @property {string}       condition.variable   - 变量名
 * @property {string}       condition.operator   - 运算符（见 OPERATORS）
 * @property {*}            condition.value      - 比较值
 * @property {boolean}      condition.negate     - 是否取反
 * @property {string}       content         - 该节点的剧情文本
 * @property {Object[]}     choices         - 玩家选项列表
 * @property {string}       choices[].label     - 选项文字
 * @property {string}       choices[].targetId  - 跳转目标节点 ID
 * @property {Object|null}  worldInfoEntry  - 关联的世界书条目
 * @property {string}       stscript        - 该节点触发时执行的 STscript
 * @property {string[]}     children        - 子节点 ID 列表
 */
export const BRANCH_NODE_SCHEMA = Object.freeze({
    id:             '',
    label:          '',
    type:           'normal',   // 'normal' | 'ending' | 'condition' | 'choice'
    condition:      null,
    content:        '',
    choices:        [],
    worldInfoEntry: null,
    stscript:       '',
    children:       [],
});

/**
 * 正则规则结构
 *
 * @typedef  {Object}   RegexRule
 * @property {string}   id          - 规则唯一 ID
 * @property {string}   name        - 规则名称（显示用）
 * @property {string}   find        - 正则表达式字符串（不含 / / 包裹）
 * @property {string}   flags       - 正则标志，如 'gi'
 * @property {string}   replace     - 替换字符串（支持 $1 和命名捕获组）
 * @property {string}   scope       - 作用域
 * @property {boolean}  enabled     - 是否启用
 * @property {number}   priority    - 执行优先级（数字越小越先执行）
 * @property {string}   description - 规则说明
 */
export const REGEX_RULE_SCHEMA = Object.freeze({
    id:             '',
    name:           '',
    find:           '',
    flags:          'g',
    replace:        '',
    scope:          'output',   // 'input' | 'output' | 'both'
    enabled:        true,
    priority:       0,
    description:    '',
});

/**
 * 增强历史版本记录结构
 *
 * @typedef  {Object}   EnhanceVersion
 * @property {string}   id          - 版本 ID（UUID v4）
 * @property {string}   fieldName   - 字段名
 * @property {string}   content     - 该版本的内容
 * @property {string}   mode        - 增强模式
 * @property {number}   intensity   - 增强强度 0.0~1.0
 * @property {number}   timestamp   - Unix 时间戳（ms）
 * @property {boolean}  isOriginal  - 是否为原始版本（未增强）
 */
export const ENHANCE_VERSION_SCHEMA = Object.freeze({
    id:         '',
    fieldName:  '',
    content:    '',
    mode:       '',
    intensity:  0.5,
    timestamp:  0,
    isOriginal: false,
});


// ═══════════════════════════════════════════════════════════════════
// § 4  接口定义
//       这些对象仅用于文档和类型说明，不作为运行时类型检查
// ═══════════════════════════════════════════════════════════════════

/**
 * 所有功能模块类必须实现的基础接口
 * @interface IModule
 */
export const MODULE_INTERFACE = Object.freeze({
    /**
     * 模块初始化
     * 在 index.js 的 _initFeatureModules() 中被调用
     * 必须在此方法中完成 DOM 挂载、事件订阅、数据加载
     * @returns {Promise<void>}
     */
    init:       async () => {},

    /**
     * 模块销毁
     * 在拓展被禁用或页面卸载时调用
     * 必须在此方法中取消所有事件订阅、清理 DOM、释放资源
     * @returns {void}
     */
    destroy:    () => {},

    /**
     * 获取模块当前状态快照
     * 用于接力文档生成和调试面板展示
     * @returns {Object}
     */
    getState:   () => ({}),

    /**
     * 模块是否已就绪（init 完成）
     * @returns {boolean}
     */
    isReady:    () => false,
});

/**
 * AIEngine 必须实现的接口
 * @interface IAIEngine
 */
export const AI_ENGINE_INTERFACE = Object.freeze({
    /** @returns {Promise<string>} */
    generateCard:           async (systemPrompt, userInput) => '',
    /** @returns {Promise<Object>} */
    generateWorldBook:      async (prompt, category) => ({}),
    /** @returns {Promise<string>} */
    enhanceField:           async (fieldName, content, mode) => '',
    /** @returns {Promise<string[]>} */
    generateGreetings:      async (characterData, options) => [],
    /** @returns {Promise<string>} */
    generateScript:         async (description) => '',
    /** @returns {number} */
    estimateTokens:         (text, model) => 0,
});

/**
 * EventBus 必须实现的接口
 * @interface IEventBus
 */
export const EVENT_BUS_INTERFACE = Object.freeze({
    /** @returns {Function} unsubscribe 函数 */
    on:     (event, callback) => () => {},
    off:    (event, callback) => {},
    emit:   (event, data) => {},
    once:   (event, callback) => {},
});


// ═══════════════════════════════════════════════════════════════════
// § 5  枚举常量
// ═══════════════════════════════════════════════════════════════════

/**
 * 条件运算符枚举
 * 用于 BranchNode.condition.operator 和 condition-parser.js
 * @enum {string}
 */
export const OPERATORS = Object.freeze({
    EQ:         'eq',           // 等于
    NEQ:        'neq',          // 不等于
    GT:         'gt',           // 大于
    GTE:        'gte',          // 大于等于
    LT:         'lt',           // 小于
    LTE:        'lte',          // 小于等于
    CONTAINS:   'contains',     // 包含子串
    MATCHES:    'matches',      // 正则匹配
});

/** OPERATORS 到 STscript rule 参数的映射 */
export const OPERATOR_TO_STSCRIPT = Object.freeze({
    [OPERATORS.EQ]:       'eq',
    [OPERATORS.NEQ]:      'neq',
    [OPERATORS.GT]:       'gt',
    [OPERATORS.GTE]:      'gte',
    [OPERATORS.LT]:       'lt',
    [OPERATORS.LTE]:      'lte',
    [OPERATORS.CONTAINS]: 'in',
    [OPERATORS.MATCHES]:  'regex',  // STscript 支持 rule=regex
});

/**
 * 世界书条目分类枚举
 * @enum {string}
 */
export const WB_CATEGORIES = Object.freeze({
    PLACE:        '地名',
    CHARACTER:    '人物',
    ORGANIZATION: '组织',
    ITEM:         '物品',
    HISTORY:      '历史',
    RULE:         '规则',
    OTHER:        '其他',
});

/**
 * 世界书条目插入位置枚举
 * @enum {string}
 */
export const WB_POSITIONS = Object.freeze({
    BEFORE_CHAR: 'before_char',
    AFTER_CHAR:  'after_char',
    CHAT:        'chat',
});

/**
 * 字段增强模式枚举
 * @enum {string}
 */
export const ENHANCE_MODES = Object.freeze({
    LITERARY:   'literary',     // 文学化
    DETAILED:   'detailed',     // 细腻化
    CONCISE:    'concise',      // 精简化
    POETIC:     'poetic',       // 诗意化
});

/**
 * 导出格式枚举
 * @enum {string}
 */
export const EXPORT_FORMATS = Object.freeze({
    JSON_V2:    'json_v2',      // CCv2 JSON
    JSON_V3:    'json_v3',      // CCv3 JSON
    PNG_V2:     'png_v2',       // 嵌入 chara chunk 的 PNG
    PNG_V3:     'png_v3',       // 嵌入 ccv3 chunk 的 PNG（同时回填 chara）
});

/**
 * 分支节点类型枚举
 * @enum {string}
 */
export const BRANCH_NODE_TYPES = Object.freeze({
    NORMAL:     'normal',       // 普通叙述节点
    ENDING:     'ending',       // 结局节点
    CONDITION:  'condition',    // 条件判断节点
    CHOICE:     'choice',       // 玩家选择节点
});

/**
 * RPG 属性类型枚举
 * @enum {string}
 */
export const STAT_TYPES = Object.freeze({
    NUMBER:     'number',       // 数值型（如 HP:75）
    PERCENT:    'percent',      // 百分比型（如 SP:80%）
    ENUM:       'enum',         // 枚举型（如 状态:中毒）
    BOOLEAN:    'boolean',      // 布尔型（如 存活:true）
});

/**
 * 开场白视角枚举
 * @enum {string}
 */
export const POV = Object.freeze({
    FIRST:  'first',    // 第一人称（我）
    SECOND: 'second',   // 第二人称（你）
    THIRD:  'third',    // 第三人称（他/她）
});


// ═══════════════════════════════════════════════════════════════════
// § 6  导入路径约定
//       以各 module 子目录为基准的相对路径
// ═══════════════════════════════════════════════════════════════════

/**
 * 标准导入路径
 * 使用方式：import { generateQuietPrompt } from IMPORT_PATHS.ST_SCRIPT
 * （实际代码中请直接使用字符串，此对象仅供参考）
 */
export const IMPORT_PATHS = Object.freeze({
    // ST 核心 API（相对于拓展根目录）
    ST_SCRIPT:          '../../../../script.js',
    ST_EXTENSIONS:      '../../../../extensions.js',

    // 内部核心模块（相对于 modules/XX_xxx/ 子目录）
    CONTRACTS:          '../../contracts.js',
    EVENT_BUS:          '../../core/event-bus.js',
    AI_ENGINE:          '../../core/ai-engine.js',
    SETTINGS_MANAGER:   '../../core/settings-manager.js',
    CACHE_MANAGER:      '../../core/cache-manager.js',
    ERROR_HANDLER:      '../../core/error-handler.js',
    I18N:               '../../core/i18n.js',

    // 工具库（相对于 modules/XX_xxx/ 子目录）
    UNDO_MANAGER:       '../../utils/undo-manager.js',
    INDEXEDDB_STORE:    '../../utils/indexeddb-store.js',
    TOKEN_COUNTER:      '../../utils/token-counter.js',
    CCv2_SCHEMA:        '../../utils/ccv2-schema.js',
    CCv3_SCHEMA:        '../../utils/ccv3-schema.js',
    PNG_METADATA:       '../../utils/png-metadata.js',
});


// ═══════════════════════════════════════════════════════════════════
// § 7  CSS 变量约定
//       在 style.css 的 :root 中定义，组件通过 var() 引用
// ═══════════════════════════════════════════════════════════════════

/**
 * CSS 自定义变量名及其默认值
 * 实际样式定义在 style.css 中，此处仅供 JS 动态样式参考
 */
export const CSS_VARS = Object.freeze({
    '--cf-primary':             '#7b68ee',
    '--cf-primary-dark':        '#5a4fcf',
    '--cf-primary-light':       '#9d8ff5',
    '--cf-success':             '#2ecc71',
    '--cf-warning':             '#f39c12',
    '--cf-danger':              '#e74c3c',
    '--cf-info':                '#3498db',

    '--cf-bg-panel':            'var(--black-tint-bg)',
    '--cf-bg-card':             'var(--black-tint-1)',
    '--cf-bg-input':            'var(--black-tint-2)',
    '--cf-border':              'var(--border-color)',
    '--cf-text':                'var(--text-color)',
    '--cf-text-muted':          'var(--text-color-muted)',

    '--cf-radius-sm':           '4px',
    '--cf-radius':              '8px',
    '--cf-radius-lg':           '12px',
    '--cf-shadow':              '0 4px 16px rgba(0,0,0,0.3)',
    '--cf-shadow-sm':           '0 2px 8px rgba(0,0,0,0.2)',
    '--cf-transition':          '0.2s ease',
    '--cf-transition-slow':     '0.4s ease',

    '--cf-z-panel':             '1000',
    '--cf-z-modal':             '1100',
    '--cf-z-toast':             '1200',
    '--cf-z-tour':              '1300',
});


// ═══════════════════════════════════════════════════════════════════
// § 8  命名规范（注释文档，不产生运行时代码）
// ═══════════════════════════════════════════════════════════════════

/**
 * 项目命名规范：
 *
 * 类名              PascalCase          CardGenerator / WorldBookEntry
 * 普通函数          camelCase           generateCard() / buildEntry()
 * 私有方法          _camelCase          _buildPrompt() / _validateField()
 * 常量/枚举         UPPER_SNAKE_CASE    PROMPT_TEMPLATES / DEFAULT_STATS
 * 事件名            cardforge:模块:动作  cardforge:card:updated
 * CSS 类名          cardforge-模块-元素  cardforge-card-editor
 * HTML id           cardforge-模块-元素  cardforge-main-panel
 * extensionSettings cardForgePro        （全局唯一 key，不得与其他拓展冲突）
 * IndexedDB 库名    CardForgeProDB
 * IndexedDB Store   drafts / history / cache
 * 代码缩进          4 空格
 * 字符串引号        单引号 ''
 * 文件编码          UTF-8
 * 行尾              LF
 */
export const NAMING_CONVENTIONS = null; // 仅供阅读，无运行时意义


// ═══════════════════════════════════════════════════════════════════
// § 9  错误处理规范（示例代码，不产生运行时导出）
// ═══════════════════════════════════════════════════════════════════

/**
 * 所有 async 函数必须使用以下错误处理模式：
 *
 * @example
 * import { EVENTS } from '../../contracts.js';
 * import { eventBus } from '../../core/event-bus.js';
 *
 * async function someAsyncOp(param) {
 *     try {
 *         // ... 业务逻辑 ...
 *         return result;
 *     } catch (error) {
 *         eventBus.emit(EVENTS.ERROR, {
 *             module:  'ModuleName',       // 所在模块类名
 *             method:  'someAsyncOp',      // 当前函数名
 *             error:   error,
 *             context: { param }           // 便于调试的参数快照
 *         });
 *         throw error; // 必须 rethrow，不得吞掉异常
 *     }
 * }
 */
export const ERROR_HANDLING_PATTERN = null; // 仅供阅读


// ═══════════════════════════════════════════════════════════════════
// § 10  运行时校验工具
// ═══════════════════════════════════════════════════════════════════

/**
 * 校验事件名是否合法（是否在 EVENTS 枚举中定义）
 * 主要供 EventBus 内部使用
 *
 * @param   {string}  eventName
 * @returns {boolean}
 */
export function isValidEvent(eventName) {
    return Object.values(EVENTS).includes(eventName);
}

/**
 * 创建一个符合 CARD_DATA_SCHEMA 的空角色卡对象（深拷贝）
 *
 * @returns {CardData}
 */
export function createEmptyCard() {
    return JSON.parse(JSON.stringify(CARD_DATA_SCHEMA));
}

/**
 * 创建一个符合 WB_ENTRY_SCHEMA 的空条目对象（深拷贝）
 *
 * @param   {number} uid   条目 UID
 * @returns {WorldBookEntry}
 */
export function createEmptyEntry(uid = 0) {
    const entry = JSON.parse(JSON.stringify(WB_ENTRY_SCHEMA));
    entry.uid = uid;
    return entry;
}

/**
 * 创建一个符合 STAT_DEF_SCHEMA 的空属性定义对象（深拷贝）
 *
 * @returns {StatDef}
 */
export function createEmptyStat() {
    return JSON.parse(JSON.stringify(STAT_DEF_SCHEMA));
}

/**
 * 创建一个符合 BRANCH_NODE_SCHEMA 的空分支节点（深拷贝）
 *
 * @param   {string} id     节点 ID
 * @param   {string} label  节点标签
 * @returns {BranchNode}
 */
export function createEmptyNode(id, label = '') {
    const node = JSON.parse(JSON.stringify(BRANCH_NODE_SCHEMA));
    node.id    = id;
    node.label = label;
    return node;
}

/**
 * 创建一个符合 REGEX_RULE_SCHEMA 的空正则规则（深拷贝）
 *
 * @param   {string} id   规则 ID
 * @returns {RegexRule}
 */
export function createEmptyRegexRule(id) {
    const rule = JSON.parse(JSON.stringify(REGEX_RULE_SCHEMA));
    rule.id    = id;
    return rule;
}