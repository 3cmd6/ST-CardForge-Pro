/**
 * @file core/ai-engine.js
 * @description AI 引擎核心模块，封装所有与 SillyTavern AI 接口的通信
 *              实现 contracts.js § 4 定义的 AI_ENGINE_INTERFACE
 * @version 1.0.0
 */

import { EVENTS } from '../contracts.js';
import { eventBus } from './event-bus.js';

// SillyTavern 原生 API（路径相对于拓展根目录）
let generateQuietPrompt, getRequestHeaders, substituteParams;

// 懒加载 ST API（避免循环依赖 + 兼容测试环境）
async function _loadSTAPI() {
    try {
        const mod = await import('../../../../script.js');
        generateQuietPrompt = mod.generateQuietPrompt;
        getRequestHeaders   = mod.getRequestHeaders;
        substituteParams    = mod.substituteParams;
    } catch {
        // 测试环境或 ST API 不可用时，使用 mock
        generateQuietPrompt = async (prompt) => `[Mock AI Response for: ${prompt.slice(0, 50)}]`;
        getRequestHeaders   = () => ({ 'Content-Type': 'application/json' });
        substituteParams    = (text) => text;
    }
}

// ─────────────────────────────────────────────
// Token 估算策略常量
// ─────────────────────────────────────────────
const TOKEN_ESTIMATE_RATIO = {
    zh:     1.5,    // 中文字符：每 1.5 字符 ≈ 1 token
    en:     0.75,   // 英文单词：每 0.75 词 ≈ 1 token
    other:  0.25,   // 其他字符：每 4 字符 ≈ 1 token
};

const MAX_RETRIES    = 3;
const RETRY_BASE_MS  = 1000;

// ─────────────────────────────────────────────
// Prompt 模板（内联，避免额外导入循环）
// ─────────────────────────────────────────────
const SYSTEM_PROMPTS = {
    card: `你是一位专业的角色卡撰写助手，擅长为 SillyTavern 创作高质量的角色扮演角色卡。
请严格按照 JSON 格式返回结果，不要添加任何额外解释。
所有文本内容使用用户指定的语言。`,

    worldbook: `你是一位世界观构建专家，擅长为角色扮演游戏创作详细的世界书条目。
请严格按照 JSON 格式返回结果，内容应当具体、生动、有内在逻辑一致性。`,

    enhance: `你是一位文学编辑，专门优化角色扮演文本的质量与表现力。
请保持原文的核心含义，仅改善文字风格、表达方式和细节描写。
直接返回优化后的文本，不要添加任何说明。`,

    greeting: `你是一位资深角色扮演作家，擅长撰写引人入胜的开场白。
请以角色的第一视角撰写，语言生动自然，能立刻抓住读者注意力。
直接返回开场白文本，不要添加任何说明。`,

    script: `你是一位 SillyTavern STscript 专家，精通所有指令和语法。
请生成可直接运行的 STscript 代码，添加必要的注释。
只返回代码，不要添加 Markdown 代码块标记。`,
};

// ─────────────────────────────────────────────
// AIEngine 类
// ─────────────────────────────────────────────
export class AIEngine {
    /**
     * @param {import('./event-bus.js').EventBus} bus
     * @param {import('./settings-manager.js').SettingsManager} settings
     */
    constructor(bus, settings) {
        this._bus      = bus;
        this._settings = settings;
        this._ready    = false;
        this._cache    = new Map();     // 轻量级请求缓存（Key = promptHash）
    }

    // ── 初始化 ─────────────────────────────────
    async init() {
        await _loadSTAPI();
        this._ready = true;
        this._bus.emit(EVENTS.MODULE_READY, { module: 'AIEngine' });
    }

    isReady() { return this._ready; }

    // ═══════════════════════════════════════════
    // 公共接口（实现 AI_ENGINE_INTERFACE）
    // ═══════════════════════════════════════════

    /**
     * 生成角色卡字段内容
     * @param {string} systemPrompt
     * @param {string} userInput
     * @returns {Promise<string>}
     */
    async generateCard(systemPrompt, userInput) {
        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: '正在生成角色卡…' });
            const prompt = this._buildSystemPrompt(
                SYSTEM_PROMPTS.card + '\n\n' + systemPrompt,
                userInput
            );
            const raw = await this._retryWithBackoff(() =>
                generateQuietPrompt(prompt, false, true)
            );
            return this._parseJSONResponse(raw);
        } catch (error) {
            this._emitError('AIEngine', 'generateCard', error, { userInput });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 生成世界书条目
     * @param {string} prompt
     * @param {string} category
     * @returns {Promise<object>}
     */
    async generateWorldBook(prompt, category) {
        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: `正在生成世界书��${category}」条目…` });
            const systemMsg = SYSTEM_PROMPTS.worldbook;
            const userMsg   = `分类：${category}\n\n${prompt}`;
            const full      = `${systemMsg}\n\n用户请求：${userMsg}`;
            const raw       = await this._retryWithBackoff(() =>
                generateQuietPrompt(full, false, true)
            );
            return this._parseJSONResponse(raw);
        } catch (error) {
            this._emitError('AIEngine', 'generateWorldBook', error, { prompt, category });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 增强单个字段
     * @param {string} fieldName
     * @param {string} content
     * @param {'literary'|'detailed'|'concise'|'poetic'} mode
     * @returns {Promise<string>}
     */
    async enhanceField(fieldName, content, mode) {
        try {
            this._bus.emit(EVENTS.FIELD_ENHANCE_STARTED, { fieldName, mode });
            this._bus.emit(EVENTS.LOADING_START, { msg: `正在增强「${fieldName}」字段…` });

            const modeDesc = {
                literary: '文学化润色：使��言更优美、有文学感',
                detailed: '扩充细节：增加更多具体描写和背景信息',
                concise:  '精炼压缩：保留��心内容，去除冗余表述',
                poetic:   '诗意化改写：使用富有意境的语言和意象',
            }[mode] || '整体优化';

            const prompt = `${SYSTEM_PROMPTS.enhance}

优化要求：${modeDesc}
字段名称：${fieldName}

原始内容：
${content}`;

            const result = await this._retryWithBackoff(() =>
                generateQuietPrompt(prompt, false, true)
            );
            const enhanced = result.trim();
            this._bus.emit(EVENTS.FIELD_ENHANCED, { fieldName, original: content, enhanced, mode });
            return enhanced;
        } catch (error) {
            this._emitError('AIEngine', 'enhanceField', error, { fieldName, mode });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 生成开场白（批量）
     * @param {object} characterData
     * @param {object} options
     * @returns {Promise<string[]>}
     */
    async generateGreetings(characterData, options = {}) {
        try {
            const {
                count    = 3,
                style    = 'literary',
                scenario = 'first_meeting',
                wordCount = 200,
                pov      = 'first',
            } = options;

            this._bus.emit(EVENTS.LOADING_START, { msg: `正在生成 ${count} 个开场白…` });

            const styleMap = {
                literary:   '文学化、有诗意',
                casual:     '轻松日常',
                dramatic:   '戏剧性、张力十足',
                mysterious: '神秘感、含蓄',
                poetic:     '充满诗意和意象',
            };

            const scenarioMap = {
                first_meeting: '初次相遇',
                reunion:       '久别重逢',
                crisis:        '危机时刻',
                daily:         '日常相处',
                farewell:      '离别时刻',
            };

            const povMap = {
                first:  '第一人称（我）',
                second: '第二人称（你）',
                third:  '第三人称',
            };

            const charSummary = `
角色名：${characterData.name || '未命名'}
性格：${characterData.personality || ''}
描述：${(characterData.description || '').slice(0, 300)}
场景：${characterData.scenario || ''}`.trim();

            const results = [];
            for (let i = 0; i < count; i++) {
                const prompt = `${SYSTEM_PROMPTS.greeting}

角色信息：
${charSummary}

写作要求：
- 风格：${styleMap[style] || style}
- 情景：${scenarioMap[scenario] || scenario}
- 视角：${povMap[pov] || pov}
- 字数：约 ${wordCount} 字
- 这是第 ${i + 1} 个版本，请与其他版本有所不同

请直接输出开场白正文：`;

                const text = await this._retryWithBackoff(() =>
                    generateQuietPrompt(prompt, false, true)
                );
                results.push(text.trim());
            }

            return results;
        } catch (error) {
            this._emitError('AIEngine', 'generateGreetings', error, { options });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 生成 STscript 代码
     * @param {string} description
     * @returns {Promise<string>}
     */
    async generateScript(description) {
        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: '正在生成 STscript…' });
            const prompt = `${SYSTEM_PROMPTS.script}

功能需求：
${description}

请生成对应的 STscript 代码：`;

            const raw = await this._retryWithBackoff(() =>
                generateQuietPrompt(prompt, false, true)
            );
            const script = this._cleanCodeBlock(raw);
            this._bus.emit(EVENTS.SCRIPT_GENERATED, { script });
            return script;
        } catch (error) {
            this._emitError('AIEngine', 'generateScript', error, { description });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 估算 Token 数量
     * @param {string} text
     * @param {string} model  目前统一使用启发式算法
     * @returns {number}
     */
    estimateTokens(text, model = 'auto') {
        if (!text || typeof text !== 'string') return 0;
        let tokens = 0;
        for (const char of text) {
            const code = char.charCodeAt(0);
            if (code >= 0x4E00 && code <= 0x9FFF) {
                // CJK 统一汉字
                tokens += 1 / TOKEN_ESTIMATE_RATIO.zh;
            } else if (code >= 0x3000 && code <= 0x9FFF) {
                // 其他 CJK 区域
                tokens += 1 / TOKEN_ESTIMATE_RATIO.zh;
            } else if ((code >= 0x41 && code <= 0x5A) || (code >= 0x61 && code <= 0x7A)) {
                // ASCII 字母（按词估算，4字母≈1token）
                tokens += 0.25;
            } else if (code === 0x20) {
                // 空格（英文单词边界，忽略计入词估算）
                tokens += 0;
            } else {
                tokens += TOKEN_ESTIMATE_RATIO.other;
            }
        }
        return Math.ceil(tokens);
    }

    // ═══════════════════════════════════════════
    // 流式输出
    // ═══════════════════════════════════════════

    /**
     * 流式生成（ST 原生流接口包装）
     * @param {string} prompt
     * @param {Function} onChunk   每个文本块回调
     * @param {Function} onDone    完成回调
     */
    async generateStream(prompt, onChunk = () => {}, onDone = () => {}) {
        try {
            // ST 目前的 generateQuietPrompt 不支持真流式，
            // 此处用「分批逐字」模拟流式效果，后续可替换为真实流接口
            const full = await generateQuietPrompt(prompt, false, true);
            const chars = [...full];
            const chunkSize = 5;
            for (let i = 0; i < chars.length; i += chunkSize) {
                const chunk = chars.slice(i, i + chunkSize).join('');
                onChunk(chunk);
                await _sleep(16);   // ~60fps
            }
            onDone(full);
        } catch (error) {
            this._emitError('AIEngine', 'generateStream', error, {});
            throw error;
        }
    }

    // ═══════════════════════════════════════════
    // Token 预算管理
    // ═══════════════════════════════════════════

    /**
     * @param {string} text
     * @param {number} limit
     * @returns {{ ok: boolean, used: number, remaining: number }}
     */
    checkTokenBudget(text, limit) {
        const used      = this.estimateTokens(text);
        const remaining = limit - used;
        return { ok: remaining >= 0, used, remaining };
    }

    /**
     * 截断文本到 Token 上限
     * @param {string} text
     * @param {number} limit
     * @returns {string}
     */
    truncateToTokenLimit(text, limit) {
        if (this.estimateTokens(text) <= limit) return text;
        // 二分截断
        let lo = 0, hi = text.length;
        while (lo < hi) {
            const mid  = Math.floor((lo + hi + 1) / 2);
            const sub  = text.slice(0, mid);
            if (this.estimateTokens(sub) <= limit) lo = mid;
            else hi = mid - 1;
        }
        return text.slice(0, lo) + '…';
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 根据任务类型选择最优模型（预留扩展点）
     * @param {'card'|'worldbook'|'enhance'|'greeting'|'script'} task
     * @returns {string}
     */
    _selectModel(task) {
        const pref = this._settings?.get('aiModelPreference', 'current');
        return pref === 'current' ? 'current' : pref;
    }

    /**
     * 构建完整 Prompt
     * @param {string} system
     * @param {string} user
     * @returns {string}
     */
    _buildSystemPrompt(system, user) {
        return `${system}\n\n---\n\n用户输入：${user}`;
    }

    /**
     * 鲁棒性 JSON 解析
     * 支持：纯 JSON、```json...``` 包裹、带前后文本的 JSON
     * @param {string} raw
     * @returns {object|string}
     */
    _parseJSONResponse(raw) {
        if (!raw || typeof raw !== 'string') return raw;
        const cleaned = raw.trim();

        // 1. 直接尝试解析
        try { return JSON.parse(cleaned); } catch {}

        // 2. 提取 ```json ... ``` 代码块
        const jsonBlock = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
        if (jsonBlock) {
            try { return JSON.parse(jsonBlock[1].trim()); } catch {}
        }

        // 3. 提取第一个 { ... } 或 [ ... ] 块
        const objMatch = cleaned.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
        if (objMatch) {
            try { return JSON.parse(objMatch[1]); } catch {}
        }

        // 4. 无法解析，返回原始字符串
        return cleaned;
    }

    /**
     * 移除 Markdown 代码块标记
     * @param {string} raw
     * @returns {string}
     */
    _cleanCodeBlock(raw) {
        return raw
            .replace(/^```[\w]*\n?/m, '')
            .replace(/\n?```$/m, '')
            .trim();
    }

    /**
     * 指数退避重试
     * @param {Function} fn         要重试的异步函数
     * @param {number} maxRetries
     * @returns {Promise<any>}
     */
    async _retryWithBackoff(fn, maxRetries = MAX_RETRIES) {
        let lastError;
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            try {
                return await fn();
            } catch (err) {
                lastError = err;
                if (attempt < maxRetries - 1) {
                    const delay = RETRY_BASE_MS * Math.pow(2, attempt);
                    console.warn(
                        `[AIEngine] 第 ${attempt + 1} 次失败，${delay}ms 后重试…`,
                        err
                    );
                    await _sleep(delay);
                }
            }
        }
        throw lastError;
    }

    /**
     * 标准错误上报
     */
    _emitError(module, method, error, context) {
        this._bus.emit(EVENTS.ERROR, { module, method, error, context });
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────
function _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}