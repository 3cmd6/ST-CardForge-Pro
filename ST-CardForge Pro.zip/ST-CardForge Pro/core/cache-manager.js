/**
 * @file core/cache-manager.js
 * @description AI 生成结果缓存管理器
 *
 *   提供两级缓存机制：
 *     L1 内存缓存（Memory Cache）：
 *       - 基于 Map 的内存缓存，访问速度最快
 *       - 进程/页面生命周期内有效
 *       - 容量上限：MAX_MEMORY_ENTRIES 条
 *       - 淘汰策略：LRU（最近最少使用）
 *
 *     L2 持久化缓存（IndexedDB Cache）：
 *       - 通过 indexeddb-store.js 的 STORES.CACHE 实现
 *       - 页面刷新后仍然有效
 *       - 支持 TTL（过期时间）
 *       - 容量上限：由 IndexedDB 存储空间决定
 *
 *   缓存键生成策略：
 *     - 对 prompt 字符串做轻量哈希（FNV-1a 32bit）
 *     - 相同 prompt 命中同一缓存，避免重复 AI 调用
 *     - 支持按缓存类型（type）批量失效
 *
 *   使用场景：
 *     - AI 生成角色卡字段（避免重复生成相同内容）
 *     - 关键词提取结果（keyword-analyzer.js）
 *     - Token 估算结果（大段文本的重复估算）
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { dbStore } from '../utils/indexeddb-store.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  常量
// ═══════════════════════════════════════════════════════════════════

/** L1 内存缓存最大条目数 */
const MAX_MEMORY_ENTRIES = 200;

/** 默认 TTL：5 分钟（毫秒） */
const DEFAULT_TTL_MS = 5 * 60 * 1000;

/** 长 TTL：30 分钟（用于不常变化的内容，如关键词提取） */
const LONG_TTL_MS = 30 * 60 * 1000;

/**
 * 缓存类型枚举
 * 用于按类型批量失效缓存
 * @readonly
 * @enum {string}
 */
export const CACHE_TYPES = Object.freeze({
    CARD_GENERATION:    'card_gen',     // 角色卡字段生成
    WORLDBOOK:          'worldbook',    // 世界书条目生成
    GREETING:           'greeting',     // 开场白生成
    SCRIPT:             'script',       // STscript 生成
    ENHANCEMENT:        'enhancement',  // 字段增强
    KEYWORD:            'keyword',      // 关键词提取
    TOKEN_COUNT:        'token_count',  // Token 估算
    GENERAL:            'general',      // 通用
});

/**
 * 各缓存类型对应的默认 TTL（ms）
 * @private
 */
const TYPE_TTL_MAP = Object.freeze({
    [CACHE_TYPES.CARD_GENERATION]:  DEFAULT_TTL_MS,
    [CACHE_TYPES.WORLDBOOK]:        DEFAULT_TTL_MS,
    [CACHE_TYPES.GREETING]:         DEFAULT_TTL_MS,
    [CACHE_TYPES.SCRIPT]:           DEFAULT_TTL_MS,
    [CACHE_TYPES.ENHANCEMENT]:      DEFAULT_TTL_MS,
    [CACHE_TYPES.KEYWORD]:          LONG_TTL_MS,
    [CACHE_TYPES.TOKEN_COUNT]:      LONG_TTL_MS,
    [CACHE_TYPES.GENERAL]:          DEFAULT_TTL_MS,
});


// ═══════════════════════════════════════════════════════════════════
// § 2  L1 内存缓存条目结构
// ═══════════════════════════════════════════════════════════════════

/**
 * @typedef  {Object} MemoryCacheEntry
 * @property {string} key         缓存键（promptHash）
 * @property {*}      value       缓存值
 * @property {number} expiresAt   过期时间戳（ms）
 * @property {string} type        缓存类型
 * @property {number} lastAccess  最近访问时间戳（ms，用于 LRU）
 * @property {number} hitCount    命中次数（统计用）
 */


// ═══════════════════════════════════════════════════════════════════
// § 3  CacheManager 类
// ═══════════════════════════════════════════════════════════════════

export class CacheManager {

    /**
     * @param {Object}  [options={}]
     * @param {boolean} [options.enableL2=true]       是否启用 L2 持久化缓存
     * @param {number}  [options.defaultTTL=300000]   默认 TTL（ms）
     * @param {boolean} [options.enabled=true]        是否启用缓存（false 时所有 get 返回 null）
     */
    constructor(options = {}) {
        const {
            enableL2    = true,
            defaultTTL  = DEFAULT_TTL_MS,
            enabled     = true,
        } = options;

        /** @private 是否启用缓存 */
        this._enabled    = enabled;

        /** @private 是否启用 L2 */
        this._enableL2   = enableL2;

        /** @private 默认 TTL */
        this._defaultTTL = defaultTTL;

        /**
         * L1 内存缓存
         * @private
         * @type {Map<string, MemoryCacheEntry>}
         */
        this._memCache = new Map();

        /**
         * 缓存统计
         * @private
         */
        this._stats = {
            l1Hits:     0,
            l2Hits:     0,
            misses:     0,
            sets:       0,
            evictions:  0,
        };

        // 定期自动清理过期条目（每 10 分钟）
        this._cleanupTimer = setInterval(
            () => this._cleanupExpired(),
            10 * 60 * 1000
        );
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.1  核心读写
    // ─────────────────────────────────────────────────────────────

    /**
     * 读取缓存
     * 先查 L1，L1 未命中再查 L2，L2 命中时回填 L1
     *
     * @param   {string}  key   缓存键（通常由 hashPrompt 生成）
     * @returns {Promise<*|null>}  缓存值，未命中或已过期返回 null
     *
     * @example
     * const key    = cacheManager.hashPrompt(prompt);
     * const cached = await cacheManager.get(key);
     * if (cached) return cached; // 命中缓存，跳过 AI 调用
     */
    async get(key) {
        if (!this._enabled) return null;

        // ── L1 查询 ───────────────────────────────────────────────
        const l1Entry = this._memCache.get(key);
        if (l1Entry) {
            if (!this._isExpired(l1Entry)) {
                l1Entry.lastAccess = Date.now();
                l1Entry.hitCount++;
                this._stats.l1Hits++;
                return l1Entry.value;
            } else {
                // L1 已过期，删除
                this._memCache.delete(key);
            }
        }

        // ── L2 查询 ───────────────────────────────────────────────
        if (this._enableL2) {
            const l2Value = await dbStore.getCache(key);
            if (l2Value !== null) {
                // L2 命中，回填 L1
                this._setMemCache(key, l2Value, this._defaultTTL, CACHE_TYPES.GENERAL);
                this._stats.l2Hits++;
                return l2Value;
            }
        }

        this._stats.misses++;
        return null;
    }

    /**
     * 写入缓存（同时写入 L1 和 L2）
     *
     * @param   {string}  key           缓存键
     * @param   {*}       value         缓存值（必须可 JSON 序列化）
     * @param   {Object}  [options={}]
     * @param   {number}  [options.ttlMs]   过期时间（ms），不传则使用类型默认值
     * @param   {string}  [options.type]    缓存类型（见 CACHE_TYPES）
     * @returns {Promise<void>}
     */
    async set(key, value, options = {}) {
        if (!this._enabled) return;

        const {
            type  = CACHE_TYPES.GENERAL,
            ttlMs = TYPE_TTL_MAP[type] ?? this._defaultTTL,
        } = options;

        // 写入 L1
        this._setMemCache(key, value, ttlMs, type);

        // 写入 L2
        if (this._enableL2) {
            const serialized = typeof value === 'string'
                ? value
                : JSON.stringify(value);
            await dbStore.setCache(key, serialized, ttlMs, type);
        }

        this._stats.sets++;
    }

    /**
     * 检查指定键是否存在于缓存中（仅检查 L1）
     *
     * @param   {string}  key
     * @returns {boolean}
     */
    has(key) {
        if (!this._enabled) return false;

        const entry = this._memCache.get(key);
        if (!entry) return false;
        if (this._isExpired(entry)) {
            this._memCache.delete(key);
            return false;
        }
        return true;
    }

    /**
     * 删除指定键的缓存（L1 + L2）
     *
     * @param   {string}  key
     * @returns {Promise<void>}
     */
    async delete(key) {
        this._memCache.delete(key);

        if (this._enableL2) {
            await dbStore.delete('cache', key);
        }
    }

    /**
     * 清空所有缓存（L1 + L2）
     *
     * @returns {Promise<void>}
     */
    async clear() {
        this._memCache.clear();
        this._resetStats();

        if (this._enableL2) {
            await dbStore.clearStore('cache');
        }
    }

    /**
     * 按类型批量失效缓存（L1）
     * 当某类数据源发生变化时，使对应类型的所有缓存失效
     *
     * @param   {string}  type  缓存类型（见 CACHE_TYPES）
     * @returns {number}        失效的 L1 条目数
     *
     * @example
     * // 世界书重新生成后，使所有世界书缓存失效
     * cacheManager.invalidateByType(CACHE_TYPES.WORLDBOOK);
     */
    invalidateByType(type) {
        let count = 0;
        for (const [key, entry] of this._memCache.entries()) {
            if (entry.type === type) {
                this._memCache.delete(key);
                count++;
            }
        }
        return count;
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.2  AI 生成结果专用接口
    // ─────────────────────────────────────────────────────────────

    /**
     * 获取 AI 生成结果缓存
     * 对 prompt 做哈希后查询，命中时直接返回上次生成结果
     *
     * @param   {string}  prompt      完整 prompt 字符串
     * @param   {string}  [type]      缓存类型
     * @returns {Promise<string|null>}
     *
     * @example
     * const cached = await cacheManager.getCachedGeneration(fullPrompt, CACHE_TYPES.CARD_GENERATION);
     * if (cached) return cached;
     * const result = await aiEngine.generate(fullPrompt);
     * await cacheManager.setCachedGeneration(fullPrompt, result, CACHE_TYPES.CARD_GENERATION);
     */
    async getCachedGeneration(prompt, type = CACHE_TYPES.GENERAL) {
        const key    = this.hashPrompt(prompt);
        const cached = await this.get(key);
        return cached;
    }

    /**
     * 存储 AI 生成结果缓存
     *
     * @param   {string}  prompt      完整 prompt 字符串
     * @param   {string}  result      AI 生成结果
     * @param   {string}  [type]      缓存类型
     * @returns {Promise<void>}
     */
    async setCachedGeneration(prompt, result, type = CACHE_TYPES.GENERAL) {
        const key = this.hashPrompt(prompt);
        await this.set(key, result, { type });
    }

    /**
     * 检查 AI 生成结果是否已缓存（仅查 L1，速度快）
     *
     * @param   {string}  prompt
     * @returns {boolean}
     */
    hasCachedGeneration(prompt) {
        const key = this.hashPrompt(prompt);
        return this.has(key);
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.3  哈希工具
    // ─────────────────────────────────────────────────────────────

    /**
     * 对 prompt 字符串做 FNV-1a 32bit 哈希，生成缓存键
     * FNV-1a 特点：简单快速，碰撞率低，适合短字符串
     *
     * @param   {string}  prompt
     * @returns {string}  格式：'cf_xxxxxxxx'（8位十六进制）
     *
     * @example
     * cacheManager.hashPrompt('生成一个法师角色');  // → 'cf_a3f2b1c9'
     */
    hashPrompt(prompt) {
        if (typeof prompt !== 'string') {
            prompt = JSON.stringify(prompt);
        }

        // FNV-1a 32bit 哈希
        let hash = 0x811c9dc5; // FNV offset basis
        for (let i = 0; i < prompt.length; i++) {
            hash ^= prompt.charCodeAt(i);
            // FNV prime：16777619（0x01000193）
            hash = Math.imul(hash, 0x01000193);
            hash >>>= 0; // 转为无符号 32 位整数
        }

        return 'cf_' + hash.toString(16).padStart(8, '0');
    }

    /**
     * 对多个参数组合生成缓存键
     * 适用于需要多维度区分缓存的场景
     *
     * @param   {...*}   parts  任意数量的参数（会被 JSON 序列化后拼接）
     * @returns {string}
     *
     * @example
     * const key = cacheManager.hashParams('description', 'fantasy', 0.8);
     */
    hashParams(...parts) {
        const combined = parts.map(p =>
            typeof p === 'string' ? p : JSON.stringify(p)
        ).join('||');
        return this.hashPrompt(combined);
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.4  统计与调试
    // ─────────────────────────────────────────────────────────────

    /**
     * 获取缓存统计信息
     *
     * @returns {CacheStats}
     *
     * @typedef  {Object} CacheStats
     * @property {number} l1Size      L1 当前条目数
     * @property {number} l1Hits      L1 命中次数
     * @property {number} l2Hits      L2 命中次数
     * @property {number} misses      未命中次数
     * @property {number} sets        写入次数
     * @property {number} evictions   LRU 淘汰次数
     * @property {number} hitRate     总命中率（0~1）
     */
    getStats() {
        const total    = this._stats.l1Hits + this._stats.l2Hits + this._stats.misses;
        const hitRate  = total > 0
            ? (this._stats.l1Hits + this._stats.l2Hits) / total
            : 0;

        return {
            l1Size:    this._memCache.size,
            l1Hits:    this._stats.l1Hits,
            l2Hits:    this._stats.l2Hits,
            misses:    this._stats.misses,
            sets:      this._stats.sets,
            evictions: this._stats.evictions,
            hitRate:   Math.round(hitRate * 1000) / 10, // 保留一位小数的百分比
        };
    }

    /**
     * 获取 L1 中的所有缓存键列表（调试用）
     *
     * @returns {string[]}
     */
    getKeys() {
        return [...this._memCache.keys()];
    }

    /**
     * 启用 / 禁用缓存
     * 禁用后所有 get 返回 null，所有 set 忽略写入
     *
     * @param   {boolean} enabled
     * @returns {void}
     */
    setEnabled(enabled) {
        this._enabled = Boolean(enabled);
        if (!enabled) {
            this._memCache.clear();
        }
        console.info(`[CardForge] CacheManager：缓存已${enabled ? '启用' : '禁用'}`);
    }

    /**
     * 销毁缓存管理器（清理定时器）
     * 在拓展被禁用时调用
     *
     * @returns {void}
     */
    destroy() {
        if (this._cleanupTimer) {
            clearInterval(this._cleanupTimer);
            this._cleanupTimer = null;
        }
        this._memCache.clear();
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.5  私有方法
    // ─────────────────────────────────────────────────────────────

    /**
     * 向 L1 写入一条缓存（含 LRU 淘汰）
     * @private
     *
     * @param {string} key
     * @param {*}      value
     * @param {number} ttlMs
     * @param {string} type
     */
    _setMemCache(key, value, ttlMs, type) {
        // 如果已存在则先删除（更新 LRU 顺序）
        if (this._memCache.has(key)) {
            this._memCache.delete(key);
        }

        // 超出容量上限时，淘汰最旧的（最近最少访问的）条目
        if (this._memCache.size >= MAX_MEMORY_ENTRIES) {
            this._evictLRU();
        }

        const now = Date.now();

        /** @type {MemoryCacheEntry} */
        const entry = {
            key,
            value,
            expiresAt:  now + ttlMs,
            type,
            lastAccess: now,
            hitCount:   0,
        };

        this._memCache.set(key, entry);
    }

    /**
     * LRU 淘汰：找到 lastAccess 最小的条目并删除
     * @private
     */
    _evictLRU() {
        let   oldestKey   = null;
        let   oldestTime  = Infinity;

        for (const [key, entry] of this._memCache.entries()) {
            if (entry.lastAccess < oldestTime) {
                oldestTime = entry.lastAccess;
                oldestKey  = key;
            }
        }

        if (oldestKey) {
            this._memCache.delete(oldestKey);
            this._stats.evictions++;
        }
    }

    /**
     * 检查一个内存缓存条目是否已过期
     * @private
     *
     * @param   {MemoryCacheEntry} entry
     * @returns {boolean}
     */
    _isExpired(entry) {
        return entry.expiresAt > 0 && entry.expiresAt < Date.now();
    }

    /**
     * 清理 L1 中所有已过期的条目
     * 由定时器定期调用
     * @private
     *
     * @returns {number}  清理的条目数
     */
    _cleanupExpired() {
        let count = 0;
        for (const [key, entry] of this._memCache.entries()) {
            if (this._isExpired(entry)) {
                this._memCache.delete(key);
                count++;
            }
        }
        if (count > 0) {
            console.debug(`[CardForge] CacheManager：清理了 ${count} 条过期 L1 缓存`);
        }
        return count;
    }

    /**
     * 重置统计计数器
     * @private
     */
    _resetStats() {
        this._stats = {
            l1Hits:    0,
            l2Hits:    0,
            misses:    0,
            sets:      0,
            evictions: 0,
        };
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 4  模块级单例
// ═══════════════════════════════════════════════════════════════════

/**
 * 全局 CacheManager 单例
 *
 * @type {CacheManager}
 *
 * @example
 * import { cacheManager, CACHE_TYPES } from '../../core/cache-manager.js';
 *
 * // 读取缓存
 * const cached = await cacheManager.getCachedGeneration(prompt, CACHE_TYPES.CARD_GENERATION);
 * if (cached) return cached;
 *
 * // 写入缓存
 * await cacheManager.setCachedGeneration(prompt, result, CACHE_TYPES.CARD_GENERATION);
 */
export const cacheManager = new CacheManager({
    enableL2:   true,
    defaultTTL: DEFAULT_TTL_MS,
    enabled:    true,
});