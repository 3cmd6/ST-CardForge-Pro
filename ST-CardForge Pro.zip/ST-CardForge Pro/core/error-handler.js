/**
 * @file core/error-handler.js
 * @description 全局错误处理器
 *
 *   提供统一的错误捕获、格式化、用户提示和错误日志功能：
 *     - 注册 window.onerror 和 window.onunhandledrejection 全局兜底
 *     - 手动上报（report）：各模块在 catch 块中调用
 *     - 用户提示：非阻断 Toast 和阻断 Modal 两种模式
 *     - 错误日志：内存中保留最近 50 条，支持导出
 *     - 错误分级：FATAL / ERROR / WARN / INFO
 *     - 与 EventBus 联动：收到 EVENTS.ERROR 事件自动处理
 *
 *   使用规范：
 *     各模块的 async 函数中必须遵守以下模式：
 *
 *       try {
 *           // ... 业务逻辑
 *       } catch (error) {
 *           eventBus.emit(EVENTS.ERROR, {
 *               module:  'CardGenerator',
 *               method:  'generateAll',
 *               error:   error,
 *               context: { description }
 *           });
 *           throw error;
 *       }
 *
 *     ErrorHandler 监听 EVENTS.ERROR 并自动处理，
 *     模块本身不需要直接调用 ErrorHandler。
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { EVENTS }    from '../contracts.js';
import { eventBus }  from './event-bus.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  错误级别枚举
// ═══════════════════════════════════════════════════════════════════

/**
 * 错误严重级别
 * @readonly
 * @enum {string}
 */
export const ERROR_LEVELS = Object.freeze({
    FATAL:  'fatal',    // 致命错误（拓展无法继续工作）
    ERROR:  'error',    // 普通错误（功能受损但可继续）
    WARN:   'warn',     // 警告（可能影响体验）
    INFO:   'info',     // 信息提示（无实质影响）
});

/**
 * 错误日志条目结构
 * @typedef  {Object}   ErrorLogEntry
 * @property {string}   id          记录 ID
 * @property {string}   level       错误级别（见 ERROR_LEVELS）
 * @property {string}   module      发生错误的模块名
 * @property {string}   method      发生错误的方法名
 * @property {string}   message     错误消息
 * @property {string}   stack       错误堆栈（可能为空）
 * @property {Object}   context     调用上下文快照
 * @property {number}   timestamp   发生时间戳（ms）
 * @property {boolean}  shownToUser 是否已向用户显示提示
 */

/**
 * 已知的可向用户友好展示的错误类型
 * key 为错误消息的匹配关键词（部分匹配），value 为用户友好提示
 * @private
 */
const USER_FRIENDLY_ERRORS = {
    'generateQuietPrompt':  'AI 生成请求失败，请检查当前选择的 API 是否正常',
    'API key':              'API 密钥无效或已过期，请在 ST 设置中重新配置',
    'context length':       '输入内容过长，超出模型上下文限制，请精简后重试',
    'network':              '网络请求失败，请检查网络连接',
    'NetworkError':         '网络请求失败，请检查网络连接',
    'QuotaExceededError':   '本地存储空间已满，请清理草稿历史',
    'IndexedDB':            '本地数据库操作失败，请尝试刷新页面',
    'PNG':                  'PNG 文件处理失败，请确认图片格式正确',
    'JSON.parse':           '数据解析失败，文件格式可能已损坏',
    'AbortError':           '操作已被取消',
};


// ═══════════════════════════════════════════════════════════════════
// § 2  ErrorHandler 类
// ═══════════════════════════════════════════════════════════════════

export class ErrorHandler {

    /**
     * @param {Object}  [options={}]
     * @param {number}  [options.maxLogSize=50]       错误日志最大保留条数
     * @param {boolean} [options.showToastOnError=true] 是否自动弹出 Toast 提示
     * @param {boolean} [options.logToConsole=true]   是否同步输出到 console
     */
    constructor(options = {}) {
        const {
            maxLogSize        = 50,
            showToastOnError  = true,
            logToConsole      = true,
        } = options;

        /** @private */
        this._maxLogSize       = maxLogSize;
        /** @private */
        this._showToast        = showToastOnError;
        /** @private */
        this._logToConsole     = logToConsole;

        /**
         * 内存错误日志
         * @private
         * @type {ErrorLogEntry[]}
         */
        this._log = [];

        /**
         * Toast 容器元素（懒创建）
         * @private
         * @type {HTMLElement|null}
         */
        this._toastContainer = null;

        /**
         * 是否已注册全局错误处理
         * @private
         */
        this._registered = false;

        /**
         * EventBus 订阅取消函数列表
         * @private
         */
        this._unsubscribers = [];
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.1  初始化 / 销毁
    // ─────────────────────────────────────────────────────────────

    /**
     * 注册全局错误处理器
     * 在 index.js 的 _setupGlobalErrorHandler() 中调用一次
     *
     * @returns {void}
     */
    register() {
        if (this._registered) return;
        this._registered = true;

        // 订阅 EventBus 错误事件
        const unsub = eventBus.on(
            EVENTS.ERROR,
            (payload) => this._onEventBusError(payload),
            { source: 'ErrorHandler', priority: 100 }
        );
        this._unsubscribers.push(unsub);

        // 全局未捕获错误（同步）
        this._origOnError = window.onerror;
        window.onerror = (message, source, lineno, colno, error) => {
            // 只处理来自本拓展的错误（通过路径判断）
            if (source && source.includes('ST-CardForge-Pro')) {
                this.report('GlobalHandler', 'window.onerror', error ?? new Error(message), {
                    source, lineno, colno
                });
            }
            // 不阻止默认行为，让 ST 本身的错误处理也能运行
            if (typeof this._origOnError === 'function') {
                return this._origOnError(message, source, lineno, colno, error);
            }
            return false;
        };

        // 全局未捕获 Promise 拒绝
        this._origOnUnhandledRejection = window.onunhandledrejection;
        window.onunhandledrejection = (event) => {
            const error = event.reason;
            if (error && this._isCardForgeError(error)) {
                this.report(
                    'GlobalHandler',
                    'unhandledrejection',
                    error,
                    {}
                );
            }
            if (typeof this._origOnUnhandledRejection === 'function') {
                this._origOnUnhandledRejection(event);
            }
        };

        console.info('[CardForge] ErrorHandler 已注册');
    }

    /**
     * 注销全局错误处理器（拓展禁用时调用）
     *
     * @returns {void}
     */
    unregister() {
        // 恢复原始全局处理器
        if (this._origOnError !== undefined) {
            window.onerror = this._origOnError;
        }
        if (this._origOnUnhandledRejection !== undefined) {
            window.onunhandledrejection = this._origOnUnhandledRejection;
        }

        // 取消 EventBus 订阅
        for (const unsub of this._unsubscribers) unsub();
        this._unsubscribers = [];

        // 清理 Toast 容器
        if (this._toastContainer) {
            this._toastContainer.remove();
            this._toastContainer = null;
        }

        this._registered = false;
        console.info('[CardForge] ErrorHandler 已注销');
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.2  手动上报
    // ─────────────────────────────────────────────────────────────

    /**
     * 手动上报一个错误
     * 通常在模块 catch 块中，发布 EVENTS.ERROR 之后调用
     * （EventBus 监听器会自动调用此方法，一般不需要直接调用）
     *
     * @param   {string}  moduleName   模块类名，如 'CardGenerator'
     * @param   {string}  methodName   方法名，如 'generateAll'
     * @param   {Error}   error        Error 对象
     * @param   {Object}  [context={}] 调用上下文（参数快照等）
     * @param   {string}  [level]      错误级别（自动推断，可手动覆盖）
     * @returns {ErrorLogEntry}        记录的日志条目
     */
    report(moduleName, methodName, error, context = {}, level = null) {
        const entry = this._buildLogEntry(moduleName, methodName, error, context, level);

        // 加入内存日志
        this._log.push(entry);
        if (this._log.length > this._maxLogSize) {
            this._log.shift();
        }

        // 输出到 console
        if (this._logToConsole) {
            this._logToConsole_(entry);
        }

        // 向用户显示提示
        if (this._showToast && this._shouldShowToUser(error)) {
            const friendlyMsg = this._getFriendlyMessage(error);
            this.showUserError(friendlyMsg, `[${moduleName}.${methodName}]`);
            entry.shownToUser = true;
        }

        return entry;
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.3  用户提示
    // ─────────────────────────────────────────────────────────────

    /**
     * 向用户展示非阻断 Toast 错误提示
     *
     * @param   {string}  message     主消息（用户友好文本）
     * @param   {string}  [detail=''] 附加详情（技术信息，折叠显示）
     * @param   {number}  [duration=5000] 自动消失时间（ms），0 表示不自动消失
     * @returns {void}
     */
    showUserError(message, detail = '', duration = 5000) {
        this._showToastUI(message, detail, 'error', duration);
    }

    /**
     * 向用户展示非阻断 Toast 警告提示
     *
     * @param   {string}  message
     * @param   {string}  [detail='']
     * @param   {number}  [duration=4000]
     * @returns {void}
     */
    showUserWarning(message, detail = '', duration = 4000) {
        this._showToastUI(message, detail, 'warning', duration);
    }

    /**
     * 向用户展示非阻断 Toast 成功提示
     *
     * @param   {string}  message
     * @param   {number}  [duration=3000]
     * @returns {void}
     */
    showUserSuccess(message, duration = 3000) {
        this._showToastUI(message, '', 'success', duration);
    }

    /**
     * 向用户展示非阻断 Toast 信息提示
     *
     * @param   {string}  message
     * @param   {number}  [duration=3000]
     * @returns {void}
     */
    showUserInfo(message, duration = 3000) {
        this._showToastUI(message, '', 'info', duration);
    }

    /**
     * 向用户展示阻断型错误 Modal
     * 适用于无法继续操作的致命错误
     *
     * @param   {string}  message   主消息
     * @param   {string}  [detail]  技术详情
     * @returns {Promise<void>}     用户点击确认后 resolve
     */
    showFatalError(message, detail = '') {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            overlay.className = 'cardforge-fatal-overlay';
            overlay.innerHTML = `
                <div class="cardforge-fatal-modal">
                    <div class="cardforge-fatal-icon">❌</div>
                    <h3 class="cardforge-fatal-title">CardForge 发生致命错误</h3>
                    <p class="cardforge-fatal-message">${_escapeHtml(message)}</p>
                    ${detail ? `
                        <details class="cardforge-fatal-detail">
                            <summary>技术详情</summary>
                            <pre>${_escapeHtml(detail)}</pre>
                        </details>
                    ` : ''}
                    <button class="cardforge-fatal-btn">我知道了</button>
                </div>
            `;

            overlay.querySelector('.cardforge-fatal-btn').addEventListener('click', () => {
                overlay.remove();
                resolve();
            });

            document.body.appendChild(overlay);
        });
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.4  日志管理
    // ─────────────────────────────────────────────────────────────

    /**
     * 获取错误日志列表
     *
     * @param   {number}  [limit=50]  最多返回条数（按时间倒序）
     * @param   {string}  [level]     筛选级别（不传则返回全部）
     * @returns {ErrorLogEntry[]}
     */
    getErrorLog(limit = 50, level = null) {
        let log = [...this._log].reverse(); // 最新在前
        if (level) {
            log = log.filter(entry => entry.level === level);
        }
        return log.slice(0, limit);
    }

    /**
     * 清空内存错误日志
     * @returns {void}
     */
    clearErrorLog() {
        this._log = [];
    }

    /**
     * 将错误日志导出为 JSON 字符串（用于用户反馈）
     *
     * @returns {string}
     */
    exportErrorLog() {
        return JSON.stringify(this._log, null, 2);
    }

    /**
     * 获取错误统计信息
     *
     * @returns {{ total, byLevel: Object.<string, number>, byModule: Object.<string, number> }}
     */
    getStats() {
        const byLevel  = {};
        const byModule = {};

        for (const entry of this._log) {
            byLevel[entry.level]    = (byLevel[entry.level]    ?? 0) + 1;
            byModule[entry.module]  = (byModule[entry.module]  ?? 0) + 1;
        }

        return {
            total: this._log.length,
            byLevel,
            byModule,
        };
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.5  私有方法
    // ─────────────────────────────────────────────────────────────

    /**
     * EventBus EVENTS.ERROR 事件的处理函数
     * @private
     *
     * @param {{ module, method, error, context }} payload
     */
    _onEventBusError(payload) {
        if (!payload || typeof payload !== 'object') return;

        const {
            module:  moduleName = 'Unknown',
            method:  methodName = 'unknown',
            error,
            context = {},
        } = payload;

        const err = error instanceof Error
            ? error
            : new Error(String(error ?? '未知错误'));

        this.report(moduleName, methodName, err, context);
    }

    /**
     * 构建错误日志条目
     * @private
     */
    _buildLogEntry(moduleName, methodName, error, context, levelOverride) {
        const level = levelOverride ?? this._inferLevel(error);

        return {
            id:          'err_' + Math.random().toString(36).slice(2, 10),
            level,
            module:      moduleName,
            method:      methodName,
            message:     error?.message ?? String(error),
            stack:       error?.stack   ?? '',
            context:     this._sanitizeContext(context),
            timestamp:   Date.now(),
            shownToUser: false,
        };
    }

    /**
     * 根据错误信息推断严重级别
     * @private
     *
     * @param   {Error} error
     * @returns {string}
     */
    _inferLevel(error) {
        if (!error) return ERROR_LEVELS.ERROR;

        const msg = (error.message ?? '').toLowerCase();

        // 网络相关通常是 WARN（可重试）
        if (msg.includes('network') || msg.includes('fetch') || msg.includes('timeout')) {
            return ERROR_LEVELS.WARN;
        }

        // 用户取消操作是 INFO
        if (msg.includes('aborted') || msg.includes('cancel')) {
            return ERROR_LEVELS.INFO;
        }

        // IndexedDB 配额是 ERROR
        if (msg.includes('quotaexceeded') || msg.includes('storage')) {
            return ERROR_LEVELS.ERROR;
        }

        return ERROR_LEVELS.ERROR;
    }

    /**
     * 判断该错误是否应该向用户展示 Toast 提示
     * @private
     *
     * @param   {Error} error
     * @returns {boolean}
     */
    _shouldShowToUser(error) {
        if (!error) return false;

        const msg = (error.message ?? '').toLowerCase();

        // AbortError / 用户主动取消，不提示
        if (msg.includes('aborted') || error.name === 'AbortError') return false;

        // 静默错误标记（模块可在 error 对象上设置此属性来抑制 Toast）
        if (error.silent === true) return false;

        return true;
    }

    /**
     * 获取对应错误的用户友好提示消息
     * @private
     *
     * @param   {Error}  error
     * @returns {string}
     */
    _getFriendlyMessage(error) {
        const raw = error?.message ?? '';

        for (const [keyword, friendlyMsg] of Object.entries(USER_FRIENDLY_ERRORS)) {
            if (raw.includes(keyword)) {
                return friendlyMsg;
            }
        }

        // 默认消息
        return `操作失败：${raw.slice(0, 80)}${raw.length > 80 ? '...' : ''}`;
    }

    /**
     * 判断错误是否来自 CardForge 拓展
     * @private
     *
     * @param   {Error} error
     * @returns {boolean}
     */
    _isCardForgeError(error) {
        if (!error || !error.stack) return false;
        return error.stack.includes('ST-CardForge-Pro');
    }

    /**
     * 清理上下文对象（移除不可序列化的值，防止 JSON 序列化失败）
     * @private
     *
     * @param   {Object} context
     * @returns {Object}
     */
    _sanitizeContext(context) {
        try {
            return JSON.parse(JSON.stringify(context, (key, value) => {
                if (typeof value === 'function') return '[Function]';
                if (value instanceof Error)      return { message: value.message, name: value.name };
                if (value instanceof HTMLElement) return `[HTMLElement: ${value.tagName}]`;
                return value;
            }));
        } catch {
            return { _sanitizeError: '上下文序列化失败' };
        }
    }

    /**
     * 将错误条目输出到 console
     * @private
     *
     * @param {ErrorLogEntry} entry
     */
    _logToConsole_(entry) {
        const prefix = `[CardForge][${entry.module}.${entry.method}]`;
        const msg    = `${prefix} ${entry.message}`;

        switch (entry.level) {
            case ERROR_LEVELS.FATAL:
            case ERROR_LEVELS.ERROR:
                console.error(msg, '\n上下文：', entry.context, '\n堆栈：', entry.stack);
                break;
            case ERROR_LEVELS.WARN:
                console.warn(msg, '\n上下文：', entry.context);
                break;
            case ERROR_LEVELS.INFO:
                console.info(msg);
                break;
        }
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.6  Toast UI
    // ─────────────────────────────────────────────────────────────

    /**
     * 创建或获取 Toast 容器
     * @private
     * @returns {HTMLElement}
     */
    _getToastContainer() {
        if (this._toastContainer && document.body.contains(this._toastContainer)) {
            return this._toastContainer;
        }

        const container = document.createElement('div');
        container.id        = 'cardforge-toast-container';
        container.className = 'cardforge-toast-container';
        document.body.appendChild(container);

        this._toastContainer = container;
        return container;
    }

    /**
     * 显示一条 Toast 提示
     * @private
     *
     * @param {string} message
     * @param {string} detail
     * @param {'error'|'warning'|'success'|'info'} type
     * @param {number} duration
     */
    _showToastUI(message, detail, type, duration) {
        const container = this._getToastContainer();

        const icons = {
            error:   '❌',
            warning: '⚠️',
            success: '✅',
            info:    'ℹ️',
        };

        const toast = document.createElement('div');
        toast.className = `cardforge-toast cardforge-toast--${type}`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <span class="cardforge-toast__icon">${icons[type] ?? 'ℹ️'}</span>
            <div class="cardforge-toast__body">
                <span class="cardforge-toast__message">${_escapeHtml(message)}</span>
                ${detail ? `<span class="cardforge-toast__detail">${_escapeHtml(detail)}</span>` : ''}
            </div>
            <button class="cardforge-toast__close" aria-label="关闭">✕</button>
        `;

        // 关闭按钮
        toast.querySelector('.cardforge-toast__close').addEventListener('click', () => {
            _removeToast(toast);
        });

        container.appendChild(toast);

        // 入场动画：下一帧添加 visible 类
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                toast.classList.add('cardforge-toast--visible');
            });
        });

        // 自动消失
        if (duration > 0) {
            setTimeout(() => _removeToast(toast), duration);
        }
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 3  工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 移除 Toast 元素（带淡出动画）
 * @private
 *
 * @param {HTMLElement} toast
 */
function _removeToast(toast) {
    if (!toast.isConnected) return;
    toast.classList.remove('cardforge-toast--visible');
    toast.classList.add('cardforge-toast--hiding');
    // 等待 CSS transition 结束后移除 DOM
    toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    // 兜底：300ms 后强制移除
    setTimeout(() => { if (toast.isConnected) toast.remove(); }, 350);
}

/**
 * 转义 HTML 特殊字符，防止 XSS
 * @private
 *
 * @param   {string} str
 * @returns {string}
 */
function _escapeHtml(str) {
    return String(str)
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;');
}


// ═══════════════════════════════════════════════════════════════════
// § 4  模块级单例
// ═══════════════════════════════════════════════════════════════════

/**
 * 全局 ErrorHandler 单例
 * 在 index.js 中调用 errorHandler.register() 完成初始化
 *
 * @type {ErrorHandler}
 *
 * @example
 * import { errorHandler } from '../../core/error-handler.js';
 *
 * // 在 index.js 初始化时：
 * errorHandler.register();
 *
 * // 显示成功提示：
 * errorHandler.showUserSuccess('角色卡已成功导出！');
 *
 * // 显示警告：
 * errorHandler.showUserWarning('description 字段 Token 较多，建议精简');
 */
export const errorHandler = new ErrorHandler({
    maxLogSize:       50,
    showToastOnError: true,
    logToConsole:     true,
});