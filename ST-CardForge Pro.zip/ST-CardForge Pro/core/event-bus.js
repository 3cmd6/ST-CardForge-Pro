/**
 * @file core/event-bus.js
 * @description 模块间通信事件总线
 *
 *   提供发布 / 订阅（Pub/Sub）模式的模块间通信能力：
 *     - 所有模块通过 EventBus 解耦通信，不直接互相引用
 *     - 事件名必须使用 contracts.js 中 EVENTS 枚举定义的值
 *     - 支持同步（emit）和异步（emitAsync）两种发布模式
 *     - 支持一次性订阅（once）和优先级调度（priority）
 *     - 内置事件名合法性校验，防止拼写错误导致的静默失败
 *     - 内置内存泄漏防护：单个事件最多允许 MAX_LISTENERS 个订阅者
 *
 *   使用规范：
 *     - 所有模块通过导入单例 eventBus 使用，不要 new EventBus()
 *     - 模块销毁时必须调用 off() 或使用 on() 返回的 unsubscribe 函数
 *     - 事件 payload 对象不应包含循环引用或不可序列化的值
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { EVENTS, isValidEvent } from '../contracts.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  常量
// ═══════════════════════════════════════════════════════════════════

/**
 * 单个事件允许的最大订阅者数量
 * 超出时输出警告，提示可能存在内存泄漏
 * @readonly
 */
const MAX_LISTENERS = 50;

/**
 * 异步发布时单个回调的最大等待时间（ms）
 * 超时后视为该回调已完成，不阻塞其他回调
 * @readonly
 */
const ASYNC_CALLBACK_TIMEOUT = 5000;


// ═══════════════════════════════════════════════════════════════════
// § 2  订阅者条目结构
// ═══════════════════════════════════════════════════════════════════

/**
 * @typedef  {Object}   ListenerEntry
 * @property {Function} callback    订阅者回调函数
 * @property {number}   priority    执行优先级（数字越大越先执行，默认 0）
 * @property {boolean}  once        是否为一次性订阅
 * @property {string}   id          订阅者唯一 ID（用于精确 off）
 * @property {string}   source      订阅来源模块名称（调试用，可选）
 */


// ═══════════════════════════════════════════════════════════════════
// § 3  EventBus 类
// ═══════════════════════════════════════════════════════════════════

export class EventBus {

    constructor() {
        /**
         * 事件监听器注册表
         * @private
         * @type {Map<string, ListenerEntry[]>}
         */
        this._listeners = new Map();

        /**
         * 事件发布历史（仅保留最近 N 条，用于调试）
         * @private
         * @type {Array<{event, data, timestamp}>}
         */
        this._history = [];

        /**
         * 是否启用调试模式（开启后每次 emit 都会 console.debug）
         * @private
         * @type {boolean}
         */
        this._debug = false;

        /**
         * 调试历史最大保留条数
         * @private
         */
        this._maxHistory = 100;
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.1  订阅
    // ─────────────────────────────────────────────────────────────

    /**
     * 订阅事件
     *
     * @param   {string}   event       事件名（必须是 EVENTS 枚举中的值）
     * @param   {Function} callback    回调函数 (data: any) => void
     * @param   {Object}   [options={}]
     * @param   {number}   [options.priority=0]    执行优先级（高优先级先执行）
     * @param   {string}   [options.source='']     订阅来源模块名（调试用）
     * @returns {Function}  取消订阅函数（调用后自动 off）
     *
     * @example
     * const unsub = eventBus.on(EVENTS.CARD_UPDATED, (data) => {
     *     console.log('角色卡已更新', data);
     * });
     * // 模块销毁时：
     * unsub();
     */
    on(event, callback, options = {}) {
        this._validateEvent(event);
        this._validateCallback(callback);

        const {
            priority = 0,
            source   = '',
        } = options;

        /** @type {ListenerEntry} */
        const entry = {
            callback,
            priority,
            once:   false,
            id:     _generateListenerId(),
            source,
        };

        this._addListener(event, entry);

        // 返回取消订阅函数
        return () => this._removeListenerById(event, entry.id);
    }

    /**
     * 订阅一次性事件
     * 回调触发一次后自动取消订阅
     *
     * @param   {string}   event
     * @param   {Function} callback
     * @param   {Object}   [options={}]
     * @param   {number}   [options.priority=0]
     * @param   {string}   [options.source='']
     * @returns {Function}  取消订阅函数
     *
     * @example
     * // 只监听下一次导出完成事件
     * eventBus.once(EVENTS.EXPORT_READY, ({ format, filename }) => {
     *     showToast(`导出完成：${filename}`);
     * });
     */
    once(event, callback, options = {}) {
        this._validateEvent(event);
        this._validateCallback(callback);

        const {
            priority = 0,
            source   = '',
        } = options;

        /** @type {ListenerEntry} */
        const entry = {
            callback,
            priority,
            once:   true,
            id:     _generateListenerId(),
            source,
        };

        this._addListener(event, entry);

        return () => this._removeListenerById(event, entry.id);
    }

    /**
     * 返回一个 Promise，在指定事件下次触发时 resolve
     * 适合在 async/await 场景中等待某个事件
     *
     * @param   {string}  event
     * @param   {number}  [timeoutMs=0]  超时时间（ms），0 表示不超时
     * @returns {Promise<*>}  resolve 为事件 payload，超时则 reject
     *
     * @example
     * const data = await eventBus.waitFor(EVENTS.CARD_GENERATE_DONE, 10000);
     * console.log('生成完成', data);
     */
    waitFor(event, timeoutMs = 0) {
        return new Promise((resolve, reject) => {
            let timer = null;

            const unsub = this.once(event, (data) => {
                if (timer) clearTimeout(timer);
                resolve(data);
            });

            if (timeoutMs > 0) {
                timer = setTimeout(() => {
                    unsub();
                    reject(new Error(
                        `[CardForge] EventBus.waitFor 超时：等待事件 "${event}" 超过 ${timeoutMs}ms`
                    ));
                }, timeoutMs);
            }
        });
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.2  取消订阅
    // ─────────────────────────────────────────────────────────────

    /**
     * 取消订阅
     * 如果同一个 callback 被注册了多次，只取消第一个匹配项
     *
     * @param   {string}   event
     * @param   {Function} callback  与 on() 时传入的同一个函数引用
     * @returns {boolean}  是否成功取消（找不到返回 false）
     */
    off(event, callback) {
        const listeners = this._listeners.get(event);
        if (!listeners) return false;

        const idx = listeners.findIndex(entry => entry.callback === callback);
        if (idx === -1) return false;

        listeners.splice(idx, 1);

        // 如果该事件没有订阅者了，清理 Map 条目
        if (listeners.length === 0) {
            this._listeners.delete(event);
        }

        return true;
    }

    /**
     * 清空指定事件的所有订阅者
     *
     * @param   {string} event
     * @returns {number}  被清除的订阅者数量
     */
    clear(event) {
        const listeners = this._listeners.get(event);
        if (!listeners) return 0;

        const count = listeners.length;
        this._listeners.delete(event);
        return count;
    }

    /**
     * 清空所有事件的所有订阅者
     * 通常在拓展被禁用时调用
     *
     * @returns {void}
     */
    clearAll() {
        this._listeners.clear();
        this._history   = [];
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.3  发布
    // ─────────────────────────────────────────────────────────────

    /**
     * 同步发布事件
     * 按优先级顺序依次调用所有订阅者回调
     * 单个回调抛出的异常不会中断其他回调的执行
     *
     * @param   {string}  event    事件名
     * @param   {*}       [data]   事件 payload
     * @returns {number}  实际触发的回调数量
     *
     * @example
     * eventBus.emit(EVENTS.CARD_UPDATED, { field: 'description', value: '...' });
     */
    emit(event, data) {
        this._validateEvent(event);
        this._recordHistory(event, data);

        if (this._debug) {
            console.debug(`[CardForge][EventBus] emit: ${event}`, data);
        }

        const listeners = this._listeners.get(event);
        if (!listeners || listeners.length === 0) return 0;

        // 拷贝一份，防止回调中修改订阅列表导致迭代错乱
        const snapshot = [...listeners];
        let   count    = 0;

        for (const entry of snapshot) {
            // 一次性订阅：先移除再调用（防止回调中再次 emit 同一事件时重复触发）
            if (entry.once) {
                this._removeListenerById(event, entry.id);
            }

            this._runCallback(entry.callback, data, event);
            count++;
        }

        return count;
    }

    /**
     * 异步发布事件
     * 并发调用所有订阅者回调（每个回调被 await），等待全部完成后 resolve
     * 单个回调超时或抛出异常不会影响其他回调
     *
     * @param   {string}  event
     * @param   {*}       [data]
     * @returns {Promise<number>}  实际触发的回调数量
     *
     * @example
     * await eventBus.emitAsync(EVENTS.EXPORT_STARTED, { format: 'png_v3' });
     */
    async emitAsync(event, data) {
        this._validateEvent(event);
        this._recordHistory(event, data);

        if (this._debug) {
            console.debug(`[CardForge][EventBus] emitAsync: ${event}`, data);
        }

        const listeners = this._listeners.get(event);
        if (!listeners || listeners.length === 0) return 0;

        const snapshot = [...listeners];

        // 移除所有一次性订阅
        for (const entry of snapshot) {
            if (entry.once) {
                this._removeListenerById(event, entry.id);
            }
        }

        // 并发执行所有回调，带超时保护
        await Promise.allSettled(
            snapshot.map(entry =>
                this._runCallbackAsync(entry.callback, data, event)
            )
        );

        return snapshot.length;
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.4  查询与调试
    // ─────────────────────────────────────────────────────────────

    /**
     * 获取指定事件当前的订阅者数量
     *
     * @param   {string}  event
     * @returns {number}
     */
    getListenerCount(event) {
        return this._listeners.get(event)?.length ?? 0;
    }

    /**
     * 获取所有已注册事件的统计信息
     *
     * @returns {Object.<string, number>}  { eventName: listenerCount }
     */
    getStats() {
        const stats = {};
        for (const [event, listeners] of this._listeners.entries()) {
            stats[event] = listeners.length;
        }
        return stats;
    }

    /**
     * 获取最近的事件历史（调试用）
     *
     * @param   {number} [limit=20]
     * @returns {Array<{event, data, timestamp}>}
     */
    getHistory(limit = 20) {
        return this._history.slice(-limit);
    }

    /**
     * 启用 / 关闭调试模式
     * 开启后每次 emit 都会输出 console.debug 日志
     *
     * @param   {boolean} enabled
     * @returns {void}
     */
    setDebug(enabled) {
        this._debug = Boolean(enabled);
        console.info(`[CardForge] EventBus 调试模式：${enabled ? '开启' : '关闭'}`);
    }

    /**
     * 获取指定事件的所有订阅者信息（调试用）
     *
     * @param   {string} event
     * @returns {Array<{id, priority, once, source}>}
     */
    getListeners(event) {
        const listeners = this._listeners.get(event) ?? [];
        return listeners.map(({ id, priority, once, source }) => ({
            id, priority, once, source
        }));
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.5  私有方法
    // ─────────────────────────────────────────────────────────────

    /**
     * 校验事件名合法性
     * @private
     *
     * @param   {string} event
     * @throws  {Error}  事件名不在 EVENTS 枚举中时抛出
     */
    _validateEvent(event) {
        if (typeof event !== 'string' || event.trim() === '') {
            throw new Error('[CardForge] EventBus：事件名必须是非空字符串');
        }
        if (!isValidEvent(event)) {
            throw new Error(
                `[CardForge] EventBus：未知事件名 "${event}"。` +
                '请使用 contracts.js 中 EVENTS 枚举定义的事件名。'
            );
        }
    }

    /**
     * 校验回调函数类型
     * @private
     *
     * @param   {*} callback
     * @throws  {Error}
     */
    _validateCallback(callback) {
        if (typeof callback !== 'function') {
            throw new Error(
                `[CardForge] EventBus：callback 必须是函数，` +
                `收到 ${typeof callback}`
            );
        }
    }

    /**
     * 向指定事件的监听器列表中添加一个条目（按优先级插入）
     * @private
     *
     * @param   {string}        event
     * @param   {ListenerEntry} entry
     */
    _addListener(event, entry) {
        if (!this._listeners.has(event)) {
            this._listeners.set(event, []);
        }

        const listeners = this._listeners.get(event);

        // 内存泄漏警告
        if (listeners.length >= MAX_LISTENERS) {
            console.warn(
                `[CardForge] EventBus：事件 "${event}" 的订阅者数量已达 ` +
                `${MAX_LISTENERS}，可能存在内存泄漏（忘记 off）`
            );
        }

        // 按 priority 降序插入（高优先级在前）
        const insertIdx = listeners.findIndex(e => e.priority < entry.priority);
        if (insertIdx === -1) {
            listeners.push(entry);
        } else {
            listeners.splice(insertIdx, 0, entry);
        }
    }

    /**
     * 通过 ID 精确移除某个订阅者
     * @private
     *
     * @param   {string} event
     * @param   {string} listenerId
     * @returns {boolean}
     */
    _removeListenerById(event, listenerId) {
        const listeners = this._listeners.get(event);
        if (!listeners) return false;

        const idx = listeners.findIndex(e => e.id === listenerId);
        if (idx === -1) return false;

        listeners.splice(idx, 1);

        if (listeners.length === 0) {
            this._listeners.delete(event);
        }

        return true;
    }

    /**
     * 安全地同步执行一个回调（捕获异常，不阻断其他回调）
     * @private
     *
     * @param   {Function} callback
     * @param   {*}        data
     * @param   {string}   event    用于错误日志
     */
    _runCallback(callback, data, event) {
        try {
            callback(data);
        } catch (error) {
            console.error(
                `[CardForge] EventBus：事件 "${event}" 的回调抛出异常：`,
                error
            );
        }
    }

    /**
     * 安全地异步执行一个回调（带超时保护）
     * @private
     *
     * @param   {Function} callback
     * @param   {*}        data
     * @param   {string}   event
     * @returns {Promise<void>}
     */
    async _runCallbackAsync(callback, data, event) {
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(
                () => reject(new Error(`回调超时（>${ASYNC_CALLBACK_TIMEOUT}ms）`)),
                ASYNC_CALLBACK_TIMEOUT
            )
        );

        try {
            await Promise.race([
                Promise.resolve(callback(data)),
                timeoutPromise,
            ]);
        } catch (error) {
            console.error(
                `[CardForge] EventBus：事件 "${event}" 的异步回调出现问题：`,
                error
            );
        }
    }

    /**
     * 记录事件历史（调试用）
     * @private
     *
     * @param   {string} event
     * @param   {*}      data
     */
    _recordHistory(event, data) {
        this._history.push({
            event,
            data,
            timestamp: Date.now(),
        });

        // 超出最大历史时，丢弃最旧的条目
        if (this._history.length > this._maxHistory) {
            this._history.shift();
        }
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 4  工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 生成订阅者唯一 ID
 * @private
 * @returns {string}
 */
function _generateListenerId() {
    return 'ls_' + Math.random().toString(36).slice(2, 10);
}


// ═══════════════════════════════════════════════════════════════════
// § 5  模块级单例
// ═══════════════════════════════════════════════════════════════════

/**
 * 全局 EventBus 单例
 * 所有模块通过此单例通信，不要自行 new EventBus()
 *
 * @type {EventBus}
 *
 * @example
 * import { eventBus } from '../../core/event-bus.js';
 * import { EVENTS }   from '../../contracts.js';
 *
 * // 订阅
 * const unsub = eventBus.on(EVENTS.CARD_UPDATED, (data) => { ... });
 *
 * // 发布
 * eventBus.emit(EVENTS.CARD_UPDATED, { field: 'name', value: '艾莉丝' });
 *
 * // 模块销毁时
 * unsub();
 */
export const eventBus = new EventBus();