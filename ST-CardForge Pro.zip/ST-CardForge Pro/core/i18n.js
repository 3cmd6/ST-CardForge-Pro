/**
 * @file core/i18n.js
 * @description 国际化（i18n）翻译管理器
 *
 *   提供中英文双语支持：
 *     - t(key, vars)：翻译函数，支持 {{变量名}} 插值
 *     - setLocale(locale)：切换语言（'zh-CN' | 'en-US'）
 *     - addMessages(locale, messages)：动态注册翻译条目
 *     - 找不到翻译时：先查 fallback 语言（en-US），再返回 key 本身
 *
 *   翻译键命名规范：
 *     '模块.分类.描述'
 *     例：'card.field.name' / 'export.button.png_v3'
 *
 *   插值语法：
 *     消息模板中使用 {{变量名}}，调用时传入 vars 对象
 *     例：t('card.token.count', { count: 1234 }) → '当前 Token：1,234'
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════
// § 1  支持的语言枚举
// ═══════════════════════════════════════════════════════════════════

/**
 * @readonly
 * @enum {string}
 */
export const LOCALES = Object.freeze({
    ZH_CN: 'zh-CN',
    EN_US: 'en-US',
});

/** 默认语言 */
const DEFAULT_LOCALE  = LOCALES.ZH_CN;

/** 回退语言（当前语言找不到 key 时使用） */
const FALLBACK_LOCALE = LOCALES.EN_US;


// ═══════════════════════════════════════════════════════════════════
// § 2  完整翻译字典
// ═══════════════════════════════════════════════════════════════════

/**
 * 翻译字典（中英双语完整版）
 * @private
 * @type {Object.<string, Object.<string, string>>}
 */
const MESSAGES = {

    // ════════════════════════════════════════════════════════════
    // zh-CN：中文翻译
    // ════════════════════════════════════════════════════════════
    [LOCALES.ZH_CN]: {

        // ── 通用 UI ────────────────────────────────────────────
        'common.confirm':               '确认',
        'common.cancel':                '取消',
        'common.save':                  '保存',
        'common.delete':                '删除',
        'common.edit':                  '编辑',
        'common.add':                   '添加',
        'common.reset':                 '重置',
        'common.close':                 '关闭',
        'common.back':                  '返回',
        'common.next':                  '下一步',
        'common.prev':                  '上一步',
        'common.finish':                '完成',
        'common.loading':               '加载中...',
        'common.generating':            '生成中...',
        'common.success':               '操作成功',
        'common.error':                 '操作失败',
        'common.warning':               '警告',
        'common.info':                  '提示',
        'common.copy':                  '复制',
        'common.copied':                '已复制',
        'common.import':                '导入',
        'common.export':                '导出',
        'common.preview':               '预览',
        'common.refresh':               '刷新',
        'common.search':                '搜索',
        'common.filter':                '筛选',
        'common.sort':                  '排序',
        'common.unknown':               '未知',
        'common.none':                  '无',
        'common.yes':                   '是',
        'common.no':                    '否',
        'common.optional':              '（可选）',
        'common.required':              '（必填）',

        // ── 主面板 ─────────────────────────────────────────────
        'panel.title':                  'ST-CardForge Pro',
        'panel.module.card':            '① 角色卡',
        'panel.module.worldbook':       '② 世界书',
        'panel.module.greeting':        '③ 开场白',
        'panel.module.stscript':        '④ STscript',
        'panel.module.rpg':             '⑤ RPG',
        'panel.module.branch':          '⑥ 剧情分支',
        'panel.module.regex':           '⑦ 正则',
        'panel.module.enhancer':        '⑧ 字段增强',
        'panel.module.exporter':        '⑨ 导出',
        'panel.token.label':            'Token 计数',
        'panel.token.count':            '{{used}} / {{limit}}',
        'panel.token.warning':          'Token 用量较高，建议精简',
        'panel.token.over':             'Token 超出限制，请压缩内容',

        // ── 角色卡生成器 ────────────────────────────────────────
        'card.title':                   '角色卡生成器',
        'card.btn.generate_all':        '✨ 一键生成',
        'card.btn.generate_field':      '🔄 生成此字段',
        'card.btn.reset':               '🗑️ 清空',
        'card.btn.save_draft':          '💾 保存草稿',
        'card.btn.load_draft':          '📂 加载草稿',
        'card.btn.ai_assist':           '🤖 AI 帮我想',
        'card.field.name':              '角色名称',
        'card.field.description':       '角色描述',
        'card.field.personality':       '性格摘要',
        'card.field.scenario':          '场景设定',
        'card.field.first_mes':         '主开场白',
        'card.field.mes_example':       '示例对话',
        'card.field.system_prompt':     '系统提示词',
        'card.field.post_history':      '历史后指令',
        'card.field.alt_greetings':     '备用开场白',
        'card.field.tags':              '标签',
        'card.field.creator':           '创作者',
        'card.field.version':           '角色版本',
        'card.field.creator_notes':     '创作者备注',
        'card.placeholder.name':        '输入角色名称...',
        'card.placeholder.description': '描述角色的外貌、背景、特征...',
        'card.placeholder.personality': '概括角色的核心性格特点...',
        'card.placeholder.scenario':    '描述故事发生的背景场景...',
        'card.placeholder.one_line':    '用一句话描述你想要的角色...',
        'card.style.fantasy':           '奇幻',
        'card.style.modern':            '现代',
        'card.style.scifi':             '科幻',
        'card.style.horror':            '恐怖',
        'card.style.cyberpunk':         '赛博朋克',
        'card.style.eastern':           '东方玄幻',
        'card.style.western':           '西方奇幻',
        'card.style.mythology':         '神话',
        'card.generating':              '正在生成角色卡...',
        'card.generate.done':           '角色卡已生成完成！',
        'card.generate.field.done':     '{{field}} 已生成',
        'card.draft.saved':             '草稿已保存',
        'card.draft.loaded':            '草稿已加载',
        'card.draft.deleted':           '草稿已删除',
        'card.draft.empty':             '暂无已保存的草稿',
        'card.draft.confirm_delete':    '确定要删除这个草稿吗？此操作不可撤销。',
        'card.validate.name_required':  '角色名称为必填项',
        'card.validate.token_over':     '{{field}} 字段 Token 超出限制',
        'card.relationship.title':      '角色关系图',
        'card.relationship.empty':      '暂无关系数据，请先生成角色卡',

        // ── 世界书生成器 ────────────────────────────────────────
        'wb.title':                     '世界书生成器',
        'wb.btn.generate':              '✨ 生成世界书',
        'wb.btn.generate_category':     '生成此分类',
        'wb.btn.add_entry':             '➕ 添加条目',
        'wb.btn.bulk_import':           '📥 批量导入',
        'wb.btn.export':                '📤 导出世界书',
        'wb.category.place':            '📍 地名',
        'wb.category.character':        '👤 人物',
        'wb.category.organization':     '🏛️ 组织',
        'wb.category.item':             '⚔️ 物品',
        'wb.category.history':          '📜 历史',
        'wb.category.rule':             '📋 规则',
        'wb.category.other':            '🔖 其他',
        'wb.field.keys':                '触发关键词',
        'wb.field.content':             '条目内容',
        'wb.field.position':            '插入位置',
        'wb.field.priority':            '优先级',
        'wb.field.depth':               '扫描深度',
        'wb.field.enabled':             '启用',
        'wb.field.constant':            '常驻',
        'wb.position.before_char':      '角色描述前',
        'wb.position.after_char':       '角色描述后',
        'wb.position.chat':             '聊天内',
        'wb.generating':                '正在生成世界书条目...',
        'wb.generate.done':             '世界书已生成，共 {{count}} 条条目',
        'wb.entry.count':               '共 {{count}} 条',
        'wb.empty':                     '暂无条目，点击「生成世界书」开始',
        'wb.import.success':            '成功导入 {{count}} 条条目',
        'wb.import.error':              '导入失败，请检查文件格式',
        'wb.keyword.analyzing':         '正在分析关键词...',

        // ── 开场白生成器 ────────────────────────────────────────
        'greeting.title':               '开场白生成器',
        'greeting.btn.generate_first':  '✨ 生成主开场白',
        'greeting.btn.generate_alts':   '✨ 批量生成备用',
        'greeting.btn.preview':         '👁️ 沙盒预览',
        'greeting.btn.use_this':        '✅ 使用此版本',
        'greeting.field.style':         '文风',
        'greeting.field.scenario':      '情景模式',
        'greeting.field.pov':           '叙事视角',
        'greeting.field.word_count':    '目标字数',
        'greeting.field.count':         '生成数量',
        'greeting.style.literary':      '📖 文学化',
        'greeting.style.casual':        '💬 轻松对话',
        'greeting.style.dramatic':      '🎭 戏剧性',
        'greeting.style.mysterious':    '🌙 神秘感',
        'greeting.style.poetic':        '🌸 诗意',
        'greeting.style.action':        '⚔️ 动作派',
        'greeting.style.slice_life':    '☕ 日常感',
        'greeting.style.formal':        '📜 正式文体',
        'greeting.scenario.first':      '✨ 初次相遇',
        'greeting.scenario.reunion':    '🔄 久别重逢',
        'greeting.scenario.crisis':     '🚨 危机时刻',
        'greeting.scenario.daily':      '☀️ 日常相处',
        'greeting.scenario.conflict':   '⚡ 正面冲突',
        'greeting.scenario.confession': '💗 坦白时刻',
        'greeting.scenario.farewell':   '🌅 告别离去',
        'greeting.pov.first':           '第一人称',
        'greeting.pov.second':          '第二人称',
        'greeting.pov.third':           '第三人称',
        'greeting.generating':          '正在生成开场白...',
        'greeting.generate.done':       '已生成 {{count}} 条开场白',
        'greeting.alt.label':           '备用开场白 #{{index}}',
        'greeting.preview.title':       '沙盒预览',
        'greeting.empty':               '暂无开场白，点击生成按钮开始',

        // ── STscript 锻造器 ─────────────────────────────────────
        'script.title':                 'STscript 锻造器',
        'script.btn.generate':          '✨ AI 生成脚本',
        'script.btn.build':             '🔧 可视化构建',
        'script.btn.validate':          '✅ 语法检验',
        'script.btn.export_qr':         '📤 导出 QR Set',
        'script.btn.debug':             '🐛 调试',
        'script.field.description':     '需求描述',
        'script.field.script':          '脚本代码',
        'script.template.rpg_bar':      '🎮 RPG 状态条',
        'script.template.plot_menu':    '📖 剧情选择菜单',
        'script.template.tool_btns':    '🛠️ 互动工具按钮',
        'script.template.auto_trigger': '⚡ 自动触发',
        'script.generating':            '正在生成脚本...',
        'script.generate.done':         '脚本已生成',
        'script.validate.ok':           '✅ 语法检验通过',
        'script.validate.error':        '❌ 发现语法问题：{{error}}',
        'script.placeholder.desc':      '描述你需要的脚本功能，例如：「生成一个显示玩家HP和MP的状态条」',

        // ── RPG 追踪器 ──────────────────────────────────────────
        'rpg.title':                    'RPG 状态追踪',
        'rpg.btn.add_stat':             '➕ 添加属性',
        'rpg.btn.reset_all':            '🔄 重置全部',
        'rpg.btn.gen_script':           '📜 生成追踪脚本',
        'rpg.btn.sync_wi':              '🌐 同步世界书',
        'rpg.btn.history':              '📊 变化历史',
        'rpg.stat.hp':                  '❤️ HP',
        'rpg.stat.mp':                  '💙 MP',
        'rpg.stat.sp':                  '💛 SP',
        'rpg.stat.level':               '⭐ 等级',
        'rpg.stat.gold':                '🪙 金币',
        'rpg.stat.atk':                 '⚔️ 攻击',
        'rpg.stat.def':                 '🛡️ 防御',
        'rpg.stat.spd':                 '💨 速度',
        'rpg.field.stat_name':          '属性名称',
        'rpg.field.current':            '当前值',
        'rpg.field.max':                '最大值',
        'rpg.field.min':                '最小值',
        'rpg.field.type':               '属性类型',
        'rpg.field.color':              '进度条颜色',
        'rpg.field.trackable':          '自动追踪',
        'rpg.type.number':              '数值型',
        'rpg.type.percent':             '百分比型',
        'rpg.type.enum':                '枚举型',
        'rpg.type.boolean':             '布尔型',
        'rpg.auto_track.on':            '✅ 自动追踪已开启',
        'rpg.auto_track.off':           '⏸️ 自动追踪已关闭',
        'rpg.sync.done':                '属性已同步至世界书',
        'rpg.history.empty':            '暂无变化记录',
        'rpg.history.entry':            '{{stat}} {{old}} → {{new}}（{{reason}}）',
        'rpg.generating_script':        '正在生成追踪脚本...',

        // ── 剧情分支系统 ────────────────────────────────────────
        'branch.title':                 '剧情分支系统',
        'branch.btn.add_node':          '➕ 添加节点',
        'branch.btn.add_ending':        '🏁 添加结局',
        'branch.btn.expand':            '✨ AI 扩写',
        'branch.btn.export':            '📤 导出',
        'branch.btn.import':            '📥 导入',
        'branch.node.normal':           '📝 普通节点',
        'branch.node.ending':           '🏁 结局节点',
        'branch.node.condition':        '🔀 条件节点',
        'branch.node.choice':           '🎯 选择节点',
        'branch.field.label':           '节点标签',
        'branch.field.content':         '剧情内容',
        'branch.field.condition':       '触发条件',
        'branch.field.stscript':        '触发脚本',
        'branch.condition.variable':    '变量名',
        'branch.condition.operator':    '运算符',
        'branch.condition.value':       '比较值',
        'branch.operator.eq':           '等于',
        'branch.operator.neq':          '不等于',
        'branch.operator.gt':           '大于',
        'branch.operator.gte':          '大于等于',
        'branch.operator.lt':           '小于',
        'branch.operator.lte':          '小于等于',
        'branch.operator.contains':     '包含',
        'branch.operator.matches':      '正则匹配',
        'branch.expand.done':           '节点内容已扩写',
        'branch.empty':                 '暂无分支节点，点击「添加节点」开始',
        'branch.export.done':           '分支树已导出',

        // ── 正则锻造器 ──────────────────────────────────────────
        'regex.title':                  '正则脚本生成器',
        'regex.btn.generate':           '✨ AI 生成正则',
        'regex.btn.test':               '🧪 测试',
        'regex.btn.add_preset':         '📚 从预设添加',
        'regex.btn.export':             '📤 导出规则',
        'regex.btn.clear_all':          '🗑️ 清空全部',
        'regex.field.name':             '规则名称',
        'regex.field.find':             '匹配正则',
        'regex.field.flags':            '正则标志',
        'regex.field.replace':          '替换为',
        'regex.field.scope':            '作用域',
        'regex.field.priority':         '优先级',
        'regex.field.description':      '规则说明',
        'regex.scope.input':            '输入处理',
        'regex.scope.output':           '输出处理',
        'regex.scope.both':             '双向处理',
        'regex.test.input':             '测试输入文本',
        'regex.test.output':            '处理结果',
        'regex.test.matches':           '匹配到 {{count}} 处',
        'regex.test.no_match':          '未找到匹配',
        'regex.generating':             '正在生成正则规则...',
        'regex.generate.done':          '正则规则已生成',
        'regex.placeholder.desc':       '描述你需要的正则功能，例如：「移除 AI 回复中的 OOC 括号内容」',
        'regex.placeholder.test':       '在此输入测试文本...',
        'regex.export.done':            '已导出 {{count}} 条规则',
        'regex.preset.category.purify':   '净化类',
        'regex.preset.category.beautify': '美化类',
        'regex.preset.category.cn_typo':  '中文排版',
        'regex.preset.category.format':   '格式转换',
        'regex.preset.category.advanced': '高级技巧',

        // ── 字段增强器 ──────────────────────────────────────────
        'enhancer.title':               '字段细腻化增强',
        'enhancer.btn.enhance':         '✨ 增强此字段',
        'enhancer.btn.enhance_all':     '✨ 批量增强全部',
        'enhancer.btn.revert':          '↩️ 回滚',
        'enhancer.btn.accept':          '✅ 接受修改',
        'enhancer.btn.reject':          '❌ 放弃修改',
        'enhancer.mode.literary':       '📖 文学化',
        'enhancer.mode.detailed':       '🔍 细腻化',
        'enhancer.mode.concise':        '✂️ 精简化',
        'enhancer.mode.poetic':         '🌸 诗意化',
        'enhancer.field.mode':          '增强模式',
        'enhancer.field.intensity':     '增强强度',
        'enhancer.field.intensity.low': '保守',
        'enhancer.field.intensity.high':'大幅改写',
        'enhancer.diff.added':          '新增',
        'enhancer.diff.removed':        '删除',
        'enhancer.diff.mode.inline':    '内联对比',
        'enhancer.diff.mode.side':      '左右对比',
        'enhancer.history.title':       '版本历史',
        'enhancer.history.empty':       '暂无历史版本',
        'enhancer.history.original':    '原始版本',
        'enhancer.history.version':     '版本 {{index}}（{{mode}}）',
        'enhancer.enhancing':           '正在增强 {{field}}...',
        'enhancer.done':                '{{field}} 增强完成',
        'enhancer.all.done':            '全部字段增强完成',

        // ── 导出器 ─────────────────────────────────────────────
        'exporter.title':               '格式导出器',
        'exporter.btn.json_v2':         '📄 导出 JSON（CCv2）',
        'exporter.btn.json_v3':         '📄 导出 JSON（CCv3）',
        'exporter.btn.png_v2':          '🖼️ 导出 PNG（CCv2）',
        'exporter.btn.png_v3':          '🖼️ 导出 PNG（CCv3）',
        'exporter.btn.batch':           '📦 批量导出',
        'exporter.btn.import':          '📥 导入角色卡',
        'exporter.btn.upload_cover':    '🖼️ 上传封面',
        'exporter.btn.ai_cover':        '🤖 AI 生成封面',
        'exporter.field.format':        '导出格式',
        'exporter.field.cover':         '角色封面',
        'exporter.field.include_wb':    '包含世界书',
        'exporter.preflight.ok':        '✅ 导出前检验通过',
        'exporter.preflight.errors':    '发现 {{count}} 个问题，请修复后再导出',
        'exporter.preflight.warnings':  '发现 {{count}} 个警告',
        'exporter.exporting':           '正在导出...',
        'exporter.done':                '✅ 导出成功：{{filename}}',
        'exporter.error':               '❌ 导出失败',
        'exporter.import.done':         '✅ 导入成功（{{version}} 格式）',
        'exporter.import.error':        '❌ 导入失败，请检查文件格式',
        'exporter.cover.size':          '封面将调整为 400×600 像素',
        'exporter.cover.none':          '未选择封面（将使用默认图片）',

        // ── 向导 ───────────────────────────────────────────────
        'wizard.title':                 '引导式创作向导',
        'wizard.step.basic':            '基础信息',
        'wizard.step.appearance':       '外貌描述',
        'wizard.step.personality':      '性格设定',
        'wizard.step.background':       '背景故事',
        'wizard.step.relations':        '人物关系',
        'wizard.step.dialogue':         '示例对话',
        'wizard.progress':              '步骤 {{current}}/{{total}}',
        'wizard.ai_help':               '🤖 AI 帮我想',
        'wizard.validate.required':     '此项为必填',

        // ── Token 状态 ─────────────────────────────────────────
        'token.status.ok':              '✅ Token 用量正常',
        'token.status.warning':         '⚠️ Token 用量较高',
        'token.status.over':            '❌ Token 超出限制',
        'token.field.warning':          '⚠️ {{field}} 超出警告线（{{count}} / {{limit}}）',
        'token.field.over':             '❌ {{field}} 超出强制线（{{count}} / {{limit}}）',

        // ── 错误提示 ───────────────────────────────────────────
        'error.ai.failed':              'AI 生成请求失败，请检查 API 设置',
        'error.ai.timeout':             'AI 生成超时，请稍后重试',
        'error.network':                '网络连接失败，请检查网络',
        'error.storage.full':           '本地存储空间已满，请清理草稿',
        'error.file.invalid':           '文件格式无效',
        'error.png.invalid':            '不是有效的角色卡 PNG 文件',
        'error.unknown':                '发生未知错误，请刷新页面重试',

        // ── 设置 ───────────────────────────────────────────────
        'settings.title':               'CardForge 设置',
        'settings.language':            '界面语言',
        'settings.ai_model':            'AI 模型偏好',
        'settings.ai_model.current':    '使用当前选择的模型',
        'settings.export_format':       '默认导出格式',
        'settings.auto_save':           '自动保存草稿',
        'settings.auto_save.interval':  '自动保存间隔（秒）',
        'settings.token_warn':          'Token 警告阈值',
        'settings.animations':          '启用动画效果',
        'settings.debug':               '调试模式',
        'settings.cache':               '启用 AI 结果缓存',
        'settings.reset':               '重置所有设置',
        'settings.reset.confirm':       '确定要重置所有设置为默认值吗？',
        'settings.saved':               '设置已保存',

        // ── 新手引导 ───────────────────────────────────────────
        'tour.welcome.title':           '欢迎使用 ST-CardForge Pro！',
        'tour.welcome.content':         '让我带你了解这个拓展的主要功能',
        'tour.module_nav.title':        '模块导航',
        'tour.module_nav.content':      '点击左侧导航标签切换不同的功能模块',
        'tour.card_gen.title':          '角色卡生成器',
        'tour.card_gen.content':        '输入一句话描述，AI 自动填充所有角色卡字段',
        'tour.preview.title':           '实时预览',
        'tour.preview.content':         '右侧面板实时展示角色卡内容和 Token 占用',
        'tour.export.title':            '导出角色卡',
        'tour.export.content':          '支持 CCv2/CCv3 JSON 和 PNG 格式导出',
        'tour.skip':                    '跳过引导',
        'tour.done':                    '开始使用',
    },

    // ════════════════════════════════════════════════════════════
    // en-US：英文翻译
    // ════════════════════════════════════════════════════════════
    [LOCALES.EN_US]: {

        // ── Common UI ──────────────────────────────────────────
        'common.confirm':               'Confirm',
        'common.cancel':                'Cancel',
        'common.save':                  'Save',
        'common.delete':                'Delete',
        'common.edit':                  'Edit',
        'common.add':                   'Add',
        'common.reset':                 'Reset',
        'common.close':                 'Close',
        'common.back':                  'Back',
        'common.next':                  'Next',
        'common.prev':                  'Previous',
        'common.finish':                'Finish',
        'common.loading':               'Loading...',
        'common.generating':            'Generating...',
        'common.success':               'Success',
        'common.error':                 'Error',
        'common.warning':               'Warning',
        'common.info':                  'Info',
        'common.copy':                  'Copy',
        'common.copied':                'Copied!',
        'common.import':                'Import',
        'common.export':                'Export',
        'common.preview':               'Preview',
        'common.refresh':               'Refresh',
        'common.search':                'Search',
        'common.filter':                'Filter',
        'common.sort':                  'Sort',
        'common.unknown':               'Unknown',
        'common.none':                  'None',
        'common.yes':                   'Yes',
        'common.no':                    'No',
        'common.optional':              '(Optional)',
        'common.required':              '(Required)',

        // ── Main Panel ─────────────────────────────────────────
        'panel.title':                  'ST-CardForge Pro',
        'panel.module.card':            '① Card',
        'panel.module.worldbook':       '② World Book',
        'panel.module.greeting':        '③ Greeting',
        'panel.module.stscript':        '④ STscript',
        'panel.module.rpg':             '⑤ RPG',
        'panel.module.branch':          '⑥ Plot Branch',
        'panel.module.regex':           '⑦ Regex',
        'panel.module.enhancer':        '⑧ Enhancer',
        'panel.module.exporter':        '⑨ Export',
        'panel.token.label':            'Token Count',
        'panel.token.count':            '{{used}} / {{limit}}',
        'panel.token.warning':          'Token usage is high, consider trimming content',
        'panel.token.over':             'Token limit exceeded, please compress content',

        // ── Card Generator ─────────────────────────────────────
        'card.title':                   'Card Generator',
        'card.btn.generate_all':        '✨ Generate All',
        'card.btn.generate_field':      '🔄 Generate Field',
        'card.btn.reset':               '🗑️ Clear',
        'card.btn.save_draft':          '💾 Save Draft',
        'card.btn.load_draft':          '📂 Load Draft',
        'card.btn.ai_assist':           '🤖 AI Suggest',
        'card.field.name':              'Name',
        'card.field.description':       'Description',
        'card.field.personality':       'Personality',
        'card.field.scenario':          'Scenario',
        'card.field.first_mes':         'First Message',
        'card.field.mes_example':       'Example Messages',
        'card.field.system_prompt':     'System Prompt',
        'card.field.post_history':      'Post History Instructions',
        'card.field.alt_greetings':     'Alternate Greetings',
        'card.field.tags':              'Tags',
        'card.field.creator':           'Creator',
        'card.field.version':           'Character Version',
        'card.field.creator_notes':     'Creator Notes',
        'card.placeholder.name':        'Enter character name...',
        'card.placeholder.description': 'Describe appearance, background, traits...',
        'card.placeholder.personality': 'Summarize core personality traits...',
        'card.placeholder.scenario':    'Describe the story background...',
        'card.placeholder.one_line':    'Describe your character in one sentence...',
        'card.style.fantasy':           'Fantasy',
        'card.style.modern':            'Modern',
        'card.style.scifi':             'Sci-Fi',
        'card.style.horror':            'Horror',
        'card.style.cyberpunk':         'Cyberpunk',
        'card.style.eastern':           'Eastern Fantasy',
        'card.style.western':           'Western Fantasy',
        'card.style.mythology':         'Mythology',
        'card.generating':              'Generating character card...',
        'card.generate.done':           'Character card generated successfully!',
        'card.generate.field.done':     '{{field}} generated',
        'card.draft.saved':             'Draft saved',
        'card.draft.loaded':            'Draft loaded',
        'card.draft.deleted':           'Draft deleted',
        'card.draft.empty':             'No saved drafts',
        'card.draft.confirm_delete':    'Delete this draft? This cannot be undone.',
        'card.validate.name_required':  'Character name is required',
        'card.validate.token_over':     '{{field}} token count exceeded',
        'card.relationship.title':      'Relationship Graph',
        'card.relationship.empty':      'No relationship data. Generate a card first.',

        // ── World Book ─────────────────────────────────────────
        'wb.title':                     'World Book Generator',
        'wb.btn.generate':              '✨ Generate World Book',
        'wb.btn.generate_category':     'Generate Category',
        'wb.btn.add_entry':             '➕ Add Entry',
        'wb.btn.bulk_import':           '📥 Bulk Import',
        'wb.btn.export':                '📤 Export',
        'wb.category.place':            '📍 Places',
        'wb.category.character':        '👤 Characters',
        'wb.category.organization':     '🏛️ Organizations',
        'wb.category.item':             '⚔️ Items',
        'wb.category.history':          '📜 History',
        'wb.category.rule':             '📋 Rules',
        'wb.category.other':            '🔖 Other',
        'wb.field.keys':                'Trigger Keys',
        'wb.field.content':             'Content',
        'wb.field.position':            'Position',
        'wb.field.priority':            'Priority',
        'wb.field.depth':               'Scan Depth',
        'wb.field.enabled':             'Enabled',
        'wb.field.constant':            'Constant',
        'wb.position.before_char':      'Before Char Desc',
        'wb.position.after_char':       'After Char Desc',
        'wb.position.chat':             'In Chat',
        'wb.generating':                'Generating world book entries...',
        'wb.generate.done':             'World book generated: {{count}} entries',
        'wb.entry.count':               '{{count}} entries',
        'wb.empty':                     'No entries. Click Generate to start.',
        'wb.import.success':            '{{count}} entries imported',
        'wb.import.error':              'Import failed. Check file format.',
        'wb.keyword.analyzing':         'Analyzing keywords...',

        // ── Greeting Generator ─────────────────────────────────
        'greeting.title':               'Greeting Generator',
        'greeting.btn.generate_first':  '✨ Generate First Message',
        'greeting.btn.generate_alts':   '✨ Generate Alternates',
        'greeting.btn.preview':         '👁️ Sandbox Preview',
        'greeting.btn.use_this':        '✅ Use This',
        'greeting.field.style':         'Style',
        'greeting.field.scenario':      'Scenario',
        'greeting.field.pov':           'POV',
        'greeting.field.word_count':    'Target Length',
        'greeting.field.count':         'Count',
        'greeting.style.literary':      '📖 Literary',
        'greeting.style.casual':        '💬 Casual',
        'greeting.style.dramatic':      '🎭 Dramatic',
        'greeting.style.mysterious':    '🌙 Mysterious',
        'greeting.style.poetic':        '🌸 Poetic',
        'greeting.style.action':        '⚔️ Action',
        'greeting.style.slice_life':    '☕ Slice of Life',
        'greeting.style.formal':        '📜 Formal',
        'greeting.scenario.first':      '✨ First Meeting',
        'greeting.scenario.reunion':    '🔄 Reunion',
        'greeting.scenario.crisis':     '🚨 Crisis',
        'greeting.scenario.daily':      '☀️ Daily Life',
        'greeting.scenario.conflict':   '⚡ Conflict',
        'greeting.scenario.confession': '💗 Confession',
        'greeting.scenario.farewell':   '🌅 Farewell',
        'greeting.pov.first':           'First Person',
        'greeting.pov.second':          'Second Person',
        'greeting.pov.third':           'Third Person',
        'greeting.generating':          'Generating greeting...',
        'greeting.generate.done':       '{{count}} greetings generated',
        'greeting.alt.label':           'Alternate Greeting #{{index}}',
        'greeting.preview.title':       'Sandbox Preview',
        'greeting.empty':               'No greetings yet. Click Generate to start.',

        // ── STscript Forge ─────────────────────────────────────
        'script.title':                 'STscript Forge',
        'script.btn.generate':          '✨ AI Generate Script',
        'script.btn.build':             '🔧 Visual Builder',
        'script.btn.validate':          '✅ Validate',
        'script.btn.export_qr':         '📤 Export QR Set',
        'script.btn.debug':             '🐛 Debug',
        'script.field.description':     'Description',
        'script.field.script':          'Script Code',
        'script.template.rpg_bar':      '🎮 RPG Status Bar',
        'script.template.plot_menu':    '📖 Plot Choice Menu',
        'script.template.tool_btns':    '🛠️ Tool Buttons',
        'script.template.auto_trigger': '⚡ Auto Trigger',
        'script.generating':            'Generating script...',
        'script.generate.done':         'Script generated',
        'script.validate.ok':           '✅ Validation passed',
        'script.validate.error':        '❌ Syntax issue: {{error}}',
        'script.placeholder.desc':      'Describe the script you need, e.g. "Create a status bar showing HP and MP"',

        // ── RPG Tracker ────────────────────────────────────────
        'rpg.title':                    'RPG Stat Tracker',
        'rpg.btn.add_stat':             '➕ Add Stat',
        'rpg.btn.reset_all':            '🔄 Reset All',
        'rpg.btn.gen_script':           '📜 Generate Script',
        'rpg.btn.sync_wi':              '🌐 Sync World Info',
        'rpg.btn.history':              '📊 Change History',
        'rpg.stat.hp':                  '❤️ HP',
        'rpg.stat.mp':                  '💙 MP',
        'rpg.stat.sp':                  '💛 SP',
        'rpg.stat.level':               '⭐ Level',
        'rpg.stat.gold':                '🪙 Gold',
        'rpg.stat.atk':                 '⚔️ ATK',
        'rpg.stat.def':                 '🛡️ DEF',
        'rpg.stat.spd':                 '💨 SPD',
        'rpg.field.stat_name':          'Stat Name',
        'rpg.field.current':            'Current',
        'rpg.field.max':                'Max',
        'rpg.field.min':                'Min',
        'rpg.field.type':               'Type',
        'rpg.field.color':              'Bar Color',
        'rpg.field.trackable':          'Auto Track',
        'rpg.type.number':              'Number',
        'rpg.type.percent':             'Percent',
        'rpg.type.enum':                'Enum',
        'rpg.type.boolean':             'Boolean',
        'rpg.auto_track.on':            '✅ Auto tracking enabled',
        'rpg.auto_track.off':           '⏸️ Auto tracking disabled',
        'rpg.sync.done':                'Stats synced to World Info',
        'rpg.history.empty':            'No change history',
        'rpg.history.entry':            '{{stat}} {{old}} → {{new}} ({{reason}})',
        'rpg.generating_script':        'Generating tracking script...',

        // ── Plot Branch ────────────────────────────────────────
        'branch.title':                 'Plot Branch System',
        'branch.btn.add_node':          '➕ Add Node',
        'branch.btn.add_ending':        '🏁 Add Ending',
        'branch.btn.expand':            '✨ AI Expand',
        'branch.btn.export':            '📤 Export',
        'branch.btn.import':            '📥 Import',
        'branch.node.normal':           '📝 Normal',
        'branch.node.ending':           '🏁 Ending',
        'branch.node.condition':        '🔀 Condition',
        'branch.node.choice':           '🎯 Choice',
        'branch.field.label':           'Node Label',
        'branch.field.content':         'Plot Content',
        'branch.field.condition':       'Trigger Condition',
        'branch.field.stscript':        'Trigger Script',
        'branch.condition.variable':    'Variable',
        'branch.condition.operator':    'Operator',
        'branch.condition.value':       'Value',
        'branch.operator.eq':           'equals',
        'branch.operator.neq':          'not equals',
        'branch.operator.gt':           'greater than',
        'branch.operator.gte':          'greater or equal',
        'branch.operator.lt':           'less than',
        'branch.operator.lte':          'less or equal',
        'branch.operator.contains':     'contains',
        'branch.operator.matches':      'matches regex',
        'branch.expand.done':           'Node content expanded',
        'branch.empty':                 'No nodes. Click Add Node to start.',
        'branch.export.done':           'Branch tree exported',

        // ── Regex Forge ────────────────────────────────────────
        'regex.title':                  'Regex Forge',
        'regex.btn.generate':           '✨ AI Generate Regex',
        'regex.btn.test':               '🧪 Test',
        'regex.btn.add_preset':         '📚 Add Preset',
        'regex.btn.export':             '📤 Export Rules',
        'regex.btn.clear_all':          '🗑️ Clear All',
        'regex.field.name':             'Rule Name',
        'regex.field.find':             'Find (Regex)',
        'regex.field.flags':            'Flags',
        'regex.field.replace':          'Replace With',
        'regex.field.scope':            'Scope',
        'regex.field.priority':         'Priority',
        'regex.field.description':      'Description',
        'regex.scope.input':            'Input',
        'regex.scope.output':           'Output',
        'regex.scope.both':             'Both',
        'regex.test.input':             'Test Input',
        'regex.test.output':            'Result',
        'regex.test.matches':           '{{count}} match(es) found',
        'regex.test.no_match':          'No matches found',
        'regex.generating':             'Generating regex rule...',
        'regex.generate.done':          'Regex rule generated',
        'regex.placeholder.desc':       'Describe the regex you need, e.g. "Remove OOC content in parentheses"',
        'regex.placeholder.test':       'Enter test text here...',
        'regex.export.done':            '{{count}} rules exported',
        'regex.preset.category.purify':   'Purify',
        'regex.preset.category.beautify': 'Beautify',
        'regex.preset.category.cn_typo':  'CN Typography',
        'regex.preset.category.format':   'Format Convert',
        'regex.preset.category.advanced': 'Advanced',

        // ── Field Enhancer ─────────────────────────────────────
        'enhancer.title':               'Field Enhancer',
        'enhancer.btn.enhance':         '✨ Enhance Field',
        'enhancer.btn.enhance_all':     '✨ Enhance All',
        'enhancer.btn.revert':          '↩️ Revert',
        'enhancer.btn.accept':          '✅ Accept',
        'enhancer.btn.reject':          '❌ Reject',
        'enhancer.mode.literary':       '📖 Literary',
        'enhancer.mode.detailed':       '🔍 Detailed',
        'enhancer.mode.concise':        '✂️ Concise',
        'enhancer.mode.poetic':         '🌸 Poetic',
        'enhancer.field.mode':          'Mode',
        'enhancer.field.intensity':     'Intensity',
        'enhancer.field.intensity.low': 'Conservative',
        'enhancer.field.intensity.high':'Major Rewrite',
        'enhancer.diff.added':          'Added',
        'enhancer.diff.removed':        'Removed',
        'enhancer.diff.mode.inline':    'Inline Diff',
        'enhancer.diff.mode.side':      'Side by Side',
        'enhancer.history.title':       'Version History',
        'enhancer.history.empty':       'No history yet',
        'enhancer.history.original':    'Original',
        'enhancer.history.version':     'Version {{index}} ({{mode}})',
        'enhancer.enhancing':           'Enhancing {{field}}...',
        'enhancer.done':                '{{field}} enhanced',
        'enhancer.all.done':            'All fields enhanced',

        // ── Exporter ───────────────────────────────────────────
        'exporter.title':               'Card Exporter',
        'exporter.btn.json_v2':         '📄 Export JSON (CCv2)',
        'exporter.btn.json_v3':         '📄 Export JSON (CCv3)',
        'exporter.btn.png_v2':          '🖼️ Export PNG (CCv2)',
        'exporter.btn.png_v3':          '🖼️ Export PNG (CCv3)',
        'exporter.btn.batch':           '📦 Batch Export',
        'exporter.btn.import':          '📥 Import Card',
        'exporter.btn.upload_cover':    '🖼️ Upload Cover',
        'exporter.btn.ai_cover':        '🤖 AI Generate Cover',
        'exporter.field.format':        'Format',
        'exporter.field.cover':         'Cover Image',
        'exporter.field.include_wb':    'Include World Book',
        'exporter.preflight.ok':        '✅ Pre-flight check passed',
        'exporter.preflight.errors':    '{{count}} issue(s) found, please fix before export',
        'exporter.preflight.warnings':  '{{count}} warning(s)',
        'exporter.exporting':           'Exporting...',
        'exporter.done':                '✅ Exported: {{filename}}',
        'exporter.error':               '❌ Export failed',
        'exporter.import.done':         '✅ Imported ({{version}} format)',
        'exporter.import.error':        '❌ Import failed. Check file format.',
        'exporter.cover.size':          'Cover will be resized to 400×600',
        'exporter.cover.none':          'No cover selected (default image will be used)',

        // ── Wizard ─────────────────────────────────────────────
        'wizard.title':                 'Creation Wizard',
        'wizard.step.basic':            'Basic Info',
        'wizard.step.appearance':       'Appearance',
        'wizard.step.personality':      'Personality',
        'wizard.step.background':       'Background',
        'wizard.step.relations':        'Relationships',
        'wizard.step.dialogue':         'Example Dialogue',
        'wizard.progress':              'Step {{current}}/{{total}}',
        'wizard.ai_help':               '🤖 AI Suggest',
        'wizard.validate.required':     'This field is required',

        // ── Token Status ───────────────────────────────────────
        'token.status.ok':              '✅ Token usage normal',
        'token.status.warning':         '⚠️ Token usage high',
        'token.status.over':            '❌ Token limit exceeded',
        'token.field.warning':          '⚠️ {{field}} over warn limit ({{count}} / {{limit}})',
        'token.field.over':             '❌ {{field}} over hard limit ({{count}} / {{limit}})',

        // ── Error Messages ─────────────────────────────────────
        'error.ai.failed':              'AI generation failed. Check API settings.',
        'error.ai.timeout':             'AI generation timed out. Please retry.',
        'error.network':                'Network error. Check your connection.',
        'error.storage.full':           'Local storage full. Clear some drafts.',
        'error.file.invalid':           'Invalid file format',
        'error.png.invalid':            'Not a valid character card PNG',
        'error.unknown':                'Unknown error. Please refresh the page.',

        // ── Settings ───────────────────────────────────────────
        'settings.title':               'CardForge Settings',
        'settings.language':            'Interface Language',
        'settings.ai_model':            'AI Model Preference',
        'settings.ai_model.current':    'Use current selected model',
        'settings.export_format':       'Default Export Format',
        'settings.auto_save':           'Auto-save Drafts',
        'settings.auto_save.interval':  'Auto-save Interval (sec)',
        'settings.token_warn':          'Token Warning Threshold',
        'settings.animations':          'Enable Animations',
        'settings.debug':               'Debug Mode',
        'settings.cache':               'Enable AI Cache',
        'settings.reset':               'Reset All Settings',
        'settings.reset.confirm':       'Reset all settings to defaults?',
        'settings.saved':               'Settings saved',

        // ── Tour Guide ─────────────────────────────────────────
        'tour.welcome.title':           'Welcome to ST-CardForge Pro!',
        'tour.welcome.content':         'Let me show you the main features of this extension',
        'tour.module_nav.title':        'Module Navigation',
        'tour.module_nav.content':      'Click the left tabs to switch between modules',
        'tour.card_gen.title':          'Card Generator',
        'tour.card_gen.content':        'Enter a one-line description and AI fills all card fields',
        'tour.preview.title':           'Live Preview',
        'tour.preview.content':         'The right panel shows card content and token usage in real time',
        'tour.export.title':            'Export Card',
        'tour.export.content':          'Supports CCv2/CCv3 JSON and PNG export formats',
        'tour.skip':                    'Skip Tour',
        'tour.done':                    'Get Started',
    },
};


// ═══════════════════════════════════════════════════════════════════
// § 3  I18n 类
// ═══════════════════════════════════════════════════════════════════

export class I18n {

    /**
     * @param {string} [defaultLocale='zh-CN']  初始语言
     */
    constructor(defaultLocale = DEFAULT_LOCALE) {
        /**
         * 当前语言
         * @private
         * @type {string}
         */
        this._locale = defaultLocale;

        /**
         * 翻译字典（支持动态扩展）
         * @private
         * @type {Object.<string, Object.<string, string>>}
         */
        this._messages = JSON.parse(JSON.stringify(MESSAGES));

        /**
         * 语言切换回调列表
         * @private
         * @type {Function[]}
         */
        this._onChangeCallbacks = [];
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.1  核心翻译
    // ─────────────────────────────────────────────────────────────

    /**
     * 翻译指定 key
     *
     * @param   {string}  key     翻译键（格式：'模块.分类.描述'）
     * @param   {Object}  [vars]  插值变量（替换模板中的 {{变量名}}）
     * @returns {string}          翻译结果，找不到时返回 key 本身
     *
     * @example
     * i18n.t('common.save');                              // → '保存'
     * i18n.t('panel.token.count', { used: 1234, limit: 4096 });
     *                                                     // → '1,234 / 4,096'
     * i18n.t('card.generate.field.done', { field: '角色描述' });
     *                                                     // → '角色描述 已生成'
     */
    t(key, vars = null) {
        // 当前语言查找
        let template = this._messages[this._locale]?.[key];

        // 回退到 FALLBACK_LOCALE
        if (template === undefined) {
            template = this._messages[FALLBACK_LOCALE]?.[key];
        }

        // 找不到翻译：返回 key 本身（方便调试）
        if (template === undefined) {
            console.warn(`[CardForge] i18n：找不到翻译 key "${key}"（locale: ${this._locale}）`);
            return key;
        }

        // 无插值变量，直接返回
        if (!vars || typeof vars !== 'object') {
            return template;
        }

        // 执行插值替换
        return this._interpolate(template, vars);
    }

    /**
     * 翻译并转义 HTML（用于将翻译结果插入 innerHTML 时防 XSS）
     *
     * @param   {string}  key
     * @param   {Object}  [vars]
     * @returns {string}  HTML 转义后的翻译结果
     */
    tHtml(key, vars = null) {
        return _escapeHtml(this.t(key, vars));
    }

    /**
     * 检查指定 key 是否有翻译（当前语言或回退语言）
     *
     * @param   {string}  key
     * @returns {boolean}
     */
    has(key) {
        return (
            this._messages[this._locale]?.[key] !== undefined ||
            this._messages[FALLBACK_LOCALE]?.[key] !== undefined
        );
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.2  语言管理
    // ─────────────────────────────────────────────────────────────

    /**
     * 切换当前语言
     *
     * @param   {string}  locale  语言代码（'zh-CN' | 'en-US'）
     * @returns {void}
     * @throws  {Error}   语言代码不在 LOCALES 枚举中时抛出
     *
     * @example
     * i18n.setLocale('en-US');
     */
    setLocale(locale) {
        if (!Object.values(LOCALES).includes(locale) &&
            !this._messages[locale]) {
            throw new Error(
                `[CardForge] i18n：不支持的语言 "${locale}"。` +
                `支持的语言：${Object.values(LOCALES).join(', ')}`
            );
        }

        const prev  = this._locale;
        this._locale = locale;

        if (prev !== locale) {
            // 更新 HTML lang 属性
            if (typeof document !== 'undefined') {
                document.documentElement.lang = locale;
            }

            // 触发语言切换回调
            for (const cb of this._onChangeCallbacks) {
                try { cb(locale, prev); } catch (e) {
                    console.error('[CardForge] i18n onChange 回调出错：', e);
                }
            }

            console.info(`[CardForge] i18n：语言已切换为 ${locale}`);
        }
    }

    /**
     * 获取当前语言代码
     *
     * @returns {string}
     */
    getLocale() {
        return this._locale;
    }

    /**
     * 获取所有已注册的语言列表
     *
     * @returns {string[]}
     */
    getAvailableLocales() {
        return Object.keys(this._messages);
    }

    /**
     * 注册语言切换回调
     *
     * @param   {Function} callback  (newLocale: string, prevLocale: string) => void
     * @returns {Function}           取消注册函数
     *
     * @example
     * const unsub = i18n.onChange((locale) => {
     *     document.querySelectorAll('[data-i18n]').forEach(el => {
     *         el.textContent = i18n.t(el.dataset.i18n);
     *     });
     * });
     */
    onChange(callback) {
        this._onChangeCallbacks.push(callback);
        return () => {
            const idx = this._onChangeCallbacks.indexOf(callback);
            if (idx !== -1) this._onChangeCallbacks.splice(idx, 1);
        };
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.3  动态扩展
    // ─────────────────────────────────────────────────────────────

    /**
     * 动态注册翻译条目
     * 用于模块按需加载时注入自己的翻译
     *
     * @param   {string}  locale    语言代码
     * @param   {Object}  messages  翻译条目对象 { key: value }
     * @param   {boolean} [override=false]  是否覆盖已有翻译
     * @returns {void}
     *
     * @example
     * i18n.addMessages('zh-CN', {
     *     'mymodule.btn.action': '执行动作',
     * });
     */
    addMessages(locale, messages, override = false) {
        if (!this._messages[locale]) {
            this._messages[locale] = {};
        }

        for (const [key, value] of Object.entries(messages)) {
            if (override || this._messages[locale][key] === undefined) {
                this._messages[locale][key] = value;
            }
        }
    }

    /**
     * 批量翻译一组 key（返回 { key: translatedValue } 映射）
     *
     * @param   {string[]} keys
     * @param   {Object}   [vars]  所有 key 共用的插值变量
     * @returns {Object.<string, string>}
     *
     * @example
     * const labels = i18n.tAll(['common.save', 'common.cancel']);
     * // → { 'common.save': '保存', 'common.cancel': '取消' }
     */
    tAll(keys, vars = null) {
        return Object.fromEntries(
            keys.map(key => [key, this.t(key, vars)])
        );
    }

    /**
     * 将页面上所有带 data-i18n 属性的元素的文本内容替换为翻译结果
     * 用于页面初始化和语言切换后的批量 DOM 更新
     *
     * @param   {HTMLElement} [root=document.body]  搜索范围
     * @returns {number}  更新的元素数量
     *
     * @example
     * // HTML: <button data-i18n="common.save"></button>
     * i18n.applyToDOM();
     * // → <button>保存</button>
     */
    applyToDOM(root = null) {
        if (typeof document === 'undefined') return 0;

        const container = root ?? document.body;
        const elements  = container.querySelectorAll('[data-i18n]');
        let   count     = 0;

        for (const el of elements) {
            const key  = el.dataset.i18n;
            const vars = el.dataset.i18nVars
                ? JSON.parse(el.dataset.i18nVars)
                : null;

            if (!key) continue;

            const translated = this.t(key, vars);

            // 根据元素类型决定如何设置翻译内容
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                if (el.getAttribute('placeholder') !== null) {
                    el.placeholder = translated;
                } else {
                    el.value = translated;
                }
            } else if (el.dataset.i18nAttr) {
                // data-i18n-attr 指定要设置的属性名
                el.setAttribute(el.dataset.i18nAttr, translated);
            } else {
                el.textContent = translated;
            }

            count++;
        }

        return count;
    }


    // ─────────────────────────────────────────────────────────────
    // § 3.4  私有方法
    // ─────────────────────────────────────────────────────────────

    /**
     * 执行插值替换
     * 将模板中的 {{变量名}} 替换为 vars 对象中对应的值
     * @private
     *
     * @param   {string} template  翻译模板字符串
     * @param   {Object} vars      插值变量
     * @returns {string}
     */
    _interpolate(template, vars) {
        return template.replace(
            /\{\{(\w+)\}\}/g,
            (match, varName) => {
                const value = vars[varName];
                if (value === undefined) {
                    console.warn(`[CardForge] i18n：插值变量 "{{${varName}}}" 未提供`);
                    return match; // 保留原始占位符
                }
                // 数字格式化（添加千位分隔符）
                if (typeof value === 'number') {
                    return value.toLocaleString('en-US');
                }
                return String(value);
            }
        );
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 4  工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * HTML 转义（防止 XSS）
 * @private
 *
 * @param   {string} str
 * @returns {string}
 */
function _escapeHtml(str) {
    return String(str)
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;');
}


// ═══════════════════════════════════════════════════════════════════
// § 5  模块级单例
// ═══════════════════════════════════════════════════════════════════

/**
 * 全局 I18n 单例
 *
 * @type {I18n}
 *
 * @example
 * import { i18n } from '../../core/i18n.js';
 *
 * // 翻译
 * const label = i18n.t('card.btn.generate_all');   // → '✨ 一键生成'
 *
 * // 带插值
 * const msg = i18n.t('wb.generate.done', { count: 12 }); // → '世界书已生成，共 12 条条目'
 *
 * // 切换语言
 * i18n.setLocale('en-US');
 */
export const i18n = new I18n(DEFAULT_LOCALE);