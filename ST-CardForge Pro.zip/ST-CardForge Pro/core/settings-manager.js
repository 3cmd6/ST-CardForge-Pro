/**
 * @file core/settings-manager.js
 * @description 全局设置管理器
 *              负责读写 SillyTavern extensionSettings，并提供 Profile 管理
 * @version 1.0.0
 */

import { EVENTS } from '../contracts.js';

// SillyTavern 全局对象（通过 window 访问，避免循环依赖）
const _getSTGlobals = () => ({
    extensionSettings:     window.extension_settings ?? {},
    saveSettingsDebounced: window.saveSettingsDebounced ?? (() => {}),
    eventSource:           window.eventSource ?? null,
});

// ─────────────────────────────────────────────
// 默认配置（与 contracts.js 第四章 DEFAULT_SETTINGS 保持同步）
// ─────────────────────────────────────────────
export const DEFAULT_SETTINGS = Object.freeze({
    version:        '1.0.0',
    activeProfile:  'default',
    profiles: {
        default: {
            aiModelPreference:      'current',
            defaultExportFormat:    'ccv3_png',
            defaultLanguage:        'zh-CN',
            tokenWarningThreshold:  2000,
            tokenLimitHard:         4096,
            autoSaveDraft:          true,
            autoSaveInterval:       30000,
            theme:                  'auto',
            enableAnimations:       true,
            enableTourGuide:        true,
        }
    }
});

// 已知版本迁移函数（key: 旧版本号）
const MIGRATIONS = {
    // 示例：'0.9.0': (data) => { data.newField = 'default'; return data; }
};

// ─────────────────────────────────────────────
// SettingsManager 类
// ─────────────────────────────────────────────
export class SettingsManager {
    /**
     * @param {string} extensionKey  extensionSettings 的命名空间 key
     * @param {import('./event-bus.js').EventBus} bus
     */
    constructor(extensionKey = 'cardForgePro', bus = null) {
        this._key  = extensionKey;
        this._bus  = bus;
        this._data = null;          // 运行时设置缓存
    }

    // ── 初始化 ─────────────────────────────────
    /**
     * 从 extensionSettings 加载设置，执行版本迁移
     */
    load() {
        const { extensionSettings } = _getSTGlobals();

        if (!extensionSettings[this._key]) {
            // 首次安装：写入默认设置
            extensionSettings[this._key] = _deepClone(DEFAULT_SETTINGS);
        }

        this._data = extensionSettings[this._key];
        this._migrateSettings(this._data.version);
        this._validateSettings(this._data);
    }

    // ═══════════════════════════════════════════
    // CRUD（操作当前激活 Profile）
    // ═══════════════════════════════════════════

    /**
     * 读取当前 profile 中的设置值
     * @param {string} key
     * @param {*} defaultValue
     * @returns {*}
     */
    get(key, defaultValue = undefined) {
        this._ensureLoaded();
        const profile = this._currentProfile();
        return key in profile ? profile[key] : defaultValue;
    }

    /**
     * 写入当前 profile 中的设置值
     * @param {string} key
     * @param {*} value
     */
    set(key, value) {
        this._ensureLoaded();
        this._currentProfile()[key] = value;
        this.save();
        this._bus?.emit(EVENTS.SETTINGS_CHANGED, { key, value });
    }

    /**
     * 获取完整设置对象（只读副本）
     * @returns {object}
     */
    getAll() {
        this._ensureLoaded();
        return _deepClone(this._data);
    }

    /**
     * 重置当前 profile 到默认值
     */
    reset() {
        this._ensureLoaded();
        const profileName = this._data.activeProfile;
        this._data.profiles[profileName] = _deepClone(
            DEFAULT_SETTINGS.profiles.default
        );
        this.save();
        this._bus?.emit(EVENTS.SETTINGS_CHANGED, { reset: true });
    }

    /**
     * 重置单个 key 到默认值
     * @param {string} key
     */
    resetKey(key) {
        const defaultProfile = DEFAULT_SETTINGS.profiles.default;
        if (key in defaultProfile) {
            this.set(key, defaultProfile[key]);
        }
    }

    // ═══════════════════════════════════════════
    // Profile 管理
    // ═══════════════════════════════════════════

    /**
     * 创建新 Profile（基于 default 克隆）
     * @param {string} name
     */
    createProfile(name) {
        this._ensureLoaded();
        if (name in this._data.profiles) {
            throw new Error(`[SettingsManager] Profile "${name}" 已存在`);
        }
        this._data.profiles[name] = _deepClone(DEFAULT_SETTINGS.profiles.default);
        this.save();
    }

    /**
     * 切换激活 Profile
     * @param {string} name
     */
    switchProfile(name) {
        this._ensureLoaded();
        if (!(name in this._data.profiles)) {
            throw new Error(`[SettingsManager] Profile "${name}" 不存在`);
        }
        this._data.activeProfile = name;
        this.save();
        this._bus?.emit(EVENTS.SETTINGS_CHANGED, { profileSwitch: name });
    }

    /**
     * 删除 Profile（不能删除 default）
     * @param {string} name
     */
    deleteProfile(name) {
        this._ensureLoaded();
        if (name === 'default') throw new Error('[SettingsManager] 不能删除 default Profile');
        delete this._data.profiles[name];
        if (this._data.activeProfile === name) {
            this._data.activeProfile = 'default';
        }
        this.save();
    }

    /**
     * 列出所有 Profile 名称
     * @returns {string[]}
     */
    listProfiles() {
        this._ensureLoaded();
        return Object.keys(this._data.profiles);
    }

    /**
     * 导出 Profile 为 JSON 字符串
     * @param {string} name
     * @returns {string}
     */
    exportProfile(name) {
        this._ensureLoaded();
        const profile = this._data.profiles[name];
        if (!profile) throw new Error(`[SettingsManager] Profile "${name}" 不存在`);
        return JSON.stringify({ name, data: _deepClone(profile) }, null, 2);
    }

    /**
     * 从 JSON 字符串导入 Profile
     * @param {string} jsonStr
     */
    importProfile(jsonStr) {
        this._ensureLoaded();
        let parsed;
        try { parsed = JSON.parse(jsonStr); }
        catch { throw new Error('[SettingsManager] 无效的 JSON 格式'); }

        const { name, data } = parsed;
        if (!name || !data) throw new Error('[SettingsManager] Profile 格式错误');
        this._data.profiles[name] = data;
        this.save();
    }

    // ═══════════════════════════════════════════
    // 持久化
    // ═══════════════════════════════════════════

    /**
     * 将当前内存数据同步到 extensionSettings 并触发 ST 保存
     */
    save() {
        const { extensionSettings, saveSettingsDebounced } = _getSTGlobals();
        extensionSettings[this._key] = this._data;
        saveSettingsDebounced();
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 返回当前激活 Profile 的引用（可写）
     * @returns {object}
     */
    _currentProfile() {
        const name = this._data.activeProfile ?? 'default';
        if (!(name in this._data.profiles)) {
            this._data.profiles[name] = _deepClone(DEFAULT_SETTINGS.profiles.default);
        }
        return this._data.profiles[name];
    }

    /**
     * 版本迁移：按顺序应用所有高于当前版本的迁移函数
     * @param {string} currentVersion
     */
    _migrateSettings(currentVersion) {
        const migrationVersions = Object.keys(MIGRATIONS).sort(_semverCompare);
        let didMigrate = false;
        for (const v of migrationVersions) {
            if (_semverCompare(v, currentVersion) > 0) {
                try {
                    MIGRATIONS[v](this._data);
                    didMigrate = true;
                    console.info(`[SettingsManager] 已迁移设置 → v${v}`);
                } catch (e) {
                    console.error(`[SettingsManager] 迁移 v${v} 失败`, e);
                }
            }
        }
        if (didMigrate) {
            this._data.version = DEFAULT_SETTINGS.version;
            this.save();
        }
    }

    /**
     * 设置 Schema 校验（补全缺失字段）
     * @param {object} data
     */
    _validateSettings(data) {
        // 确保根级字段存在
        if (!data.activeProfile) data.activeProfile = 'default';
        if (!data.profiles) data.profiles = {};
        if (!data.profiles.default) {
            data.profiles.default = _deepClone(DEFAULT_SETTINGS.profiles.default);
        }

        // 补全 default profile 中缺失的 key
        const defaultProfile = DEFAULT_SETTINGS.profiles.default;
        const currentProfile = data.profiles[data.activeProfile] ?? data.profiles.default;
        for (const [key, val] of Object.entries(defaultProfile)) {
            if (!(key in currentProfile)) {
                currentProfile[key] = val;
            }
        }
    }

    _ensureLoaded() {
        if (!this._data) this.load();
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/** 深拷贝（纯 JSON 对象，无 Date/RegExp/Function） */
function _deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

/**
 * 简单语义版本比较
 * @returns {-1|0|1}
 */
function _semverCompare(a, b) {
    const pa = a.split('.').map(Number);
    const pb = b.split('.').map(Number);
    for (let i = 0; i < 3; i++) {
        const diff = (pa[i] || 0) - (pb[i] || 0);
        if (diff !== 0) return diff > 0 ? 1 : -1;
    }
    return 0;
}