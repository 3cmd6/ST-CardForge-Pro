/**
 * @file core/undo-manager.js
 * @description 撤销/重做管理器
 *              基于快照栈实现通用 undo/redo，支持历史记录描述、变更监听
 *              所有需要撤销支持的模块均应注入此实例
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 常量
// ─────────────────────────────────────────────
const DEFAULT_MAX_HISTORY = 50;

// ─────────────────────────────────────────────
// UndoManager 类
// ─────────────────────────────────────────────
export class UndoManager {
    /**
     * @param {number} [maxHistorySize=50]  历史记录上限
     */
    constructor(maxHistorySize = DEFAULT_MAX_HISTORY) {
        /** @type {HistoryEntry[]}  撤销栈（index 0 = 最旧） */
        this._undoStack   = [];
        /** @type {HistoryEntry[]}  重做栈 */
        this._redoStack   = [];
        /** @type {number} */
        this._maxSize     = Math.max(1, maxHistorySize);
        /** @type {Set<Function>}  变更监听器 */
        this._listeners   = new Set();
        /** @type {boolean}  批量操作锁（批量期间暂停快照） */
        this._batchLock   = false;
        /** @type {HistoryEntry[]}  批量操作暂存区 */
        this._batchBuffer = [];
    }

    // ═══════════════════════════════════════════
    // 核心操作
    // ═══════════════════════════════════════════

    /**
     * 推入一个快照
     * 推入后清空重做栈（新操作使重做历史失效）
     *
     * @param {*}      snapshot     当前状态快照（任意可序列化对象）
     * @param {string} [description='']  操作描述，显示在历史记录列表中
     * @returns {void}
     */
    push(snapshot, description = '') {
        // 批量模式：暂存到 buffer
        if (this._batchLock) {
            this._batchBuffer.push(_buildEntry(snapshot, description));
            return;
        }

        this._pushEntry(_buildEntry(snapshot, description));
    }

    /**
     * 撤销：回退到上一个快照
     * @returns {*|null}  上一个快照数据，若无可撤销内容返回 null
     */
    undo() {
        if (!this.canUndo()) return null;

        const entry = this._undoStack.pop();
        this._redoStack.push(entry);

        // 限制重做栈大小
        if (this._redoStack.length > this._maxSize) {
            this._redoStack.shift();
        }

        this._notifyChange('undo', entry);
        return entry.snapshot;
    }

    /**
     * 重做：前进到下一个快照
     * @returns {*|null}  下一个快照数据，若无可重做内容返回 null
     */
    redo() {
        if (!this.canRedo()) return null;

        const entry = this._redoStack.pop();
        this._undoStack.push(entry);

        this._notifyChange('redo', entry);
        return entry.snapshot;
    }

    // ═══════════════════════════════════════════
    // 状态查询
    // ═══════════════════════════════════════════

    /** @returns {boolean} */
    canUndo() { return this._undoStack.length > 0; }

    /** @returns {boolean} */
    canRedo() { return this._redoStack.length > 0; }

    /**
     * 获取当前撤销栈深度
     * @returns {number}
     */
    undoDepth() { return this._undoStack.length; }

    /**
     * 获取当前重做栈深度
     * @returns {number}
     */
    redoDepth() { return this._redoStack.length; }

    /**
     * 获取完整历史记录列表（最新在前）
     * @returns {HistoryMeta[]}  不含完整 snapshot，仅含摘要
     */
    getHistory() {
        return [...this._undoStack]
            .reverse()
            .map((entry, idx) => ({
                index:       idx,
                description: entry.description,
                timestamp:   entry.timestamp,
                timestampStr: _formatTime(entry.timestamp),
                isCurrent:   idx === 0,
            }));
    }

    /**
     * 获取最近一次操作的描述
     * @returns {string}
     */
    getLastDescription() {
        return this._undoStack[this._undoStack.length - 1]?.description ?? '';
    }

    /**
     * 获取下一个可重做操作的描述
     * @returns {string}
     */
    getNextRedoDescription() {
        return this._redoStack[this._redoStack.length - 1]?.description ?? '';
    }

    // ═══════════════════════════════════════════
    // 批量操作
    // ═══════════════════════════════════════════

    /**
     * 开始批量操作
     * 批量操作期间所有 push() 调用都会被合并为单次撤销步骤
     * @param {string} [description]  批量操作的整体描述
     */
    beginBatch(description = '批量操作') {
        this._batchLock   = true;
        this._batchDesc   = description;
        this._batchBuffer = [];
    }

    /**
     * 提交批量操作（将 buffer 中的最后一个快照作为整体快照入栈）
     * 使用最后一个 buffer 条目的 snapshot 作为代表性快照
     */
    commitBatch() {
        if (!this._batchLock) return;
        this._batchLock = false;

        if (this._batchBuffer.length === 0) {
            this._batchBuffer = [];
            return;
        }

        // 使用最后一个快照作为批量操作的代表
        const lastEntry = this._batchBuffer[this._batchBuffer.length - 1];
        this._pushEntry(_buildEntry(lastEntry.snapshot, this._batchDesc));
        this._batchBuffer = [];
    }

    /**
     * 取消批量操作（丢弃所有暂存快照）
     */
    cancelBatch() {
        this._batchLock   = false;
        this._batchBuffer = [];
    }

    // ═══════════════════════════════════════════
    // 监听器
    // ═══════════════════════════════════════════

    /**
     * 注册变更监听器
     * 每次 push/undo/redo/clear 时触发
     * @param {Function} callback  (event: { type, entry, canUndo, canRedo }) => void
     * @returns {Function}  取消监听的函数
     */
    onChange(callback) {
        this._listeners.add(callback);
        return () => this._listeners.delete(callback);
    }

    /**
     * 移除变更监听器
     * @param {Function} callback
     */
    offChange(callback) {
        this._listeners.delete(callback);
    }

    // ═══════════════════════════════════════════
    // 清除
    // ═══════════════════════════════════════════

    /**
     * 清空所有历史记录（撤销栈 + 重做栈）
     */
    clear() {
        this._undoStack   = [];
        this._redoStack   = [];
        this._batchBuffer = [];
        this._batchLock   = false;
        this._notifyChange('clear', null);
    }

    /**
     * 仅清空重做栈（新操作时调用）
     */
    clearRedo() {
        this._redoStack = [];
        this._notifyChange('clearRedo', null);
    }

    // ═══════════════════════════════════════════
    // 快照访问（不触发 undo/redo）
    // ═══════════════════════════════════════════

    /**
     * 查看撤销栈顶快照（不弹出）
     * @returns {*|null}
     */
    peekUndo() {
        const entry = this._undoStack[this._undoStack.length - 1];
        return entry?.snapshot ?? null;
    }

    /**
     * 查看重做栈顶快照（不弹出）
     * @returns {*|null}
     */
    peekRedo() {
        const entry = this._redoStack[this._redoStack.length - 1];
        return entry?.snapshot ?? null;
    }

    /**
     * 跳转到历史记录中的指定位置
     * 会执行多次 undo（向后）或 redo（向前）
     * @param {number} targetIndex  getHistory() 返回列表中的 index（0 = 最新）
     * @returns {*|null}  目标快照
     */
    jumpTo(targetIndex) {
        const history = this.getHistory();
        if (targetIndex < 0 || targetIndex >= history.length) return null;

        // targetIndex 0 = 当前（不需要操作）
        // targetIndex 1 = 撤销 1 次，以此类推
        let result = null;
        for (let i = 0; i < targetIndex; i++) {
            result = this.undo();
        }
        return result;
    }

    // ═══════════════════════════════════════════
    // 序列化（用于持久化到 IndexedDB）
    // ═══════════════════════════════════════════

    /**
     * 导出当前状态为可序列化对象
     * @param {boolean} [includeSnapshots=true]  是否包含完整快照数据
     * @returns {object}
     */
    export(includeSnapshots = true) {
        return {
            maxSize:   this._maxSize,
            undoStack: includeSnapshots
                ? this._undoStack.map(e => ({ ...e }))
                : this._undoStack.map(e => ({ ...e, snapshot: null })),
            redoStack: includeSnapshots
                ? this._redoStack.map(e => ({ ...e }))
                : [],
        };
    }

    /**
     * 从序列化对象恢复状态
     * @param {object} data
     */
    import(data) {
        if (!data || typeof data !== 'object') return;
        this._maxSize   = data.maxSize   ?? DEFAULT_MAX_HISTORY;
        this._undoStack = data.undoStack ?? [];
        this._redoStack = data.redoStack ?? [];
        this._notifyChange('import', null);
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 将条目压入撤销栈并清空重做栈
     * @param {HistoryEntry} entry
     */
    _pushEntry(entry) {
        this._undoStack.push(entry);

        // 超出上限：移除最旧的条目
        if (this._undoStack.length > this._maxSize) {
            this._undoStack.shift();
        }

        // 新操作使重做历史失效
        this._redoStack = [];

        this._notifyChange('push', entry);
    }

    /**
     * 触发所有变更监听器
     * @param {string}       type    'push'|'undo'|'redo'|'clear'|'clearRedo'|'import'
     * @param {HistoryEntry|null} entry
     */
    _notifyChange(type, entry) {
        const event = {
            type,
            entry,
            canUndo:          this.canUndo(),
            canRedo:          this.canRedo(),
            undoDepth:        this._undoStack.length,
            redoDepth:        this._redoStack.length,
            lastDescription:  this.getLastDescription(),
            nextRedoDesc:     this.getNextRedoDescription(),
        };
        for (const cb of this._listeners) {
            try { cb(event); }
            catch (err) { console.error('[UndoManager] 监听器执行出错', err); }
        }
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 构建历史条目对象
 * @param {*}      snapshot
 * @param {string} description
 * @returns {HistoryEntry}
 */
function _buildEntry(snapshot, description) {
    return {
        snapshot,
        description: description || '未命名操作',
        timestamp:   Date.now(),
        id:          `undo_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    };
}

/**
 * 格式化时间戳为可读字符串
 * @param {number} ts
 * @returns {string}  如 "14:32:05"
 */
function _formatTime(ts) {
    const d = new Date(ts);
    return [d.getHours(), d.getMinutes(), d.getSeconds()]
        .map(n => String(n).padStart(2, '0'))
        .join(':');
}

// ─────────────────────────────────────────────
// 单例工厂（每个模块应创建自己的实例，此处仅供顶层使用）
// ─────────────────────────────────────────────

/**
 * 创建一个新的 UndoManager 实例
 * @param {number} [maxHistorySize]
 * @returns {UndoManager}
 */
export function createUndoManager(maxHistorySize) {
    return new UndoManager(maxHistorySize);
}