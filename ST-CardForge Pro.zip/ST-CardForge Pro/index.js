/**
 * @file index.js
 * @description ST-CardForge Pro 主入口（完整修复版）
 * @version 1.0.0-fixed
 */

// ═══════════════════════════════════════════════
// § 1  全局状态管理
// ═══════════════════════════════════════════════

/** ST Context 引用 */
let _stContext = null;

/** 扩展是否已完整初始化 */
let _initialized = false;

/** 所有已初始化的模块实例 */
const _modules = {
    // 核心层
    eventBus:         null,
    aiEngine:         null,
    settings:         null,
    cache:            null,
    i18n:             null,
    errorHandler:     null,

    // 功能模块
    cardGenerator:    null,
    wbGenerator:      null,
    greetingGen:      null,
    scriptForge:      null,
    rpgTracker:       null,
    branchEngine:     null,
    regexForge:       null,
    fieldEnhancer:    null,
    exporter:         null,

    // UI层
    mainPanel:        null,
    wizard:           null,
};

/** 模块导入缓存 */
const _importCache = new Map();

// ═══════════════════════════════════════════════
// § 2  ST Context 获取
// ═══════════════════════════════════════════════

async function _getSTContext() {
    if (_stContext) return _stContext;

    if (typeof SillyTavern !== 'undefined' && SillyTavern.getContext) {
        _stContext = SillyTavern.getContext();
        if (_stContext) return _stContext;
    }

    if (typeof getContext !== 'undefined') {
        _stContext = getContext();
        if (_stContext) return _stContext;
    }

    const candidates = [
        window.SillyTavern?.getContext?.(),
        globalThis.SillyTavern?.getContext?.(),
        window.getContext?.(),
        globalThis.getContext?.(),
    ];
    for (const ctx of candidates) {
        if (ctx && (ctx.extensionSettings !== undefined || ctx.saveSettingsDebounced !== undefined)) {
            _stContext = ctx;
            return _stContext;
        }
    }

    await new Promise(r => setTimeout(r, 500));
    if (!_getSTContext._retryCount) _getSTContext._retryCount = 0;
    if (_getSTContext._retryCount++ < 10) return _getSTContext();

    console.error('[CardForge] ❌ 无法获取 ST Context');
    return null;
}

// ═══════════════════════════════════════════════
// § 3  安全导入 + 缓存
// ═══════════════════════════════════════════════

async function _safeImport(path, label) {
    if (_importCache.has(path)) return _importCache.get(path);

    try {
        const mod = await import(path);
        _importCache.set(path, mod);
        console.debug(`[CardForge] ✅ 已加载：${label}`);
        return mod;
    } catch (err) {
        const isMissing =
            err?.message?.includes('Failed to fetch') ||
            err?.message?.includes('Cannot find') ||
            err?.message?.includes('404') ||
            err?.code === 'MODULE_NOT_FOUND';

        if (isMissing) {
            console.debug(`[CardForge] ⏳ 模块尚未生成，已跳过：${label}`);
        } else {
            console.error(`[CardForge] ❌ 模块加载出错：${label}`, err);
        }

        _importCache.set(path, null);
        return null;
    }
}

function _getCachedModule(shortName) {
    const paths = [
        `./utils/${shortName}.js`,
        `./core/${shortName}.js`,
        `./modules/${shortName}.js`,
    ];
    for (const p of paths) {
        const mod = _importCache.get(p);
        if (mod) return mod;
    }
    return null;
}

// ═══════════════════════════════════════════════
// § 4  CSS 变量注入
// ═══════════════════════════════════════════════

function _registerCSSVars() {
    const CSS_VARS = {
        '--cf-primary':         '#7b68ee',
        '--cf-primary-dark':    '#5a4fcf',
        '--cf-success':         '#2ecc71',
        '--cf-warning':         '#f39c12',
        '--cf-danger':          '#e74c3c',
        '--cf-info':            '#3498db',
        '--cf-bg-panel':        'var(--black-tint-bg, #1a1a2e)',
        '--cf-bg-card':         'var(--black-tint-1, #16213e)',
        '--cf-border':          'var(--border-color, #444)',
        '--cf-text':            'var(--text-color, #eee)',
        '--cf-text-muted':      'var(--text-color-muted, #aaa)',
        '--cf-radius':          '8px',
        '--cf-shadow':          '0 4px 16px rgba(0,0,0,0.3)',
        '--cf-transition':      '0.2s ease',
    };
    try {
        const root = document.documentElement;
        for (const [k, v] of Object.entries(CSS_VARS)) {
            root.style.setProperty(k, v);
        }
        console.debug('[CardForge] ✅ CSS 变量已注入');
    } catch (e) {
        console.warn('[CardForge] CSS 变量注入失败：', e);
    }
}

// ═══════════════════════════════════════════════
// § 5  降级实现
// ═══════════════════════════════════════════════

function _createFallbackEventBus() {
    const listeners = new Map();
    return {
        on: (event, cb) => {
            if (!listeners.has(event)) listeners.set(event, new Set());
            listeners.get(event).add(cb);
            return () => listeners.get(event)?.delete(cb);
        },
        off: (event, cb) => {
            listeners.get(event)?.delete(cb);
        },
        emit: (event, data) => {
            listeners.get(event)?.forEach(cb => {
                try { cb(data); } catch (e) { console.error('[EventBus] cb error', e); }
            });
        },
        once: (event, cb) => {
            const wrap = (data) => {
                listeners.get(event)?.delete(wrap);
                cb(data);
            };
            if (!listeners.has(event)) listeners.set(event, new Set());
            listeners.get(event).add(wrap);
        },
        clear: (event) => listeners.delete(event),
        clearAll: () => listeners.clear(),
        getListenerCount: (event) => listeners.get(event)?.size ?? 0,
    };
}

function _createFallbackSettings() {
    const ctx = _stContext;
    const KEY = 'cardForgePro';
    if (ctx?.extensionSettings) {
        ctx.extensionSettings[KEY] = ctx.extensionSettings[KEY] || {};
    }
    return {
        get: (k, def) => ctx?.extensionSettings?.[KEY]?.[k] ?? def,
        set: (k, v) => {
            if (!ctx?.extensionSettings) return;
            ctx.extensionSettings[KEY] = ctx.extensionSettings[KEY] || {};
            ctx.extensionSettings[KEY][k] = v;
            ctx.saveSettingsDebounced?.();
        },
        getAll: () => ctx?.extensionSettings?.[KEY] || {},
        save: () => ctx?.saveSettingsDebounced?.(),
        load: () => {},
        reset: () => {
            if (!ctx?.extensionSettings) return;
            ctx.extensionSettings[KEY] = {};
            ctx.saveSettingsDebounced?.();
        },
    };
}

// ═══════════════════════════════════════════════
// § 6  核心层初始化
// ═══════════════════════════════════════════════

async function _initCoreModules() {
    console.log('[CardForge] 正在初始化核心层...');

    // EventBus
    const busMod = await _safeImport('./core/event-bus.js', 'EventBus');
    _modules.eventBus = busMod?.EventBus ? new busMod.EventBus() : _createFallbackEventBus();

    // ErrorHandler
    const errMod = await _safeImport('./core/error-handler.js', 'ErrorHandler');
    if (errMod?.ErrorHandler) {
        _modules.errorHandler = new errMod.ErrorHandler(_modules.eventBus);
        _modules.errorHandler.register();
    }

    // CacheManager
    const cacheMod = await _safeImport('./core/cache-manager.js', 'CacheManager');
    if (cacheMod?.CacheManager) {
        _modules.cache = new cacheMod.CacheManager('cardforge', 300000);
        try { await _modules.cache.init(); } catch (e) {
            console.warn('[CardForge] CacheManager 初始化失败：', e);
        }
    }

    // SettingsManager
    const settingsMod = await _safeImport('./core/settings-manager.js', 'SettingsManager');
    if (settingsMod?.SettingsManager) {
        _modules.settings = new settingsMod.SettingsManager('cardForgePro');
        _modules.settings.load();
    } else {
        _modules.settings = _createFallbackSettings();
        console.warn('[CardForge] ⚠️ 使用降级 Settings');
    }

    // AIEngine
    const aiMod = await _safeImport('./core/ai-engine.js', 'AIEngine');
    if (aiMod?.AIEngine) {
        _modules.aiEngine = new aiMod.AIEngine(_modules.eventBus, _modules.settings);
    }

    // I18n
    const i18nMod = await _safeImport('./core/i18n.js', 'I18n');
    if (i18nMod?.I18n) {
        const locale = _modules.settings?.get('defaultLanguage', 'zh-CN') || 'zh-CN';
        _modules.i18n = new i18nMod.I18n(locale);
    }

    // 预加载 utils（供后续 _getCachedModule 使用）
    await _safeImport('./utils/indexeddb-store.js', 'IndexedDBStore');
    await _safeImport('./utils/undo-manager.js', 'UndoManager');

    console.log('[CardForge] ✅ 核心层初始化完成');
}

// ═══════════════════════════════════════════════
// § 7  功能模块懒加载
// ═══════════════════════════════════════════════

async function _initFeatureModules() {
    console.log('[CardForge] 正在加载功能模块...');

    const { eventBus, aiEngine, settings } = _modules;
    if (!eventBus) {
        console.error('[CardForge] EventBus 未就绪，跳过功能模块');
        return;
    }

    const MODULE_REGISTRY = [
        {
            key: 'cardGenerator',
            path: './modules/01_card-generator/card-generator.js',
            name: 'CardGenerator',
            factory: (mod) => {
                const dbMod   = _getCachedModule('indexeddb-store');
                const undoMod = _getCachedModule('undo-manager');
                const dbStore = dbMod?.IndexedDBStore
                    ? new dbMod.IndexedDBStore('CardForgeProDB', 'drafts', 1)
                    : null;
                const undoMgr = undoMod?.UndoManager
                    ? new undoMod.UndoManager(50)
                    : null;
                return new mod.CardGenerator(aiEngine, eventBus, settings, undoMgr, dbStore);
            },
        },
        {
            key: 'wbGenerator',
            path: './modules/02_world-book/worldbook-generator.js',
            name: 'WorldBookGenerator',
            factory: (mod) => new mod.WorldBookGenerator(aiEngine, eventBus, settings),
        },
        {
            key: 'greetingGen',
            path: './modules/03_greeting/greeting-generator.js',
            name: 'GreetingGenerator',
            factory: (mod) => new mod.GreetingGenerator(aiEngine, eventBus, settings),
        },
        {
            key: 'scriptForge',
            path: './modules/04_stscript-forge/script-forge.js',
            name: 'ScriptForge',
            factory: (mod) => new mod.ScriptForge(aiEngine, eventBus, settings),
        },
        {
            key: 'rpgTracker',
            path: './modules/05_rpg-tracker/rpg-tracker.js',
            name: 'RPGTracker',
            factory: (mod) => {
                const dbMod   = _getCachedModule('indexeddb-store');
                const dbStore = dbMod?.IndexedDBStore
                    ? new dbMod.IndexedDBStore('CardForgeProDB', 'rpg_history', 1)
                    : null;
                return new mod.RPGTracker(aiEngine, eventBus, settings, dbStore);
            },
        },
        {
            key: 'branchEngine',
            path: './modules/06_plot-branch/branch-engine.js',
            name: 'BranchEngine',
            factory: (mod) => new mod.BranchEngine(aiEngine, eventBus, settings),
        },
        {
            key: 'regexForge',
            path: './modules/07_regex-forge/regex-forge.js',
            name: 'RegexForge',
            factory: (mod) => {
                const dbMod   = _getCachedModule('indexeddb-store');
                const dbStore = dbMod?.IndexedDBStore
                    ? new dbMod.IndexedDBStore('CardForgeProDB', 'regex_rules', 1)
                    : null;
                return new mod.RegexForge(aiEngine, eventBus, settings, dbStore);
            },
        },
        {
            key: 'fieldEnhancer',
            path: './modules/08_field-enhancer/field-enhancer.js',
            name: 'FieldEnhancer',
            factory: (mod) => {
                const undoMod = _getCachedModule('undo-manager');
                const undoMgr = undoMod?.UndoManager
                    ? new undoMod.UndoManager(30)
                    : null;
                return new mod.FieldEnhancer(aiEngine, eventBus, settings, undoMgr);
            },
        },
        {
            key: 'exporter',
            path: './modules/09_exporter/exporter.js',
            name: 'Exporter',
            factory: (mod) => new mod.Exporter(eventBus, settings),
        },
    ];

    const loaded = [];
    for (const entry of MODULE_REGISTRY) {
        const mod = await _safeImport(entry.path, entry.name);
        if (!mod?.[entry.name]) continue;

        try {
            const instance = entry.factory(mod);
            if (instance.init) await instance.init();
            _modules[entry.key] = instance;

            eventBus.emit?.('cardforge:module:ready', { module: entry.key });
            loaded.push(entry.key);
        } catch (e) {
            console.error(`[CardForge] ❌ 模块初始化失败：${entry.name}`, e);
        }
    }

    console.log('[CardForge] ✅ 功能模块加载完成，已激活：', loaded);
}

// ═══════════════════════════════════════════════
// § 8  UI 初始化 + 入口按钮
// ═══════════════════════════════════════════════

async function _initUI() {
    console.log('[CardForge] 正在初始化 UI...');

    const { eventBus, i18n, settings, cardGenerator } = _modules;

    // 主面板
    const panelMod = await _safeImport('./ui/main-panel.js', 'MainPanel');
    if (panelMod?.MainPanel) {
        try {
            _modules.mainPanel = new panelMod.MainPanel(eventBus, i18n, settings, _modules);
            await _modules.mainPanel.init();
            console.log('[CardForge] ✅ 主面板已初始化');
        } catch (e) {
            console.error('[CardForge] 主面板初始化失败：', e);
        }
    }

    // 向导
    if (cardGenerator) {
        const wizardMod = await _safeImport('./ui/wizard.js', 'Wizard');
        if (wizardMod?.Wizard) {
            try {
                _modules.wizard = new wizardMod.Wizard(cardGenerator, eventBus, i18n);
                console.log('[CardForge] ✅ 向导已初始化');
            } catch (e) {
                console.warn('[CardForge] 向导初始化失败（非致命）：', e);
            }
        }
    }

    // 全局按钮 + 设置面板
    _injectGlobalButton();
    _injectExtensionSettingsPanel();

    console.log('[CardForge] ✅ UI 初始化完成');
}

function _injectGlobalButton() {
    const tryInject = (retry = 0) => {
        const inputContainer =
            document.getElementById('send_form') ||
            document.getElementById('chat-input-container') ||
            document.querySelector('.chat_form_wrapper') ||
            document.querySelector('.chat-input-container') ||
            document.querySelector('#form_sheld');

        if (!inputContainer) {
            if (retry < 20) setTimeout(() => tryInject(retry + 1), 500);
            else console.warn('[CardForge] 未找到聊天输入栏，无法注入按钮');
            return;
        }

        if (document.querySelector('.cardforge-global-btn')) return;

        const btn = document.createElement('button');
        btn.className = 'cardforge-global-btn menu_button';
        btn.innerHTML = `
            <span style="font-size:16px">🃏</span>
            <span style="font-size:11px;margin-left:3px">CardForge</span>
        `;
        btn.style.cssText = `
            padding: 6px 12px;
            background: var(--cf-primary, #7b68ee);
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 13px;
            transition: all 0.2s;
            margin-left: 8px;
        `;
        btn.title = '打开 ST-CardForge Pro 主面板';

        btn.onmouseenter = () => {
            btn.style.background = 'var(--cf-primary-dark, #5a4fcf)';
            btn.style.transform = 'scale(1.05)';
        };
        btn.onmouseleave = () => {
            btn.style.background = 'var(--cf-primary, #7b68ee)';
            btn.style.transform = 'scale(1)';
        };
        btn.onclick = () => {
            if (_modules.mainPanel?.toggle) _modules.mainPanel.toggle();
            else _showFallbackPanel();
        };

        const sendButton =
            inputContainer.querySelector('#send_but') ||
            inputContainer.querySelector('[type="submit"]');

        if (sendButton?.parentElement) {
            sendButton.parentElement.insertBefore(btn, sendButton.nextSibling);
        } else {
            inputContainer.appendChild(btn);
        }

        console.log('[CardForge] ✅ 全局按钮已注入到聊天输入栏');
    };
    tryInject();
}

function _injectExtensionSettingsPanel() {
    const tryInject = (retry = 0) => {
        const container =
            document.getElementById('extensions_settings') ||
            document.querySelector('.extensions_settings');

        if (!container) {
            if (retry < 10) setTimeout(() => tryInject(retry + 1), 1000);
            return;
        }
        if (document.getElementById('cardforge-settings-panel')) return;

        const panel = document.createElement('div');
        panel.id = 'cardforge-settings-panel';
        panel.className = 'extension_settings';
        panel.innerHTML = `
            <div class="extension_settings_block">
                <h3 style="display:flex;align-items:center;gap:8px;color:var(--cf-primary,#7b68ee)">
                    <span style="font-size:24px">🃏</span>
                    ST-CardForge Pro
                    <span style="font-size:10px;padding:2px 6px;background:var(--cf-warning,#f39c12);color:#000;border-radius:4px">
                        v1.0.0
                    </span>
                </h3>
                <div style="margin:12px 0">
                    <div style="margin-bottom:8px;color:var(--cf-text-muted,#aaa);font-size:12px">
                        模块加载状态：
                    </div>
                    <div id="cardforge-module-status" style="
                        display:grid;
                        grid-template-columns:repeat(auto-fill,minmax(150px,1fr));
                        gap:4px;
                        font-size:11px;
                    ">
                        ${_getModuleStatusHTML()}
                    </div>
                </div>
                <div style="display:flex;gap:8px;margin-top:12px">
                    <button id="cardforge-open-panel-btn" class="menu_button" style="
                        background:var(--cf-primary,#7b68ee);
                        color:white;
                    ">
                        ✨ 打开主面板
                    </button>
                    <button id="cardforge-reload-btn" class="menu_button">
                        🔄 重载扩展
                    </button>
                </div>
            </div>
        `;

        container.appendChild(panel);

        document.getElementById('cardforge-open-panel-btn')?.addEventListener('click', () => {
            if (_modules.mainPanel?.show) _modules.mainPanel.show();
            else _showFallbackPanel();
        });

        document.getElementById('cardforge-reload-btn')?.addEventListener('click', () => {
            location.reload();
        });

        console.log('[CardForge] ✅ 扩展设置面板已注入');
    };
    tryInject();
}

function _showFallbackPanel() {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    const panel = document.createElement('div');
    panel.style.cssText = `
        background: var(--cf-bg-panel, #1a1a2e);
        border: 1px solid var(--cf-border, #444);
        border-radius: 12px;
        padding: 24px;
        max-width: 600px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        color: var(--cf-text, #eee);
    `;
    panel.innerHTML = `
        <h2 style="margin:0 0 16px;color:var(--cf-primary,#7b68ee)">
            🃏 ST-CardForge Pro
        </h2>
        <p style="color:var(--cf-text-muted,#aaa);margin-bottom:20px">
            主面板尚未加载完成，显示调试信息：
        </p>
        <div style="background:var(--cf-bg-card,#16213e);padding:12px;border-radius:8px;margin-bottom:16px">
            <h4 style="margin:0 0 8px">模块状态</h4>
            <div style="font-size:12px;line-height:1.8">
                ${_getModuleStatusHTML()}
            </div>
        </div>
        <div style="text-align:right;margin-top:20px">
            <button id="cardforge-fallback-close" style="
                padding:8px 16px;
                background:var(--cf-danger,#e74c3c);
                color:white;
                border:none;
                border-radius:6px;
                cursor:pointer;
            ">关闭</button>
        </div>
    `;
    modal.appendChild(panel);
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal || e.target.id === 'cardforge-fallback-close') modal.remove();
    });
}

function _getModuleStatusHTML() {
    const labels = {
        eventBus:      '⚡ EventBus',
        aiEngine:      '🤖 AI Engine',
        settings:      '⚙️ Settings',
        cache:         '💾 Cache',
        i18n:          '🌐 I18n',
        errorHandler:  '🛡️ ErrorHandler',
        cardGenerator: '🃏 角色卡生成器',
        wbGenerator:   '📖 世界书生成器',
        greetingGen:   '💬 开场白生成器',
        scriptForge:   '⚒️ STscript锻造器',
        rpgTracker:    '🎲 RPG追踪器',
        branchEngine:  '🌿 剧情分支',
        regexForge:    '🔍 正则锻造器',
        fieldEnhancer: '✨ 字段增强器',
        exporter:      '📦 导出器',
        mainPanel:     '🖼️ 主面板',
        wizard:        '🧙 向导',
    };
    return Object.entries(labels).map(([k, label]) => {
        const ok = !!_modules[k];
        const color = ok ? '#2ecc71' : '#666';
        const icon  = ok ? '✅' : '⏳';
        return `<div style="color:${color}">${icon} ${label}</div>`;
    }).join('');
}

// ═══════════════════════════════════════════════
// § 9  ST 事件集成
// ═══════════════════════════════════════════════

function _registerSTHooks() {
    const ctx = _stContext;
    if (!ctx?.eventSource?.on) return;

    try {
        ctx.eventSource.on('messageReceived', async (data) => {
            try {
                await _modules.rpgTracker?.scanMessage?.(data.message);
            } catch {}
        });
        console.debug('[CardForge] ✅ 已注册 messageReceived 事件');

        ctx.eventSource.on('characterSelected', (data) => {
            _modules.eventBus?.emit('cardforge:character:changed', data);
        });

        ctx.eventSource.on('chatDeleted', () => {
            _modules.eventBus?.emit('cardforge:chat:cleared');
        });
    } catch (e) {
        console.warn('[CardForge] ST hooks 注册失败：', e);
    }
}

// ═══════════════════════════════════════════════
// § 10  扩展生命周期（给 manifest hooks 调用）
// ═══════════════════════════════════════════════

export async function activate() {
    if (_initialized) {
        console.log('[CardForge] 已初始化，跳过重复激活');
        return;
    }

    console.log('╔══════════════════════════════════════╗');
    console.log('║   🃏 ST-CardForge Pro v1.0.1         ║');
    console.log('║   正在激活...                        ║');
    console.log('╚══════════════════════════════════════╝');

    try {
        _stContext = await _getSTContext();
        if (!_stContext) throw new Error('无法获取 ST Context');

        _registerCSSVars();
        await _initCoreModules();
        await _initFeatureModules();
        await _initUI();
        _registerSTHooks();

        _initialized = true;

        console.log('╔══════════════════════════════════════╗');
        console.log('║   ✅ CardForge Pro 已成功激活！      ║');
        console.log('║   点击输入栏旁 🃏 按钮打开主面板     ║');
        console.log('╚══════════════════════════════════════╝');

        _stContext.toastr?.success?.('点击输入栏旁的 🃏 按钮打开', 'CardForge Pro 已就绪');
    } catch (e) {
        console.error('[CardForge] ❌ 激活失败：', e);
        _stContext?.toastr?.error?.(e.message, 'CardForge Pro 激活失败');
    }
}

export const enable = activate;
export const disable = deactivate;

export function deactivate() {
    console.log('[CardForge] 正在停用...');

    try {
        Object.values(_modules).forEach(mod => {
            if (mod?.destroy) {
                try { mod.destroy(); } catch (e) {
                    console.error('[CardForge] 模块销毁失败：', e);
                }
            }
        });
        document.querySelector('.cardforge-global-btn')?.remove();
        document.getElementById('cardforge-settings-panel')?.remove();
        _importCache.clear();
        _initialized = false;
        _stContext = null;
        console.log('[CardForge] ✅ 已停用');
    } catch (e) {
        console.error('[CardForge] 停用出错：', e);
    }
}

// ═══════════════════════════════════════════════
// § 11  调试辅助（本地开发时可用）
// ═══════════════════════════════════════════════

if (typeof window !== 'undefined') {
    window._cardforge = {
        modules: _modules,
        context: () => _stContext,
        status: () => ({
            initialized: _initialized,
            modules: Object.keys(_modules).filter(k => _modules[k]),
        }),
        reload: () => {
            deactivate();
            setTimeout(() => activate(), 100);
        },
        open: () => _modules.mainPanel?.show?.(),
    };
    console.log('[CardForge] 🔧 调试接口已导出到 window._cardforge');
}

// ═══════════════════════════════════════════════
// § 12  自动激活（兜底：若 hooks 未被 ST 调用）
// ═══════════════════════════════════════════════
(function _autoActivate() {
    const doActivate = () => activate().catch(e => console.error('[CardForge] 自动激活失败:', e));
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => setTimeout(doActivate, 800));
    } else {
        setTimeout(doActivate, 800);
    }
})();