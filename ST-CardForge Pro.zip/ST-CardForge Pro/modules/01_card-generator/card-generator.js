/**
 * @file modules/01_card-generator/card-generator.js
 * @description 角色卡生成器核心模块
 *              实现 IModule 接口，集成 AI 生成、字段管理、草稿、undo/redo、验证
 * @version 1.0.0
 */

import { EVENTS, CARD_DATA_SCHEMA }  from '../../contracts.js';
import { eventBus }                   from '../../core/event-bus.js';
import { PROMPT_TEMPLATES }           from './prompt-templates.js';
import { FIELD_SCHEMA, validateCard, getFieldDef, getAIGenerableFields } from './field-schema.js';
import { DraftManager }               from './draft-manager.js';
import { RelationshipGraph }          from './relationship-graph.js';

// ─────────────────────────────────────────────
// 常量
// ─────────────────────────────────────────────

/** 生成各字段时的顺序（决定 UI 进度条显示顺序） */
const GENERATION_ORDER = [
    'description',
    'personality',
    'scenario',
    'first_mes',
    'mes_example',
    'system_prompt',
    'tags',
    'alternate_greetings',
];

// ─────────────────────────────────────────────
// CardGenerator 类
// ─────────────────────────────────────────────
export class CardGenerator {
    /**
     * @param {import('../../core/ai-engine.js').AIEngine}               aiEngine
     * @param {import('../../core/event-bus.js').EventBus}               bus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     * @param {import('../../utils/undo-manager.js').UndoManager}        undoManager
     * @param {import('../../utils/indexeddb-store.js').IndexedDBStore}  dbStore
     */
    constructor(aiEngine, bus, settings, undoManager, dbStore) {
        this._ai          = aiEngine;
        this._bus         = bus;
        this._settings    = settings;
        this._undo        = undoManager;
        this._dbStore     = dbStore;

        /** @type {object}  运行时角色卡数据（深拷贝自 CARD_DATA_SCHEMA） */
        this._cardData    = _cloneSchema();

        /** @type {DraftManager} */
        this._draftMgr    = new DraftManager(settings);

        /** @type {RelationshipGraph} */
        this._relGraph    = new RelationshipGraph('（主角色）');

        /** @type {boolean} */
        this._ready       = false;

        /** @type {boolean}  是否正在生成 */
        this._generating  = false;

        /** @type {AbortController|null}  用于取消生成 */
        this._abortCtrl   = null;
    }

    // ═══════════════════════════════════════════
    // IModule 接口实现
    // ═══════════════════════════════════════════

    async init() {
        await this._draftMgr.init();
        // 绑定自动保存数据源
        this._draftMgr.bindAutoSave(() => this._cardData);
        this._ready = true;
        this._bus.emit(EVENTS.MODULE_READY, { module: 'CardGenerator' });
    }

    destroy() {
        this._draftMgr.destroy();
        this._ready = false;
    }

    getState() {
        return {
            ready:      this._ready,
            generating: this._generating,
            cardName:   this._cardData?.data?.name ?? '',
            validation: validateCard(this._cardData?.data ?? {}),
        };
    }

    isReady() { return this._ready; }

    // ═══════════════════════════════════════════
    // 核心：全字段生成
    // ═══════════════════════════════════════════

    /**
     * 一键全生成——根据向导数据生成所有核心字段
     * @param {object} wizardData   来自 wizard.html 收集的数据
     * @param {object} [options]
     * @param {Function} [options.onFieldStart]   (fieldKey: string) => void
     * @param {Function} [options.onFieldDone]    (fieldKey: string, value: any) => void
     * @param {Function} [options.onProgress]     (percent: number, msg: string) => void
     * @returns {Promise<object>}  生成完成的 CardData
     */
    async generateAll(wizardData, options = {}) {
        if (this._generating) throw new Error('[CardGenerator] 当前正在生成中，请等待完成');

        const { onFieldStart, onFieldDone, onProgress } = options;
        this._generating = true;
        this._abortCtrl  = new AbortController();

        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: '正在准备生成…' });

            const style    = wizardData.genre ?? 'fantasy';
            const lang     = wizardData.outputLanguage ?? 'zh-CN';
            const genFields = _resolveFieldsToGenerate(wizardData);

            // ── 步骤1：先确定基础字段（不需要 AI 的）
            this._setFieldDirect('name', wizardData.name || '');
            this._setFieldDirect('creator', this._settings.get('creatorName', '') );
            this._setFieldDirect('character_version', '1.0');

            // ── 步骤2：逐字段调用 AI 生成
            const total = genFields.length;
            for (let i = 0; i < total; i++) {
                const fieldKey = genFields[i];

                // 检查是否已被中止
                if (this._abortCtrl.signal.aborted) {
                    console.info('[CardGenerator] 生成已被用户取消');
                    break;
                }

                onFieldStart?.(fieldKey);
                onProgress?.(
                    Math.round((i / total) * 90),
                    `正在生成「${getFieldDef(fieldKey)?.label ?? fieldKey}」…`
                );

                try {
                    const value = await this._generateSingleField(fieldKey, wizardData, style, lang);
                    this._applyGeneratedField(fieldKey, value);
                    onFieldDone?.(fieldKey, value);
                } catch (err) {
                    console.warn(`[CardGenerator] 字段「${fieldKey}」生成失败，跳过`, err);
                    // 单字段失败不中断整体流程
                }
            }

            // ── 步骤3：生成关系图摘要文本追加到 description
            const relText = this._relGraph.toDescriptionText();
            if (relText) {
                const existing = this._cardData.data.description ?? '';
                this._setFieldDirect('description', existing + '\n\n' + relText);
            }

            onProgress?.(100, '生成完成！');

            // ── 步骤4：自动保存草稿
            await this._draftMgr.saveDraft(
                this._cardData,
                `${wizardData.name || '新角色'} · 向导生成`
            );

            this._bus.emit(EVENTS.CARD_UPDATED, { source: 'generateAll', cardData: this._cardData });
            return this._cardData;

        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module:  'CardGenerator',
                method:  'generateAll',
                error,
                context: { wizardData },
            });
            throw error;
        } finally {
            this._generating = false;
            this._abortCtrl  = null;
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 取消正在进行的生成
     */
    cancelGeneration() {
        this._abortCtrl?.abort();
    }

    // ═══════════════════════════════════════════
    // 单字段生成
    // ═══════════════════════════════════════════

    /**
     * 生成单个字段（供字段编辑器的「重新生成」按钮使用）
     * @param {string} fieldKey
     * @param {object} [contextOverride]  额外的上下文参数
     * @returns {Promise<any>}
     */
    async generateField(fieldKey, contextOverride = {}) {
        const def = getFieldDef(fieldKey);
        if (!def) throw new Error(`[CardGenerator] 未知字段：${fieldKey}`);
        if (!def.aiGenerable) throw new Error(`[CardGenerator] 字段「${fieldKey}」不支持 AI 生成`);

        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: `正在生成「${def.label}」…` });

            // 以当前卡片数据作为上下文
            const context = {
                ...this._cardData.data,
                ...contextOverride,
                genre: contextOverride.genre ?? this._cardData.data?.extensions?.cardforge?.meta?.genre ?? 'fantasy',
                outputLanguage: contextOverride.outputLanguage
                    ?? this._settings.get('defaultLanguage', 'zh-CN'),
            };

            const value = await this._generateSingleField(
                fieldKey,
                context,
                context.genre,
                context.outputLanguage
            );

            // 推入 undo 快照（仅保存该字段的旧值）
            this._undo.push(
                { fieldKey, oldValue: this._cardData.data[fieldKey] },
                `重新生成「${def.label}」`
            );

            this._applyGeneratedField(fieldKey, value);
            return value;

        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module:  'CardGenerator',
                method:  'generateField',
                error,
                context: { fieldKey },
            });
            throw error;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 重新生成某字段（别名，语义更清晰）
     * @param {string} fieldKey
     * @returns {Promise<any>}
     */
    async regenerateField(fieldKey) {
        return this.generateField(fieldKey);
    }

    // ═══════════════════════════════════════════
    // 字段编辑
    // ═══════════════════════════════════════════

    /**
     * 设置字段值（支持 undo）
     * @param {string} fieldKey
     * @param {*}      value
     */
    setField(fieldKey, value) {
        const oldValue = this._cardData.data[fieldKey];
        if (oldValue === value) return;

        // 推入 undo 快照
        this._undo?.push(
            { type: 'field', fieldKey, oldValue },
            `编辑「${getFieldDef(fieldKey)?.label ?? fieldKey}」`
        );

        this._setFieldDirect(fieldKey, value);
    }

    /**
     * 读取字段值
     * @param {string} fieldKey
     * @returns {*}
     */
    getField(fieldKey) {
        return this._cardData.data[fieldKey];
    }

    /**
     * 获取完整 CardData（只读副本）
     * @returns {object}
     */
    getCardData() {
        return JSON.parse(JSON.stringify(this._cardData));
    }

    /**
     * 直接加载一个完整的 CardData（用于导入或草稿恢复）
     * @param {object} cardData
     */
    loadCardData(cardData) {
        // 推入 undo 快照
        this._undo?.push(
            { type: 'fullCard', data: JSON.parse(JSON.stringify(this._cardData)) },
            '加载角色卡'
        );
        this._cardData = JSON.parse(JSON.stringify(cardData));
        // 同步更新关系图中的主角色名
        this._relGraph.updateMainCharName(this._cardData.data?.name ?? '主角色');
        this._bus.emit(EVENTS.CARD_UPDATED, { source: 'loadCardData' });
    }

    /**
     * 重置所有字段
     */
    resetCard() {
        this._undo?.push(
            { type: 'fullCard', data: JSON.parse(JSON.stringify(this._cardData)) },
            '重置角色卡'
        );
        this._cardData = _cloneSchema();
        this._relGraph.clear();
        this._bus.emit(EVENTS.CARD_RESET);
    }

    // ═══════════════════════════════════════════
    // 草稿管理
    // ═══════════════════════════════════════════

    /**
     * 保存当前状态为草稿
     * @param {string} [label]
     * @returns {Promise<string>}  草稿 ID
     */
    async saveDraft(label = '') {
        return this._draftMgr.saveDraft(this._cardData, label);
    }

    /**
     * 从草稿恢复
     * @param {string} draftId
     * @returns {Promise<void>}
     */
    async loadDraft(draftId) {
        const record = await this._draftMgr.loadDraft(draftId);
        if (!record) throw new Error(`[CardGenerator] 草稿不存在：${draftId}`);
        this.loadCardData(record.cardData);
    }

    /**
     * 列出所有草稿
     * @returns {Promise<object[]>}
     */
    async listDrafts() {
        return this._draftMgr.listDrafts();
    }

    /**
     * 检查并恢复自动保存
     * @returns {Promise<boolean>}  是否存在自动保存
     */
    async checkAutoSave() {
        return this._draftMgr.hasAutoSave();
    }

    /**
     * 恢复自动保存的草稿
     * @returns {Promise<void>}
     */
    async restoreAutoSave() {
        const record = await this._draftMgr.loadAutoSave();
        if (record) {
            this.loadCardData(record.cardData);
            await this._draftMgr.clearAutoSave();
        }
    }

    // ═══════════════════════════════════════════
    // 关系图
    // ═══════════════════════════════════════════

    /**
     * 更新关系图数据
     * @param {Array} relations
     */
    updateRelationshipGraph(relations) {
        this._relGraph.loadFromRelations(relations);
        // 同步到 cardData 扩展字段
        this._cardData.data.extensions.cardforge.relations = this._relGraph.toJSON();
    }

    /**
     * 获取关系图数据
     * @returns {{ nodes: object[], edges: object[] }}
     */
    getRelationshipData() {
        return this._relGraph.toJSON();
    }

    /**
     * 渲染关系图 SVG
     * @param {object} [options]
     * @returns {string}
     */
    renderRelationshipSVG(options) {
        return this._relGraph.renderSVG(options);
    }

    // ═══════════════════════════════════════════
    // 验证
    // ═══════════════════════════════════════════

    /**
     * 验证当前角色卡
     * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
     */
    validate() {
        return validateCard(this._cardData.data ?? {});
    }

    // ═══════════════════════════════════════════
    // Undo / Redo
    // ═══════════════════════════════════════════

    undo() {
        const snapshot = this._undo?.undo();
        if (!snapshot) return false;
        this._applyUndoSnapshot(snapshot);
        return true;
    }

    redo() {
        const snapshot = this._undo?.redo();
        if (!snapshot) return false;
        this._applyUndoSnapshot(snapshot);
        return true;
    }

    canUndo() { return this._undo?.canUndo() ?? false; }
    canRedo() { return this._undo?.canRedo() ?? false; }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 调用 AI 生成单个字段
     * @param {string} fieldKey
     * @param {object} context
     * @param {string} style
     * @param {string} lang
     * @returns {Promise<any>}
     */
    async _generateSingleField(fieldKey, context, style, lang) {
        const template = PROMPT_TEMPLATES.field_generation[fieldKey];
        if (!template) {
            console.warn(`[CardGenerator] 字段「${fieldKey}」没有对应的生成模板`);
            return null;
        }

        const systemPrompt = template.system(style, lang);
        const userPrompt   = template.user(context);

        const raw = await this._ai.generateCard(systemPrompt, userPrompt);

        // 根据字段类型解析返回值
        return this._parseFieldValue(fieldKey, raw);
    }

    /**
     * 解析 AI 返回值为正确的字段类型
     * @param {string} fieldKey
     * @param {*}      raw
     * @returns {*}
     */
    _parseFieldValue(fieldKey, raw) {
        const def = getFieldDef(fieldKey);
        if (!def) return raw;

        // 数组类型（alternate_greetings、tags）
        if (def.type === 'array') {
            if (Array.isArray(raw)) return raw;
            if (typeof raw === 'string') {
                // 尝试 JSON 解析
                try {
                    const parsed = JSON.parse(raw);
                    if (Array.isArray(parsed)) return parsed;
                } catch {}
                // 按换行拆分
                return raw.split('\n')
                    .map(s => s.trim().replace(/^[-*•]\s*/, ''))
                    .filter(Boolean);
            }
            return [];
        }

        // 对象类型
        if (def.type === 'object') {
            if (typeof raw === 'object' && raw !== null) return raw;
            try { return JSON.parse(String(raw)); } catch {}
            return {};
        }

        // 文本类型：确保是字符串
        if (typeof raw === 'object' && raw !== null) {
            // AI 可能返回 { description: "..." } 形式
            if (fieldKey in raw) return String(raw[fieldKey]);
            return JSON.stringify(raw);
        }

        return String(raw ?? '').trim();
    }

    /**
     * 应用生成结果到 cardData（不触发 undo）
     * @param {string} fieldKey
     * @param {*}      value
     */
    _applyGeneratedField(fieldKey, value) {
        if (value === null || value === undefined) return;
        this._setFieldDirect(fieldKey, value);
        this._bus.emit(EVENTS.CARD_FIELD_CHANGED, {
            fieldKey,
            value,
            source: 'ai-generated',
        });
    }

    /**
     * 直接设置字段值（不推入 undo）
     * @param {string} fieldKey
     * @param {*}      value
     */
    _setFieldDirect(fieldKey, value) {
        if (!this._cardData.data) this._cardData.data = {};
        this._cardData.data[fieldKey] = value;

        // 更新 meta.updated_at
        if (!this._cardData.data.extensions?.cardforge?.meta) {
            _ensureExtensions(this._cardData);
        }
        this._cardData.data.extensions.cardforge.meta.updated_at = new Date().toISOString();

        this._bus.emit(EVENTS.CARD_FIELD_CHANGED, { fieldKey, value, source: 'direct' });
    }

    /**
     * 应用 undo/redo 快照
     * @param {object} snapshot
     */
    _applyUndoSnapshot(snapshot) {
        if (snapshot.type === 'field') {
            this._setFieldDirect(snapshot.fieldKey, snapshot.oldValue);
        } else if (snapshot.type === 'fullCard') {
            this._cardData = JSON.parse(JSON.stringify(snapshot.data));
            this._bus.emit(EVENTS.CARD_UPDATED, { source: 'undo' });
        }
    }

    /**
     * 构建生成 Prompt 时所需的上下文对象
     * @param {object} wizardData
     * @returns {object}
     */
    _buildGenerationPrompt(wizardData) {
        return {
            ...wizardData,
            // 注入已生成字段作为上下文（供后续字段参考）
            existingDescription: this._cardData.data.description ?? '',
            existingPersonality: this._cardData.data.personality ?? '',
        };
    }
}

// ─────────────────────────────────────────────
// 辅助函数
// ─────────────────────────────────────────────

/**
 * 深拷贝初始 CardData Schema
 * @returns {object}
 */
function _cloneSchema() {
    const clone = JSON.parse(JSON.stringify(CARD_DATA_SCHEMA));
    // 注入创建时间
    _ensureExtensions(clone);
    clone.data.extensions.cardforge.meta.created_at = new Date().toISOString();
    clone.data.extensions.cardforge.meta.session_id = _generateSessionId();
    return clone;
}

/**
 * 确保 extensions.cardforge 字段存在
 * @param {object} cardData
 */
function _ensureExtensions(cardData) {
    if (!cardData.data) cardData.data = {};
    if (!cardData.data.extensions) cardData.data.extensions = {};
    if (!cardData.data.extensions.cardforge) {
        cardData.data.extensions.cardforge = {
            version: '1.0.0',
            stats:   {},
            branches: [],
            worldbook: null,
            regex:    [],
            meta: {
                created_at: null,
                updated_at: null,
                session_id: null,
            },
        };
    }
}

/**
 * 根据向导数据决定要生成哪些字段
 * @param {object} wizardData
 * @returns {string[]}
 */
function _resolveFieldsToGenerate(wizardData) {
    const always = ['description', 'personality', 'scenario', 'first_mes'];
    const optional = [];

    if (wizardData.genMesExample !== false)       optional.push('mes_example');
    if (wizardData.genSystemPrompt === true)       optional.push('system_prompt');
    if (wizardData.genTags !== false)              optional.push('tags');
    if (wizardData.genAltGreetings !== false)      optional.push('alternate_greetings');

    // 按照预定义顺序排序
    const all = [...always, ...optional];
    return GENERATION_ORDER.filter(k => all.includes(k));
}

function _generateSessionId() {
    return `sess_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}