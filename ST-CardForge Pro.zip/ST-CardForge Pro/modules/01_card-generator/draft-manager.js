/**
 * @file modules/01_card-generator/draft-manager.js
 * @description 草稿管理器
 *              负责角色卡草稿的自动保存、手动保存、列表管理与恢复
 *              底层存储使用 utils/indexeddb-store.js
 * @version 1.0.0
 */

import { IndexedDBStore } from '../../utils/indexeddb-store.js';
import { EVENTS }         from '../../contracts.js';
import { eventBus }       from '../../core/event-bus.js';

// ─────────────────────────────────────────────
// 常量
// ─────────────────────────────────────────────
const STORE_NAME        = 'drafts';
const DB_NAME           = 'CardForgeProDB';
const DB_VERSION        = 1;
const MAX_DRAFTS        = 30;           // 最多保存草稿数量
const AUTO_SAVE_LABEL   = '__autosave__';

// ─────────────────────────────────────────────
// DraftManager 类
// ─────────────────────────────────────────────
export class DraftManager {
    /**
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     */
    constructor(settings) {
        this._settings      = settings;
        this._store         = new IndexedDBStore(DB_NAME, STORE_NAME, DB_VERSION);
        this._autoSaveTimer = null;
        this._ready         = false;
    }

    // ═══════════════════════════════════════════
    // 初始化 / 销毁
    // ═══════════════════════════════════════════

    async init() {
        await this._store.open();
        this._ready = true;
        this._startAutoSave();
    }

    destroy() {
        this._stopAutoSave();
        this._ready = false;
    }

    isReady() { return this._ready; }

    // ═══════════════════════════════════════════
    // 保存草稿
    // ═══════════════════════════════════════════

    /**
     * 手动保存草稿
     * @param {object} cardData   完整 CardData 对象
     * @param {string} [label]    草稿名称（不填则自动生成）
     * @returns {Promise<string>} 草稿 ID
     */
    async saveDraft(cardData, label = '') {
        this._ensureReady();
        const id      = _generateDraftId();
        const name    = cardData?.data?.name ?? '未命名角色';
        const draftLabel = label || `${name} · ${_formatDateTime()}`;

        const draft = _buildDraftRecord(id, cardData, draftLabel);
        await this._store.set(id, draft);
        await this._pruneOldDrafts();

        eventBus.emit(EVENTS.CARD_DRAFT_SAVED, { id, label: draftLabel });
        console.info(`[DraftManager] 草稿已保存：${draftLabel} (${id})`);
        return id;
    }

    /**
     * 自动保存（覆盖同一个 autosave 槽位）
     * @param {object} cardData
     * @returns {Promise<void>}
     */
    async autoSave(cardData) {
        if (!cardData?.data?.name && !cardData?.data?.description) return;
        this._ensureReady();

        const draft = _buildDraftRecord(
            AUTO_SAVE_LABEL,
            cardData,
            `自动保存 · ${_formatDateTime()}`
        );
        draft.isAutoSave = true;
        await this._store.set(AUTO_SAVE_LABEL, draft);
    }

    // ═══════════════════════════════════════════
    // 读取草稿
    // ═══════════════════════════════════════════

    /**
     * 读取指定草稿
     * @param {string} draftId
     * @returns {Promise<object|null>}  DraftRecord 或 null
     */
    async loadDraft(draftId) {
        this._ensureReady();
        const record = await this._store.get(draftId);
        if (!record) {
            console.warn(`[DraftManager] 草稿不存在：${draftId}`);
            return null;
        }
        return record;
    }

    /**
     * 读取最新自动保存
     * @returns {Promise<object|null>}
     */
    async loadAutoSave() {
        return this.loadDraft(AUTO_SAVE_LABEL);
    }

    /**
     * 列出所有手动保存的草稿（不含 autosave）
     * @returns {Promise<DraftMeta[]>}
     */
    async listDrafts() {
        this._ensureReady();
        const all = await this._store.getAll();
        return all
            .filter(d => !d.isAutoSave)
            .sort((a, b) => b.savedAt - a.savedAt)
            .map(_toDraftMeta);
    }

    /**
     * 检查是否有未恢复的自动保存
     * @returns {Promise<boolean>}
     */
    async hasAutoSave() {
        this._ensureReady();
        const record = await this._store.get(AUTO_SAVE_LABEL);
        return !!record;
    }

    // ═══════════════════════════════════════════
    // 删除草稿
    // ═══════════════════════════════════════════

    /**
     * 删除指定草稿
     * @param {string} draftId
     * @returns {Promise<void>}
     */
    async deleteDraft(draftId) {
        this._ensureReady();
        await this._store.delete(draftId);
    }

    /**
     * 清空所有草稿（含自动保存）
     * @returns {Promise<void>}
     */
    async clearAllDrafts() {
        this._ensureReady();
        await this._store.clear();
    }

    /**
     * 清除自动保存记录
     * @returns {Promise<void>}
     */
    async clearAutoSave() {
        await this._store.delete(AUTO_SAVE_LABEL);
    }

    // ═══════════════════════════════════════════
    // 导出 / 导入
    // ═══════════════════════════════════════════

    /**
     * 将草稿导出为 JSON 字符串
     * @param {string} draftId
     * @returns {Promise<string>}
     */
    async exportDraft(draftId) {
        const record = await this.loadDraft(draftId);
        if (!record) throw new Error(`[DraftManager] 草稿不存在：${draftId}`);
        return JSON.stringify(record, null, 2);
    }

    /**
     * 从 JSON 字符串导入草稿
     * @param {string} jsonStr
     * @returns {Promise<string>}  新草稿 ID
     */
    async importDraft(jsonStr) {
        let record;
        try { record = JSON.parse(jsonStr); }
        catch { throw new Error('[DraftManager] 无效的 JSON 格式'); }

        _validateDraftRecord(record);

        // 重新分配 ID，避免覆盖现有草稿
        const newId     = _generateDraftId();
        record.id       = newId;
        record.savedAt  = Date.now();
        record.label    = `[导入] ${record.label ?? ''}`.trim();

        await this._store.set(newId, record);
        return newId;
    }

    // ═══════════════════════════════════════════
    // 草稿统计
    // ═══════════════════════════════════════════

    /**
     * @returns {Promise<number>}  草稿总数（不含自动保存）
     */
    async getDraftCount() {
        const list = await this.listDrafts();
        return list.length;
    }

    /**
     * 获取存储使用情况（估算）
     * @returns {Promise<{ count: number, estimatedSizeKB: number }>}
     */
    async getStorageStats() {
        this._ensureReady();
        const all = await this._store.getAll();
        const totalChars = all.reduce((acc, d) => {
            return acc + JSON.stringify(d).length;
        }, 0);
        return {
            count:           all.filter(d => !d.isAutoSave).length,
            estimatedSizeKB: Math.round(totalChars / 1024),
        };
    }

    // ═══════════════════════════════════════════
    // 自动保存定时器
    // ═══════════════════════════════════════════

    /**
     * 绑定角色卡状态获取函数，启动自动保存
     * @param {Function} getCardDataFn  () => CardData
     */
    bindAutoSave(getCardDataFn) {
        this._getCardData = getCardDataFn;
        this._startAutoSave();
    }

    _startAutoSave() {
        this._stopAutoSave();
        const interval = this._settings?.get('autoSaveInterval', 30000) ?? 30000;
        const enabled  = this._settings?.get('autoSaveDraft', true) ?? true;

        if (!enabled || !this._ready) return;

        this._autoSaveTimer = setInterval(async () => {
            const cardData = this._getCardData?.();
            if (cardData) {
                await this.autoSave(cardData).catch(err =>
                    console.warn('[DraftManager] 自动保存失败', err)
                );
            }
        }, interval);
    }

    _stopAutoSave() {
        if (this._autoSaveTimer) {
            clearInterval(this._autoSaveTimer);
            this._autoSaveTimer = null;
        }
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 清理超出上限的旧草稿（保留最新的 MAX_DRAFTS 条）
     */
    async _pruneOldDrafts() {
        const list = await this.listDrafts();
        if (list.length <= MAX_DRAFTS) return;

        const toDelete = list.slice(MAX_DRAFTS);
        for (const meta of toDelete) {
            await this._store.delete(meta.id);
        }
        console.info(`[DraftManager] 清理旧草稿 ${toDelete.length} 条`);
    }

    _ensureReady() {
        if (!this._ready) throw new Error('[DraftManager] 尚未初始化，请先调用 init()');
    }
}

// ─────────────────────────────────────────────
// 数据结构工具函数
// ─────────────────────────────────────────────

/**
 * 构建草稿记录对象
 * @param {string} id
 * @param {object} cardData
 * @param {string} label
 * @returns {DraftRecord}
 */
function _buildDraftRecord(id, cardData, label) {
    return {
        id,
        label,
        savedAt:   Date.now(),
        isAutoSave: false,
        version:   '1.0.0',
        // 快照摘要（用于列表展示，不包含完整数据）
        summary: {
            name:        cardData?.data?.name         ?? '',
            description: (cardData?.data?.description ?? '').slice(0, 100),
            tags:        cardData?.data?.tags          ?? [],
            hasAvatar:   false,
        },
        // 完整数据深拷贝
        cardData: JSON.parse(JSON.stringify(cardData ?? {})),
    };
}

/**
 * 将完整草稿记录转换为摘要元数据
 * @param {DraftRecord} record
 * @returns {DraftMeta}
 */
function _toDraftMeta(record) {
    return {
        id:        record.id,
        label:     record.label,
        savedAt:   record.savedAt,
        savedAtStr: _formatDateTime(record.savedAt),
        summary:   record.summary,
    };
}

/** 校验草稿记录格式 */
function _validateDraftRecord(record) {
    if (!record || typeof record !== 'object') {
        throw new Error('[DraftManager] 无效的草稿记录格式');
    }
    if (!record.cardData) {
        throw new Error('[DraftManager] 草稿记录缺少 cardData 字段');
    }
}

/** 生成唯一草稿 ID */
function _generateDraftId() {
    return `draft_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

/**
 * 格式化时间
 * @param {number} [ts]  时间戳，默认当前时间
 * @returns {string}     如：2025-01-15 14:32
 */
function _formatDateTime(ts = Date.now()) {
    const d = new Date(ts);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ` +
           `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}