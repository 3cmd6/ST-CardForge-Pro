/**
 * @file modules/01_card-generator/field-schema.js
 * @description 角色卡字段完整定义（Schema）
 *              包含字段的元数据：名称、类型、限制、提示文字、验证规则
 *              所有字段定义以 contracts.js 的 CARD_DATA_SCHEMA 为准
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 字段类型常量
// ─────────────────────────────────────────────
export const FIELD_TYPES = Object.freeze({
    TEXT:        'text',        // 单行文本
    TEXTAREA:    'textarea',    // 多行文本
    ARRAY:       'array',       // 字符串数组（如 alternate_greetings、tags）
    OBJECT:      'object',      // 嵌套对象
    BOOLEAN:     'boolean',
    NUMBER:      'number',
});

// ─────────────────────────────────────────────
// 完整字段 Schema 定义
// ─────────────────────────────────────────────

/**
 * @typedef {Object} FieldDef
 * @property {string}   key           - 在 CardData.data 中的 key
 * @property {string}   label         - 用于 UI 显示的中文标签
 * @property {string}   labelEn       - 英文标签（对应 CCv2/CCv3 规范名）
 * @property {string}   type          - FIELD_TYPES 中的值
 * @property {boolean}  required      - 是否必填
 * @property {boolean}  recommended   - 是否推荐填写
 * @property {number}   tokenWarn     - Token 警告阈值
 * @property {number}   tokenHard     - Token 硬限制（超出后 UI 报错）
 * @property {string}   placeholder   - 编辑器占位文本
 * @property {string}   description   - 字段说明（用于 tooltip）
 * @property {boolean}  aiGenerable   - 是否可由 AI 生成
 * @property {string}   aiHint        - 生成该字段时对 AI 的提示补充
 * @property {number}   sortOrder     - UI 显示顺序
 * @property {string}   section       - 所属分组
 * @property {boolean}  markdown      - 是否支持 Markdown 预览
 * @property {number}   [minLength]   - 最小字符数
 * @property {number}   [maxLength]   - 最大字符数
 */

export const FIELD_SCHEMA = Object.freeze([

    // ─── 基础信息组 ───────────────────────────────────────
    {
        key:            'name',
        label:          '角色名称',
        labelEn:        'Name',
        type:           FIELD_TYPES.TEXT,
        required:       true,
        recommended:    true,
        tokenWarn:      20,
        tokenHard:      50,
        placeholder:    '如：叶千夜 / Yuki Sato / Luna Evershade',
        description:    '角色的正式名字，将显示在 SillyTavern 角色列表中',
        aiGenerable:    false,    // 名字由用户决定，AI 不主动生成
        aiHint:         '',
        sortOrder:      1,
        section:        'basic',
        markdown:       false,
        minLength:      1,
        maxLength:      100,
    },

    {
        key:            'creator',
        label:          '作者',
        labelEn:        'Creator',
        type:           FIELD_TYPES.TEXT,
        required:       false,
        recommended:    true,
        tokenWarn:      50,
        tokenHard:      100,
        placeholder:    '您的名字或笔名',
        description:    '角色卡作者署名',
        aiGenerable:    false,
        aiHint:         '',
        sortOrder:      2,
        section:        'basic',
        markdown:       false,
    },

    {
        key:            'character_version',
        label:          '版本号',
        labelEn:        'Character Version',
        type:           FIELD_TYPES.TEXT,
        required:       false,
        recommended:    false,
        tokenWarn:      10,
        tokenHard:      20,
        placeholder:    '如：1.0 / v2.3',
        description:    '角色卡版本标识，用于追踪修订历史',
        aiGenerable:    false,
        aiHint:         '',
        sortOrder:      3,
        section:        'basic',
        markdown:       false,
    },

    {
        key:            'tags',
        label:          '标签',
        labelEn:        'Tags',
        type:           FIELD_TYPES.ARRAY,
        required:       false,
        recommended:    true,
        tokenWarn:      100,
        tokenHard:      200,
        placeholder:    '按 Enter 或逗号添加标签',
        description:    '用于搜索和分类的标签，如角色特征、世界观类型',
        aiGenerable:    true,
        aiHint:         '生成3~8个准确描述角色特征和世界观的英文标签（参考 Chub.ai 标签规范）',
        sortOrder:      4,
        section:        'basic',
        markdown:       false,
    },

    // ─── 核心内容组 ───────────────────────────────────────
    {
        key:            'description',
        label:          '角色描述',
        labelEn:        'Description',
        type:           FIELD_TYPES.TEXTAREA,
        required:       true,
        recommended:    true,
        tokenWarn:      2000,
        tokenHard:      3000,
        placeholder:    '详细描述角色的外貌、背景、能力和关键特征\n这是 AI 在对话时最主要的参考依据',
        description:    '角色的核心描述，包含外貌、背景、能力等。AI 在每次对话中都会参考这个字段，建议详细且具体。',
        aiGenerable:    true,
        aiHint:         '以第三人称写作，包含外貌描述（发色/眼色/体型/服装）、性格特征、背景故事、特殊能力或技能、行为习惯。避免直接对话，语言应客观但生动。',
        sortOrder:      10,
        section:        'core',
        markdown:       true,
        minLength:      50,
        maxLength:      6000,
    },

    {
        key:            'personality',
        label:          '性格',
        labelEn:        'Personality',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    true,
        tokenWarn:      500,
        tokenHard:      800,
        placeholder:    '简洁描述角色的性格特质，如：温柔体贴，但内心藏着不为人知的秘密…',
        description:    '角色的性格摘要，相较于 description 更简洁，通常以关键词或短句形式呈现',
        aiGenerable:    true,
        aiHint:         '用简洁有力的短语描述核心性格（3~6个特质），可包含矛盾性格以增加深度。避免使用"好人""坏人"等笼统描述。',
        sortOrder:      11,
        section:        'core',
        markdown:       false,
        maxLength:      1200,
    },

    {
        key:            'scenario',
        label:          '场景设定',
        labelEn:        'Scenario',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    true,
        tokenWarn:      800,
        tokenHard:      1500,
        placeholder:    '描述角色与玩家相遇的世界背景、时间地点、初始情境',
        description:    '场景设定为对话提供初始背景，告诉 AI 和玩家故事发生的具体情境',
        aiGenerable:    true,
        aiHint:         '描述角色与{{user}}相处的具体背景设定，包括：时代背景、地点、两人关系起点、当前局势或氛围。语言宜沉浸感强，能立刻让读者代入情境。',
        sortOrder:      12,
        section:        'core',
        markdown:       true,
        maxLength:      3000,
    },

    {
        key:            'first_mes',
        label:          '开场白（首条消息）',
        labelEn:        'First Message',
        type:           FIELD_TYPES.TEXTAREA,
        required:       true,
        recommended:    true,
        tokenWarn:      500,
        tokenHard:      1000,
        placeholder:    '角色主动开口的第一句话，要有代入感，能吸引玩家继续互动',
        description:    '对话开始时角色发送的第一条消息，直接影响第一印象。建议包含场景描写和角色行动。',
        aiGenerable:    true,
        aiHint:         '以角色第一人称写作，包含动作描写（用*号包裹）和对话。要有场景感，能立刻把读者拉入故事。长度适中（150~300字），结尾留有互动空间。',
        sortOrder:      13,
        section:        'core',
        markdown:       true,
        minLength:      20,
        maxLength:      2000,
    },

    {
        key:            'alternate_greetings',
        label:          '备用开场白',
        labelEn:        'Alternate Greetings',
        type:           FIELD_TYPES.ARRAY,
        required:       false,
        recommended:    true,
        tokenWarn:      2000,
        tokenHard:      4000,
        placeholder:    '',
        description:    '多个备用开场白，让玩家可以选择不同的故事起点。建议提供 2~5 个',
        aiGenerable:    true,
        aiHint:         '生成3条风格各异的备用开场白，每条对应不同情境或角色状态。',
        sortOrder:      14,
        section:        'core',
        markdown:       true,
    },

    // ─── 对话示例组 ───────────────────────────────────────
    {
        key:            'mes_example',
        label:          '对话示例',
        labelEn:        'Example Messages',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    true,
        tokenWarn:      1000,
        tokenHard:      2000,
        placeholder:    '<START>\n{{user}}: 你好…\n{{char}}: 哦，是你啊，终于来了…',
        description:    '通过示例对话展示角色的说话方式和风格。使用 <START> 分隔多组对话，{{user}} 和 {{char}} 作为占位符',
        aiGenerable:    true,
        aiHint:         '生成2~3组对话示例，每组以<START>开头，使用{{user}}和{{char}}作占位符。对话应充分展示角色的说话风格、语气、习惯用语和性格特征。',
        sortOrder:      20,
        section:        'dialogue',
        markdown:       false,
        maxLength:      4000,
    },

    // ─── 系统提示组 ───────────────────────────────────────
    {
        key:            'system_prompt',
        label:          '系统提示（System Prompt）',
        labelEn:        'System Prompt',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    false,
        tokenWarn:      800,
        tokenHard:      1500,
        placeholder:    '覆盖 SillyTavern 全局系统提示的自定义指令\n（可选，不填则使用全局设置）',
        description:    '覆盖 ST 全局 System Prompt 的角色专属指令。通常用于设置角色扮演规则、限制或特殊行为要求',
        aiGenerable:    true,
        aiHint:         '生成一段精炼的系统提示，要求 AI 严格扮演角色、保持角色一致性，包含必要的行为规范。语言简洁直接，避免冗余。',
        sortOrder:      30,
        section:        'system',
        markdown:       false,
        maxLength:      3000,
    },

    {
        key:            'post_history_instructions',
        label:          '历史后指令',
        labelEn:        'Post History Instructions',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    false,
        tokenWarn:      400,
        tokenHard:      800,
        placeholder:    '插入在对话历史之后的持续指令（如：始终保持角色扮演，不要出戏）',
        description:    '每次 AI 响应前都会附加在对话历史末尾的指令，用于持续强化某些行为要求',
        aiGenerable:    true,
        aiHint:         '生成简短的持续性指令（50~150字），用于在每轮对话中提醒 AI 维持角色特性。',
        sortOrder:      31,
        section:        'system',
        markdown:       false,
        maxLength:      1500,
    },

    // ─── 元信息组 ───────────────────────────────────────
    {
        key:            'creator_notes',
        label:          '作者备注',
        labelEn:        'Creator Notes',
        type:           FIELD_TYPES.TEXTAREA,
        required:       false,
        recommended:    false,
        tokenWarn:      400,
        tokenHard:      800,
        placeholder:    '给使用者的说明、推荐设置、触发词提示等',
        description:    '作者给使用者的说明和建议，不会传入 AI 上下文，仅供参考',
        aiGenerable:    false,
        aiHint:         '',
        sortOrder:      40,
        section:        'meta',
        markdown:       true,
    },

]);

// ─────────────────────────────────────────────
// Schema 查询工具函数
// ─────────────────────────────────────────────

/**
 * 按 key 获取字段定义
 * @param {string} key
 * @returns {FieldDef|undefined}
 */
export function getFieldDef(key) {
    return FIELD_SCHEMA.find(f => f.key === key);
}

/**
 * 获取指定分组的所有字段
 * @param {'basic'|'core'|'dialogue'|'system'|'meta'} section
 * @returns {FieldDef[]}
 */
export function getFieldsBySection(section) {
    return FIELD_SCHEMA
        .filter(f => f.section === section)
        .sort((a, b) => a.sortOrder - b.sortOrder);
}

/**
 * 获取所有可由 AI 生成的字段
 * @returns {FieldDef[]}
 */
export function getAIGenerableFields() {
    return FIELD_SCHEMA.filter(f => f.aiGenerable);
}

/**
 * 获取所有必填字段
 * @returns {FieldDef[]}
 */
export function getRequiredFields() {
    return FIELD_SCHEMA.filter(f => f.required);
}

/**
 * 验证单个字段值
 * @param {string} key
 * @param {*}      value
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
export function validateField(key, value) {
    const def    = getFieldDef(key);
    const errors   = [];
    const warnings = [];

    if (!def) return { valid: false, errors: [`未知字段：${key}`], warnings };

    // 必填检查
    if (def.required && (value === null || value === undefined || value === '' ||
        (Array.isArray(value) && value.length === 0))) {
        errors.push(`「${def.label}」为必填字段`);
        return { valid: false, errors, warnings };
    }

    // 字符串类型检查
    if (typeof value === 'string') {
        if (def.minLength && value.length < def.minLength) {
            warnings.push(`「${def.label}」建议至少 ${def.minLength} 个字符（当前 ${value.length} 个）`);
        }
        if (def.maxLength && value.length > def.maxLength) {
            errors.push(`「${def.label}」超过最大长度 ${def.maxLength}（当前 ${value.length} 个）`);
        }
        // Token 检查（使用简单估算）
        const tokens = _quickEstimateTokens(value);
        if (tokens >= def.tokenHard) {
            errors.push(`「${def.label}」Token 数（${tokens}）超过硬限制 ${def.tokenHard}`);
        } else if (tokens >= def.tokenWarn) {
            warnings.push(`「${def.label}」Token 数（${tokens}）较多，可能影响 AI 响应质量`);
        }
    }

    return { valid: errors.length === 0, errors, warnings };
}

/**
 * 验证整张角色卡
 * @param {object} cardData  CardData.data 部分
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
export function validateCard(cardData) {
    const allErrors   = [];
    const allWarnings = [];

    for (const def of FIELD_SCHEMA) {
        const value = cardData[def.key];
        const { errors, warnings } = validateField(def.key, value);
        allErrors.push(...errors);
        allWarnings.push(...warnings);
    }

    return {
        valid:    allErrors.length === 0,
        errors:   allErrors,
        warnings: allWarnings,
    };
}

// ─────────────────────────────────────────────
// 字段分组元数据（用于 UI 分组标题）
// ─────────────────────────────────────────────
export const FIELD_SECTIONS = Object.freeze({
    basic:    { label: '📋 基础信息',     icon: '📋', order: 1 },
    core:     { label: '✍️ 核心内容',     icon: '✍️', order: 2 },
    dialogue: { label: '💬 对话示例',     icon: '💬', order: 3 },
    system:   { label: '⚙️ 系统指令',     icon: '⚙️', order: 4 },
    meta:     { label: '📝 元信息',       icon: '📝', order: 5 },
});

// ─────────────────────────────────────────────
// 内部工具
// ─────────────────────────────────────────────

/** 快速 Token 估算（无需导入 token-counter.js，避免循环） */
function _quickEstimateTokens(text) {
    if (!text) return 0;
    let t = 0;
    for (const c of text) {
        const code = c.charCodeAt(0);
        t += (code >= 0x4E00 && code <= 0x9FFF) ? 0.67 : 0.25;
    }
    return Math.ceil(t);
}