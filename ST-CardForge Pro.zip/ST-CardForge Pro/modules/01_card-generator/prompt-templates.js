/**
 * @file modules/01_card-generator/prompt-templates.js
 * @description 角色卡生成 Prompt 模板库
 *              覆盖 8 种风格 × 各字段，支持变量插值
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 风格类型枚举
// ─────────────────────────────────────────────
export const GENRE_STYLES = Object.freeze({
    fantasy:    { label: '⚔️ 西方奇幻',  icon: '⚔️',  desc: '魔法、剑术、精灵龙族' },
    eastern:    { label: '🌸 东方玄幻',  icon: '🌸',  desc: '修仙、门派、灵气天道' },
    modern:     { label: '🏙 现代都市',  icon: '🏙',  desc: '当代背景、日常生活' },
    scifi:      { label: '🚀 科幻宇宙',  icon: '🚀',  desc: '星际、机甲、未来科技' },
    horror:     { label: '👁 克苏鲁/恐怖', icon: '👁', desc: '暗黑、未知恐惧、诡异' },
    cyberpunk:  { label: '⚡ 赛博朋克',  icon: '⚡',  desc: '反乌托邦、义体、黑客' },
    mythology:  { label: '⚡ 神话史诗',  icon: '🌩',  desc: '神祇、英雄、上古传说' },
    historical: { label: '📜 历史架空',  icon: '📜',  desc: '历史时期、架空朝代' },
});

// ─────────────────────────────────────────────
// 通用 Prompt 前缀
// ─────────────────────────────────────────────
const COMMON_RULES = `
## 通用规则
- 所有文本用{{LANGUAGE}}输出
- 用第三人称客观描述（description），不直接使用"你"作为主语
- 角色扮演文本中使用 {{char}} 代替角色名
- 避免 AI 模型常见套话（如"作为一个AI"）
- 生成内容要具体、生动、有画面感，避免空洞泛泛
- 严格按照要求的 JSON 格式返回，key 名与示例完全一致
`.trim();

// ─────────────────────────────────────────────
// 全生成模板（一次性生成所有核心字段）
// ─────────────────────────────────────────────

/**
 * 风格专属的世界观提示词
 * 在全生成模板中注入，用于引导 AI 生成符合设定风格的内容
 */
const STYLE_FLAVOR = {
    fantasy: `
世界观提示：这是一个存在魔法、剑与盾、精灵/矮人/龙族等奇幻种族的世界。
描述中可包含魔法系统、古老预言、骑士誓言、贵族/平民阶级等元素。`,

    eastern: `
世界观提示：这是一个以修炼为核心的东方玄幻世界，存在灵气、境界（炼气/筑基/结丹等）、
宗门派系、法宝法器等设定。描述可包含剑气、功法名称、阵法、天劫等东方玄幻元素。`,

    modern: `
世界观提示：这是现代都市背景，科技水平与现实相符。
角色可能是普通职场人、学生、特殊职业者，或拥有隐秘身份。
避免过度超自然元素，除非角色本身具有隐秘能力。`,

    scifi: `
世界观提示：这是一个星际或未来科技高度发达的世界。
可包含宇宙飞船、AI意识、基因改造、星际联盟、星球殖民等元素。
科技描述要有合理的硬科幻基础，避免无限魔法化。`,

    horror: `
世界观提示：这是一个充满未知恐惧的黑暗世界，受洛夫克拉夫特风格影响。
可包含旧神、禁忌知识、精神侵蚀、异次元存在等元素。
描述中应充满隐晦的压迫感和难以言说的恐惧，而非直白的血腥暴力。`,

    cyberpunk: `
世界观提示：这是一个反乌托邦赛博朋克世界，人类与机械义体融合，
巨型企业统治社会，网络空间与现实交融。
可包含黑市改造、数据入侵、地下帮派、企业特工等元素。`,

    mythology: `
世界观提示：这是一个神话史诗背景，可基于任意神话体系（希腊/北欧/中华/埃及等）
或原创神话世界。角色可能是神灵后裔、英雄、神祇的化身或古老存在。
语言风格应有史诗感与庄重气质。`,

    historical: `
世界观提示：这是一个历史或架空历史背景，可基于真实朝代/时期或原创历史时代。
注重时代感和文化特色，服装、礼仪、社会结构应符合设定时期。
语言风格应符合时代背景。`,
};

// ─────────────────────────────────────────────
// 核心：全字段生成模板
// ─────────────────────────────────────────────

/**
 * 构建全字段生成的 System Prompt
 * @param {string} style  GENRE_STYLES 中的 key
 * @returns {string}
 */
function buildFullGenSystemPrompt(style) {
    const flavor = STYLE_FLAVOR[style] ?? '';
    return `你是一位专业的角色卡创作者，擅长为 SillyTavern 角色扮演平台创作高质量角色。
${COMMON_RULES}
${flavor}

## 输出格式
你必须严格输出以下 JSON 格式，不要添加任何额外说明：
\`\`\`json
{
  "name":                    "角色名（保持用户输入）",
  "description":             "详细的角色描述（500~1500字）",
  "personality":             "性格特质摘要（50~200字）",
  "scenario":                "场景设定（100~400字）",
  "first_mes":               "开场白（150~400字）",
  "mes_example":             "<START>\\n{{user}}: ...\\n{{char}}: ...",
  "system_prompt":           "系统提示（可为空字符串）",
  "tags":                    ["tag1", "tag2", "tag3"],
  "alternate_greetings":     ["备用开场白1", "备用开场白2", "备用开场白3"],
  "creator_notes":           "作者备注（简短使用说明）"
}
\`\`\``.trim();
}

/**
 * 构建全字段生成的 User Prompt
 * @param {object} wizardData  向导收集的数据
 * @returns {string}
 */
function buildFullGenUserPrompt(wizardData) {
    const {
        name              = '',
        concept           = '',
        genre             = 'fantasy',
        gender            = 'unknown',
        appearance        = '',
        personalityNote   = '',
        traits            = [],
        age               = '',
        worldBackground   = '',
        backstory         = '',
        motivation        = '',
        relationship      = 'stranger',
        speechHabits      = '',
        greetingScenario  = 'first_meeting',
        greetingWordCount = 200,
        pov               = 'first',
        extraRequirements = '',
        outputLanguage    = 'zh-CN',
    } = wizardData;

    const genderMap = {
        female:   '女性',
        male:     '男性',
        nonbinary:'非二元性别',
        unknown:  '不限',
    };

    const relMap = {
        stranger:    '陌生人',
        acquaintance:'相识',
        friend:      '朋友',
        rival:       '对手/竞争者',
        lover:       '恋人/爱慕对象',
    };

    const scenarioMap = {
        first_meeting: '初次相遇',
        reunion:       '久别重逢',
        crisis:        '危机时刻',
        daily:         '日常相处',
        conflict:      '正面冲突',
    };

    const povMap = {
        first:  '第一人称（我）',
        second: '第二人称（你）',
        third:  '第三人称',
    };

    const langMap = {
        'zh-CN': '简体中文',
        'zh-TW': '繁體中文',
        'en-US': 'English',
        'ja-JP': '日本語',
        'ko-KR': '한국어',
    };

    return `
## 角色基础信息
- 角色名：${name || '（请 AI 根据概念建议一个名字）'}
- 核心概念：${concept}
- 性别：${genderMap[gender] ?? gender}
- 年龄：${age || '（AI 自由决定）'}
- 风格类型：${GENRE_STYLES[genre]?.label ?? genre}

## 外貌与性格
${appearance ? `- 外貌：${appearance}` : '- 外貌：请 AI 根据角色概念自由发挥'}
${traits.length ? `- 性格标签：${traits.join('、')}` : ''}
${personalityNote ? `- 性格补充：${personalityNote}` : ''}

## 背景设定
${worldBackground ? `- 世界背景：${worldBackground}` : '- 世界背景：请 AI 根据风格类型创作'}
${backstory ? `- 角色经历：${backstory}` : ''}
${motivation ? `- 目标/动机：${motivation}` : ''}
- 与玩家关系：${relMap[relationship] ?? relationship}

## 对话与开场白
${speechHabits ? `- 语言习惯：${speechHabits}` : ''}
- 开场情景：${scenarioMap[greetingScenario] ?? greetingScenario}
- 开场白字数：约 ${greetingWordCount} 字
- 视角：${povMap[pov] ?? pov}

## 输出语言
请用【${langMap[outputLanguage] ?? outputLanguage}】输出所有文本内容。

${extraRequirements ? `## 特殊要求\n${extraRequirements}` : ''}

请根据以上信息，生成完整的高质量角色卡 JSON。`.trim();
}

// ─────────────────────────────────────────────
// 单字段生成模板
// ─────────────────────────────────────────────

/**
 * 单字段生成模板
 * 每个字段有专属的 system 和 user prompt 构建函数
 */
export const FIELD_GEN_TEMPLATES = Object.freeze({

    description: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位专业的角色描述撰写者，擅长为 SillyTavern 角色扮演平台创作精细的角色描述。
${STYLE_FLAVOR[style] ?? ''}
要求：
- 用${_langName(lang)}输出
- 第三人称客观描述
- 包含：外貌特征 → 性格特质 → 背景经历 → 行为习惯 → 特殊能力（如有）
- 500~1500字，语言生动具体有画面感
- 不要出现"{{user}}"，角色用"她/他"指代
- 直接输出描述文本，不要 JSON 包装`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请撰写这个角色的详细描述（description 字段）：`.trim(),
    },

    personality: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位角色分析师，擅长用简洁有力的语言总结角色性格。
要求：
- 用${_langName(lang)}输出
- 50~200字，关键词或短句形式
- 突出角色最核心、最与众不同的性格特征
- 可以包含矛盾性（如：表面冷漠，内心炽热）
- 直接输出性格描述文本`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请撰写这个角色的性格摘要（personality 字段）：`.trim(),
    },

    scenario: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位沉浸式场景设计师，擅长为角色扮演创作引人入胜的场景设定。
${STYLE_FLAVOR[style] ?? ''}
要求：
- 用${_langName(lang)}输出
- 100~400字
- 描述角色与玩家（{{user}}）相处的具体情境和背景
- 有时间感、空间感、氛围感
- 为开场白做铺垫，但不重复开场白内容
- 直接输出场景文本`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请撰写这个角色的场景设定（scenario 字段）：`.trim(),
    },

    first_mes: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位角色扮演开场白写作专家，擅长用第一条消息瞬间抓住玩家注意力。
${STYLE_FLAVOR[style] ?? ''}
要求：
- 用${_langName(lang)}输出
- 150~400字
- 以角色视角出发（第一或第三人称取决于设定）
- 动作描写用 *号* 包裹
- 包含场景描写和角色初始行动
- 结尾设置互动钩子，引导玩家回应
- 直接输出开场白文本，不要任何说明`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}
${context.greetingScenario ? `\n开场情景：${context.greetingScenario}` : ''}
${context.greetingWordCount ? `开场字数：约 ${context.greetingWordCount} 字` : ''}

请撰写这个角色的开场白（first_mes 字段）：`.trim(),
    },

    mes_example: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位对话示例创作专家，擅长通过示例对话展示角色的说话风格。
要求：
- 用${_langName(lang)}输出
- 生成2~3组对话，每组以 <START> 开头
- 使用 {{user}} 和 {{char}} 作为占位符
- 每组对话2~4个来回
- 充分体现角色的语气、习惯用语、情绪反应
- 动作描写用 *号* 包裹
- 直接输出对话文本`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请撰写这个角色的对话示例（mes_example 字段）：`.trim(),
    },

    system_prompt: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位 SillyTavern 配置专家，擅长撰写精确有效的角色扮演系统提示。
要求：
- 用${_langName(lang)}输出
- 100~300字
- 语言简洁直接，指令明确
- 包含：角色扮演规则 + 角色核心特征提醒 + 禁止出戏要求
- 不要使用 {{user}} {{char}} 变量（这里是纯文本指令）
- 直接输出系统提示文本`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请撰写这个角色的系统提示（system_prompt 字段）：`.trim(),
    },

    alternate_greetings: {
        system: (style = 'fantasy', lang = 'zh-CN') => `
你是一位角色扮演开场白写作专家。
要求：
- 用${_langName(lang)}输出
- 生成3条备用开场白
- 每条对应不同情景或角色状态，要有明显区别
- 每条150~300字
- 动作描写用 *号* 包裹
- 严格以 JSON 数组格式输出：["开场白1", "开场白2", "开场白3"]
- 不要其他任何说明`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请生成3条备用开场白 JSON 数组（alternate_greetings 字段）：`.trim(),
    },

    tags: {
        system: (_style, lang = 'zh-CN') => `
你是一位角色卡标签专家，熟悉 Chub.ai、Character.AI 等平台的标签规范。
要求：
- 生成5~10个英文小写标签（部分可中文）
- 涵盖：世界观类型、角色性格、互动风格、内容类型
- 避免过于宽泛的标签（如"fantasy"单独出现）
- 严格以 JSON 数组格式输出：["tag1", "tag2", ...]
- 不要其他任何说明`.trim(),

        user: (context) => `
角色信息：
${_formatContext(context)}

请生成标签 JSON 数组（tags 字段）：`.trim(),
    },

});

// ─────────────────────────────────────────────
// 增强（Field Enhance）专属 Prompt
// ─────────────────────────────────────────────

export const ENHANCE_PROMPTS = Object.freeze({
    literary: (fieldName, content) => `
请对以下「${fieldName}」内容进行文学化润色：
- 提升语言的文学性和表现力
- 使用更精准、更有画面感的词汇
- 保持原文核心含义不变
- 不要改变整体结构

原文：
${content}

请直接输出润色后的文本：`.trim(),

    detailed: (fieldName, content) => `
请对以下「${fieldName}」内容进行扩充细节：
- 增加具体的描写细节（场景/动作/心理）
- 补充背景信息使内容更丰富立体
- 保持原有核心内容，在其基础上扩充
- 扩充后字数约为原文的1.5~2倍

原文：
${content}

请直接输出扩充后的文本：`.trim(),

    concise: (fieldName, content) => `
请对以下「${fieldName}」内容进行精炼压缩：
- 去除冗余表述和重复内容
- 保留最核心、最有价值的信息
- 压缩后字数约为原文的60~75%
- 保持语言流畅，不要变成列表

原文：
${content}

请直接输出精炼后的文本：`.trim(),

    poetic: (fieldName, content) => `
请对以下「${fieldName}」内容进行诗意化改写：
- 使用富有意境的语言和意象
- 适当加入隐喻、比喻等修辞手法
- 保持东方或西方文学美感（根据内容风格）
- 保留核心含义，但表达方式更具诗意

原文：
${content}

请直接输出诗意化改写后的文本：`.trim(),
});

// ─────────────────────────────────────────────
// 完整 PROMPT_TEMPLATES 导出对象
// ─────────────────────────────────────────────
export const PROMPT_TEMPLATES = Object.freeze({

    // 全字段生成
    full_generation: Object.fromEntries(
        Object.keys(GENRE_STYLES).map(style => [
            style,
            {
                system: (lang = 'zh-CN') => buildFullGenSystemPrompt(style)
                    .replace('{{LANGUAGE}}', _langName(lang)),
                user:   (wizardData)     => buildFullGenUserPrompt({ ...wizardData, genre: style }),
            }
        ])
    ),

    // 单字段生成
    field_generation: FIELD_GEN_TEMPLATES,

    // 字段增强
    field_enhance: ENHANCE_PROMPTS,

    // 语言变体前缀
    language_variants: {
        'zh-CN': '请用简体中文生成：',
        'zh-TW': '請用繁體中文生成：',
        'en-US': 'Please generate in English: ',
        'ja-JP': '日本語で生成してください：',
        'ko-KR': '한국어로 생성해 주세요：',
    },
});

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 向模板中注入变量（替换 {{VAR_NAME}} 占位符）
 * @param {string} template
 * @param {object} vars
 * @returns {string}
 */
export function fillTemplate(template, vars = {}) {
    return template.replace(/\{\{(\w+)\}\}/g, (_, key) =>
        key in vars ? String(vars[key]) : `{{${key}}}`
    );
}

/**
 * 获取指定风格 + 类型的模板
 * @param {string} style   如 'fantasy'
 * @param {'system'|'user'} type
 * @returns {Function|undefined}
 */
export function getTemplate(style, type) {
    return PROMPT_TEMPLATES.full_generation[style]?.[type];
}

/**
 * 获取指定字段的生成模板
 * @param {string} fieldKey
 * @returns {{ system: Function, user: Function }|undefined}
 */
export function getFieldTemplate(fieldKey) {
    return FIELD_GEN_TEMPLATES[fieldKey];
}

/**
 * 获取所有可用风格列表
 * @returns {Array<{ key, label, icon, desc }>}
 */
export function listStyles() {
    return Object.entries(GENRE_STYLES).map(([key, val]) => ({ key, ...val }));
}

/** 将语言代码转为语言名称 */
function _langName(code) {
    const map = {
        'zh-CN': '简体中文',
        'zh-TW': '繁體中文',
        'en-US': 'English',
        'ja-JP': '日本語',
        'ko-KR': '한국어',
    };
    return map[code] ?? code;
}

/** 将上下文对象格式化为可读文本 */
function _formatContext(ctx = {}) {
    const lines = [];
    if (ctx.name)            lines.push(`- 名称：${ctx.name}`);
    if (ctx.concept)         lines.push(`- 核心概念：${ctx.concept}`);
    if (ctx.genre)           lines.push(`- 风格：${GENRE_STYLES[ctx.genre]?.label ?? ctx.genre}`);
    if (ctx.gender)          lines.push(`- 性别：${ctx.gender}`);
    if (ctx.age)             lines.push(`- 年龄：${ctx.age}`);
    if (ctx.appearance)      lines.push(`- 外貌：${ctx.appearance}`);
    if (ctx.traits?.length)  lines.push(`- 性格标签：${ctx.traits.join('、')}`);
    if (ctx.personalityNote) lines.push(`- 性格补充：${ctx.personalityNote}`);
    if (ctx.backstory)       lines.push(`- 背景：${ctx.backstory}`);
    if (ctx.motivation)      lines.push(`- 目标：${ctx.motivation}`);
    if (ctx.speechHabits)    lines.push(`- 说话习惯：${ctx.speechHabits}`);
    // 已生成字段（用于单字段补充生成时给 AI 更多上下文）
    if (ctx.description)     lines.push(`- 已有描述（节选）：${ctx.description.slice(0, 200)}…`);
    if (ctx.personality)     lines.push(`- 已有性格：${ctx.personality}`);
    return lines.length ? lines.join('\n') : '（暂无详细信息）';
}