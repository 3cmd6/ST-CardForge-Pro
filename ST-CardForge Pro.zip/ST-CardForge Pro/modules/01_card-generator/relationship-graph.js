/**
 * @file modules/01_card-generator/relationship-graph.js
 * @description 角色关系图管理器
 *              管理角色与其他 NPC / 势力之间的关系数据
 *              提供数据模型与 SVG 渲染（轻量级，无需 d3 全量引入）
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import { eventBus } from '../../core/event-bus.js';

// ─────────────────────────────────────────────
// 关系类型定义
// ─────────────────────────────────────────────
export const RELATION_TYPES = Object.freeze({
    family:    { label: '家人',   color: '#2ecc71', icon: '👨‍👩‍👧' },
    friend:    { label: '朋友',   color: '#3498db', icon: '🤝' },
    lover:     { label: '恋人',   color: '#e91e8c', icon: '💗' },
    rival:     { label: '对手',   color: '#e74c3c', icon: '⚔️' },
    enemy:     { label: '敌人',   color: '#c0392b', icon: '💀' },
    ally:      { label: '盟友',   color: '#27ae60', icon: '🛡' },
    mentor:    { label: '师父',   color: '#9b59b6', icon: '📚' },
    disciple:  { label: '弟子',   color: '#8e44ad', icon: '🎓' },
    colleague: { label: '同僚',   color: '#7f8c8d', icon: '🏢' },
    neutral:   { label: '中立',   color: '#95a5a6', icon: '⚖️' },
    unknown:   { label: '未知',   color: '#555',    icon: '❓' },
    custom:    { label: '自定义', color: '#f39c12', icon: '✏️' },
});

// ─────────────────────────────────────────────
// RelationshipGraph 类
// ─────────────────────────────────────────────
export class RelationshipGraph {
    /**
     * @param {string} mainCharName  主角色名（图的中心节点）
     */
    constructor(mainCharName = '主角色') {
        /** @type {Map<string, GraphNode>}  节点集合，key = 节点 ID */
        this._nodes = new Map();
        /** @type {Map<string, GraphEdge>}  边集合，key = 边 ID */
        this._edges = new Map();
        /** @type {string}  主角色节点 ID */
        this._mainNodeId = null;

        // 初始化主角色节点
        this._mainNodeId = this._addMainNode(mainCharName);
    }

    // ═══════════════════════════════════════════
    // 节点操作
    // ═══════════════════════════════════════════

    /**
     * 添加一个关联角色节点
     * @param {object} options
     * @param {string} options.name           角色名
     * @param {string} [options.role]         角色身份/职位
     * @param {string} [options.description]  简短描述
     * @param {string} [options.avatar]       头像 URL（可选）
     * @param {string} [options.group]        所属阵营/势力
     * @returns {string}  节点 ID
     */
    addNode({ name, role = '', description = '', avatar = '', group = '' }) {
        const id = _genNodeId(name);
        if (this._nodes.has(id)) {
            // 更新已有节点
            const node = this._nodes.get(id);
            if (role)        node.role        = role;
            if (description) node.description = description;
            if (avatar)      node.avatar      = avatar;
            if (group)       node.group       = group;
            return id;
        }

        this._nodes.set(id, {
            id,
            name,
            role,
            description,
            avatar,
            group,
            isMain: false,
        });

        eventBus.emit(EVENTS.CARD_UPDATED, { source: 'RelationshipGraph', action: 'nodeAdded', id });
        return id;
    }

    /**
     * 更新节点属性
     * @param {string} nodeId
     * @param {object} changes
     */
    updateNode(nodeId, changes) {
        const node = this._nodes.get(nodeId);
        if (!node) throw new Error(`[RelationshipGraph] 节点不存在：${nodeId}`);
        Object.assign(node, changes);
        eventBus.emit(EVENTS.CARD_UPDATED, { source: 'RelationshipGraph', action: 'nodeUpdated', nodeId });
    }

    /**
     * 删除节点（同时删除相关的边）
     * @param {string} nodeId
     */
    deleteNode(nodeId) {
        if (nodeId === this._mainNodeId) {
            throw new Error('[RelationshipGraph] 不能删除主角色节点');
        }
        this._nodes.delete(nodeId);
        // 删除关联的边
        for (const [edgeId, edge] of this._edges) {
            if (edge.sourceId === nodeId || edge.targetId === nodeId) {
                this._edges.delete(edgeId);
            }
        }
        eventBus.emit(EVENTS.CARD_UPDATED, { source: 'RelationshipGraph', action: 'nodeDeleted', nodeId });
    }

    /**
     * 获取节点
     * @param {string} nodeId
     * @returns {GraphNode|undefined}
     */
    getNode(nodeId) {
        return this._nodes.get(nodeId);
    }

    /**
     * 更新主角色名称
     * @param {string} newName
     */
    updateMainCharName(newName) {
        const node = this._nodes.get(this._mainNodeId);
        if (node) node.name = newName;
    }

    // ═══════════════════════════════════════════
    // 边（关系）操作
    // ═══════════════════════════════════════════

    /**
     * 在两个节点之间添加关系
     * @param {object} options
     * @param {string} options.sourceId       源节点 ID（通常是主角色）
     * @param {string} options.targetId       目标节点 ID
     * @param {string} options.type           RELATION_TYPES 中的 key
     * @param {string} [options.label]        自定义关系描述
     * @param {boolean} [options.bidirectional] 是否双向（默认 true）
     * @returns {string}  边 ID
     */
    addRelation({ sourceId, targetId, type, label = '', bidirectional = true }) {
        if (!this._nodes.has(sourceId)) throw new Error(`[RelationshipGraph] 源节点不存在：${sourceId}`);
        if (!this._nodes.has(targetId)) throw new Error(`[RelationshipGraph] 目标节点不存在：${targetId}`);

        const edgeId = _genEdgeId(sourceId, targetId);
        const relDef = RELATION_TYPES[type] ?? RELATION_TYPES.custom;

        this._edges.set(edgeId, {
            id:            edgeId,
            sourceId,
            targetId,
            type,
            label:         label || relDef.label,
            color:         relDef.color,
            icon:          relDef.icon,
            bidirectional,
        });

        return edgeId;
    }

    /**
     * 快捷方法：添加主角色与某角色的关系
     * @param {string} targetNodeId
     * @param {string} type
     * @param {string} [label]
     * @returns {string}  边 ID
     */
    addMainRelation(targetNodeId, type, label = '') {
        return this.addRelation({
            sourceId:      this._mainNodeId,
            targetId:      targetNodeId,
            type,
            label,
            bidirectional: true,
        });
    }

    /**
     * 删除关系边
     * @param {string} edgeId
     */
    deleteRelation(edgeId) {
        this._edges.delete(edgeId);
    }

    /**
     * 获取某节点的所有关系
     * @param {string} nodeId
     * @returns {GraphEdge[]}
     */
    getRelationsOf(nodeId) {
        return [...this._edges.values()].filter(
            e => e.sourceId === nodeId || e.targetId === nodeId
        );
    }

    // ═══════════════════════════════════════════
    // 批量操作
    // ═══════════════════════════════════════════

    /**
     * 从结构化数据批量加载（向导收集的关系数据）
     * @param {Array<RelationInput>} relations
     * [{ name, type, role, description, label, group }]
     */
    loadFromRelations(relations = []) {
        for (const rel of relations) {
            const nodeId = this.addNode({
                name:        rel.name,
                role:        rel.role        ?? '',
                description: rel.description ?? '',
                group:       rel.group       ?? '',
            });
            if (rel.type) {
                this.addMainRelation(nodeId, rel.type, rel.label ?? '');
            }
        }
    }

    /**
     * 清空所有节点和边（保留主角色节点）
     */
    clear() {
        const mainNode = this._nodes.get(this._mainNodeId);
        this._nodes.clear();
        this._edges.clear();
        if (mainNode) this._nodes.set(this._mainNodeId, mainNode);
    }

    // ═══════════════════════════════════════════
    // 序列化 / 反序列化
    // ═══════════════════════════════════════════

    /**
     * 导出为可序列化的纯对象
     * @returns {{ nodes: GraphNode[], edges: GraphEdge[], mainNodeId: string }}
     */
    toJSON() {
        return {
            mainNodeId: this._mainNodeId,
            nodes:      [...this._nodes.values()],
            edges:      [...this._edges.values()],
        };
    }

    /**
     * 从纯对象恢复图状态
     * @param {{ nodes: GraphNode[], edges: GraphEdge[], mainNodeId: string }} data
     */
    fromJSON(data) {
        this._nodes.clear();
        this._edges.clear();

        for (const node of data.nodes ?? []) {
            this._nodes.set(node.id, { ...node });
        }
        for (const edge of data.edges ?? []) {
            this._edges.set(edge.id, { ...edge });
        }
        this._mainNodeId = data.mainNodeId ?? [...this._nodes.keys()][0];
    }

    /**
     * 将关系图摘要转换为角色描述追加文本（供 AI 生成时参考）
     * @returns {string}
     */
    toDescriptionText() {
        const relations = this.getRelationsOf(this._mainNodeId);
        if (!relations.length) return '';

        const lines = ['【人物关系】'];
        for (const edge of relations) {
            const otherId   = edge.sourceId === this._mainNodeId ? edge.targetId : edge.sourceId;
            const otherNode = this._nodes.get(otherId);
            if (!otherNode) continue;
            const role = otherNode.role ? `（${otherNode.role}）` : '';
            lines.push(`- ${otherNode.name}${role}：${edge.label}${otherNode.description ? ' — ' + otherNode.description : ''}`);
        }
        return lines.join('\n');
    }

    // ═══════════════════════════════════════════
    // SVG 渲染（轻量级，无依赖）
    // ═══════════════════════════════════════════

    /**
     * 将关系图渲染为 SVG 字符串
     * @param {object} [options]
     * @param {number} [options.width=600]
     * @param {number} [options.height=400]
     * @returns {string}  SVG 字符串
     */
    renderSVG({ width = 600, height = 400 } = {}) {
        const nodes = [...this._nodes.values()];
        const edges = [...this._edges.values()];

        if (nodes.length === 0) return _emptySVG(width, height);

        // 计算布局（径向布局：主角色在中心，其他节点均匀分布在圆周）
        const positions = _radialLayout(nodes, this._mainNodeId, width, height);

        // 构建 SVG
        const edgeSVGs = edges.map(e => _renderEdgeSVG(e, positions)).join('\n');
        const nodeSVGs = nodes.map(n => _renderNodeSVG(n, positions[n.id], n.id === this._mainNodeId)).join('\n');

        return `<svg xmlns="http://www.w3.org/2000/svg"
    width="${width}" height="${height}"
    viewBox="0 0 ${width} ${height}"
    style="background:var(--cf-bg-card,#16213e);border-radius:8px;font-family:system-ui,sans-serif"
>
    <defs>
        <marker id="cf-arrow" markerWidth="8" markerHeight="8"
                refX="6" refY="3" orient="auto">
            <path d="M0,0 L0,6 L8,3 z" fill="rgba(255,255,255,0.4)" />
        </marker>
    </defs>
    <!-- 边 -->
    ${edgeSVGs}
    <!-- 节点 -->
    ${nodeSVGs}
</svg>`;
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _addMainNode(name) {
        const id = 'main';
        this._nodes.set(id, {
            id,
            name,
            role:        '主角色',
            description: '',
            avatar:      '',
            group:       '',
            isMain:      true,
        });
        return id;
    }
}

// ─────────────────────────────────────────────
// SVG 辅助函数
// ─────────────────────────────────────────────

function _radialLayout(nodes, mainNodeId, width, height) {
    const cx = width  / 2;
    const cy = height / 2;
    const r  = Math.min(width, height) * 0.38;

    const positions = {};
    positions[mainNodeId] = { x: cx, y: cy };

    const others = nodes.filter(n => n.id !== mainNodeId);
    const count  = others.length;
    if (count === 0) return positions;

    const angleStep = (Math.PI * 2) / count;
    others.forEach((node, i) => {
        const angle = i * angleStep - Math.PI / 2;
        positions[node.id] = {
            x: cx + r * Math.cos(angle),
            y: cy + r * Math.sin(angle),
        };
    });

    return positions;
}

function _renderNodeSVG(node, pos, isMain) {
    if (!pos) return '';
    const { x, y } = pos;
    const r    = isMain ? 32 : 24;
    const fill = isMain ? 'rgba(123,104,238,0.8)' : 'rgba(52,73,94,0.9)';
    const stroke = isMain ? '#7b68ee' : 'rgba(255,255,255,0.2)';
    const fontSize = isMain ? 13 : 11;
    // 截断名字
    const label = node.name.length > 6 ? node.name.slice(0, 5) + '…' : node.name;
    const roleLabel = node.role && node.role !== '主角色'
        ? `<text x="${x}" y="${y + r + 14}" text-anchor="middle"
               font-size="9" fill="rgba(255,255,255,0.45)">${_esc(node.role)}</text>`
        : '';

    return `<g class="cf-rg-node" data-id="${_esc(node.id)}">
    <circle cx="${x}" cy="${y}" r="${r}"
            fill="${fill}" stroke="${stroke}" stroke-width="1.5" />
    <text x="${x}" y="${y + 1}" text-anchor="middle" dominant-baseline="middle"
          font-size="${fontSize}" font-weight="${isMain ? 700 : 500}"
          fill="${isMain ? '#fff' : 'rgba(255,255,255,0.85)'}">
        ${_esc(label)}
    </text>
    ${roleLabel}
</g>`;
}

function _renderEdgeSVG(edge, positions) {
    const src = positions[edge.sourceId];
    const tgt = positions[edge.targetId];
    if (!src || !tgt) return '';

    const mx = (src.x + tgt.x) / 2;
    const my = (src.y + tgt.y) / 2;
    const color = edge.color ?? 'rgba(255,255,255,0.25)';

    return `<g>
    <line x1="${src.x}" y1="${src.y}" x2="${tgt.x}" y2="${tgt.y}"
          stroke="${color}" stroke-width="1.5" stroke-opacity="0.6"
          marker-end="url(#cf-arrow)" />
    <text x="${mx}" y="${my - 5}" text-anchor="middle"
          font-size="10" fill="${color}">${_esc(edge.icon ?? '')} ${_esc(edge.label)}</text>
</g>`;
}

function _emptySVG(width, height) {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"
    style="background:var(--cf-bg-card,#16213e);border-radius:8px">
    <text x="${width/2}" y="${height/2}" text-anchor="middle" dominant-baseline="middle"
          font-size="13" fill="rgba(255,255,255,0.3)">暂无关系数据</text>
</svg>`;
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

function _genNodeId(name) {
    return 'node_' + name.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '') + '_' +
           Math.random().toString(36).slice(2, 5);
}

function _genEdgeId(srcId, tgtId) {
    return `edge_${srcId}__${tgtId}`;
}

function _esc(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}