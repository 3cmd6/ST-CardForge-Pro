/**
 * @file modules/02_world-book/bulk-import.js
 * @description 世界书批量导入器
 *              支持多种来源格式：ST 标准 JSON、纯文本（按行/按段落）、
 *              CSV、Lorebook JSON（NovelAI 格式）
 * @version 1.0.0
 */

import { buildEntry, worldBookToEntries, ENTRY_CATEGORIES } from './entry-builder.js';
import { EVENTS } from '../../contracts.js';
import { eventBus } from '../../core/event-bus.js';

// ─────────────────────────────────────────────
// 支持的导入格式
// ─────────────────────────────────────────────
export const IMPORT_FORMATS = Object.freeze({
    st_json:     { label: 'SillyTavern 世界书 JSON',  ext: '.json' },
    nai_json:    { label: 'NovelAI Lorebook JSON',     ext: '.json' },
    text_lines:  { label: '纯文本（每行一条）',         ext: '.txt'  },
    text_blocks: { label: '纯文本（段落分隔）',         ext: '.txt'  },
    csv:         { label: 'CSV（关键词,内容）',         ext: '.csv'  },
    markdown:    { label: 'Markdown（## 标题 + 内容）', ext: '.md'   },
});

// ─────────────────────────────────────────────
// BulkImporter 类
// ─────────────────────────────────────────────
export class BulkImporter {
    /**
     * @param {import('./keyword-analyzer.js').KeywordAnalyzer} keywordAnalyzer
     */
    constructor(keywordAnalyzer) {
        this._kwAnalyzer = keywordAnalyzer;
    }

    // ═══════════════════════════════════════════
    // 主接口：自动检测格式并导入
    // ═══════════════════════════════════════════

    /**
     * 从文件自动检测格式并导入
     * @param {File|string} source   File 对象或文本字符串
     * @param {object}      [opts]
     * @param {string}      [opts.format]        强制指定格式，否则自动检测
     * @param {string}      [opts.defaultCategory='custom']
     * @param {boolean}     [opts.autoKeywords=false]  是否用 AI 自动提取关键词
     * @param {Function}    [opts.onProgress]    (percent, msg) => void
     * @returns {Promise<ImportResult>}
     */
    async import(source, opts = {}) {
        const {
            format           = null,
            defaultCategory  = 'custom',
            autoKeywords     = false,
            onProgress       = () => {},
        } = opts;

        onProgress(5, '读取文件内容…');

        // 读取内容
        let content;
        let filename = '';
        if (source instanceof File) {
            filename = source.name;
            content  = await _readFile(source);
        } else if (typeof source === 'string') {
            content = source;
        } else {
            throw new Error('[BulkImporter] 不支持的 source 类型');
        }

        if (!content || !content.trim()) {
            throw new Error('[BulkImporter] 文件内容为空');
        }

        // 自动检测格式
        const detectedFormat = format ?? this._detectFormat(content, filename);
        onProgress(15, `检测到格式：${IMPORT_FORMATS[detectedFormat]?.label ?? detectedFormat}`);

        // 按格式解析
        let rawEntries;
        switch (detectedFormat) {
            case 'st_json':
                rawEntries = this._parseSTJson(content);
                break;
            case 'nai_json':
                rawEntries = this._parseNAIJson(content);
                break;
            case 'text_lines':
                rawEntries = this._parseTextLines(content, defaultCategory);
                break;
            case 'text_blocks':
                rawEntries = this._parseTextBlocks(content, defaultCategory);
                break;
            case 'csv':
                rawEntries = this._parseCSV(content, defaultCategory);
                break;
            case 'markdown':
                rawEntries = this._parseMarkdown(content, defaultCategory);
                break;
            default:
                throw new Error(`[BulkImporter] 不支持的格式：${detectedFormat}`);
        }

        onProgress(60, `已解析 ${rawEntries.length} 条条目，正在处理…`);

        // 可选：AI 自动提取关键词（针对没有关键词的条目）
        if (autoKeywords && this._kwAnalyzer) {
            rawEntries = await this._autoFillKeywords(rawEntries, onProgress);
        }

        // 构建标准 WBEntry 对象
        const entries = rawEntries
            .filter(r => r.content && r.content.trim())
            .map(r => buildEntry({
                keys:            r.keys            ?? [],
                secondary_keys:  r.secondary_keys  ?? [],
                content:         r.content,
                category:        r.category        ?? defaultCategory,
                enabled:         r.enabled         ?? true,
                constant:        r.constant        ?? false,
                selective:       r.selective       ?? false,
                insertion_order: r.insertion_order,
                priority:        r.priority,
                position:        r.position,
                extensions:      r.extensions      ?? {},
            }));

        onProgress(100, `导入完成，共 ${entries.length} 条`);

        eventBus.emit(EVENTS.WB_UPDATED, {
            source: 'BulkImporter',
            count:  entries.length,
            format: detectedFormat,
        });

        return {
            entries,
            format:  detectedFormat,
            total:   entries.length,
            skipped: rawEntries.length - entries.length,
        };
    }

    // ═══════════════════════════════════════════
    // 格式解析器
    // ═══════════════════════════════════════════

    /**
     * 解析 SillyTavern 标准世界书 JSON
     * @param {string} content
     * @returns {object[]}
     */
    _parseSTJson(content) {
        let parsed;
        try { parsed = JSON.parse(content); }
        catch { throw new Error('[BulkImporter] 无效的 JSON 格式'); }

        // 兼容两种结构：{ entries: {...} } 或 { entries: [...] }
        const entriesRaw = parsed.entries ?? parsed;
        const arr = Array.isArray(entriesRaw)
            ? entriesRaw
            : Object.values(entriesRaw);

        return arr.map(e => ({
            keys:            e.key          ?? e.keys           ?? [],
            secondary_keys:  e.keysecondary ?? e.secondary_keys ?? [],
            content:         e.content      ?? e.text           ?? '',
            enabled:         e.disable === false || e.enabled !== false,
            constant:        e.constant     ?? false,
            selective:       e.selective    ?? false,
            insertion_order: e.order        ?? e.insertion_order,
            priority:        e.priority,
            position:        e.position,
            category:        e.comment?.split(':')?.[0]?.trim() ?? 'custom',
            extensions:      e.extensions   ?? {},
        }));
    }

    /**
     * 解析 NovelAI Lorebook JSON 格式
     * @param {string} content
     * @returns {object[]}
     */
    _parseNAIJson(content) {
        let parsed;
        try { parsed = JSON.parse(content); }
        catch { throw new Error('[BulkImporter] 无效的 NovelAI JSON 格式'); }

        const entries = parsed.entries ?? parsed.lorebookEntries ?? [];
        return entries.map(e => ({
            keys:     e.keys             ?? e.searchterms ?? [],
            content:  e.text             ?? e.content     ?? '',
            enabled:  e.enabled          ?? true,
            constant: e.forceActivation  ?? false,
            priority: e.tokenBudget      ?? undefined,
            category: 'lore',
        }));
    }

    /**
     * 解析纯文本（每行一条）
     * 格式：关键词1,关键词2 | 内容
     * 或：  仅内容（无关键词）
     * @param {string} content
     * @param {string} defaultCategory
     * @returns {object[]}
     */
    _parseTextLines(content, defaultCategory) {
        return content
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && !line.startsWith('#'))
            .map(line => {
                // 尝试解析「关键词 | 内容」格式
                const pipeIdx = line.indexOf('|');
                if (pipeIdx > 0) {
                    const keysPart    = line.slice(0, pipeIdx).trim();
                    const contentPart = line.slice(pipeIdx + 1).trim();
                    const keys = keysPart.split(/[,，]/).map(k => k.trim()).filter(Boolean);
                    return { keys, content: contentPart, category: defaultCategory };
                }
                // 无关键词：整行作为内容
                return { keys: [], content: line, category: defaultCategory };
            });
    }

    /**
     * 解析纯文本（段落分隔）
     * 空行作为条目分隔符，第一行作为关键词
     * @param {string} content
     * @param {string} defaultCategory
     * @returns {object[]}
     */
    _parseTextBlocks(content, defaultCategory) {
        const blocks = content.split(/\n\s*\n/).map(b => b.trim()).filter(Boolean);
        return blocks.map(block => {
            const lines   = block.split('\n').map(l => l.trim()).filter(Boolean);
            if (lines.length === 0) return null;

            // 第一行作为标题/关键词（如果以特殊符号开头则去掉）
            const firstLine = lines[0].replace(/^[#*>【《「『\-]+\s*/, '').trim();
            const bodyLines = lines.slice(1);
            const body      = bodyLines.join('\n').trim() || firstLine;

            return {
                keys:     [firstLine],
                content:  body,
                category: defaultCategory,
            };
        }).filter(Boolean);
    }

    /**
     * 解析 CSV 格式
     * 列格式：关键词(s), 内容, [分类], [enabled]
     * @param {string} content
     * @param {string} defaultCategory
     * @returns {object[]}
     */
    _parseCSV(content, defaultCategory) {
        const lines = content.split('\n').map(l => l.trim()).filter(Boolean);
        // 检查是否有标题行
        const hasHeader = lines[0].toLowerCase().includes('key') ||
                          lines[0].toLowerCase().includes('content');
        const dataLines = hasHeader ? lines.slice(1) : lines;

        return dataLines.map(line => {
            const cols = _parseCSVLine(line);
            if (cols.length < 2) return null;

            const keysPart = cols[0] ?? '';
            const body     = cols[1] ?? '';
            const cat      = cols[2] ?? defaultCategory;

            const keys = keysPart.split(/[;；|｜]/).map(k => k.trim()).filter(Boolean);
            return {
                keys,
                content:  body,
                category: Object.keys(ENTRY_CATEGORIES).includes(cat) ? cat : defaultCategory,
            };
        }).filter(Boolean);
    }

    /**
     * 解析 Markdown 格式
     * ## 二级标题 = 条目标题（关键词）
     * 标题下的内容 = 条目内容
     * @param {string} content
     * @param {string} defaultCategory
     * @returns {object[]}
     */
    _parseMarkdown(content, defaultCategory) {
        const entries = [];
        // 按 ## 标题分割
        const sections = content.split(/^##\s+/m).filter(Boolean);

        for (const section of sections) {
            const firstNewline = section.indexOf('\n');
            if (firstNewline < 0) continue;

            const titleLine = section.slice(0, firstNewline).trim();
            const body      = section.slice(firstNewline + 1).trim();

            if (!titleLine || !body) continue;

            // 标题中可能包含分类标记，如「地点：长安城」
            let category = defaultCategory;
            let keyTitle = titleLine;
            const colonIdx = titleLine.indexOf('：');
            if (colonIdx > 0) {
                const prefix = titleLine.slice(0, colonIdx).trim();
                const catKey = Object.entries(ENTRY_CATEGORIES)
                    .find(([, v]) => v.label.includes(prefix))?.[0];
                if (catKey) {
                    category = catKey;
                    keyTitle = titleLine.slice(colonIdx + 1).trim();
                }
            }

            entries.push({
                keys:     [keyTitle],
                content:  body,
                category,
            });
        }
        return entries;
    }

    // ═══════════════════════════════════════════
    // 格式检测
    // ═══════════════════════════════════════════

    /**
     * 自动检测内容格式
     * @param {string} content
     * @param {string} filename
     * @returns {string}  IMPORT_FORMATS 的 key
     */
    _detectFormat(content, filename = '') {
        const trimmed = content.trim();
        const ext     = filename.split('.').pop()?.toLowerCase();

        // JSON 格式
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
            try {
                const parsed = JSON.parse(trimmed);
                // NovelAI 特征：存在 lorebookEntries 或 entries[].searchterms
                if (parsed.lorebookEntries || parsed.entries?.[0]?.searchterms) {
                    return 'nai_json';
                }
                return 'st_json';
            } catch {}
        }

        // Markdown
        if (ext === 'md' || (trimmed.includes('## ') && trimmed.includes('\n'))) {
            return 'markdown';
        }

        // CSV：包含逗号且每行列数一致
        const lines = trimmed.split('\n').slice(0, 5);
        const csvColCounts = lines.map(l => _parseCSVLine(l).length);
        if (csvColCounts.every(c => c >= 2) && ext === 'csv') {
            return 'csv';
        }

        // 纯文本：判断是否有段落间空行
        if (trimmed.includes('\n\n')) return 'text_blocks';

        return 'text_lines';
    }

    // ═══════════════════════════════════════════
    // AI 自动关键词填充
    // ═══════════════════════════════════════════

    /**
     * 对没有关键词的条目用 AI 自动填充
     * @param {object[]} rawEntries
     * @param {Function} onProgress
     * @returns {Promise<object[]>}
     */
    async _autoFillKeywords(rawEntries, onProgress) {
        const noKeyEntries = rawEntries.filter(e => !e.keys || e.keys.length === 0);
        const total = noKeyEntries.length;

        for (let i = 0; i < total; i++) {
            const entry = noKeyEntries[i];
            onProgress(
                60 + Math.round((i / total) * 30),
                `AI 提取关键词 ${i + 1}/${total}…`
            );
            try {
                const kwResults = await this._kwAnalyzer.extract(entry.content, {
                    maxKeywords: 5,
                    useAI:       true,
                });
                entry.keys = kwResults.map(k => k.text).filter(Boolean);
            } catch {
                // 单条失败不中断
                entry.keys = [];
            }
        }
        return rawEntries;
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 读取 File 对象为文本
 * @param {File} file
 * @returns {Promise<string>}
 */
function _readFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload  = e => resolve(e.target.result);
        reader.onerror = ()  => reject(new Error(`文件读取失败：${file.name}`));
        reader.readAsText(file, 'utf-8');
    });
}

/**
 * 解析 CSV 单行（处理引号内的逗号）
 * @param {string} line
 * @returns {string[]}
 */
function _parseCSVLine(line) {
    const result = [];
    let cur      = '';
    let inQuote  = false;

    for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
            if (inQuote && line[i + 1] === '"') { cur += '"'; i++; }
            else inQuote = !inQuote;
        } else if ((c === ',' || c === '，') && !inQuote) {
            result.push(cur.trim());
            cur = '';
        } else {
            cur += c;
        }
    }
    result.push(cur.trim());
    return result;
}