/**
 * @file modules/02_world-book/entry-builder.js
 * @description 世界书条目构建器
 *              提供符合 WB_ENTRY_SCHEMA 的条目工厂函数与合并/排序工具
 * @version 1.0.0
 */

import { WB_ENTRY_SCHEMA } from '../../contracts.js';

// ─────────────────────────────────────────────
// 分类常量
// ─────────────────────────────────────────────
export const ENTRY_CATEGORIES = Object.freeze({
    place:        { label: '🗺 地名/地点',  icon: '🗺',  insertionOrder: 80,  priority: 8  },
    character:    { label: '👤 人物',        icon: '👤',  insertionOrder: 90,  priority: 9  },
    organization: { label: '🏛 组织/势力',  icon: '🏛',  insertionOrder: 70,  priority: 7  },
    item:         { label: '⚔️ 物品/道具',  icon: '⚔️',  insertionOrder: 60,  priority: 6  },
    history:      { label: '📜 历史/事件',  icon: '📜',  insertionOrder: 50,  priority: 5  },
    rule:         { label: '⚙️ 规则/设定',  icon: '⚙️',  insertionOrder: 100, priority: 10 },
    concept:      { label: '💡 概念/术语',  icon: '💡',  insertionOrder: 65,  priority: 6  },
    lore:         { label: '🌟 传说/秘闻',  icon: '🌟',  insertionOrder: 55,  priority: 5  },
    custom:       { label: '✏️ 自定义',      icon: '✏️',  insertionOrder: 100, priority: 5  },
});

// 位置选项
export const ENTRY_POSITIONS = Object.freeze({
    before_char: '角色卡之前',
    after_char:  '角色卡之后',
    chat:        '聊天历史中',
});

// ─────────────────────────────────────────────
// UID 生成器（模块内简单自增，非持久化）
// ─────────────────────────────────────────────
let _uidCounter = 1;

function _nextUID() {
    return _uidCounter++;
}

/**
 * 重置 UID 计数器（用于测试）
 * @param {number} [start=1]
 */
export function resetUIDCounter(start = 1) {
    _uidCounter = start;
}

// ─────────────────────────────────────────────
// 核心工厂函数
// ─────────────────────────────────────────────

/**
 * 构建符合 WB_ENTRY_SCHEMA 的条目对象
 * @param {object} options
 * @param {string[]}  options.keys              触发关键词
 * @param {string}    options.content           条目内容
 * @param {string}    [options.category]        分类 key
 * @param {string[]}  [options.secondary_keys]  次级关键词
 * @param {boolean}   [options.enabled=true]
 * @param {boolean}   [options.constant=false]  是否常驻
 * @param {boolean}   [options.selective=false] 是否选择性触发
 * @param {string}    [options.position]        插入位置
 * @param {number}    [options.insertion_order]
 * @param {number}    [options.priority]
 * @param {number}    [options.depth]
 * @param {object}    [options.extensions]
 * @returns {WBEntry}
 */
export function buildEntry(options = {}) {
    const catDef   = ENTRY_CATEGORIES[options.category] ?? ENTRY_CATEGORIES.custom;
    const uid      = options.uid ?? _nextUID();

    return {
        ...JSON.parse(JSON.stringify(WB_ENTRY_SCHEMA)),   // 深拷贝默认值
        uid,
        keys:             options.keys             ?? [],
        secondary_keys:   options.secondary_keys   ?? [],
        content:          options.content          ?? '',
        enabled:          options.enabled          ?? true,
        insertion_order:  options.insertion_order  ?? catDef.insertionOrder,
        priority:         options.priority         ?? catDef.priority,
        position:         options.position         ?? 'before_char',
        depth:            options.depth            ?? 4,
        selective:        options.selective        ?? false,
        constant:         options.constant         ?? false,
        category:         options.category         ?? 'custom',
        extensions:       options.extensions       ?? {},
    };
}

// ─────────────────────────────────────────────
// 分类工厂函数（预设默认值）
// ─────────────────────────────────────────────

/**
 * 创建地名/地点条目
 * @param {string}   name     地名
 * @param {string}   content  详细描述
 * @param {string[]} [keys]   关键词（默认用名称）
 * @returns {WBEntry}
 */
export function createPlaceEntry(name, content, keys) {
    return buildEntry({
        keys:     keys ?? [name],
        content,
        category: 'place',
        position: 'before_char',
        extensions: { cardforge_name: name },
    });
}

/**
 * 创建人物条目
 * @param {string}   name
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createCharacterEntry(name, content, keys) {
    return buildEntry({
        keys:     keys ?? [name],
        content,
        category: 'character',
        position: 'before_char',
        priority: 9,
        extensions: { cardforge_name: name },
    });
}

/**
 * 创建组织/势力条目
 * @param {string}   name
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createOrganizationEntry(name, content, keys) {
    return buildEntry({
        keys:     keys ?? [name],
        content,
        category: 'organization',
        position: 'before_char',
        extensions: { cardforge_name: name },
    });
}

/**
 * 创建物品/道具条目
 * @param {string}   name
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createItemEntry(name, content, keys) {
    return buildEntry({
        keys:     keys ?? [name],
        content,
        category: 'item',
        extensions: { cardforge_name: name },
    });
}

/**
 * 创建历史/事件条目
 * @param {string}   title    事件名
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createHistoryEntry(title, content, keys) {
    return buildEntry({
        keys:     keys ?? [title],
        content,
        category: 'history',
        position: 'before_char',
        extensions: { cardforge_name: title },
    });
}

/**
 * 创建规则/设定条目（常驻）
 * @param {string}   name
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createRuleEntry(name, content, keys) {
    return buildEntry({
        keys:     keys ?? [name],
        content,
        category:  'rule',
        constant:  true,       // 规则条目默认常驻
        priority:  10,
        position: 'before_char',
        extensions: { cardforge_name: name },
    });
}

/**
 * 创建概念/术语条目
 * @param {string}   term
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createConceptEntry(term, content, keys) {
    return buildEntry({
        keys:     keys ?? [term],
        content,
        category: 'concept',
        extensions: { cardforge_name: term },
    });
}

/**
 * 创建传说/秘闻条目
 * @param {string}   title
 * @param {string}   content
 * @param {string[]} [keys]
 * @returns {WBEntry}
 */
export function createLoreEntry(title, content, keys) {
    return buildEntry({
        keys:     keys ?? [title],
        content,
        category: 'lore',
        selective: true,    // 传说条目默认选择性触发
        extensions: { cardforge_name: title },
    });
}

// ─────────────────────────────────────────────
// 条目合并
// ─────────────────────────────────────────────

/**
 * 合并两个条目数组，自动处理重复和冲突
 * 合并策略：
 *   - UID 相同 → 以 incoming 为准更新
 *   - 关键词完全相同 → 以 incoming 为准更新（视为同一条目的更新版本）
 *   - 其他 → 直接追加，重新分配 UID
 *
 * @param {WBEntry[]} existing  现有条目
 * @param {WBEntry[]} incoming  新条目
 * @returns {{ merged: WBEntry[], stats: MergeStats }}
 */
export function mergeEntries(existing, incoming) {
    const result = [...existing];
    const stats  = { added: 0, updated: 0, skipped: 0 };

    const existingByUID  = new Map(existing.map(e => [e.uid,  e]));
    const existingByKeys = new Map(existing.map(e => [_keysFingerprint(e.keys), e]));

    for (const entry of incoming) {
        const keysFP = _keysFingerprint(entry.keys);

        if (existingByUID.has(entry.uid)) {
            // UID 匹配：更新现有条目
            const idx = result.findIndex(e => e.uid === entry.uid);
            if (idx >= 0) {
                result[idx] = { ...result[idx], ...entry, uid: result[idx].uid };
                stats.updated++;
            }
        } else if (existingByKeys.has(keysFP)) {
            // 关键词匹配：视为同一条目更新
            const existingEntry = existingByKeys.get(keysFP);
            const idx = result.findIndex(e => e.uid === existingEntry.uid);
            if (idx >= 0) {
                result[idx] = { ...result[idx], ...entry, uid: result[idx].uid };
                stats.updated++;
            }
        } else {
            // 全新条目：分配新 UID
            result.push({ ...entry, uid: _nextUID() });
            stats.added++;
        }
    }

    return { merged: result, stats };
}

// ─────────────────────────────────────────────
// 条目排序
// ─────────────────────────────────────────────

/**
 * 对条目数组排序
 * @param {WBEntry[]} entries
 * @param {'priority'|'category'|'insertion_order'|'uid'} by
 * @param {'asc'|'desc'} [order='desc']
 * @returns {WBEntry[]}  新数组，原数组不变
 */
export function sortEntries(entries, by = 'insertion_order', order = 'desc') {
    const comparators = {
        priority:        (a, b) => b.priority        - a.priority,
        insertion_order: (a, b) => a.insertion_order - b.insertion_order,
        uid:             (a, b) => a.uid              - b.uid,
        category:        (a, b) => {
            const catOrder = Object.keys(ENTRY_CATEGORIES);
            const ia = catOrder.indexOf(a.category);
            const ib = catOrder.indexOf(b.category);
            return ia - ib;
        },
    };

    const cmp = comparators[by] ?? comparators.insertion_order;
    const sorted = [...entries].sort(cmp);
    return order === 'asc' ? sorted : sorted.reverse();
}

// ─────────────────────────────────────────────
// 条目验证
// ─────────────────────────────────────────────

/**
 * 验证单个条目
 * @param {WBEntry} entry
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
export function validateEntry(entry) {
    const errors   = [];
    const warnings = [];

    if (!entry.keys || entry.keys.length === 0) {
        errors.push('条目缺少关键词（keys），将永远不会触发');
    }
    if (!entry.content || entry.content.trim() === '') {
        errors.push('条目内容（content）为空');
    }
    if (entry.content && entry.content.length > 2000) {
        warnings.push(`条目内容过长（${entry.content.length} 字），可能影响 Token 预算`);
    }
    if (entry.keys && entry.keys.some(k => k.length < 2)) {
        warnings.push('部分关键词过短（少于2个字符），可能导致误触发');
    }
    if (!ENTRY_POSITIONS[entry.position]) {
        warnings.push(`未知的 position 值：${entry.position}，将使用默认值 before_char`);
    }

    return { valid: errors.length === 0, errors, warnings };
}

/**
 * 检测多个条目之间的关键词冲突
 * @param {WBEntry[]} entries
 * @returns {Array<{ key: string, uids: number[] }>}  冲突列表
 */
export function detectKeywordConflicts(entries) {
    const keyMap = new Map();  // key → [uid, ...]

    for (const entry of entries) {
        for (const k of (entry.keys ?? [])) {
            const normalized = k.trim().toLowerCase();
            if (!keyMap.has(normalized)) keyMap.set(normalized, []);
            keyMap.get(normalized).push(entry.uid);
        }
    }

    return [...keyMap.entries()]
        .filter(([, uids]) => uids.length > 1)
        .map(([key, uids]) => ({ key, uids }));
}

// ─────────────────────────────────────────────
// 序列化
// ─────────────────────────────────────────────

/**
 * 将条目数组序列化为标准世界书 JSON 格式
 * @param {WBEntry[]} entries
 * @param {string}    [name]  世界书名称
 * @returns {object}
 */
export function entriesToWorldBook(entries, name = 'CardForge WorldBook') {
    const entriesObj = {};
    entries.forEach((entry, idx) => {
        entriesObj[idx] = { ...entry };
    });
    return {
        name,
        entries:  entriesObj,
        version:  2,
        generatedBy: 'ST-CardForge Pro',
    };
}

/**
 * 从标准世界书 JSON 解析条目数组
 * @param {object} worldbookJSON
 * @returns {WBEntry[]}
 */
export function worldBookToEntries(worldbookJSON) {
    const entriesObj = worldbookJSON.entries ?? {};
    return Object.values(entriesObj).map(e => ({
        ...JSON.parse(JSON.stringify(WB_ENTRY_SCHEMA)),
        ...e,
    }));
}

// ─────────────────────────────────────────────
// 内部工具
// ─────────────────────────────────────────────

/**
 * 生成关键词指纹（用于去重判断）
 * @param {string[]} keys
 * @returns {string}
 */
function _keysFingerprint(keys) {
    if (!keys || keys.length === 0) return '';
    return [...keys].map(k => k.trim().toLowerCase()).sort().join('|');
}