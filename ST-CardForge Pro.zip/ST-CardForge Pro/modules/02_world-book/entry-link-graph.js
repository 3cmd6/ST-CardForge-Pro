/**
 * @file modules/02_world-book/entry-link-graph.js
 * @description 世界书条目关联图
 *              分析条目之间的关键词引用关系，构建有向图并检测孤立/循环依赖
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 数据结构定义
// ─────────────────────────────────────────────

/**
 * @typedef {Object} LinkNode
 * @property {number}   uid       条目 UID
 * @property {string}   label     条目显示名（取第一个 key）
 * @property {string}   category  条目分类
 * @property {number[]} outLinks  指向的条目 UID 列表
 * @property {number[]} inLinks   被哪些条目指向的 UID 列表
 */

/**
 * @typedef {Object} LinkEdge
 * @property {number} sourceUid
 * @property {number} targetUid
 * @property {string} matchedKey  匹配到的关键词
 */

// ─────────────────────────────────────────────
// EntryLinkGraph 类
// ─────────────────────────────────────────────
export class EntryLinkGraph {
    constructor() {
        /** @type {Map<number, LinkNode>} */
        this._nodes = new Map();
        /** @type {LinkEdge[]} */
        this._edges = [];
    }

    // ═══════════════════════════════════════════
    // 构建图
    // ═══════════════════════════════════════════

    /**
     * 从条目数组构建关联图
     * 分析每个条目的 content 中是否引用了其他条目的 keys
     * @param {object[]} entries  WBEntry 数组
     */
    build(entries) {
        this._nodes.clear();
        this._edges = [];

        // 第一遍：建立节点
        for (const entry of entries) {
            this._nodes.set(entry.uid, {
                uid:      entry.uid,
                label:    entry.keys?.[0] ?? `条目#${entry.uid}`,
                category: entry.category ?? 'custom',
                outLinks: [],
                inLinks:  [],
            });
        }

        // 第二遍：分析 content 中的关键词引用，建立边
        for (const entry of entries) {
            const content = (entry.content ?? '').toLowerCase();
            for (const other of entries) {
                if (other.uid === entry.uid) continue;
                for (const key of (other.keys ?? [])) {
                    if (key.length < 2) continue;
                    // 精确词边界匹配（避免误匹配）
                    const escaped = _escapeRegex(key.toLowerCase());
                    const pattern = new RegExp(`(?:^|[\\s，。！？、【《「『])(${escaped})(?:[\\s，。！？、】》」』]|$)`);
                    if (pattern.test(content)) {
                        this._addEdge(entry.uid, other.uid, key);
                        break;  // 同一对条目只记录一条边
                    }
                }
            }
        }
    }

    // ═══════════════════════════════════════════
    // 图查询
    // ═══════════════════════════════════════════

    /**
     * 获取所有节点
     * @returns {LinkNode[]}
     */
    getNodes() {
        return [...this._nodes.values()];
    }

    /**
     * 获取所有边
     * @returns {LinkEdge[]}
     */
    getEdges() {
        return [...this._edges];
    }

    /**
     * 获取孤立节点（既没有出链也没有入链）
     * @returns {LinkNode[]}
     */
    getIsolatedNodes() {
        return [...this._nodes.values()].filter(
            n => n.outLinks.length === 0 && n.inLinks.length === 0
        );
    }

    /**
     * 获取指定节点的直接邻居
     * @param {number} uid
     * @returns {{ outbound: LinkNode[], inbound: LinkNode[] }}
     */
    getNeighbors(uid) {
        const node = this._nodes.get(uid);
        if (!node) return { outbound: [], inbound: [] };
        return {
            outbound: node.outLinks.map(id => this._nodes.get(id)).filter(Boolean),
            inbound:  node.inLinks.map(id  => this._nodes.get(id)).filter(Boolean),
        };
    }

    /**
     * 检测循环依赖（有向图环检测，DFS）
     * @returns {Array<number[]>}  每个数组是一个环的 UID 序列
     */
    detectCycles() {
        const visited  = new Set();
        const recStack = new Set();
        const cycles   = [];

        const dfs = (uid, path) => {
            visited.add(uid);
            recStack.add(uid);
            path.push(uid);

            const node = this._nodes.get(uid);
            for (const neighborUid of (node?.outLinks ?? [])) {
                if (!visited.has(neighborUid)) {
                    dfs(neighborUid, [...path]);
                } else if (recStack.has(neighborUid)) {
                    // 找到环：截取从 neighborUid 开始的路径
                    const cycleStart = path.indexOf(neighborUid);
                    if (cycleStart !== -1) {
                        cycles.push(path.slice(cycleStart));
                    }
                }
            }
            recStack.delete(uid);
        };

        for (const uid of this._nodes.keys()) {
            if (!visited.has(uid)) dfs(uid, []);
        }
        return cycles;
    }

    /**
     * 按拓扑顺序排列条目 UID（无循环时可用）
     * 返回建议的 insertion_order 序列
     * @returns {number[]}  排序后的 UID 列表（被依赖的排前面）
     */
    topologicalSort() {
        const inDegree  = new Map();
        const queue     = [];
        const result    = [];

        for (const [uid, node] of this._nodes) {
            inDegree.set(uid, node.inLinks.length);
            if (node.inLinks.length === 0) queue.push(uid);
        }

        while (queue.length > 0) {
            const uid  = queue.shift();
            result.push(uid);
            const node = this._nodes.get(uid);
            for (const outUid of (node?.outLinks ?? [])) {
                const deg = (inDegree.get(outUid) ?? 0) - 1;
                inDegree.set(outUid, deg);
                if (deg <= 0) queue.push(outUid);
            }
        }

        // 处理有环的情况：剩余节点直接追加
        for (const uid of this._nodes.keys()) {
            if (!result.includes(uid)) result.push(uid);
        }
        return result;
    }

    /**
     * 获取图的统计摘要
     * @returns {GraphStats}
     */
    getStats() {
        const nodes    = [...this._nodes.values()];
        const isolated = this.getIsolatedNodes();
        const cycles   = this.detectCycles();
        const maxLinks = nodes.reduce((m, n) => Math.max(m, n.outLinks.length + n.inLinks.length), 0);

        return {
            nodeCount:    nodes.length,
            edgeCount:    this._edges.length,
            isolatedCount: isolated.length,
            cycleCount:   cycles.length,
            maxDegreeNode: nodes.find(n => n.outLinks.length + n.inLinks.length === maxLinks),
            density:      nodes.length > 1
                ? this._edges.length / (nodes.length * (nodes.length - 1))
                : 0,
        };
    }

    // ═══════════════════════════════════════════
    // SVG 渲染
    // ═══════════════════════════════════════════

    /**
     * 渲染关联图为 SVG
     * @param {object} [opts]
     * @param {number} [opts.width=700]
     * @param {number} [opts.height=460]
     * @param {number} [opts.maxNodes=30]  超出时截断（性能保护）
     * @returns {string}
     */
    renderSVG({ width = 700, height = 460, maxNodes = 30 } = {}) {
        const nodes = [...this._nodes.values()].slice(0, maxNodes);
        const uids  = new Set(nodes.map(n => n.uid));
        const edges = this._edges.filter(
            e => uids.has(e.sourceUid) && uids.has(e.targetUid)
        );

        if (nodes.length === 0) {
            return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"
                style="background:var(--cf-bg-card,#16213e);border-radius:8px">
                <text x="${width/2}" y="${height/2}" text-anchor="middle"
                      dominant-baseline="middle" font-size="13"
                      fill="rgba(255,255,255,0.3)">暂无条目关联数据</text>
            </svg>`;
        }

        const positions = _circleLayout(nodes, width, height);
        const CATEGORY_COLORS = {
            place:        '#3498db',
            character:    '#2ecc71',
            organization: '#f39c12',
            item:         '#e74c3c',
            history:      '#9b59b6',
            rule:         '#1abc9c',
            concept:      '#e67e22',
            lore:         '#e91e8c',
            custom:       '#95a5a6',
        };

        const edgeSVGs = edges.map(e => {
            const src = positions[e.sourceUid];
            const tgt = positions[e.targetUid];
            if (!src || !tgt) return '';
            return `<line x1="${src.x}" y1="${src.y}" x2="${tgt.x}" y2="${tgt.y}"
                stroke="rgba(255,255,255,0.18)" stroke-width="1"
                marker-end="url(#cf-link-arrow)" />`;
        }).join('\n');

        const nodeSVGs = nodes.map(n => {
            const pos   = positions[n.uid];
            if (!pos) return '';
            const r     = 18 + Math.min(n.outLinks.length + n.inLinks.length, 6) * 2;
            const color = CATEGORY_COLORS[n.category] ?? '#95a5a6';
            const label = n.label.length > 5 ? n.label.slice(0, 4) + '…' : n.label;
            return `<g>
    <circle cx="${pos.x}" cy="${pos.y}" r="${r}"
            fill="${color}33" stroke="${color}" stroke-width="1.5" />
    <text x="${pos.x}" y="${pos.y}" text-anchor="middle"
          dominant-baseline="middle" font-size="10"
          font-weight="600" fill="${color}">${_esc(label)}</text>
</g>`;
        }).join('\n');

        return `<svg xmlns="http://www.w3.org/2000/svg"
    width="${width}" height="${height}"
    viewBox="0 0 ${width} ${height}"
    style="background:var(--cf-bg-card,#16213e);border-radius:8px;
           font-family:system-ui,sans-serif">
    <defs>
        <marker id="cf-link-arrow" markerWidth="6" markerHeight="6"
                refX="5" refY="3" orient="auto">
            <path d="M0,0 L0,6 L6,3 z" fill="rgba(255,255,255,0.3)" />
        </marker>
    </defs>
    ${edgeSVGs}
    ${nodeSVGs}
    ${nodes.length >= maxNodes
        ? `<text x="10" y="${height - 10}" font-size="10"
                 fill="rgba(255,255,255,0.4)">仅显示前 ${maxNodes} 个条目</text>`
        : ''}
</svg>`;
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _addEdge(sourceUid, targetUid, matchedKey) {
        // 避免重复边
        const exists = this._edges.some(
            e => e.sourceUid === sourceUid && e.targetUid === targetUid
        );
        if (exists) return;

        this._edges.push({ sourceUid, targetUid, matchedKey });

        const srcNode = this._nodes.get(sourceUid);
        const tgtNode = this._nodes.get(targetUid);
        if (srcNode && !srcNode.outLinks.includes(targetUid)) {
            srcNode.outLinks.push(targetUid);
        }
        if (tgtNode && !tgtNode.inLinks.includes(sourceUid)) {
            tgtNode.inLinks.push(sourceUid);
        }
    }
}

// ─────────────────────────────────────────────
// 布局辅助
// ─────────────────────────────────────────────

function _circleLayout(nodes, width, height) {
    const cx = width  / 2;
    const cy = height / 2;
    const r  = Math.min(width, height) * 0.4;
    const positions = {};

    nodes.forEach((node, i) => {
        const angle = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
        positions[node.uid] = {
            x: cx + r * Math.cos(angle),
            y: cy + r * Math.sin(angle),
        };
    });
    return positions;
}

function _escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function _esc(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}