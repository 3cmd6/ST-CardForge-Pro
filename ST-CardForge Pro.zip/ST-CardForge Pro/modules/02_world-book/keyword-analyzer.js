/**
 * @file modules/02_world-book/keyword-analyzer.js
 * @description 关键词分析器
 *              从文本中提取关键词、扩展同义词、检测冲突
 *              使用 AI 辅助 + 启发式规则双通道
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import { eventBus } from '../../core/event-bus.js';

// ─────────────────────────────────────────────
// 停用词表（中英双语，过滤无意义词）
// ─────────────────────────────────────────────
const STOP_WORDS_ZH = new Set([
    '的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一',
    '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着',
    '没有', '看', '好', '自己', '这', '那', '他', '她', '它', '们', '与',
    '为', '以', '及', '或', '但', '而', '如', '其', '已', '被', '将', '可',
    '来', '过', '再', '又', '则', '对', '更', '使', '等', '后', '前',
]);

const STOP_WORDS_EN = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'not', 'no', 'nor', 'so',
    'yet', 'both', 'either', 'neither', 'it', 'its', 'this', 'that',
    'these', 'those', 'i', 'you', 'he', 'she', 'we', 'they', 'who', 'what',
    'which', 'when', 'where', 'why', 'how', 'all', 'each', 'every', 'any',
]);

// ─────────────────────────────────────────────
// KeywordAnalyzer 类
// ─────────────────────────────────────────────
export class KeywordAnalyzer {
    /**
     * @param {import('../../core/ai-engine.js').AIEngine} aiEngine
     */
    constructor(aiEngine) {
        this._ai    = aiEngine;
        this._cache = new Map();    // 简单内存缓存，key = 文本 hash
    }

    // ═══════════════════════════════════════════
    // 主接口：关键词提取
    // ═══════════════════════════════════════════

    /**
     * 从文本中提取关键词
     * 双通道：启发式快速提取 + AI 深度分析
     * @param {string}   text
     * @param {object}   [options]
     * @param {number}   [options.maxKeywords=10]      最多关键词数
     * @param {boolean}  [options.includeVariants=true] 包含变体/别名
     * @param {'zh'|'en'|'auto'} [options.language='auto'] 文本语言
     * @param {boolean}  [options.useAI=true]           是否使用 AI 深度提取
     * @param {string[]} [options.exclude]              排除的词
     * @returns {Promise<KeywordResult[]>}
     */
    async extract(text, options = {}) {
        const {
            maxKeywords    = 10,
            includeVariants = true,
            language       = 'auto',
            useAI          = true,
            exclude        = [],
        } = options;

        if (!text || typeof text !== 'string') return [];

        const excludeSet = new Set(exclude.map(e => e.toLowerCase()));

        // ── 第一通道：启发式提取（快速，离线）
        const heuristicKws = this._heuristicExtract(text, { language, maxKeywords: maxKeywords * 2 });

        // ── 第二通道：AI 深度提取（如果启用且文本足够长）
        let aiKws = [];
        if (useAI && text.length > 100) {
            try {
                aiKws = await this._aiExtract(text, { maxKeywords, language });
            } catch (err) {
                console.warn('[KeywordAnalyzer] AI 提取失败，使用启发式结果', err);
            }
        }

        // ── 合并与去重
        const merged = this._mergeKeywords(heuristicKws, aiKws, {
            maxKeywords,
            excludeSet,
        });

        // ── 可选：扩展变体
        if (includeVariants && merged.length > 0) {
            for (const kw of merged) {
                kw.variants = this._generateVariants(kw.text, language);
            }
        }

        return merged;
    }

    // ═══════════════════════════════════════════
    // 同义词 / 别名扩展
    // ═══════════════════════════════════════════

    /**
     * 扩展关键词的同义词和别名（AI 辅助）
     * @param {string[]} keywords
     * @param {string}   [language='auto']
     * @returns {Promise<Map<string, string[]>>}  key → [同义词...]
     */
    async expandSynonyms(keywords, language = 'auto') {
        if (!keywords || keywords.length === 0) return new Map();

        const prompt = this._buildExpansionPrompt(keywords, language);

        try {
            const raw = await this._ai.generateCard(
                `你是一位语言学专家，专门为角色扮演世界书生成关键词别名和同义词。
请严格按照 JSON 格式返回，不要添加任何说明。`,
                prompt
            );

            const parsed = typeof raw === 'object' ? raw : _tryParseJSON(raw);
            if (!parsed) return new Map();

            const result = new Map();
            for (const [kw, synonyms] of Object.entries(parsed)) {
                if (Array.isArray(synonyms)) {
                    result.set(kw, synonyms.filter(s => typeof s === 'string' && s.trim()));
                }
            }
            return result;

        } catch (err) {
            console.warn('[KeywordAnalyzer] 同义词扩展失败', err);
            return new Map();
        }
    }

    // ═══════════════════════════════════════════
    // 冲突检测
    // ═══════════════════════════════════════════

    /**
     * 检测两组条目的关键词是否有重叠（冲突）
     * @param {object[]} entriesA
     * @param {object[]} entriesB
     * @returns {Array<{ keyword: string, inA: number[], inB: number[] }>}
     */
    detectConflicts(entriesA, entriesB) {
        const mapA = this._buildKeywordMap(entriesA);
        const mapB = this._buildKeywordMap(entriesB);
        const conflicts = [];

        for (const [kw, uidsA] of mapA) {
            if (mapB.has(kw)) {
                conflicts.push({
                    keyword: kw,
                    inA:     uidsA,
                    inB:     mapB.get(kw),
                });
            }
        }
        return conflicts;
    }

    // ═══════════════════════════════════════════
    // 关键词权重评分
    // ═══════════════════════════════════════════

    /**
     * 给关键词列表评分（基于上下文中的重要性）
     * @param {string[]} keywords
     * @param {string}   context   参考文本
     * @returns {Array<{ text: string, score: number }>}
     */
    scoreKeywords(keywords, context) {
        return keywords.map(kw => ({
            text:  kw,
            score: this._scoreKeyword(kw, context),
        })).sort((a, b) => b.score - a.score);
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    /**
     * 启发式关键词提取（纯本地，无 AI）
     * 策略：
     *   1. 提取大写专有名词（英文）
     *   2. 提取《》【】「」包围的词（中文专有名词标记）
     *   3. 提取高频非停用词
     *   4. 提取 2~6 字的名词短语
     * @param {string} text
     * @param {object} opts
     * @returns {KeywordResult[]}
     */
    _heuristicExtract(text, opts = {}) {
        const { language = 'auto', maxKeywords = 20 } = opts;
        const detectedLang = language === 'auto' ? this._detectLanguage(text) : language;
        const results = new Map();   // text.lower → { text, score, source }

        // ── 策略1：专有名词标记提取（《》【】「」引号内容）
        const bracketMatches = [
            ...text.matchAll(/《([^》]{1,20})》/g),
            ...text.matchAll(/【([^】]{1,20})】/g),
            ...text.matchAll(/「([^」]{1,20})」/g),
            ...text.matchAll(/『([^』]{1,20})』/g),
        ];
        for (const m of bracketMatches) {
            const word = m[1].trim();
            if (word && !STOP_WORDS_ZH.has(word)) {
                _upsertKW(results, word, 3.0, 'bracket');
            }
        }

        // ── 策略2：英文专有名词（连续大写开头的词）
        if (detectedLang === 'en' || detectedLang === 'mixed') {
            const properNouns = text.match(/\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]+){0,3}\b/g) ?? [];
            for (const w of properNouns) {
                if (!STOP_WORDS_EN.has(w.toLowerCase())) {
                    _upsertKW(results, w, 2.5, 'proper-noun');
                }
            }
        }

        // ── 策略3：高频词提取
        const tokens = this._tokenize(text, detectedLang);
        const freqMap = new Map();
        for (const t of tokens) {
            freqMap.set(t, (freqMap.get(t) ?? 0) + 1);
        }
        for (const [word, freq] of freqMap) {
            if (freq >= 2 && word.length >= 2) {
                _upsertKW(results, word, freq * 0.5, 'frequency');
            }
        }

        // ── 策略4：中文 2~4 字名词短语（正则模式）
        if (detectedLang === 'zh' || detectedLang === 'mixed') {
            // 匹配 2~4 个汉字的词（避免停用词）
            const zhPhrases = text.match(/[\u4e00-\u9fff]{2,4}/g) ?? [];
            for (const phrase of zhPhrases) {
                if (!STOP_WORDS_ZH.has(phrase)) {
                    _upsertKW(results, phrase, 1.0, 'zh-phrase');
                }
            }
        }

        // ── 过滤 + 排序 + 截取
        return [...results.values()]
            .filter(kw => kw.text.length >= 2 && kw.text.length <= 20)
            .sort((a, b) => b.score - a.score)
            .slice(0, maxKeywords)
            .map(kw => ({ text: kw.text, score: kw.score, source: kw.source, variants: [] }));
    }

    /**
     * AI 深度关键词提取
     * @param {string} text
     * @param {object} opts
     * @returns {Promise<KeywordResult[]>}
     */
    async _aiExtract(text, opts = {}) {
        const { maxKeywords = 10, language = 'auto' } = opts;

        const cacheKey = _hashText(text.slice(0, 500));
        if (this._cache.has(cacheKey)) {
            return this._cache.get(cacheKey);
        }

        const langHint = language === 'zh' || language === 'auto'
            ? '关键词可以是中文或英文'
            : 'keywords in English';

        const prompt = `从以下角色扮演文本中提取最重要的关键词（专有名词、地名、人名、特殊术语等）。
这些关键词将用于触发世界书条目，需要准确且具有辨识度。
${langHint}，最多 ${maxKeywords} 个，按重要性排序。

文本：
${text.slice(0, 800)}

严格按以下 JSON 格式返回（只要关键词文本，不要解释）：
["词1", "词2", "词3", ...]`;

        const raw     = await this._ai.generateCard('', prompt);
        const parsed  = typeof raw === 'object' && Array.isArray(raw)
            ? raw
            : _tryParseJSON(String(raw));

        const results = (Array.isArray(parsed) ? parsed : [])
            .filter(k => typeof k === 'string' && k.trim())
            .slice(0, maxKeywords)
            .map((text, idx) => ({
                text:     text.trim(),
                score:    (maxKeywords - idx) / maxKeywords * 2.0,
                source:   'ai',
                variants: [],
            }));

        this._cache.set(cacheKey, results);
        return results;
    }

    /**
     * 合并启发式和 AI 提取的关键词
     * @param {KeywordResult[]} heuristic
     * @param {KeywordResult[]} ai
     * @param {object} opts
     * @returns {KeywordResult[]}
     */
    _mergeKeywords(heuristic, ai, opts = {}) {
        const { maxKeywords = 10, excludeSet = new Set() } = opts;
        const seen   = new Map();   // lower → KeywordResult

        // AI 结果优先级更高（加 1.5 分）
        for (const kw of ai) {
            const lower = kw.text.toLowerCase();
            if (!excludeSet.has(lower)) {
                seen.set(lower, { ...kw, score: kw.score + 1.5, source: 'ai' });
            }
        }

        for (const kw of heuristic) {
            const lower = kw.text.toLowerCase();
            if (!excludeSet.has(lower)) {
                if (seen.has(lower)) {
                    // 两者都提取到：加分
                    seen.get(lower).score += kw.score * 0.5;
                    seen.get(lower).source = 'both';
                } else {
                    seen.set(lower, { ...kw });
                }
            }
        }

        return [...seen.values()]
            .sort((a, b) => b.score - a.score)
            .slice(0, maxKeywords);
    }

    /**
     * 生成关键词的常见变体（简/繁/缩写/拼音首字母等）
     * @param {string} text
     * @param {string} language
     * @returns {string[]}
     */
    _generateVariants(text, language) {
        const variants = new Set();

        // 全角 / 半角变体
        variants.add(text.replace(/[Ａ-Ｚａ-ｚ０-９]/g, c =>
            String.fromCharCode(c.charCodeAt(0) - 0xFEE0)
        ));

        // 英文：大小写变体
        if (/[a-zA-Z]/.test(text)) {
            variants.add(text.toLowerCase());
            variants.add(text.toUpperCase());
            // 首字母大写
            variants.add(text.charAt(0).toUpperCase() + text.slice(1).toLowerCase());
        }

        // 去除空格变体
        if (text.includes(' ')) {
            variants.add(text.replace(/\s+/g, ''));
            variants.add(text.replace(/\s+/g, '_'));
        }

        // 去除本体
        variants.delete(text);
        return [...variants].filter(v => v && v !== text);
    }

    /**
     * 对单个文本分词
     * @param {string} text
     * @param {string} language
     * @returns {string[]}
     */
    _tokenize(text, language) {
        const tokens = [];
        if (language === 'zh' || language === 'mixed') {
            // 中文按单字拆分（简化版，无完整分词库）
            // 同时提取 2~4 字组合（滑动窗口）
            const chars = [...text.replace(/[^\u4e00-\u9fff]/g, ' ').split(/\s+/)
                .filter(Boolean)];
            for (const seg of chars) {
                for (let i = 0; i < seg.length; i++) {
                    for (let len = 2; len <= Math.min(4, seg.length - i); len++) {
                        const slice = seg.slice(i, i + len);
                        if (!STOP_WORDS_ZH.has(slice)) tokens.push(slice);
                    }
                }
            }
        }
        if (language === 'en' || language === 'mixed') {
            const words = text.toLowerCase().match(/\b[a-z]{3,}\b/g) ?? [];
            for (const w of words) {
                if (!STOP_WORDS_EN.has(w)) tokens.push(w);
            }
        }
        return tokens;
    }

    /**
     * 检测文本语言
     * @param {string} text
     * @returns {'zh'|'en'|'mixed'}
     */
    _detectLanguage(text) {
        const zhCount  = (text.match(/[\u4e00-\u9fff]/g) ?? []).length;
        const enCount  = (text.match(/[a-zA-Z]/g) ?? []).length;
        const total    = zhCount + enCount;
        if (total === 0) return 'zh';
        const zhRatio  = zhCount / total;
        if (zhRatio > 0.7)  return 'zh';
        if (zhRatio < 0.3)  return 'en';
        return 'mixed';
    }

    /**
     * 单个关键词评分
     * 考量：长度、在文本中出现的位置（标题更重要）、是否为专有名词
     * @param {string} kw
     * @param {string} context
     * @returns {number}
     */
    _scoreKeyword(kw, context) {
        let score = 1.0;
        const lower    = kw.toLowerCase();
        const ctxLower = context.toLowerCase();

        // 出现频次
        const freq = (ctxLower.match(new RegExp(_escapeRegex(lower), 'g')) ?? []).length;
        score += freq * 0.3;

        // 长度奖励（3~6 字最优）
        if (kw.length >= 3 && kw.length <= 6)  score += 0.5;
        if (kw.length > 10)                     score -= 0.3;

        // 首次出现在文本前 20%
        const pos = ctxLower.indexOf(lower);
        if (pos !== -1 && pos < context.length * 0.2) score += 0.4;

        // 专有名词：首字母大写（英文）
        if (/^[A-Z]/.test(kw))  score += 0.3;

        // 被书名号包裹
        if (context.includes(`《${kw}》`) || context.includes(`【${kw}】`)) score += 1.0;

        return Math.max(0, score);
    }

    /**
     * 构建关键词扩展的 Prompt
     * @param {string[]} keywords
     * @param {string}   language
     * @returns {string}
     */
    _buildExpansionPrompt(keywords, language) {
        const langHint = language === 'en'
            ? '返回英文同义词和别名'
            : '返回中文和英文同义词、别名、常见写法变体';

        return `为以下角色扮演世界书关键词生成同义词和别名。
${langHint}，每个关键词最多3个变体。

关键词列表：${keywords.join('、')}

严格按以下 JSON 格式返回：
{
  "关键词1": ["别名1", "别名2"],
  "关键词2": ["别名1"],
  ...
}`;
    }

    /**
     * 构建关键词 → UID 的映射表
     * @param {object[]} entries
     * @returns {Map<string, number[]>}
     */
    _buildKeywordMap(entries) {
        const map = new Map();
        for (const entry of entries) {
            for (const k of (entry.keys ?? [])) {
                const normalized = k.trim().toLowerCase();
                if (!map.has(normalized)) map.set(normalized, []);
                map.get(normalized).push(entry.uid);
            }
        }
        return map;
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 在 Map 中更新或插入关键词
 * @param {Map} map
 * @param {string} text
 * @param {number} score
 * @param {string} source
 */
function _upsertKW(map, text, score, source) {
    const lower = text.toLowerCase().trim();
    if (!lower || lower.length < 2) return;
    if (map.has(lower)) {
        const existing = map.get(lower);
        existing.score  += score;
        existing.source  = existing.source === source ? source : 'heuristic';
    } else {
        map.set(lower, { text, score, source, variants: [] });
    }
}

/** 尝试解析 JSON，失败返回 null */
function _tryParseJSON(str) {
    try {
        // 提取第一个 JSON 数组或对象
        const m = str.match(/(\[[\s\S]*\]|\{[\s\S]*\})/);
        if (m) return JSON.parse(m[1]);
    } catch {}
    return null;
}

/** 文本哈希（用于缓存 key） */
function _hashText(text) {
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = (Math.imul(31, hash) + text.charCodeAt(i)) | 0;
    }
    return hash.toString(36);
}

/** 转义正则特殊字符 */
function _escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}