/**
 * @file modules/02_world-book/worldbook-generator.js
 * @description 世界书生成器核心模块
 *              实现 IModule 接口，集成 AI 生成、条目管理、关键词分析、批量操作
 * @version 1.0.0
 */

import { EVENTS, WB_ENTRY_SCHEMA }        from '../../contracts.js';
import { eventBus }                        from '../../core/event-bus.js';
import {
    buildEntry, mergeEntries, sortEntries,
    validateEntry, entriesToWorldBook, worldBookToEntries,
    ENTRY_CATEGORIES,
}                                          from './entry-builder.js';
import { KeywordAnalyzer }                 from './keyword-analyzer.js';
import { EntryLinkGraph }                  from './entry-link-graph.js';
import { BulkImporter }                    from './bulk-import.js';

// ─────────────────────────────────────────────
// AI 生成 Prompt 模板
// ─────────────────────────────────────────────
const WB_SYSTEM_PROMPT = `你是一位专业的世界观构建师，擅长为 SillyTavern 角色扮演创作详尽的世界书条目。
每个条目应当：
- 具体、生动、有内在逻辑一致性
- 为角色扮演提供直接可用的背景信息
- 语言与角色卡的整体风格一致
- 严格按照要求的 JSON 格式返回`;

const CATEGORY_PROMPTS = {
    place: (name, context) => `
请为角色扮演世界书生成一个【地名/地点】条目。

地点名称：${name}
世界背景：${context}

要求：
- 描述该地点的地理位置、环境特征、历史背景
- 包含该地点的重要居民、势力或特色
- 描述该地点的氛围和对角色的意义
- 150~300字，语言生动有画面感
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["主关键词", "别名1"], "secondary_keys": ["次要词1"]}`,

    character: (name, context) => `
请为角色扮演世界书生成一个【人物】条目。

人物名称：${name}
世界背景：${context}

要求：
- 描述该人物的外貌、性格、身份背景
- 说明与主角色的关系和互动方式
- 包含该人物的动机和秘密（如有）
- 150~300字
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["人名", "别称"], "secondary_keys": ["相关词"]}`,

    organization: (name, context) => `
请为角色扮演世界书生成一个【组织/势力】条目。

组织名称：${name}
世界背景：${context}

要求：
- 描述组织的目标、结构和影响力
- 说明组织的关键人物和总部所在
- 描述组织对世界局势的影响
- 150~300字
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["组织名", "简称"], "secondary_keys": ["相关词"]}`,

    item: (name, context) => `
请为角色扮演世界书生成一个【物品/道具】条目。

物品名称：${name}
世界背景：${context}

要求：
- 描述物品的外观、材质、来源
- 说明物品的功能、效果或特殊属性
- 描述物品的历史价值或稀有程度
- 100~250字
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["物品名", "别称"], "secondary_keys": ["相关词"]}`,

    history: (name, context) => `
请为角色扮演世界书生成一个【历史/事件】条目。

事件名称：${name}
世界背景：${context}

要求：
- 描述事件的起因、经过和结果
- 说明事件对世界格局的影响
- 描述事件中的关键人物和转折点
- 150~300字，具有史诗感
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["事件名", "时代"], "secondary_keys": ["相关词"]}`,

    rule: (name, context) => `
请为角色扮演世界书生成一个【规则/设定】条目。

设定名称：${name}
世界背景：${context}

要求：
- 清晰说明该规则/设定的内容和运作方式
- 描述其在世界中的重要性和限制条件
- 提供具体例子帮助理解
- 100~200字，简洁准确
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["设定名"], "secondary_keys": ["相关词"]}`,

    lore: (name, context) => `
请为角色扮演世界书生成一个【传说/秘闻】条目。

传说名称：${name}
世界背景：${context}

要求：
- 描述传说的内容，充满神秘感和引人入胜的细节
- 说明传说的可信度（民间流传？还是有文字记载？）
- 暗示与主线剧情可能的关联
- 150~300字，语言富有文学性
- 严格按以下 JSON 返回：
{"content": "条目内容", "keys": ["传说名"], "secondary_keys": ["相关词"]}`,
};

// ─────────────────────────────────────────────
// WorldBookGenerator 类
// ─────────────────────────────────────────────
export class WorldBookGenerator {
    /**
     * @param {import('../../core/ai-engine.js').AIEngine}               aiEngine
     * @param {import('../../core/event-bus.js').EventBus}               bus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     */
    constructor(aiEngine, bus, settings) {
        this._ai       = aiEngine;
        this._bus      = bus;
        this._settings = settings;

        /** @type {object[]}  当前世界书条目列表 */
        this._entries  = [];

        this._kwAnalyzer = new KeywordAnalyzer(aiEngine);
        this._linkGraph  = new EntryLinkGraph();
        this._importer   = new BulkImporter(this._kwAnalyzer);

        this._ready      = false;
        this._generating = false;
    }

    // ═══════════════════════════════════════════
    // IModule 接口
    // ═══════════════════════════════════════════

    async init() {
        this._ready = true;
        this._bus.emit(EVENTS.MODULE_READY, { module: 'WorldBookGenerator' });
    }

    destroy() {
        this._entries  = [];
        this._ready    = false;
    }

    getState() {
        return {
            ready:       this._ready,
            generating:  this._generating,
            entryCount:  this._entries.length,
            graphStats:  this._linkGraph.getStats(),
        };
    }

    isReady() { return this._ready; }

    // ═══════════════════════════════════════════
    // 核心生成：基于角色卡生成世界书
    // ═══════════════════════════════════════════

    /**
     * 基于完整角色卡数据生成世界书
     * @param {object}   cardData   CardData 对象
     * @param {string[]} [categories]  要生成的分类，默认全部
     * @param {object}   [opts]
     * @param {Function} [opts.onProgress]
     * @param {number}   [opts.entriesPerCategory=3]  每分类生成几条
     * @returns {Promise<object[]>}  新生成的条目
     */
    async generateFromCard(cardData, categories, opts = {}) {
        if (this._generating) throw new Error('[WorldBookGenerator] 正在生成中');

        const {
            onProgress          = () => {},
            entriesPerCategory  = 3,
        } = opts;

        const targetCats = categories ??
            ['place', 'character', 'organization', 'item', 'history', 'rule'];

        this._generating = true;
        this._bus.emit(EVENTS.LOADING_START, { msg: '正在生成世界书…' });

        try {
            const charData = cardData.data ?? {};
            const context  = _buildCardContext(charData);
            const generated = [];
            const total    = targetCats.length;

            for (let i = 0; i < total; i++) {
                const cat = targetCats[i];
                onProgress(
                    Math.round((i / total) * 90),
                    `正在生成「${ENTRY_CATEGORIES[cat]?.label ?? cat}」条目…`
                );

                try {
                    const newEntries = await this.generateCategory(
                        cat, context, entriesPerCategory
                    );
                    generated.push(...newEntries);
                } catch (err) {
                    console.warn(`[WorldBookGenerator] 分类「${cat}」生成失败`, err);
                }
            }

            // 重建关联图
            this._rebuildLinkGraph();

            onProgress(100, `生成完成，共 ${generated.length} 条`);
            this._bus.emit(EVENTS.WB_UPDATED, {
                source: 'generateFromCard',
                count:  generated.length,
            });
            return generated;

        } finally {
            this._generating = false;
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 生成指定分类的多个条目
     * @param {string} category
     * @param {string} context    角色卡上下文摘要
     * @param {number} [count=3]  生成数量
     * @returns {Promise<object[]>}
     */
    async generateCategory(category, context, count = 3) {
        const entries = [];
        const promptFn = CATEGORY_PROMPTS[category] ?? CATEGORY_PROMPTS.lore;

        // 先让 AI 建议该分类下的名称列表
        const nameListPrompt = `
基于以下角色扮演世界背景，为【${ENTRY_CATEGORIES[category]?.label ?? category}】分类
建议 ${count} 个具体的名称/主题（每行一个，不要编号）：

${context}

直接输出名称列表：`;

        const rawNames = await this._ai.generateCard('', nameListPrompt);
        const names = String(rawNames).split('\n')
            .map(l => l.trim().replace(/^[\d.、。\-*•]+\s*/, ''))
            .filter(Boolean)
            .slice(0, count);

        // 为每个名称生成完整条目
        for (const name of names) {
            try {
                const entry = await this.generateEntry(category, name, context);
                if (entry) entries.push(entry);
            } catch (err) {
                console.warn(`[WorldBookGenerator] 条目「${name}」生成失败`, err);
            }
        }

        return entries;
    }

    /**
     * 生成单个条目
     * @param {string} category
     * @param {string} topic     条目主题/名称
     * @param {string} context   背景上下文
     * @returns {Promise<object|null>}
     */
    async generateEntry(category, topic, context) {
        const promptFn = CATEGORY_PROMPTS[category] ?? CATEGORY_PROMPTS.lore;
        const userPrompt = promptFn(topic, context);

        const raw = await this._ai.generateCard(WB_SYSTEM_PROMPT, userPrompt);
        const parsed = typeof raw === 'object' ? raw : _tryParseJSON(String(raw));

        if (!parsed?.content) return null;

        const entry = buildEntry({
            keys:           parsed.keys           ?? [topic],
            secondary_keys: parsed.secondary_keys ?? [],
            content:        parsed.content,
            category,
        });

        this._entries.push(entry);
        this._bus.emit(EVENTS.WB_ENTRY_ADDED, { uid: entry.uid, category });
        return entry;
    }

    // ═══════════════════════════════════════════
    // 条目 CRUD
    // ═══════════════════════════════════════════

    /**
     * 手动添加条目
     * @param {object} entryOptions
     * @returns {number}  UID
     */
    addEntry(entryOptions) {
        const entry = buildEntry(entryOptions);
        this._entries.push(entry);
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_ENTRY_ADDED, { uid: entry.uid });
        return entry.uid;
    }

    /**
     * 更新条目
     * @param {number} uid
     * @param {object} changes
     */
    updateEntry(uid, changes) {
        const idx = this._entries.findIndex(e => e.uid === uid);
        if (idx < 0) throw new Error(`[WorldBookGenerator] 条目不存在：UID=${uid}`);
        this._entries[idx] = { ...this._entries[idx], ...changes, uid };
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_UPDATED, { source: 'updateEntry', uid });
    }

    /**
     * 删除条目
     * @param {number} uid
     */
    removeEntry(uid) {
        const before = this._entries.length;
        this._entries = this._entries.filter(e => e.uid !== uid);
        if (this._entries.length === before) {
            throw new Error(`[WorldBookGenerator] 条目不存在：UID=${uid}`);
        }
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_ENTRY_REMOVED, { uid });
    }

    /**
     * 获取全部条目（副本）
     * @returns {object[]}
     */
    getEntries() {
        return JSON.parse(JSON.stringify(this._entries));
    }

    /**
     * 按分类获取条目
     * @param {string} category
     * @returns {object[]}
     */
    getEntriesByCategory(category) {
        return this._entries.filter(e => e.category === category);
    }

    /**
     * 清空所有条目
     */
    clearEntries() {
        this._entries = [];
        this._linkGraph = new EntryLinkGraph();
        this._bus.emit(EVENTS.WB_UPDATED, { source: 'clearEntries' });
    }

    // ═══════════════════════════════════════════
    // 关键词管理
    // ═══════════════════════════════════════════

    /**
     * 从文本提取关键词（代理到 KeywordAnalyzer）
     * @param {string} text
     * @returns {Promise<string[]>}
     */
    async extractKeywords(text) {
        const results = await this._kwAnalyzer.extract(text, {
            maxKeywords: 10,
            useAI:       true,
        });
        return results.map(r => r.text);
    }

    /**
     * 扩展关键词同义词
     * @param {string[]} keywords
     * @returns {Promise<Map<string, string[]>>}
     */
    async expandKeywords(keywords) {
        return this._kwAnalyzer.expandSynonyms(keywords);
    }

    // ═══════════════════════════════════════════
    // 批量操作
    // ═══════════════════════════════════════════

    /**
     * 批量导入已有世界书
     * @param {object|string} worldbookData  JSON 对象或字符串
     * @param {object}        [opts]
     * @returns {Promise<{ added: number, updated: number }>}
     */
    async bulkImport(worldbookData, opts = {}) {
        const content = typeof worldbookData === 'string'
            ? worldbookData
            : JSON.stringify(worldbookData);

        const result = await this._importer.import(content, {
            format:     'st_json',
            onProgress: opts.onProgress ?? (() => {}),
        });

        const { merged, stats } = mergeEntries(this._entries, result.entries);
        this._entries = merged;
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_UPDATED, { source: 'bulkImport', stats });
        return stats;
    }

    /**
     * 从文件导入（自动检测格式）
     * @param {File} file
     * @param {object} [opts]
     * @returns {Promise<ImportResult>}
     */
    async importFromFile(file, opts = {}) {
        const result = await this._importer.import(file, opts);
        const { merged, stats } = mergeEntries(this._entries, result.entries);
        this._entries = merged;
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_UPDATED, { source: 'importFromFile', stats });
        return { ...result, mergeStats: stats };
    }

    /**
     * 批量 AI 增强指定条目
     * @param {number[]} uids
     * @param {object}   [opts]
     * @param {Function} [opts.onProgress]
     * @returns {Promise<number>}  成功增强的条目数
     */
    async bulkEnhance(uids, opts = {}) {
        const { onProgress = () => {} } = opts;
        let count = 0;

        for (let i = 0; i < uids.length; i++) {
            const uid   = uids[i];
            const entry = this._entries.find(e => e.uid === uid);
            if (!entry?.content) continue;

            onProgress(
                Math.round((i / uids.length) * 100),
                `增强条目 ${i + 1}/${uids.length}…`
            );

            try {
                const enhanced = await this._ai.enhanceField(
                    entry.category, entry.content, 'detailed'
                );
                this.updateEntry(uid, { content: enhanced });
                count++;
            } catch (err) {
                console.warn(`[WorldBookGenerator] 条目 UID=${uid} 增强失败`, err);
            }
        }
        return count;
    }

    // ═══════════════════════════════════════════
    // 关联图
    // ═══════════════════════════════════════════

    /**
     * 获取关联图实例
     * @returns {EntryLinkGraph}
     */
    getLinkGraph() {
        return this._linkGraph;
    }

    /**
     * 渲染关联图 SVG
     * @param {object} [opts]
     * @returns {string}
     */
    renderLinkGraphSVG(opts) {
        return this._linkGraph.renderSVG(opts);
    }

    // ═══════════════════════════════════════════
    // 序列化
    // ═══════════════════════════════════════════

    /**
     * 导出为标准世界书 JSON 对象
     * @param {string} [name]
     * @returns {object}
     */
    toJSON(name) {
        return entriesToWorldBook(
            sortEntries(this._entries, 'insertion_order', 'asc'),
            name
        );
    }

    /**
     * 从 JSON 加载（覆盖当前条目）
     * @param {object} json
     */
    fromJSON(json) {
        this._entries = worldBookToEntries(json);
        this._rebuildLinkGraph();
        this._bus.emit(EVENTS.WB_UPDATED, { source: 'fromJSON' });
    }

    /**
     * 获取完整统计信息
     * @returns {object}
     */
    getStats() {
        const byCategory = {};
        for (const cat of Object.keys(ENTRY_CATEGORIES)) {
            byCategory[cat] = this._entries.filter(e => e.category === cat).length;
        }
        return {
            total:      this._entries.length,
            byCategory,
            graphStats: this._linkGraph.getStats(),
        };
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _rebuildLinkGraph() {
        this._linkGraph.build(this._entries);
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 从 CardData 构建世界书生成用的上下文字符串
 * @param {object} charData  CardData.data
 * @returns {string}
 */
function _buildCardContext(charData) {
    const parts = [];
    if (charData.name)        parts.push(`角色名：${charData.name}`);
    if (charData.description) parts.push(`描述：${charData.description.slice(0, 400)}`);
    if (charData.scenario)    parts.push(`场景：${charData.scenario.slice(0, 300)}`);
    if (charData.personality) parts.push(`性格：${charData.personality.slice(0, 150)}`);
    return parts.join('\n\n') || '（无角色信息）';
}

function _tryParseJSON(str) {
    try {
        const m = str.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
        if (m) return JSON.parse(m[1]);
    } catch {}
    return null;
}