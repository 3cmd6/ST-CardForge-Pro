/**
 * @file modules/03_greeting/greeting-generator.js
 * @description 开场白生成器核心模块
 *              实现 IModule 接口，集成风格档案、沙盒预览、批量生成、增强
 * @version 1.0.0
 */

import { EVENTS }                       from '../../contracts.js';
import { eventBus }                     from '../../core/event-bus.js';
import {
    STYLE_PROFILES,
    SCENARIOS,
    POV_OPTIONS,
    WORD_COUNT_PRESETS,
    buildStylePrompt,
    recommendStyle,
    listStyles,
    listScenarios,
}                                        from './style-profiles.js';
import { SandboxPreview, injectSandboxStyles } from './sandbox-preview.js';

// ─────────────────────────────────────────────
// System Prompt 常量
// ─────────────────────────────────────────────

const GREETING_SYSTEM = `你是一位资深角色扮演作家，专门为 SillyTavern 平台撰写角色开场白（First Message）。

【铁律】
- 严格遵守角色设定，保持角色外貌/身份/性格/语气一致
- 不得出现"作为 AI""我无法""不��提供"等出戏语句
- 动作/心理描写用 *星号* 包裹，对话用正常引号或直接书写
- 结尾必须留有互动钩子，引导 {{user}} 自然回应
- 直接输出正文，不要加标题、不加前言、不加解释`.trim();

const ALT_GREETING_SYSTEM = `你是一位角色扮演开场白写作专家，擅长为同一个角色创作风格各异的多版本开场白。

【铁律】
- 每条开场白情境/情绪/起手方式要有明显差异
- 每条都需要动作描写（*...*）与对话结合
- 每条结尾留有互动空间
- 严格按 JSON 数组格式输出，不加任何额外说明：
  ["第一条开场白正文", "第二条开场白正文", ...]`.trim();

// ─────────────────────────────────────────────
// 校验规则
// ─────────────────────────────────────────────
const OUT_OF_CHARACTER_PATTERNS = [
    /作为.{0,6}(AI|人工智能|语言模型)/,
    /我(无法|不能|不可以)(提供|生成|写|创作)/,
    /这(违反|不符合|超出)/,
    /抱歉[，,].{0,20}(无法|不能)/,
];

// ─────────────────────────────────────────────
// GreetingGenerator 类
// ─────────────────────────────────────────────
export class GreetingGenerator {
    /**
     * @param {import('../../core/ai-engine.js').AIEngine}               aiEngine
     * @param {import('../../core/event-bus.js').EventBus}               bus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     */
    constructor(aiEngine, bus, settings) {
        this._ai       = aiEngine;
        this._bus      = bus;
        this._settings = settings;

        /** @type {string} 当前主开场白 */
        this._firstMes    = '';
        /** @type {string[]} 当前备用开场白 */
        this._alternates  = [];

        /** @type {SandboxPreview|null} */
        this._sandbox     = null;

        /** @type {boolean} */
        this._ready       = false;

        /** @type {boolean} 生成中锁 */
        this._generating  = false;
    }

    // ═══════════════════════════════════════════
    // IModule 接口
    // ═══════════════════════════════════════════

    async init() {
        injectSandboxStyles();
        this._ready = true;
        this._bus.emit(EVENTS.MODULE_READY, { module: 'GreetingGenerator' });
    }

    destroy() {
        this._sandbox    = null;
        this._firstMes   = '';
        this._alternates = [];
        this._ready      = false;
    }

    getState() {
        return {
            ready:          this._ready,
            generating:     this._generating,
            firstMesLength: this._firstMes.length,
            alternateCount: this._alternates.length,
        };
    }

    isReady() { return this._ready; }

    // ═══════════════════════════════════════════
    // 生成主开场白
    // ═══════════════════════════════════════════

    /**
     * 生成 first_mes
     *
     * @param {object}  cardData             CardData.data 兼容对象
     * @param {object}  [options]
     * @param {string}  [options.style]      STYLE_PROFILES key，默认智能推荐
     * @param {string}  [options.scenario]   SCENARIOS key
     * @param {string}  [options.customScenario]  自定义情景（scenario='custom'时）
     * @param {number}  [options.wordCount]  目标字数
     * @param {string}  [options.pov]        POV_OPTIONS key
     * @returns {Promise<string>}
     */
    async generateFirstMes(cardData, options = {}) {
        if (this._generating) throw new Error('[GreetingGenerator] 正在生成中，请稍候');
        this._generating = true;

        const {
            style          = recommendStyle(cardData?.tags ?? [], cardData?.genre),
            scenario       = 'first_meeting',
            customScenario = '',
            wordCount      = 250,
            pov            = 'first',
        } = options;

        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: '正在生成开场白…' });

            const stylePrompt = buildStylePrompt({ style, scenario, pov, customScenario });
            const userPrompt  = this._buildFirstMesPrompt(cardData, {
                style, scenario, customScenario, wordCount, pov, stylePrompt,
            });

            const raw  = await this._retryGenerate(GREETING_SYSTEM, userPrompt);
            const text = this._cleanResponse(raw);

            this._assertNotOutOfCharacter(text);

            this._firstMes = text;

            this._bus.emit(EVENTS.GREETING_GENERATED, {
                type: 'first_mes',
                style, scenario, text,
            });

            // 同步到沙盒预览
            this._syncSandbox(cardData);

            return text;

        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module:  'GreetingGenerator',
                method:  'generateFirstMes',
                error,
                context: { options },
            });
            throw error;
        } finally {
            this._generating = false;
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    // ═══════════════════════════════════════════
    // 批量生成备用开场白
    // ═══════════════════════════════════════════

    /**
     * 批量生成 alternate_greetings
     *
     * @param {object}   cardData
     * @param {number}   [count=3]
     * @param {string[]} [scenarios]  为每条指定不同情景（建议条数与 count 一致）
     * @param {object}   [options]
     * @param {string}   [options.style]
     * @param {string}   [options.pov]
     * @param {number}   [options.wordCount]
     * @returns {Promise<string[]>}
     */
    async generateAlternateGreetings(cardData, count = 3, scenarios = [], options = {}) {
        if (this._generating) throw new Error('[GreetingGenerator] 正在生成中，请稍候');
        this._generating = true;

        const {
            style     = recommendStyle(cardData?.tags ?? [], cardData?.genre),
            pov       = 'first',
            wordCount = 220,
        } = options;

        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: `正在生成 ${count} 条备用开场白…` });

            const stylePrompt = buildStylePrompt({
                style,
                scenario: scenarios[0] ?? 'first_meeting',
                pov,
            });

            const userPrompt = this._buildAltGreetingPrompt(cardData, {
                style, pov, wordCount, count, scenarios, stylePrompt,
            });

            const raw    = await this._retryGenerate(ALT_GREETING_SYSTEM, userPrompt);
            const result = this._parseAltGreetings(raw, count);

            // 过滤出戏内容
            const valid = result.filter(t => {
                try   { this._assertNotOutOfCharacter(t); return true; }
                catch { return false; }
            });

            this._alternates = valid;

            this._bus.emit(EVENTS.GREETING_GENERATED, {
                type: 'alternate_greetings',
                style, count: valid.length, texts: valid,
            });

            this._syncSandbox(cardData);

            return valid;

        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module:  'GreetingGenerator',
                method:  'generateAlternateGreetings',
                error,
                context: { count, scenarios, options },
            });
            throw error;
        } finally {
            this._generating = false;
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    /**
     * 对单条开场白进行 AI 增强
     *
     * @param {string} text        原始文本
     * @param {string} [mode]      'literary'|'detailed'|'concise'|'poetic'
     * @returns {Promise<string>}
     */
    async enhanceGreeting(text, mode = 'literary') {
        if (!text?.trim()) throw new Error('[GreetingGenerator] 增强文本为空');

        try {
            this._bus.emit(EVENTS.LOADING_START, { msg: '正在增强开场白…' });
            const enhanced = await this._ai.enhanceField('开场白', text, mode);
            return enhanced;
        } finally {
            this._bus.emit(EVENTS.LOADING_END);
        }
    }

    // ═══════════════════════════════════════════
    // 情景 / 风格列表
    // ═══════════════════════════════════════════

    /** @returns {Array<{ key, label, icon, desc }>} */
    getScenarios() { return listScenarios(); }

    /** @returns {Array<{ key, label, icon, desc }>} */
    getStyles()    { return listStyles(); }

    /** @returns {Array<{ label, value, hint }>} */
    getWordCountPresets() { return [...WORD_COUNT_PRESETS]; }

    // ═══════════════════════════════════════════
    // 沙盒预览
    // ═══════════════════════════════════════════

    /**
     * 绑定沙盒容器
     * @param {HTMLElement} container
     * @param {object}      [opts]    传给 SandboxPreview 的选项
     */
    bindSandbox(container, opts = {}) {
        this._sandbox = new SandboxPreview(container, opts);
    }

    /**
     * 在沙盒中预览指定文本
     * @param {string} greeting
     * @param {object} cardData
     */
    async previewInSandbox(greeting, cardData) {
        if (!this._sandbox) return;
        const vars = {
            char: cardData?.name ?? cardData?.data?.name ?? '角色',
            user: '你',
        };
        this._sandbox.update(greeting, [], vars);
    }

    /**
     * 在沙盒中同步显示当前主开场白 + 备用列表
     * @param {object} [cardData]
     */
    _syncSandbox(cardData) {
        if (!this._sandbox || !this._firstMes) return;
        const vars = {
            char: cardData?.name ?? '角色',
            user: '你',
        };
        this._sandbox.update(this._firstMes, this._alternates, vars);
    }

    // ═══════════════════════════════════════════
    // 数据管理
    // ═══════════════════════════════════════════

    /**
     * 直接写入开场白数据（用于从角色卡载入）
     * @param {string}   first
     * @param {string[]} [alternates=[]]
     */
    setGreetings(first, alternates = []) {
        this._firstMes   = String(first ?? '');
        this._alternates = alternates.filter(s => typeof s === 'string');

        this._bus.emit(EVENTS.GREETING_SELECTED, {
            first:      this._firstMes,
            alternates: this._alternates,
        });
    }

    /**
     * 获取当前开场白数据
     * @returns {{ first: string, alternates: string[] }}
     */
    getGreetings() {
        return {
            first:      this._firstMes,
            alternates: [...this._alternates],
        };
    }

    /**
     * 更新单条备用开场白
     * @param {number} idx
     * @param {string} text
     */
    setAlternate(idx, text) {
        if (idx < 0) return;
        // 自动扩容
        while (this._alternates.length <= idx) this._alternates.push('');
        this._alternates[idx] = String(text ?? '');
    }

    /**
     * 删除单条备用开场白
     * @param {number} idx
     */
    removeAlternate(idx) {
        this._alternates.splice(idx, 1);
    }

    /**
     * 新增一条空的备用开场白
     */
    addEmptyAlternate() {
        this._alternates.push('');
    }

    // ═══════════════════════════════════════════
    // 私有：Prompt 构建
    // ═══════════════════════════════════════════

    _buildFirstMesPrompt(cardData, opts) {
        const name    = cardData?.name        ?? '';
        const desc    = cardData?.description ?? '';
        const pers    = cardData?.personality ?? '';
        const scen    = cardData?.scenario    ?? '';
        const speech  = cardData?.speech_habits ?? '';

        const scenarioLabel = opts.scenario === 'custom'
            ? (opts.customScenario || '请 AI 自由发挥')
            : (SCENARIOS[opts.scenario]?.label ?? opts.scenario);

        const povLabel = POV_OPTIONS[opts.pov]?.label ?? opts.pov;

        return `
【角色信息】
名字：${name}
性格：${pers.slice(0, 200)}
描述摘要：${desc.slice(0, 450)}
${scen ? `场景背景：${scen.slice(0, 280)}` : ''}
${speech ? `说话习惯：${speech}` : ''}

【写作参数】
目标字数：约 ${opts.wordCount} 字
开场情景：${scenarioLabel}
视角：${povLabel}
语言：${this._settings?.get('defaultLanguage', 'zh-CN') === 'en-US' ? 'English' : '中文（简体）'}

【风格修饰】
${opts.stylePrompt}

请直接输出开场白正文：`.trim();
    }

    _buildAltGreetingPrompt(cardData, opts) {
        const name   = cardData?.name        ?? '';
        const desc   = cardData?.description ?? '';
        const pers   = cardData?.personality ?? '';
        const scen   = cardData?.scenario    ?? '';

        const fallbackScenarios = ['first_meeting', 'daily', 'crisis', 'reunion', 'night_talk'];
        const scenList = (opts.scenarios?.length ? opts.scenarios : fallbackScenarios)
            .slice(0, opts.count);

        const scenLines = scenList.map((s, i) => {
            const label = SCENARIOS[s]?.label ?? s;
            return `第 ${i + 1} 条 → ${label}`;
        }).join('\n');

        return `
【角色信息】
名字：${name}
性格：${pers.slice(0, 200)}
描述摘要：${desc.slice(0, 420)}
${scen ? `场景背景：${scen.slice(0, 250)}` : ''}

【生成要求】
数量：${opts.count} 条
每条字数：约 ${opts.wordCount} 字
视角：${POV_OPTIONS[opts.pov]?.label ?? opts.pov}

每条对应情景（仅供参考，不必照搬）：
${scenLines}

【风格修饰】
${opts.stylePrompt}

输出格式：JSON 数组，每个元素为一条开场白完整正文。
直接输出，不要加任何其他说明：`.trim();
    }

    // ═══════════════════════════════════════════
    // 私有：解析 / 校验 / 工具
    // ═══════════════════════════════════════════

    /**
     * 对 AI 原始返回进行清洗
     * @param {*} raw
     * @returns {string}
     */
    _cleanResponse(raw) {
        if (Array.isArray(raw))  return String(raw[0] ?? '').trim();
        if (typeof raw === 'object' && raw !== null) {
            return String(raw.text ?? raw.content ?? raw.greeting ?? JSON.stringify(raw)).trim();
        }
        return String(raw ?? '')
            .replace(/^```[\w]*\n?/m, '')
            .replace(/\n?```$/m, '')
            .trim();
    }

    /**
     * 解析批量备用开场白的 AI 返回
     * @param {*}      raw
     * @param {number} count
     * @returns {string[]}
     */
    _parseAltGreetings(raw, count) {
        // Case 1：已经是数组
        if (Array.isArray(raw)) {
            return raw.map(s => String(s).trim()).filter(Boolean).slice(0, count);
        }

        // Case 2：字符串 → 尝试 JSON 解析
        const txt = String(raw ?? '');
        const jsonMatch = txt.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
            try {
                const parsed = JSON.parse(jsonMatch[0]);
                if (Array.isArray(parsed)) {
                    return parsed.map(s => String(s).trim()).filter(Boolean).slice(0, count);
                }
            } catch {}
        }

        // Case 3：按空行拆分
        const blocks = txt.split(/\n\s*\n/)
            .map(b => b.trim())
            .filter(b => b.length > 20)
            .slice(0, count);

        if (blocks.length >= 2) return blocks;

        // Case 4：按数字序号拆分（"1. xxx"、"第1条 xxx"）
        const numbered = txt.split(/(?:^|\n)(?:\d+[.、．]|第\d+条)\s*/m)
            .map(s => s.trim())
            .filter(s => s.length > 20)
            .slice(0, count);

        if (numbered.length >= 2) return numbered;

        // Case 5：兜底 - 整段作为第一条
        return txt.trim() ? [txt.trim()] : [];
    }

    /**
     * 检查是否包含出戏语句
     * @param {string} text
     * @throws {Error}
     */
    _assertNotOutOfCharacter(text) {
        if (!text || typeof text !== 'string') {
            throw new Error('开场白为空或格式非法');
        }
        if (text.trim().length < 20) {
            throw new Error('开场白过短，请重新生成');
        }
        for (const pattern of OUT_OF_CHARACTER_PATTERNS) {
            if (pattern.test(text)) {
                throw new Error(`开场白包含出戏语句（匹配：${pattern}），请重新生成`);
            }
        }
    }

    /**
     * 带一次重试的生成包装
     * @param {string} system
     * @param {string} user
     * @returns {Promise<*>}
     */
    async _retryGenerate(system, user) {
        try {
            return await this._ai.generateCard(system, user);
        } catch (firstErr) {
            console.warn('[GreetingGenerator] 首次生成失败，重试…', firstErr);
            return await this._ai.generateCard(system, user);
        }
    }
}