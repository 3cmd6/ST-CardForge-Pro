/**
 * @file modules/03_greeting/sandbox-preview.js
 * @description 开场白沙盒预览
 *              在类似 SillyTavern 聊天界面的沙盒中预览开场白效果
 *              支持变量替换（{{char}} {{user}}）、Markdown 渲染、Token 统计
 * @version 1.0.0
 */

import { estimateTokens } from '../../utils/token-counter.js';
import { eventBus }       from '../../core/event-bus.js';
import { EVENTS }         from '../../contracts.js';

// ─────────────────────────────────────────────
// 简易 Markdown 渲染器（无外部依赖）
// ─────────────────────────────────────────────

/**
 * 将文本中的常见 Markdown 语法转换为 HTML
 * 仅处理 SillyTavern 开场白中常见的格式：
 *   *斜体*  **加粗**  *动作描写*  换行
 * @param {string} text
 * @returns {string}  HTML 字符串
 */
function renderMarkdown(text) {
    if (!text) return '';

    return text
        // 转义 HTML 特殊字符（防止 XSS）
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        // **加粗**
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        // *斜体 / 动作描写*（多行支持）
        .replace(/\*([^*\n]+(?:\n[^*\n]+)*)\*/g,
            '<em class="cf-action-text">$1</em>')
        // ~~删除线~~
        .replace(/~~(.+?)~~/g, '<del>$1</del>')
        // `行内代码`
        .replace(/`(.+?)`/g, '<code>$1</code>')
        // 换行 → <br>（保留段落间距）
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');
}

/**
 * 替换开场白中的变量占位符
 * @param {string} text
 * @param {object} vars  { char, user, ... }
 * @returns {string}
 */
function substituteVars(text, vars = {}) {
    return text.replace(/\{\{(\w+)\}\}/g, (_, key) => {
        return key in vars ? String(vars[key]) : `{{${key}}}`;
    });
}

// ─────────────────────────────────────────────
// SandboxPreview 类
// ─────────────────────────────────────────────
export class SandboxPreview {
    /**
     * @param {HTMLElement} containerElement  预览容器
     * @param {object}      [options]
     * @param {string}      [options.charName='角色']   角色名
     * @param {string}      [options.userName='你']     玩家名
     * @param {string}      [options.charAvatar]        角色头像 URL
     * @param {boolean}     [options.showTokenCount=true]
     */
    constructor(containerElement, options = {}) {
        this._container   = containerElement;
        this._opts = {
            charName:       '角色',
            userName:       '你',
            charAvatar:     '',
            showTokenCount: true,
            ...options,
        };

        /** @type {string[]}  当前预览中的消息列表（开场白 + 备用） */
        this._messages    = [];
        /** @type {number}  当前激活的消息索引 */
        this._activeIdx   = 0;
        /** @type {HTMLElement|null} */
        this._rootEl      = null;

        this._render();
    }

    // ═══════════════════════════════════════════
    // 公共接口
    // ═══════════════════════════════════════════

    /**
     * 更新预览内容
     * @param {string}   firstMes           主开场白
     * @param {string[]} [altGreetings=[]]  备用开场白列表
     * @param {object}   [vars]             变量替换表
     */
    update(firstMes, altGreetings = [], vars = {}) {
        this._messages = [firstMes, ...altGreetings].filter(Boolean);
        this._activeIdx = 0;
        this._vars = {
            char: this._opts.charName,
            user: this._opts.userName,
            ...vars,
        };
        this._renderMessages();
    }

    /**
     * 更新角色名和玩家名
     * @param {string} charName
     * @param {string} [userName]
     */
    updateNames(charName, userName) {
        this._opts.charName = charName || '角色';
        this._opts.userName = userName || '你';
        if (this._vars) {
            this._vars.char = this._opts.charName;
            this._vars.user = this._opts.userName;
        }
        this._renderMessages();
    }

    /**
     * 更新角色头像
     * @param {string} avatarUrl
     */
    updateAvatar(avatarUrl) {
        this._opts.charAvatar = avatarUrl;
        const avatarEl = this._rootEl?.querySelector('.cf-sb-avatar');
        if (avatarEl) {
            avatarEl.style.backgroundImage = avatarUrl
                ? `url(${avatarUrl})`
                : 'none';
        }
    }

    /**
     * 切换到指定消息版本
     * @param {number} idx
     */
    switchTo(idx) {
        if (idx < 0 || idx >= this._messages.length) return;
        this._activeIdx = idx;
        this._renderMessages();
    }

    /**
     * 切换到下一条消息
     */
    next() {
        if (this._activeIdx < this._messages.length - 1) {
            this.switchTo(this._activeIdx + 1);
        }
    }

    /**
     * 切换到上一条消息
     */
    prev() {
        if (this._activeIdx > 0) {
            this.switchTo(this._activeIdx - 1);
        }
    }

    /**
     * 清空预览内容
     */
    clear() {
        this._messages  = [];
        this._activeIdx = 0;
        this._renderMessages();
    }

    /**
     * 获取当前显示消息的 Token 数
     * @returns {number}
     */
    getCurrentTokenCount() {
        const msg = this._messages[this._activeIdx] ?? '';
        return estimateTokens(msg);
    }

    // ═══════════════════════════════════════════
    // 渲染
    // ═══════════════════════════════════════════

    _render() {
        this._container.innerHTML = '';
        this._container.style.position = 'relative';

        const root = document.createElement('div');
        root.className = 'cf-sandbox-root';
        root.innerHTML = `
            <!-- 沙盒顶部栏 -->
            <div class="cf-sb-topbar">
                <div class="cf-sb-char-info">
                    <div class="cf-sb-avatar"
                         style="${this._opts.charAvatar
                             ? `background-image:url(${this._opts.charAvatar})`
                             : ''}">
                        ${!this._opts.charAvatar ? '👤' : ''}
                    </div>
                    <div>
                        <div class="cf-sb-char-name"
                             id="cf-sb-char-name">${_esc(this._opts.charName)}</div>
                        <div class="cf-sb-online-status">● 在线</div>
                    </div>
                </div>
                <div class="cf-sb-topbar-right">
                    ${this._opts.showTokenCount
                        ? '<span class="cf-sb-token-count" id="cf-sb-token-count">— tokens</span>'
                        : ''}
                </div>
            </div>

            <!-- 消息区域 -->
            <div class="cf-sb-messages" id="cf-sb-messages">
                <div class="cf-sb-empty" id="cf-sb-empty">
                    <span style="font-size:24px">💬</span>
                    <span>预览将显示在此处</span>
                </div>
            </div>

            <!-- 版本切换导航 -->
            <div class="cf-sb-nav" id="cf-sb-nav" style="display:none">
                <button class="cf-sb-nav-btn" id="cf-sb-prev">◀</button>
                <span class="cf-sb-nav-label" id="cf-sb-nav-label">1 / 1</span>
                <button class="cf-sb-nav-btn" id="cf-sb-next">▶</button>
                <span class="cf-sb-nav-type" id="cf-sb-nav-type"></span>
            </div>
        `;
        this._rootEl = root;
        this._container.appendChild(root);

        // 绑定导航按钮
        root.querySelector('#cf-sb-prev')?.addEventListener('click', () => this.prev());
        root.querySelector('#cf-sb-next')?.addEventListener('click', () => this.next());
    }

    /**
     * 渲染消息内容
     */
    _renderMessages() {
        if (!this._rootEl) return;

        const messagesEl  = this._rootEl.querySelector('#cf-sb-messages');
        const emptyEl     = this._rootEl.querySelector('#cf-sb-empty');
        const navEl       = this._rootEl.querySelector('#cf-sb-nav');
        const navLabel    = this._rootEl.querySelector('#cf-sb-nav-label');
        const navTypeEl   = this._rootEl.querySelector('#cf-sb-nav-type');
        const tokenEl     = this._rootEl.querySelector('#cf-sb-token-count');
        const charNameEl  = this._rootEl.querySelector('#cf-sb-char-name');

        // 更新角色名
        if (charNameEl) charNameEl.textContent = this._opts.charName;

        if (this._messages.length === 0) {
            if (emptyEl)     emptyEl.style.display    = 'flex';
            if (navEl)       navEl.style.display       = 'none';
            if (messagesEl)  messagesEl.innerHTML      = '';
            messagesEl?.appendChild(emptyEl);
            if (tokenEl)     tokenEl.textContent       = '— tokens';
            return;
        }

        if (emptyEl) emptyEl.style.display = 'none';

        // 当前消息
        const rawText   = this._messages[this._activeIdx] ?? '';
        const subText   = substituteVars(rawText, this._vars ?? {});
        const htmlText  = renderMarkdown(subText);

        // 构建消息气泡
        const avatarStyle = this._opts.charAvatar
            ? `background-image:url(${this._opts.charAvatar});background-size:cover`
            : '';
        const avatarInner = this._opts.charAvatar ? '' : '👤';

        if (messagesEl) {
            messagesEl.innerHTML = `
                <div class="cf-sb-message-row">
                    <div class="cf-sb-avatar cf-sb-msg-avatar"
                         style="${avatarStyle}">${avatarInner}</div>
                    <div class="cf-sb-bubble-wrap">
                        <div class="cf-sb-bubble-name">${_esc(this._opts.charName)}</div>
                        <div class="cf-sb-bubble">
                            <p>${htmlText}</p>
                        </div>
                    </div>
                </div>
            `;
        }

        // 更新 Token 计数
        const tokens = estimateTokens(rawText);
        if (tokenEl) {
            const warnLimit  = 500;
            const dangerLimit = 800;
            tokenEl.textContent = `${tokens} tokens`;
            tokenEl.className   = 'cf-sb-token-count' +
                (tokens >= dangerLimit ? ' danger' : tokens >= warnLimit ? ' warn' : '');
        }

        // 更新导航
        if (navEl) {
            navEl.style.display = this._messages.length > 1 ? 'flex' : 'none';
        }
        if (navLabel) {
            navLabel.textContent = `${this._activeIdx + 1} / ${this._messages.length}`;
        }
        if (navTypeEl) {
            navTypeEl.textContent = this._activeIdx === 0 ? '主开场白' : `备用 #${this._activeIdx}`;
        }

        // 更新导航按钮状态
        const prevBtn = this._rootEl.querySelector('#cf-sb-prev');
        const nextBtn = this._rootEl.querySelector('#cf-sb-next');
        if (prevBtn) prevBtn.disabled = this._activeIdx === 0;
        if (nextBtn) nextBtn.disabled = this._activeIdx === this._messages.length - 1;
    }
}

// ─────────────────────────────────────────────
// SandboxPreview 全局 CSS 注入（仅注入一次）
// ─────────────────────────────────────────────
let _stylesInjected = false;

export function injectSandboxStyles() {
    if (_stylesInjected) return;
    _stylesInjected = true;

    const style = document.createElement('style');
    style.textContent = `
/* ── 沙盒根容器 ── */
.cf-sandbox-root {
    display:        flex;
    flex-direction: column;
    height:         100%;
    background:     var(--cf-bg-panel, #1a1a2e);
    border-radius:  var(--cf-radius, 8px);
    overflow:       hidden;
    border:         1px solid var(--cf-border, rgba(255,255,255,0.1));
    min-height:     280px;
}

/* 顶部栏 */
.cf-sb-topbar {
    display:        flex;
    align-items:    center;
    justify-content: space-between;
    padding:        8px 14px;
    background:     var(--cf-bg-card, #16213e);
    border-bottom:  1px solid var(--cf-border, rgba(255,255,255,0.1));
    flex-shrink:    0;
}

.cf-sb-char-info {
    display:        flex;
    align-items:    center;
    gap:            8px;
}

.cf-sb-avatar {
    width:          34px;
    height:         34px;
    border-radius:  50%;
    background:     rgba(123,104,238,0.3);
    display:        flex;
    align-items:    center;
    justify-content: center;
    font-size:      16px;
    flex-shrink:    0;
    background-size: cover;
    background-position: center;
    overflow:       hidden;
}

.cf-sb-char-name {
    font-size:      13px;
    font-weight:    700;
    color:          var(--cf-text-heading, #fff);
}

.cf-sb-online-status {
    font-size:      10px;
    color:          var(--cf-success, #2ecc71);
}

.cf-sb-topbar-right {
    display:        flex;
    align-items:    center;
    gap:            8px;
}

.cf-sb-token-count {
    font-size:      10px;
    color:          var(--cf-text-muted, #888);
    font-weight:    600;
    padding:        2px 6px;
    background:     rgba(255,255,255,0.06);
    border-radius:  4px;
}

.cf-sb-token-count.warn   { color: var(--cf-warning, #f39c12); }
.cf-sb-token-count.danger { color: var(--cf-danger,  #e74c3c); }

/* 消息区 */
.cf-sb-messages {
    flex:           1;
    overflow-y:     auto;
    padding:        16px;
    display:        flex;
    flex-direction: column;
    gap:            12px;
}

.cf-sb-empty {
    flex:           1;
    display:        flex;
    flex-direction: column;
    align-items:    center;
    justify-content: center;
    gap:            8px;
    color:          var(--cf-text-muted, #888);
    font-size:      12px;
}

/* 消息行 */
.cf-sb-message-row {
    display:        flex;
    gap:            10px;
    align-items:    flex-start;
    animation:      cf-fade-in 0.25s ease;
}

.cf-sb-msg-avatar {
    width:          36px;
    height:         36px;
    flex-shrink:    0;
    margin-top:     2px;
}

.cf-sb-bubble-wrap {
    flex:           1;
    min-width:      0;
}

.cf-sb-bubble-name {
    font-size:      11px;
    font-weight:    700;
    color:          var(--cf-primary-light, #9d8ef5);
    margin-bottom:  4px;
}

.cf-sb-bubble {
    background:     var(--cf-bg-card, #16213e);
    border:         1px solid var(--cf-border, rgba(255,255,255,0.1));
    border-radius:  0 var(--cf-radius, 8px) var(--cf-radius, 8px) var(--cf-radius, 8px);
    padding:        10px 14px;
    font-size:      13px;
    line-height:    1.75;
    color:          var(--cf-text, #e0e0e0);
    word-break:     break-word;
}

.cf-sb-bubble p {
    margin: 0 0 0.5em;
}

.cf-sb-bubble p:last-child { margin-bottom: 0; }

/* 动作描写（斜体 em）样式 */
.cf-sandbox-root .cf-action-text {
    color:          var(--cf-text-muted, #888);
    font-style:     italic;
}

.cf-sb-bubble strong { color: var(--cf-text-heading, #fff); }
.cf-sb-bubble code {
    background:     rgba(255,255,255,0.08);
    padding:        1px 4px;
    border-radius:  3px;
    font-size:      12px;
    color:          var(--cf-primary-light, #9d8ef5);
}

/* 版本切换导航 */
.cf-sb-nav {
    display:        flex;
    align-items:    center;
    justify-content: center;
    gap:            10px;
    padding:        8px;
    border-top:     1px solid var(--cf-border, rgba(255,255,255,0.1));
    background:     var(--cf-bg-card, #16213e);
    flex-shrink:    0;
}

.cf-sb-nav-btn {
    background:     var(--cf-bg-input, #0f3460);
    border:         1px solid var(--cf-border, rgba(255,255,255,0.1));
    color:          var(--cf-text, #e0e0e0);
    border-radius:  var(--cf-radius-sm, 4px);
    padding:        3px 10px;
    cursor:         pointer;
    font-size:      12px;
    transition:     background 0.15s;
}

.cf-sb-nav-btn:hover:not(:disabled) {
    background: rgba(123,104,238,0.2);
    border-color: var(--cf-primary, #7b68ee);
}

.cf-sb-nav-btn:disabled {
    opacity:  0.3;
    cursor:   not-allowed;
}

.cf-sb-nav-label {
    font-size:      12px;
    font-weight:    700;
    color:          var(--cf-text, #e0e0e0);
    min-width:      48px;
    text-align:     center;
}

.cf-sb-nav-type {
    font-size:      10px;
    color:          var(--cf-text-muted, #888);
}
`;
    document.head.appendChild(style);
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

function _esc(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}