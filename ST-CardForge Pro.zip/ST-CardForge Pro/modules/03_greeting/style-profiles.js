/**
 * @file modules/03_greeting/style-profiles.js
 * @description 开场白风格档案库
 *              定义写作风格、情景类型、视角选项及其对 Prompt 的修饰文本
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 写作风格档案
// ─────────────────────────────────────────────

/**
 * @typedef {Object} StyleProfile
 * @property {string} label       显示名称
 * @property {string} icon        图标
 * @property {string} desc        简短说明
 * @property {string} promptMod   注入 Prompt 的修饰文本
 * @property {string} exampleHint 示例提示（用于 UI tooltip）
 */

export const STYLE_PROFILES = Object.freeze({

    literary: {
        label:      '📖 文学化',
        icon:       '📖',
        desc:       '优美的文字，丰富的意象，具有文学质感',
        promptMod:  `写作风格要求：
- 使用精炼优美的文学语言，避免平铺直叙
- 多运用比喻、通感、意象等修辞手法
- 注重意境的营造，让读者身临其境
- 段落节奏舒缓有致，如散文般流畅`,
        exampleHint: '「月色如水，漫过青石板路的每一道缝隙……」',
    },

    casual: {
        label:      '💬 轻松日常',
        icon:       '💬',
        desc:       '口语化、亲切自然，如朋友对话',
        promptMod:  `写作风格要求：
- 语言自然口语化，贴近日常对话
- 可以用短句、省略号、感叹词增强真实感
- 轻松活泼，不要过于严肃
- 保持角色的个人说话习惯和小癖好`,
        exampleHint: '「哦，来了啊？等你好一会儿了——进来进来！」',
    },

    dramatic: {
        label:      '🎭 戏剧性',
        icon:       '🎭',
        desc:       '张力十足，充满戏剧冲突感',
        promptMod:  `写作风格要求：
- 营造强烈的戏剧张力和冲突感
- 善用悬念、转折和出人意料的细节
- 动作和情绪描写要有力度和冲击感
- 节奏紧凑，让读者迫不及待想继续`,
        exampleHint: '「*她猛地抬起头——那双眼睛里，藏着整座深渊。*」',
    },

    mysterious: {
        label:      '🌙 神秘感',
        icon:       '🌙',
        desc:       '含蓄克制，充满意味深长的留白',
        promptMod:  `写作风格要求：
- 语言含蓄克制，多用暗示而非直述
- 留有大量耐人寻味的空白和细节
- 营造一种「未说出口的秘密」的氛围
- 让读者感到好奇，想要探究更多`,
        exampleHint: '「她只是微微一笑，什么都没说——但那笑容里，似乎什么都说了。」',
    },

    poetic: {
        label:      '🌸 诗意',
        icon:       '🌸',
        desc:       '充满诗意与意境，东方美学气质',
        promptMod:  `写作风格要求：
- 语言如诗，富有意境和节奏感
- 善用自然意象（山水、花鸟、四季）
- 文字轻盈飘逸，如水墨画般淡雅
- 可适当引用诗词或创造诗意的表达`,
        exampleHint: '「落花无声，他站在风里，像一首还没写完的诗。」',
    },

    action: {
        label:      '⚔️ 动作派',
        icon:       '⚔️',
        desc:       '节奏明快，充满力量感与动感',
        promptMod:  `写作风格要求：
- 节奏快速有力，短句为主
- 动作描写精准具体，每个细节都有画面感
- 充满肾上腺素的紧张感和力量感
- 对话简练有力，角色行动胜于言辞`,
        exampleHint: '「*刀光一闪。他侧身让过，反手扣住对方手腕——*「说。」」',
    },

    slice_life: {
        label:      '☕ 日常感',
        icon:       '☕',
        desc:       '细腻温暖的生活气息，治愈向',
        promptMod:  `写作风格要求：
- 捕捉细小而温暖的生活细节
- 营造治愈、温馨的氛围
- 笔触细腻，关注感官体验（气味、触感、声音）
- 慢节奏，让读者感到放松和愉悦`,
        exampleHint: '「咖啡机开始咕噜作响，窗外的阳光正好落在地板的某个角落。」',
    },

    formal: {
        label:      '📜 正式文体',
        icon:       '📜',
        desc:       '庄重严肃的文风，适合历史/贵族背景',
        promptMod:  `写作风格要求：
- 语言庄重典雅，符合角色的贵族/官方身份
- 用词正式，避免口语化表达
- 适当使用文言词汇或正式称谓
- 展现角色的教养、身份和威严`,
        exampleHint: '「在下见过阁下。久仰大名，今日得见，实乃幸甚。」',
    },

    gothic: {
        label:      '🖤 哥特暗黑',
        icon:       '🖤',
        desc:       '黑暗美学，颓废又迷人的气质',
        promptMod:  `写作风格要求：
- 黑暗、颓废而又迷人的美学气质
- 善用死亡、玫瑰、黑夜等哥特意象
- 语言华丽而忧郁，带有末世美感
- 角色气质神秘危险，让人敬畏又着迷`,
        exampleHint: '「*腐朽的玫瑰香气弥漫开来……*「你终于来了，我的祭品。」」',
    },

    humorous: {
        label:      '😄 幽默风趣',
        icon:       '😄',
        desc:       '充满笑点，轻松诙谐',
        promptMod:  `写作风格要求：
- 轻松诙谐，适时加入笑点和俏皮话
- 角色可以有意无意地制造幽默效果
- 避免过于严肃，保持轻松欢快的基调
- 角色的窘迫或反应可以夸张化处理`,
        exampleHint: '「「我是传说中的——」*一个踉跄*「——传说中摔了个狗啃泥的。」」',
    },

});

// ─────────────────────────────────────────────
// 情景类型定义
// ─────────────────────────────────────────────

/**
 * @typedef {Object} ScenarioProfile
 * @property {string} label
 * @property {string} icon
 * @property {string} desc
 * @property {string} promptMod
 */

export const SCENARIOS = Object.freeze({

    first_meeting: {
        label:     '✨ 初次相遇',
        icon:      '✨',
        desc:      '角色与玩家第一次见面',
        promptMod: '情景：这是角色与{{user}}第一次相遇的场景。要有初见的新鲜感和适当的距离感，为后续关系发展留下空间。',
    },

    reunion: {
        label:     '🔄 久别重逢',
        icon:      '🔄',
        desc:      '分离已久，重新相见',
        promptMod: '情景：角色与{{user}}久别重逢。应包含时光流逝的感慨、物是人非的微妙，以及重见旧人的复杂情绪。',
    },

    crisis: {
        label:     '🚨 危机时刻',
        icon:      '🚨',
        desc:      '两人正面临紧急危机',
        promptMod: '情景：角色与{{user}}正处于紧急危机中，时间紧迫，形势危险。节奏应紧张快速，体现角色在危急时刻的反应。',
    },

    daily: {
        label:     '☀️ 日常相处',
        icon:      '☀️',
        desc:      '普通的日常场景',
        promptMod: '情景：这是角色与{{user}}普通而温馨的日常场景。轻松自然，展现角色在放松状态下的真实性格。',
    },

    conflict: {
        label:     '⚡ 正面冲突',
        icon:      '⚡',
        desc:      '角色与玩家之间存在矛盾',
        promptMod: '情景：角色与{{user}}之间产生了正面冲突或矛盾。角色的立场鲜明，但内心的冲突也要有所体现。',
    },

    confession: {
        label:     '💗 坦白时刻',
        icon:      '💗',
        desc:      '角色准备吐露心声',
        promptMod: '情景：角色即将向{{user}}坦白某件重要的事，可能是感情，也可能是秘密。充满紧张感和情绪张力。',
    },

    farewell: {
        label:     '🌅 告别离去',
        icon:      '🌅',
        desc:      '即将分离的时刻',
        promptMod: '情景：角色与{{user}}即将告别，不知何时再见。充满不舍、留恋，以及对未来的未知感。',
    },

    adventure_start: {
        label:     '🗺 冒险启程',
        icon:      '🗺',
        desc:      '一段新冒险的开始',
        promptMod: '情景：角色与{{user}}即将踏上一段新的冒险旅程。充满期待、未知和跃跃欲试的兴奋感。',
    },

    night_talk: {
        label:     '🌙 深夜倾谈',
        icon:      '🌙',
        desc:      '夜深人静的私密对话',
        promptMod: '情景：深夜，角色与{{user}}独处，进行一场私密而坦诚的倾谈。氛围宁静，两人的距离在夜色中无形拉近。',
    },

    custom: {
        label:     '✏️ 自定义',
        icon:      '✏️',
        desc:      '自定义情景描述',
        promptMod: '',  // 由用户输入
    },

});

// ─────────────────────────────────────────────
// 视角选项
// ─────────────────────────────────────────────

export const POV_OPTIONS = Object.freeze({
    first: {
        label:     '第一人称（我）',
        icon:      '👤',
        promptMod: '以角色第一人称（「我」）写作，让读者直接进入角色内心世界。',
    },
    second: {
        label:     '第二人称（你）',
        icon:      '👥',
        promptMod: '以第二人称（「你」）写作，直接对{{user}}说话，代入感更强。',
    },
    third: {
        label:     '第三人称',
        icon:      '📝',
        promptMod: '以第三人称（「她/他」）写作，旁观者视角，有利于描写动作和场景。',
    },
});

// ─────────────────────────────────────────────
// 字数档次
// ─────────────────────────────────────────────

export const WORD_COUNT_PRESETS = Object.freeze([
    { label: '极短（约 80 字）',   value: 80,  hint: '适合简洁有力的第一印象' },
    { label: '短（约 150 字）',    value: 150, hint: '适合轻松日常场景' },
    { label: '标准（约 250 字）',  value: 250, hint: '平衡感强，推荐默认' },
    { label: '长（约 400 字）',    value: 400, hint: '适合复杂剧情或初次相遇' },
    { label: '超长（约 600 字）',  value: 600, hint: '适合史诗开场或重要场景' },
]);

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────

/**
 * 获取完整的风格 Prompt 修饰文本
 * 组合：写作风格 + 情景 + 视角
 *
 * @param {object} options
 * @param {string} options.style      STYLE_PROFILES 中的 key
 * @param {string} options.scenario   SCENARIOS 中的 key
 * @param {string} options.pov        POV_OPTIONS 中的 key
 * @param {string} [options.customScenario]  自定义情景描述（scenario='custom' 时使用）
 * @returns {string}
 */
export function buildStylePrompt(options = {}) {
    const {
        style          = 'literary',
        scenario       = 'first_meeting',
        pov            = 'first',
        customScenario = '',
    } = options;

    const styleMod    = STYLE_PROFILES[style]?.promptMod    ?? '';
    const povMod      = POV_OPTIONS[pov]?.promptMod         ?? '';
    const scenarioMod = scenario === 'custom'
        ? (customScenario ? `情景：${customScenario}` : '')
        : (SCENARIOS[scenario]?.promptMod ?? '');

    return [styleMod, scenarioMod, povMod]
        .filter(Boolean)
        .join('\n\n');
}

/**
 * 获取所有风格列表
 * @returns {Array<{ key, label, icon, desc }>}
 */
export function listStyles() {
    return Object.entries(STYLE_PROFILES).map(([key, val]) => ({
        key,
        label: val.label,
        icon:  val.icon,
        desc:  val.desc,
    }));
}

/**
 * 获取所有情景列表
 * @returns {Array<{ key, label, icon, desc }>}
 */
export function listScenarios() {
    return Object.entries(SCENARIOS).map(([key, val]) => ({
        key,
        label: val.label,
        icon:  val.icon,
        desc:  val.desc,
    }));
}

/**
 * 根据角色风格标签智能推荐写作风格
 * @param {string[]} tags  角色卡 tags 数组
 * @param {string}   genre 世界观风格
 * @returns {string}  推荐的 STYLE_PROFILES key
 */
export function recommendStyle(tags = [], genre = 'fantasy') {
    const tagStr = tags.join(' ').toLowerCase();

    // 基于标签推荐
    if (/dark|horror|gothic|villain/.test(tagStr))    return 'gothic';
    if (/comedy|funny|humor|silly/.test(tagStr))       return 'humorous';
    if (/action|fight|warrior|combat/.test(tagStr))    return 'action';
    if (/mystery|secret|detective/.test(tagStr))       return 'mysterious';
    if (/romance|love|sweet/.test(tagStr))             return 'poetic';
    if (/modern|contemporary|slice.?of.?life/.test(tagStr)) return 'slice_life';
    if (/noble|aristocrat|royal|formal/.test(tagStr)) return 'formal';

    // 基于世界观风格推荐
    const genreMap = {
        fantasy:    'literary',
        eastern:    'poetic',
        modern:     'casual',
        scifi:      'dramatic',
        horror:     'gothic',
        cyberpunk:  'dramatic',
        mythology:  'literary',
        historical: 'formal',
    };
    return genreMap[genre] ?? 'literary';
}