/**
 * @file modules/04_stscript-forge/debugger.js
 * @description STscript 调试器
 *              提供：单步执行模拟、变量快照追踪、执行轨迹记录、
 *              断点管理、执行结果 diff 对比、调试日志面板等功能。
 *              注意：STscript 本身无法被真正「单步执行」，
 *              本调试器通过静态分析 + 模拟变量状态来提供调试体验。
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  调试器状态枚举
// ═══════════════════════════════════════════════

/**
 * 调试会话状态
 * @enum {string}
 */
export const DEBUG_STATE = {
    /** 空闲，未加载脚本 */
    IDLE:       'idle',
    /** 已加载脚本，等待运行 */
    READY:      'ready',
    /** 单步暂停中 */
    PAUSED:     'paused',
    /** 正在执行（连续运行模式） */
    RUNNING:    'running',
    /** 执行完毕 */
    FINISHED:   'finished',
    /** 遇到错误，已中止 */
    ERROR:      'error',
};

/**
 * 执行步骤类型
 * @enum {string}
 */
export const STEP_TYPE = {
    COMMAND:    'command',      // 普通命令执行
    VAR_SET:    'var_set',      // 变量赋值
    VAR_GET:    'var_get',      // 变量读取
    CONDITION:  'condition',    // 条件判断
    BRANCH:     'branch',       // 分支跳转
    PIPE:       'pipe',         // 管道传递
    ECHO:       'echo',         // echo 输出
    ERROR:      'error',        // 错误步骤
    SKIP:       'skip',         // 被跳过的行（注释/空行）
};

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} DebugStep
 * @property {number}  stepIndex   - 步骤序号（从 0 开始）
 * @property {number}  lineNumber  - 对应脚本行号（从 1 开始）
 * @property {string}  lineContent - 原始行内容
 * @property {string}  type        - STEP_TYPE 中的值
 * @property {string}  command     - 解析出的命令（如 '/setvar'）
 * @property {object}  params      - 解析出的参数对象
 * @property {object}  varsBefore  - 执行前的变量快照
 * @property {object}  varsAfter   - 执行后的变量快照（模拟）
 * @property {string}  [output]    - 该步骤产生的输出（echo/input 等）
 * @property {boolean} [hasBreakpoint] - 该行是否设置了断点
 * @property {string}  [error]     - 该步骤的错误信息（如有）
 * @property {number}  [duration]  - 模拟执行耗时（毫秒）
 */

/**
 * @typedef {Object} DebugSession
 * @property {string}      id          - 会话 ID
 * @property {string}      script      - 被调试的脚本
 * @property {DebugStep[]} steps       - 所有解析出的步骤
 * @property {number}      currentStep - 当前执行到的步骤索引
 * @property {object}      variables   - 当前变量状态（key→value）
 * @property {string[]}    outputs     - 累积的输出日志
 * @property {DEBUG_STATE} state       - 调试会话状态
 * @property {Set<number>} breakpoints - 断点行号集合
 * @property {number}      startTime   - 会话开始时间戳
 */

// ═══════════════════════════════════════════════
// § 3  STScriptDebugger 主类
// ═══════════════════════════════════════════════

/**
 * STscript 调试器
 * 通过静态分析将脚本分解为可逐步追踪的步骤序列，
 * 并模拟变量状态变化，提供类 IDE 的调试体验。
 */
export class STScriptDebugger {
    /**
     * @param {object} eventBus - EventBus 实例
     * @param {object} [options]
     * @param {number} [options.stepDelayMs=200]   - 连续运行时每步延迟（毫秒）
     * @param {number} [options.maxSteps=500]       - 防止死循环的最大步骤数
     * @param {Function} [options.onStepChange]     - 每步执行后的回调
     * @param {Function} [options.onOutputAppend]   - 有新输出时的回调
     * @param {Function} [options.onStateChange]    - 调试状态变化的回调
     */
    constructor(eventBus, options = {}) {
        this._eventBus = eventBus;
        this._options  = {
            stepDelayMs:    200,
            maxSteps:       500,
            onStepChange:   null,
            onOutputAppend: null,
            onStateChange:  null,
            ...options,
        };

        /** @type {DebugSession|null} */
        this._session       = null;

        /** @type {boolean} */
        this._runningTimer  = null;
    }

    // ─── 会话管理 ─────────────────────────────────

    /**
     * 加载脚本，创建新调试会话
     * @param {string} script          - 要调试的 STscript 文本
     * @param {object} [initVars={}]   - 初始变量集（模拟预设变量）
     * @returns {DebugSession}
     */
    loadScript(script, initVars = {}) {
        // 停止旧会话
        this.stop();

        const steps = this._parseScriptToSteps(script, initVars);

        this._session = {
            id:          `dbg_${Date.now()}`,
            script,
            steps,
            currentStep: -1,        // -1 表示尚未开始
            variables:   { ...initVars },
            outputs:     [],
            state:       DEBUG_STATE.READY,
            breakpoints: new Set(),
            startTime:   Date.now(),
        };

        this._setState(DEBUG_STATE.READY);
        return this._session;
    }

    /**
     * 单步执行（执行下一步）
     * @returns {DebugStep|null} 刚执行的步骤，执行完毕返回 null
     */
    stepForward() {
        if (!this._session) return null;
        if (this._session.state === DEBUG_STATE.FINISHED) return null;
        if (this._session.state === DEBUG_STATE.ERROR)    return null;

        const nextIdx = this._session.currentStep + 1;
        if (nextIdx >= this._session.steps.length) {
            this._setState(DEBUG_STATE.FINISHED);
            return null;
        }

        this._session.currentStep = nextIdx;
        const step = this._session.steps[nextIdx];

        // 模拟执行该步骤（更新变量状态、收集输出）
        this._executeStep(step);
        this._setState(DEBUG_STATE.PAUSED);

        if (this._options.onStepChange) {
            this._options.onStepChange(step, this._session);
        }

        return step;
    }

    /**
     * 单步回退（撤销上一步的变量状态）
     * @returns {DebugStep|null} 回退到的步骤
     */
    stepBackward() {
        if (!this._session) return null;
        if (this._session.currentStep <= 0) return null;

        this._session.currentStep--;
        const step = this._session.steps[this._session.currentStep];

        // 恢复该步骤执行前的变量快照
        this._session.variables = { ...step.varsBefore };
        this._setState(DEBUG_STATE.PAUSED);

        if (this._options.onStepChange) {
            this._options.onStepChange(step, this._session);
        }

        return step;
    }

    /**
     * 连续运行（直到结束或遇到断点）
     * @returns {Promise<void>}
     */
    async run() {
        if (!this._session) return;
        this._setState(DEBUG_STATE.RUNNING);

        let safetyCounter = 0;

        while (
            this._session.state === DEBUG_STATE.RUNNING &&
            this._session.currentStep + 1 < this._session.steps.length
        ) {
            if (++safetyCounter > this._options.maxSteps) {
                this._appendOutput('⚠️ [调试器] 超过最大步骤限制，强制停止');
                this._setState(DEBUG_STATE.ERROR);
                break;
            }

            const nextIdx = this._session.currentStep + 1;
            const nextStep = this._session.steps[nextIdx];

            // 遇到断点时暂停
            if (this._session.breakpoints.has(nextStep.lineNumber)) {
                this.stepForward();
                this._setState(DEBUG_STATE.PAUSED);
                this._appendOutput(`⏸️ [调试器] 断点命中：第 ${nextStep.lineNumber} 行`);
                break;
            }

            this.stepForward();

            // 连续运行时加入延迟，防止界面卡死
            if (this._options.stepDelayMs > 0) {
                await _sleep(this._options.stepDelayMs);
            }
        }

        if (this._session.state === DEBUG_STATE.RUNNING) {
            this._setState(DEBUG_STATE.FINISHED);
        }
    }

    /**
     * 停止/重置调试会话
     */
    stop() {
        if (this._runningTimer) {
            clearTimeout(this._runningTimer);
            this._runningTimer = null;
        }
        if (this._session) {
            this._setState(DEBUG_STATE.IDLE);
        }
        this._session = null;
    }

    /**
     * 重新开始（保留脚本和初始变量，重置执行位置）
     */
    restart() {
        if (!this._session) return;
        const { script, breakpoints } = this._session;
        this.loadScript(script);
        this._session.breakpoints = breakpoints;   // 保留断点
    }

    // ─── 断点管理 ─────────────────────────────────

    /**
     * 添加断点
     * @param {number} lineNumber - 行号（从 1 开始）
     */
    addBreakpoint(lineNumber) {
        if (!this._session) return;
        this._session.breakpoints.add(lineNumber);
    }

    /**
     * 移除断点
     * @param {number} lineNumber
     */
    removeBreakpoint(lineNumber) {
        if (!this._session) return;
        this._session.breakpoints.delete(lineNumber);
    }

    /**
     * 切换断点（有则删，无则加）
     * @param {number} lineNumber
     * @returns {boolean} 操作后该行是否有断点
     */
    toggleBreakpoint(lineNumber) {
        if (!this._session) return false;
        if (this._session.breakpoints.has(lineNumber)) {
            this._session.breakpoints.delete(lineNumber);
            return false;
        } else {
            this._session.breakpoints.add(lineNumber);
            return true;
        }
    }

    /**
     * 清除所有断点
     */
    clearBreakpoints() {
        if (!this._session) return;
        this._session.breakpoints.clear();
    }

    /**
     * 获取所有断点行号
     * @returns {number[]}
     */
    getBreakpoints() {
        if (!this._session) return [];
        return [...this._session.breakpoints];
    }

    // ─── 变量监控 ─────────────────────────────────

    /**
     * 获取当前变量快照
     * @returns {object}
     */
    getVariables() {
        return this._session ? { ...this._session.variables } : {};
    }

    /**
     * 手动修改变量值（调试时注入）
     * @param {string} key
     * @param {string|number} value
     */
    setVariable(key, value) {
        if (!this._session) return;
        this._session.variables[key] = value;
        this._appendOutput(`🔧 [调试器] 手动注入变量：${key} = ${value}`);
    }

    /**
     * 获取变量的历史变化记录
     * @param {string} key - 变量名
     * @returns {Array<{ stepIndex: number, before: *, after: * }>}
     */
    getVariableHistory(key) {
        if (!this._session) return [];
        return this._session.steps
            .filter(step =>
                step.varsAfter[key] !== step.varsBefore[key] &&
                step.stepIndex <= this._session.currentStep
            )
            .map(step => ({
                stepIndex: step.stepIndex,
                lineNumber: step.lineNumber,
                before:    step.varsBefore[key],
                after:     step.varsAfter[key],
            }));
    }

    // ─── 状态查询 ─────────────────────────────────

    /**
     * 获取当前会话状态
     * @returns {DebugSession|null}
     */
    getSession() {
        return this._session;
    }

    /**
     * 获取当前步骤
     * @returns {DebugStep|null}
     */
    getCurrentStep() {
        if (!this._session || this._session.currentStep < 0) return null;
        return this._session.steps[this._session.currentStep] ?? null;
    }

    /**
     * 获取调试输出日志
     * @returns {string[]}
     */
    getOutputs() {
        return this._session ? [...this._session.outputs] : [];
    }

    /**
     * 获取所有步骤列表
     * @returns {DebugStep[]}
     */
    getSteps() {
        return this._session ? [...this._session.steps] : [];
    }

    /**
     * 是否可以继续步进
     * @returns {boolean}
     */
    canStepForward() {
        if (!this._session) return false;
        return (
            this._session.state !== DEBUG_STATE.FINISHED &&
            this._session.state !== DEBUG_STATE.ERROR &&
            this._session.currentStep + 1 < this._session.steps.length
        );
    }

    /**
     * 是否可以回退
     * @returns {boolean}
     */
    canStepBackward() {
        if (!this._session) return false;
        return this._session.currentStep > 0;
    }

    // ═══════════════════════════════════════════════
    // § 4  脚本解析器（私有）
    // ═══════════════════════════════════════════════

    /**
     * 将 STscript 文本解析为步骤数组
     * @param {string} script
     * @param {object} initVars
     * @returns {DebugStep[]}
     */
    _parseScriptToSteps(script, initVars) {
        const rawLines = script.split('\n');
        const steps    = [];
        let   vars     = { ...initVars };
        let   stepIdx  = 0;

        rawLines.forEach((rawLine, lineIdx) => {
            const lineNumber = lineIdx + 1;
            const trimmed    = rawLine.trim();

            // 空行或注释：记录为 SKIP 步骤
            if (!trimmed || trimmed.startsWith('//')) {
                steps.push({
                    stepIndex:    stepIdx++,
                    lineNumber,
                    lineContent:  rawLine,
                    type:         STEP_TYPE.SKIP,
                    command:      '',
                    params:       {},
                    varsBefore:   { ...vars },
                    varsAfter:    { ...vars },
                    hasBreakpoint: false,
                });
                return;
            }

            // 解析命令
            const parsed = _parseOneLine(trimmed);

            // 构建步骤（varsAfter 在 _executeStep 时填充）
            const step = {
                stepIndex:    stepIdx++,
                lineNumber,
                lineContent:  rawLine,
                type:         parsed.type,
                command:      parsed.command,
                params:       parsed.params,
                varsBefore:   { ...vars },
                varsAfter:    { ...vars },  // 占位，执行时更新
                output:       '',
                hasBreakpoint: false,
                error:        null,
                duration:     0,
            };

            steps.push(step);
        });

        return steps;
    }

    // ═══════════════════════════════════════════════
    // § 5  步骤模拟执行器（私有）
    // ═══════════════════════════════════════════════

    /**
     * 模拟执行单个步骤，更新变量状态和输出
     * @param {DebugStep} step
     */
    _executeStep(step) {
        const startTime = Date.now();
        const vars      = { ...this._session.variables };

        try {
            switch (step.command) {

                case '/setvar': {
                    const key   = _resolveInterpolation(step.params.key   || '', vars);
                    const value = _resolveInterpolation(step.params.value || '', vars);
                    vars[key]   = value;
                    step.type   = STEP_TYPE.VAR_SET;
                    step.output = `✏️ ${key} ← "${value}"`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/getvar': {
                    const key   = step.params._arg || '';
                    const value = vars[key] ?? '(未定义)';
                    step.type   = STEP_TYPE.VAR_GET;
                    step.output = `📖 getvar::${key} = "${value}"`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/addvar': {
                    const key     = step.params.key   || '';
                    const delta   = parseFloat(step.params.value || '0');
                    const current = parseFloat(vars[key] || '0');
                    vars[key]     = String(current + delta);
                    step.type     = STEP_TYPE.VAR_SET;
                    step.output   = `➕ ${key} = ${current} + ${delta} → ${vars[key]}`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/subvar': {
                    const key     = step.params.key   || '';
                    const delta   = parseFloat(step.params.value || '0');
                    const current = parseFloat(vars[key] || '0');
                    vars[key]     = String(current - delta);
                    step.type     = STEP_TYPE.VAR_SET;
                    step.output   = `➖ ${key} = ${current} - ${delta} → ${vars[key]}`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/flushvar': {
                    const key = step.params._arg || '';
                    delete vars[key];
                    step.type   = STEP_TYPE.VAR_SET;
                    step.output = `🗑️ flushvar::${key}`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/echo': {
                    const msg   = _resolveInterpolation(step.params._arg || '', vars);
                    step.type   = STEP_TYPE.ECHO;
                    step.output = `💬 echo → "${msg}"`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/if': {
                    const left    = _resolveInterpolation(step.params.left  || '', vars);
                    const right   = _resolveInterpolation(step.params.right || '', vars);
                    const op      = step.params._op || 'eq';
                    const result  = _evaluateCondition(left, right, op);
                    step.type     = STEP_TYPE.CONDITION;
                    step.output   = `🔀 if ${left} ${op} ${right} → ${result ? '✅ true' : '❌ false'}`;
                    // 模拟存储条件结果（用于 /else 追踪）
                    vars['_if_result_last'] = String(result);
                    this._appendOutput(step.output);
                    break;
                }

                case '/else': {
                    step.type   = STEP_TYPE.BRANCH;
                    step.output = `↩️ else 分支`;
                    this._appendOutput(step.output);
                    break;
                }

                case '/input': {
                    const prompt = _resolveInterpolation(step.params._arg || '请输入：', vars);
                    step.output  = `⌨️ input 弹窗 → "${prompt}"（调试模式：返回空字符串）`;
                    vars['_pipe'] = '';      // 调试模式下 input 返回空字符串
                    this._appendOutput(step.output);
                    break;
                }

                default: {
                    // 其他命令：记录但不模拟具体效果
                    const argStr = JSON.stringify(step.params);
                    step.output  = `⚙️ ${step.command} ${argStr}`;
                    this._appendOutput(step.output);
                    break;
                }
            }
        } catch (err) {
            step.type  = STEP_TYPE.ERROR;
            step.error = err.message;
            step.output = `❌ 错误：${err.message}`;
            this._appendOutput(step.output);
            this._setState(DEBUG_STATE.ERROR);
        }

        // 更新变量快照和耗时
        step.varsAfter    = { ...vars };
        step.duration     = Date.now() - startTime;
        this._session.variables = vars;
    }

    // ═══════════════════════════════════════════════
    // § 6  辅助方法（私有）
    // ═══════════════════════════════════════════════

    /**
     * 更新调试状态并触发回调
     * @param {DEBUG_STATE} state
     */
    _setState(state) {
        if (this._session) this._session.state = state;
        if (this._options.onStateChange) {
            this._options.onStateChange(state, this._session);
        }
    }

    /**
     * 追加输出日志并触发回调
     * @param {string} message
     */
    _appendOutput(message) {
        if (!this._session) return;
        const ts  = new Date().toLocaleTimeString();
        const log = `[${ts}] ${message}`;
        this._session.outputs.push(log);
        if (this._options.onOutputAppend) {
            this._options.onOutputAppend(log, this._session.outputs);
        }
    }

    // ═══════════════════════════════════════════════
    // § 7  执行统计
    // ═══════════════════════════════════════════════

    /**
     * 获取调试会话统计信息
     * @returns {object}
     */
    getStats() {
        if (!this._session) return {};

        const executedSteps = this._session.steps.slice(
            0, this._session.currentStep + 1
        );

        const byType = {};
        executedSteps.forEach(s => {
            byType[s.type] = (byType[s.type] || 0) + 1;
        });

        const varCount  = Object.keys(this._session.variables).length;
        const totalTime = executedSteps.reduce((sum, s) => sum + (s.duration || 0), 0);

        return {
            totalSteps:    this._session.steps.length,
            executedSteps: executedSteps.length,
            remainingSteps: this._session.steps.length - executedSteps.length - 1,
            stepsByType:   byType,
            variableCount: varCount,
            outputCount:   this._session.outputs.length,
            totalDuration: totalTime,
            breakpointCount: this._session.breakpoints.size,
            sessionState:  this._session.state,
            elapsedMs:     Date.now() - this._session.startTime,
        };
    }
}

// ═══════════════════════════════════════════════
// § 8  独立工具函数（纯函数，可单独使用）
// ═══════════════════════════════════════════════

/**
 * 解析单行 STscript，返回命令和参数
 *
 * @param {string} line - 已 trim 的单行
 * @returns {{ command: string, params: object, type: string }}
 */
function _parseOneLine(line) {
    // 不是命令行
    if (!line.startsWith('/')) {
        return { command: '', params: { _raw: line }, type: STEP_TYPE.SKIP };
    }

    // 提取命令名
    const spaceIdx = line.search(/\s/);
    const command  = spaceIdx === -1 ? line : line.slice(0, spaceIdx);
    const rest     = spaceIdx === -1 ? '' : line.slice(spaceIdx + 1).trim();

    // 解析 key=value 形式的参数
    const params   = _parseParams(rest, command);

    // 推断步骤类型
    const type = _inferStepType(command);

    return { command, params, type };
}

/**
 * 解析命令参数字符串为键值对
 * @param {string} rest    - 命令名后面的剩余字符串
 * @param {string} command - 命令名（用于特殊处理）
 * @returns {object}
 */
function _parseParams(rest, command) {
    const params = {};

    // 提取所有 key=value 对（支持引号内含空格）
    const kvPattern = /(\w+)=("(?:[^"\\]|\\.)*"|[^\s|]+)/g;
    let match;
    let lastIndex = 0;

    while ((match = kvPattern.exec(rest)) !== null) {
        const key   = match[1];
        let   value = match[2];
        // 去掉外层引号
        if (value.startsWith('"') && value.endsWith('"')) {
            value = value.slice(1, -1);
        }
        params[key] = value;
        lastIndex   = kvPattern.lastIndex;
    }

    // 残余文本作为位置参数 _arg
    const remaining = rest.replace(kvPattern, '').trim();
    if (remaining) {
        // 去掉管道符
        params._arg = remaining.replace(/\s*\|\s*$/, '').trim()
            .replace(/^"(.+)"$/, '$1');
    }

    // /if 命令特殊处理：提取操作符（eq/neq/gt/...）
    if (command === '/if') {
        const opPattern = /\b(eq|neq|gt|gte|lt|lte|contains|not-contains)\b/;
        const opMatch   = rest.match(opPattern);
        if (opMatch) params._op = opMatch[1];
    }

    return params;
}

/**
 * 根据命令名推断步骤类型
 * @param {string} command
 * @returns {string}
 */
function _inferStepType(command) {
    if (['/setvar', '/addvar', '/subvar', '/mulvar', '/divvar', '/flushvar', '/let', '/var'].includes(command)) {
        return STEP_TYPE.VAR_SET;
    }
    if (['/getvar'].includes(command)) {
        return STEP_TYPE.VAR_GET;
    }
    if (['/if', '/while'].includes(command)) {
        return STEP_TYPE.CONDITION;
    }
    if (['/else', '/break', '/continue', '/return', '/pass', '/abort'].includes(command)) {
        return STEP_TYPE.BRANCH;
    }
    if (['/echo', '/input', '/popup', '/prompt'].includes(command)) {
        return STEP_TYPE.ECHO;
    }
    return STEP_TYPE.COMMAND;
}

/**
 * 解析 {{xxx}} 插值，将变量替换为实际值
 * @param {string} text
 * @param {object} vars
 * @returns {string}
 */
function _resolveInterpolation(text, vars) {
    return text.replace(/\{\{getvar::([^}]+)\}\}/g, (_, key) => {
        return vars[key] !== undefined ? String(vars[key]) : `(${key}:未定义)`;
    }).replace(/\{\{([^}:]+)\}\}/g, (match, key) => {
        // 简单变量名
        return vars[key] !== undefined ? String(vars[key]) : match;
    });
}

/**
 * 模拟条件判断
 * @param {string} left
 * @param {string} right
 * @param {string} op
 * @returns {boolean}
 */
function _evaluateCondition(left, right, op) {
    const numLeft  = parseFloat(left);
    const numRight = parseFloat(right);
    const hasNums  = !isNaN(numLeft) && !isNaN(numRight);

    switch (op) {
        case 'eq':           return left === right;
        case 'neq':          return left !== right;
        case 'gt':           return hasNums ? numLeft >  numRight : left >  right;
        case 'gte':          return hasNums ? numLeft >= numRight : left >= right;
        case 'lt':           return hasNums ? numLeft <  numRight : left <  right;
        case 'lte':          return hasNums ? numLeft <= numRight : left <= right;
        case 'contains':     return left.includes(right);
        case 'not-contains': return !left.includes(right);
        case 'starts-with':  return left.startsWith(right);
        case 'ends-with':    return left.endsWith(right);
        default:             return left === right;
    }
}

/**
 * 睡眠函数（用于连续运行的步骤间延迟）
 * @param {number} ms
 * @returns {Promise<void>}
 */
function _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ═══════════════════════════════════════════════
// § 9  DebugPanel UI 辅助类
// ═══════════════════════════════════════════════

/**
 * 调试面板 UI 辅助（将调试器状态渲染到 DOM）
 * 与 ui-script-builder.html 中的面板元素配合使用
 */
export class DebugPanel {
    /**
     * @param {HTMLElement} containerElement - 调试面板容器
     * @param {STScriptDebugger} debugger_   - 调试器实例
     */
    constructor(containerElement, debugger_) {
        this._container = containerElement;
        this._debugger  = debugger_;
        this._elements  = {};
        this._init();
    }

    /**
     * 初始化 DOM 引用
     */
    _init() {
        this._elements = {
            stepsTable:   this._container.querySelector('.cf-debug-steps'),
            varsTable:    this._container.querySelector('.cf-debug-vars'),
            outputLog:    this._container.querySelector('.cf-debug-output'),
            statsBar:     this._container.querySelector('.cf-debug-stats'),
            progressBar:  this._container.querySelector('.cf-debug-progress'),
        };
    }

    /**
     * 渲染步骤列表
     */
    renderSteps() {
        const el     = this._elements.stepsTable;
        if (!el) return;

        const steps  = this._debugger.getSteps();
        const cur    = this._debugger.getSession()?.currentStep ?? -1;
        const bps    = this._debugger.getBreakpoints();

        el.innerHTML = steps.map(step => {
            const isCurrent = step.stepIndex === cur;
            const hasBP     = bps.includes(step.lineNumber);
            const cls       = [
                'cf-debug-step-row',
                isCurrent ? 'cf-debug-step-current' : '',
                step.type === STEP_TYPE.ERROR ? 'cf-debug-step-error' : '',
                step.type === STEP_TYPE.SKIP  ? 'cf-debug-step-skip'  : '',
            ].filter(Boolean).join(' ');

            const bpIcon  = hasBP    ? '🔴' : '　';
            const curIcon = isCurrent ? '▶' : '　';
            const typeIcon = {
                [STEP_TYPE.VAR_SET]:   '✏️',
                [STEP_TYPE.VAR_GET]:   '📖',
                [STEP_TYPE.CONDITION]: '🔀',
                [STEP_TYPE.BRANCH]:    '↩️',
                [STEP_TYPE.ECHO]:      '💬',
                [STEP_TYPE.ERROR]:     '❌',
                [STEP_TYPE.SKIP]:      '　',
                [STEP_TYPE.COMMAND]:   '⚙️',
                [STEP_TYPE.PIPE]:      '→',
            }[step.type] || '⚙️';

            return `<tr class="${cls}" data-step="${step.stepIndex}" data-line="${step.lineNumber}">
                <td class="cf-debug-bp-col">${bpIcon}</td>
                <td class="cf-debug-cur-col">${curIcon}</td>
                <td class="cf-debug-line-col">${step.lineNumber}</td>
                <td class="cf-debug-type-col">${typeIcon}</td>
                <td class="cf-debug-code-col"><code>${_escapeHtml(step.lineContent)}</code></td>
                <td class="cf-debug-out-col">${_escapeHtml(step.output || '')}</td>
            </tr>`;
        }).join('');

        // 滚动到当前步骤
        const curRow = el.querySelector('.cf-debug-step-current');
        curRow?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    /**
     * 渲染变量监控表格
     */
    renderVariables() {
        const el   = this._elements.varsTable;
        if (!el) return;

        const vars = this._debugger.getVariables();
        const step = this._debugger.getCurrentStep();

        el.innerHTML = Object.entries(vars).map(([key, val]) => {
            // 检查是否是刚被修改的变量（高亮）
            const changed = step && step.varsAfter[key] !== step.varsBefore[key];
            const cls = changed ? 'cf-debug-var-changed' : '';
            return `<tr class="${cls}">
                <td class="cf-debug-var-key">${_escapeHtml(key)}</td>
                <td class="cf-debug-var-val">${_escapeHtml(String(val))}</td>
                <td class="cf-debug-var-type">${typeof val}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="3" class="cf-debug-empty">（暂无变量）</td></tr>';
    }

    /**
     * 渲染输出日志
     */
    renderOutput() {
        const el = this._elements.outputLog;
        if (!el) return;

        const outputs = this._debugger.getOutputs();
        el.innerHTML  = outputs
            .map(line => `<div class="cf-debug-log-line">${_escapeHtml(line)}</div>`)
            .join('');
        el.scrollTop = el.scrollHeight;
    }

    /**
     * 渲染统计信息栏
     */
    renderStats() {
        const el    = this._elements.statsBar;
        const pbEl  = this._elements.progressBar;
        if (!el) return;

        const stats = this._debugger.getStats();
        if (!stats.totalSteps) return;

        const pct = Math.round((stats.executedSteps / stats.totalSteps) * 100);

        el.innerHTML = [
            `步骤：${stats.executedSteps} / ${stats.totalSteps}`,
            `变量：${stats.variableCount}`,
            `断点：${stats.breakpointCount}`,
            `耗时：${stats.totalDuration}ms`,
        ].join('　|　');

        if (pbEl) {
            pbEl.style.width = `${pct}%`;
            pbEl.title       = `${pct}%`;
        }
    }

    /**
     * 全量刷新面板
     */
    refresh() {
        this.renderSteps();
        this.renderVariables();
        this.renderOutput();
        this.renderStats();
    }
}

/**
 * 转义 HTML（供 DebugPanel 使用）
 * @param {string} str
 * @returns {string}
 */
function _escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

export default STScriptDebugger;