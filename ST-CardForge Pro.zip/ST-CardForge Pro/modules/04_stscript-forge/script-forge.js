/**
 * @file script-forge.js
 * @description STscript 锻造器（简化版，移除未实现的依赖）
 * @version 1.0.0-simplified
 */

import { EVENTS } from '../../contracts.js';

// ═══════════════════════════════════════════════
// § 常量定义
// ═══════════════════════════════════════════════

export const FORGE_MODES = {
    FROM_DESCRIPTION: 'from_description',
    REFACTOR: 'refactor',
    FROM_TEMPLATE: 'from_template',
    FROM_VISUAL: 'from_visual',
};

const QR_DEFAULTS = {
    version: '1.0',
    disabledByDefault: false,
    isGlobal: false,
    quickReplySetCommands: [],
    quickReplies: [],
};

// ═══════════════════════════════════════════════
// § ScriptForge 主类
// ═══════════════════════════════════════════════

export class ScriptForge {
    constructor(aiEngine, eventBus, settings) {
        this._ai = aiEngine;
        this._bus = eventBus;
        this._settings = settings;
        this._ready = false;
        this._currentScript = '';
        this._currentQRName = null;
        this._currentQRSet = null;
        this._history = [];
        this._maxHistory = 50;
    }

    // ── IModule 接口 ─────────────────────────

    async init() {
        try {
            this._loadHistory();
            this._ready = true;
            this._bus?.emit?.(EVENTS.MODULE_READY, { module: 'ScriptForge' });
            console.log('[ScriptForge] 初始化完成');
        } catch (error) {
            this._bus?.emit?.(EVENTS.ERROR, {
                module: 'ScriptForge',
                method: 'init',
                error,
                context: {},
            });
            throw error;
        }
    }

    destroy() {
        this._ready = false;
    }

    getState() {
        return {
            ready: this._ready,
            currentScript: this._currentScript,
            currentQRName: this._currentQRName,
            historyCount: this._history.length,
        };
    }

    isReady() {
        return this._ready;
    }

    // ── AI 生成功能 ──────────────────────────

    async generateFromDescription(description, context = {}) {
        try {
            this._bus?.emit?.(EVENTS.LOADING_START, { message: '🤖 正在生成 STscript...' });

            const prompt = this._buildGenerationPrompt(description, context);
            
            // 如果 AI 引擎不可用，返回示例脚本
            let script;
            if (this._ai?.generateScript) {
                const rawResp = await this._ai.generateScript(prompt);
                script = this._parseScriptResponse(rawResp);
            } else {
                // 降级：返回示例脚本
                script = this._generateExampleScript(description);
            }

            this._currentScript = script;
            this._addToHistory({ name: description.slice(0, 30), script, qrSet: null });

            this._bus?.emit?.(EVENTS.SCRIPT_GENERATED, { 
                script, 
                mode: FORGE_MODES.FROM_DESCRIPTION 
            });
            
            return script;

        } catch (error) {
            this._bus?.emit?.(EVENTS.ERROR, {
                module: 'ScriptForge',
                method: 'generateFromDescription',
                error,
                context: { description },
            });
            throw error;
        } finally {
            this._bus?.emit?.(EVENTS.LOADING_END);
        }
    }

    async generateQRSet(name, buttonDefs) {
        try {
            this._bus?.emit?.(EVENTS.LOADING_START, { message: `🤖 正在生成 QR Set: ${name}...` });

            const replies = await Promise.all(
                buttonDefs.map(async (btn, idx) => {
                    let script;
                    if (this._ai?.generateScript) {
                        script = await this._ai.generateScript(btn.description);
                    } else {
                        script = `/echo 按钮 ${idx + 1}: ${btn.label}`;
                    }
                    
                    return {
                        id: idx + 1,
                        label: btn.label,
                        title: btn.title || btn.label,
                        message: script,
                        contextMenu: '',
                        preventInput: true,
                        isHidden: false,
                        executeOnUser: false,
                        executeOnAi: false,
                        autoExecute: false,
                    };
                })
            );

            const qrSet = {
                ...QR_DEFAULTS,
                name,
                quickReplies: replies,
            };

            this._currentQRName = name;
            this._currentQRSet = qrSet;
            this._addToHistory({ name, script: '', qrSet });

            this._bus?.emit?.(EVENTS.SCRIPT_GENERATED, { 
                qrSet, 
                mode: FORGE_MODES.FROM_DESCRIPTION 
            });
            
            return qrSet;

        } catch (error) {
            this._bus?.emit?.(EVENTS.ERROR, {
                module: 'ScriptForge',
                method: 'generateQRSet',
                error,
                context: { name, buttonDefs },
            });
            throw error;
        } finally {
            this._bus?.emit?.(EVENTS.LOADING_END);
        }
    }

    // ── 脚本验证 ─────────────────────────────

    validateScript(script) {
        const target = script ?? this._currentScript;
        const lines = target.split('\n');
        const errors = [];
        const warnings = [];

        lines.forEach((line, idx) => {
            const n = idx + 1;
            const trimmed = line.trim();

            if (!trimmed || trimmed.startsWith('//')) return;

            // 基本规则检查
            if (!trimmed.startsWith('/') && !trimmed.startsWith('{{')) {
                warnings.push(`第 ${n} 行：命令应以 / 开头`);
            }

            // /if 语法检查
            if (/^\/if\b/.test(trimmed)) {
                if (!trimmed.includes('left=')) errors.push(`第 ${n} 行：/if 缺少 left=`);
                if (!trimmed.includes('right=')) errors.push(`第 ${n} 行：/if 缺少 right=`);
            }

            // /setvar 语法检查
            if (/^\/setvar\b/.test(trimmed) && !trimmed.includes('key=')) {
                errors.push(`第 ${n} 行：/setvar 缺少 key=`);
            }

            // 大括号配对检查
            const opens = (line.match(/\{\{/g) || []).length;
            const closes = (line.match(/\}\}/g) || []).length;
            if (opens !== closes) {
                errors.push(`第 ${n} 行：{{ }} 未正确闭合`);
            }
        });

        const result = { 
            ok: errors.length === 0, 
            errors, 
            warnings 
        };

        this._bus?.emit?.(EVENTS.SCRIPT_VALIDATED, result);
        return result;
    }

    // ── 调试相关（简化版）─────────────────────

    async debugStep(script, variables) {
        // 简化版：只返回模拟结果
        console.log('[ScriptForge] debugStep 调用（模拟）');
        return { 
            step: 0, 
            output: '调试功能开发中...', 
            variables: variables || {} 
        };
    }

    // ── 模板系统 ─────────────────────────────

    applyTemplate(templateId, vars = {}) {
        const templates = this.listTemplates();
        const template = templates.find(t => t.id === templateId);
        
        if (!template) {
            throw new Error(`[ScriptForge] 找不到模板：${templateId}`);
        }

        // 生成示例脚本
        let script = '';
        switch (templateId) {
            case 'rpg-status-bar':
                script = this._generateRPGStatusBar(vars);
                break;
            case 'plot-menu':
                script = this._generatePlotMenu(vars);
                break;
            case 'tool-buttons':
                script = this._generateToolButtons(vars);
                break;
            case 'auto-triggers':
                script = this._generateAutoTriggers(vars);
                break;
            default:
                script = `// 模板 ${templateId}\n/echo 模板功能开发中...`;
        }

        this._currentScript = script;
        this._bus?.emit?.(EVENTS.SCRIPT_GENERATED, {
            script,
            mode: FORGE_MODES.FROM_TEMPLATE,
            template: templateId,
        });

        return { script, qrSetJSON: null, preview: template.name };
    }

    listTemplates() {
        return [
            { id: 'rpg-status-bar', name: '🎮 RPG 状态条', category: 'ui' },
            { id: 'plot-menu', name: '📋 剧情选项菜单', category: 'interaction' },
            { id: 'tool-buttons', name: '🔧 工具按钮组', category: 'utility' },
            { id: 'auto-triggers', name: '⚡ 自动触发器', category: 'automation' },
        ];
    }

    // ── 可视化构建器接口（占位）───────────────

    getBuilderState() {
        return { nodes: [], connections: [] };
    }

    updateBuilderNode(nodeId, changes) {
        console.log('[ScriptForge] updateBuilderNode:', nodeId, changes);
        return true;
    }

    addBuilderNode(type, parentId) {
        const node = {
            id: `node_${Date.now()}`,
            type,
            parentId,
            x: 100,
            y: 100,
        };
        console.log('[ScriptForge] addBuilderNode:', node);
        return node;
    }

    removeBuilderNode(nodeId) {
        console.log('[ScriptForge] removeBuilderNode:', nodeId);
        return true;
    }

    compileBuilderToScript() {
        const script = '// 可视化构建器编译结果\n/echo 功能开发中...';
        this._currentScript = script;
        return script;
    }

    // ── 快捷回复集管理 ────────────────────────

    buildQRSet(name, replies) {
        return {
            ...QR_DEFAULTS,
            name,
            quickReplies: replies.map((r, idx) => ({
                id: idx + 1,
                label: r.label || `按钮 ${idx + 1}`,
                message: r.message || '',
                ...r,
            })),
        };
    }

    serializeQRSet(qrSet) {
        return JSON.stringify(qrSet || this._currentQRSet, null, 2);
    }

    exportQRSet() {
        if (!this._currentQRSet && this._currentScript) {
            // 将当前脚本包装为单按钮 QR Set
            return JSON.stringify({
                ...QR_DEFAULTS,
                name: this._currentQRName || 'cardforge_script',
                quickReplies: [{
                    id: 1,
                    label: '▶ 执行',
                    title: '运行脚本',
                    message: this._currentScript,
                    preventInput: true,
                }],
            }, null, 2);
        }
        return this.serializeQRSet(this._currentQRSet);
    }

    // ── 私有方法 ─────────────────────────────

    _buildGenerationPrompt(description, context) {
        const contextBlock = Object.keys(context).length > 0
            ? `\n\n已知上下文：\n${JSON.stringify(context, null, 2)}`
            : '';

        return [
            '你是 SillyTavern STscript 专家。',
            '请根据需求生成 STscript 代码，只输出代码。',
            '',
            `需求：${description}`,
            contextBlock,
        ].join('\n');
    }

    _parseScriptResponse(raw) {
        if (!raw) return '';
        
        // 尝试提取代码块
        const codeBlock = raw.match(/```[\s\S]*?\n([\s\S]+?)\n```/);
        if (codeBlock) return codeBlock[1].trim();
        
        return raw.trim();
    }

    _generateExampleScript(description) {
        // 生成示例脚本（AI 不可用时的降级方案）
        return [
            `// ${description}`,
            '/setvar key=script_name value="CardForge 生成的脚本"',
            '/echo {{getvar::script_name}} 已加载',
            '',
            '// TODO: 在此添加您的脚本逻辑',
            '/if left={{getvar::player_hp}} right=0 rule=lte',
            '    /echo 游戏结束！',
            '/else',
            '    /echo 继续冒险...',
            '/fi',
        ].join('\n');
    }

    _generateRPGStatusBar(vars) {
        const stats = vars.stats || ['HP:100', 'MP:50', 'EXP:0'];
        return [
            '// RPG 状态条',
            ...stats.map(s => {
                const [key, val] = s.split(':');
                return `/setvar key=player_${key.toLowerCase()} value=${val}`;
            }),
            '/echo 📊 状态：HP={{getvar::player_hp}} | MP={{getvar::player_mp}} | EXP={{getvar::player_exp}}',
        ].join('\n');
    }

    _generatePlotMenu(vars) {
        const choices = vars.choices || ['选项1', '选项2', '选项3'];
        return [
            '// 剧情选项菜单',
            '/echo 请选择你的行动：',
            ...choices.map((c, i) => `/button label="${c}" /setvar key=choice value=${i + 1}`),
            '/echo 你选择了：{{getvar::choice}}',
        ].join('\n');
    }

    _generateToolButtons(vars) {
        return [
            '// 工具按钮组',
            '/button label="💾 保存" /echo 游戏已保存',
            '/button label="📂 读取" /echo 读取存档',
            '/button label="🔄 重置" /echo 重置游戏',
            '/button label="❓ 帮助" /echo 显示帮助信息',
        ].join('\n');
    }

    _generateAutoTriggers(vars) {
        return [
            '// 自动触发器',
            '/setvar key=turn_count value={{getvar::turn_count::0}}',
            '/incvar key=turn_count',
            '',
            '// 每5回合触发事件',
            '/if left={{getvar::turn_count}} right=5 rule=gte',
            '    /echo 🎲 触发随机事件！',
            '    /setvar key=turn_count value=0',
            '/fi',
        ].join('\n');
    }

    _addToHistory(entry) {
        const record = {
            id: `hist_${Date.now()}`,
            name: entry.name,
            script: entry.script,
            qrSet: entry.qrSet,
            createdAt: Date.now(),
        };
        
        this._history.unshift(record);
        if (this._history.length > this._maxHistory) {
            this._history = this._history.slice(0, this._maxHistory);
        }
        
        this._saveHistory();
    }

    _saveHistory() {
        try {
            // 只保存元数据，不保存完整内容（节省空间）
            const meta = this._history.map(({ id, name, createdAt }) => 
                ({ id, name, createdAt })
            );
            localStorage.setItem('cf_script_history', JSON.stringify(meta));
        } catch {}
    }

    _loadHistory() {
        try {
            const raw = localStorage.getItem('cf_script_history');
            if (raw) {
                const meta = JSON.parse(raw);
                // 恢复基本结构（实际内容已丢失）
                this._history = meta.slice(0, this._maxHistory);
            }
        } catch {}
    }
}