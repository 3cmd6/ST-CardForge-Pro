/**
 * @file modules/04_stscript-forge/syntax-highlighter.js
 * @description STscript 语法高亮器
 *              为 CodeMirror 6 定义 STscript 自定义语言模式，
 *              支持：命令高亮、变量插值高亮、字符串/注释/操作符着色、
 *              错误标注、括号匹配等。
 *              同时提供一个轻量级「纯 DOM 高亮」降级方案（不依赖 CodeMirror）。
 * @version 1.0.0
 * @see {@link https://codemirror.net/docs/}
 */

// ═══════════════════════════════════════════════
// § 1  STscript Token 定义（词法规则）
// ═══════════════════════════════════════════════

/**
 * STscript 所有已知命令（用于关键词高亮）
 * 分组便于管理和扩展
 */
export const STSCRIPT_COMMANDS = {
    /** 变量操作命令 */
    vars: [
        '/setvar', '/getvar', '/addvar', '/subvar', '/mulvar', '/divvar',
        '/flushvar', '/let', '/var', '/return',
    ],
    /** 控制流命令 */
    flow: [
        '/if', '/else', '/while', '/times', '/break', '/continue', '/pass',
        '/abort', '/return',
    ],
    /** 输入输出命令 */
    io: [
        '/echo', '/input', '/popup', '/prompt', '/buttons',
        '/send', '/sendas', '/trigger', '/run',
    ],
    /** 快捷回复命令 */
    qr: [
        '/qr', '/qr-set-enable', '/qr-set-disable',
        '/qr-show', '/qr-hide', '/qr-create', '/qr-update', '/qr-delete',
        '/qr-get',
    ],
    /** 世界书 / 角色 命令 */
    world: [
        '/wi-enable', '/wi-disable', '/wi-entry-add', '/wi-entry-remove',
        '/char', '/persona',
    ],
    /** 数学 / 工具 命令 */
    util: [
        '/math', '/roll', '/random', '/length', '/trim',
        '/replace', '/slice', '/split', '/join', '/date',
        '/pipe', '/closure', '/define',
    ],
    /** 调试命令 */
    debug: [
        '/log', '/warn', '/assert', '/inspect',
    ],
};

/** 所有命令的扁平列表（用于快速查找） */
export const ALL_COMMANDS = Object.values(STSCRIPT_COMMANDS).flat();

/**
 * STscript 操作符（用于 /if 等命令）
 */
export const STSCRIPT_OPERATORS = [
    'eq', 'neq', 'gt', 'gte', 'lt', 'lte',
    'contains', 'not-contains', 'starts-with', 'ends-with',
    'and', 'or', 'not',
];

/**
 * STscript 变量插值模式（正则）
 * 匹配 {{xxx}} 和 {{getvar::xxx}} 等形式
 */
export const VAR_INTERPOLATION_PATTERN = /\{\{[^}]+\}\}/g;

/**
 * STscript 注释模式（// 开头的整行）
 */
export const COMMENT_PATTERN = /^\/\/.*$/m;

/**
 * STscript 命令模式（/ 开头的命令）
 */
export const COMMAND_PATTERN = /^\s*\/[a-zA-Z][\w\-]*/m;

/**
 * STscript 管道符
 */
export const PIPE_PATTERN = /\s*\|\s*/;

// ═══════════════════════════════════════════════
// § 2  Token 类型（与 CSS 类名映射）
// ═══════════════════════════════════════════════

/**
 * 语法 Token 类型枚举
 * 每种类型对应一个 CSS 类，style.css 中定义对应颜色
 * @enum {string}
 */
export const TOKEN_TYPES = {
    COMMAND:        'cf-hl-command',       // /setvar  /if 等命令      → 紫色
    VAR_CMD:        'cf-hl-var-cmd',       // 变量操作命令              → 蓝色
    FLOW_CMD:       'cf-hl-flow-cmd',      // 控制流命令                → 橙色
    QR_CMD:         'cf-hl-qr-cmd',        // QR 相关命令               → 青色
    INTERPOLATION:  'cf-hl-interpolation', // {{xxx}}  {{getvar::xxx}}  → 绿色
    VAR_NAME:       'cf-hl-var-name',      // getvar:: 后面的变量名     → 浅绿
    OPERATOR:       'cf-hl-operator',      // eq / neq / gt / left/right → 黄色
    STRING:         'cf-hl-string',        // "字符串内容"              → 橙红色
    NUMBER:         'cf-hl-number',        // 数字                      → 浅蓝
    COMMENT:        'cf-hl-comment',       // // 注释                   → 灰色
    PIPE:           'cf-hl-pipe',          // | 管道符                  → 白色/加粗
    KEYWORD_PARAM:  'cf-hl-keyword-param', // key= value= left= right=  → 粉色
    ERROR:          'cf-hl-error',         // 语法错误标记              → 红色下划线
};

// ═══════════════════════════════════════════════
// § 3  CodeMirror 模式定义
// ═══════════════════════════════════════════════

/**
 * 创建 STscript 的 CodeMirror 5 兼容 Mode 对象
 * （ST 拓展中 CodeMirror 通常以 v5 形式内嵌）
 *
 * @returns {object} CodeMirror Mode 对象
 */
export function createSTScriptMode() {
    return {
        name:        'stscript',
        lineComment: '//',

        startState() {
            return {
                inString:        false,
                inInterpolation: false,
                inComment:       false,
                commandParsed:   false,
                stringChar:      null,
            };
        },

        token(stream, state) {
            // 注释处理（// 开头，整行注释）
            if (stream.match('//')) {
                stream.skipToEnd();
                state.commandParsed = true;
                return TOKEN_TYPES.COMMENT;
            }

            // 字符串处理（双引号）
            if (!state.inString && stream.peek() === '"') {
                stream.next();
                state.inString   = true;
                state.stringChar = '"';
            }
            if (state.inString) {
                let escaped = false;
                while (!stream.eol()) {
                    const ch = stream.next();
                    if (escaped) {
                        escaped = false;
                        continue;
                    }
                    if (ch === '\\') { escaped = true; continue; }
                    // 字符串内也可能有 {{interpolation}}
                    if (ch === '{' && stream.peek() === '{') {
                        // 回退到 {{ 之前，让插值处理器处理
                        stream.backUp(1);
                        return TOKEN_TYPES.STRING;
                    }
                    if (ch === state.stringChar) {
                        state.inString = false;
                        break;
                    }
                }
                return TOKEN_TYPES.STRING;
            }

            // 变量插值 {{ ... }}
            if (stream.match('{{')) {
                // 消费到 }}
                while (!stream.eol()) {
                    if (stream.match('}}', true)) break;
                    // 标记 getvar:: / setvar:: 后的变量名
                    stream.next();
                }
                return TOKEN_TYPES.INTERPOLATION;
            }

            // 管道符 |
            if (stream.match(/^\s*\|\s*/)) {
                return TOKEN_TYPES.PIPE;
            }

            // 命令 /xxx（以 / 开头）
            if (stream.match(/^\/[a-zA-Z][\w\-]*/)) {
                const cmd = stream.current().trim();
                state.commandParsed = true;

                if (STSCRIPT_COMMANDS.vars.includes(cmd))  return TOKEN_TYPES.VAR_CMD;
                if (STSCRIPT_COMMANDS.flow.includes(cmd))  return TOKEN_TYPES.FLOW_CMD;
                if (STSCRIPT_COMMANDS.qr.includes(cmd))    return TOKEN_TYPES.QR_CMD;
                if (ALL_COMMANDS.includes(cmd))            return TOKEN_TYPES.COMMAND;

                // 未知命令（可能是错误）
                return TOKEN_TYPES.ERROR;
            }

            // 关键词参数 key= value= left= right= 等
            if (stream.match(/^(key|value|left|right|else|times)=/)) {
                return TOKEN_TYPES.KEYWORD_PARAM;
            }

            // 操作符（eq/neq/gt 等，独立词）
            for (const op of STSCRIPT_OPERATORS) {
                if (stream.match(new RegExp(`^${op}(?=\\s|\\||$)`))) {
                    return TOKEN_TYPES.OPERATOR;
                }
            }

            // 数字
            if (stream.match(/^-?\d+(\.\d+)?/)) {
                return TOKEN_TYPES.NUMBER;
            }

            // 跳过空白
            if (stream.eatSpace()) return null;

            // 其他字符
            stream.next();
            return null;
        },

        indent(state, textAfter) {
            // STscript 的 else 块缩进与 if 对齐
            if (/^\/else/.test(textAfter)) return 0;
            return 0;
        },

        electricInput: /^\s*\/else/,
        blockCommentStart: null,
        blockCommentEnd:   null,
        lineComment:       '//',
    };
}

// ═══════════════════════════════════════════════
// § 4  SyntaxHighlighter 主类
// ═══════════════════════════════════════════════

/**
 * STscript 语法高亮器主类
 * 支持两种模式：
 *   1. CodeMirror 编辑器（完整功能，含实时编辑）
 *   2. 纯 DOM 静态高亮（只读预览，无第三方依赖）
 */
export class SyntaxHighlighter {
    /**
     * @param {HTMLElement} containerElement - 挂载容器
     * @param {object}      [options]
     * @param {boolean}     [options.readonly=false]    - 是否只读（只读时使用轻量高亮）
     * @param {boolean}     [options.lineNumbers=true]  - 是否显示行号
     * @param {boolean}     [options.autoCloseBrackets=true]
     * @param {string}      [options.theme='cardforge-dark']
     * @param {Function}    [options.onChange]          - 内容变化回调
     */
    constructor(containerElement, options = {}) {
        this._container  = containerElement;
        this._options    = {
            readonly:          false,
            lineNumbers:       true,
            autoCloseBrackets: true,
            theme:             'cardforge-dark',
            onChange:          null,
            ...options,
        };

        /** @type {object|null} CodeMirror 实例 */
        this._cm          = null;

        /** @type {boolean} CodeMirror 是否可用 */
        this._cmAvailable = false;

        /** @type {string} 当前脚本内容 */
        this._content     = '';

        /** @type {Array<{line: number, message: string, severity: 'error'|'warning'}>} */
        this._diagnostics = [];
    }

    // ─── 初始化 ───────────────────────────────────

    /**
     * 初始化高亮器（异步，尝试加载 CodeMirror）
     * @returns {Promise<void>}
     */
    async init() {
        this._cmAvailable = await this._tryLoadCodeMirror();

        if (this._cmAvailable) {
            this._initCodeMirror();
        } else {
            this._initFallbackDOM();
        }
    }

    /**
     * 尝试加载 CodeMirror（检测全局对象）
     * @returns {Promise<boolean>}
     */
    async _tryLoadCodeMirror() {
        // SillyTavern 中 CodeMirror 通常以全局变量存在
        if (typeof window !== 'undefined' && window.CodeMirror) {
            return true;
        }
        return false;
    }

    /**
     * 初始化 CodeMirror 编辑器
     */
    _initCodeMirror() {
        const CM = window.CodeMirror;

        // 注册 STscript 模式
        if (!CM.modes['stscript']) {
            CM.defineMode('stscript', createSTScriptMode);
        }

        this._cm = CM(this._container, {
            mode:              'stscript',
            theme:             this._options.theme,
            lineNumbers:       this._options.lineNumbers,
            readOnly:          this._options.readonly ? 'nocursor' : false,
            autoCloseBrackets: this._options.autoCloseBrackets,
            matchBrackets:     true,
            indentUnit:        4,
            tabSize:           4,
            indentWithTabs:    false,
            extraKeys: {
                'Ctrl-/':   (cm) => this._toggleLineComment(cm),
                'Ctrl-D':   (cm) => this._duplicateLine(cm),
                'Alt-Up':   (cm) => this._moveLineUp(cm),
                'Alt-Down': (cm) => this._moveLineDown(cm),
                'Ctrl-Z':   'undo',
                'Ctrl-Y':   'redo',
            },
            gutters:    ['CodeMirror-lint-markers', 'CodeMirror-linenumbers'],
        });

        // 内容变化监听
        this._cm.on('change', (cm) => {
            this._content = cm.getValue();
            if (this._options.onChange) {
                this._options.onChange(this._content);
            }
            // 触发实时语法检查（防抖）
            this._scheduleDiagnostics();
        });
    }

    /**
     * 初始化降级纯 DOM 高亮方案（只读）
     */
    _initFallbackDOM() {
        this._container.innerHTML = '';
        this._container.classList.add('cf-syntax-fallback');

        const pre = document.createElement('pre');
        pre.className = 'cf-syntax-pre';
        this._container.appendChild(pre);

        this._fallbackPre = pre;
        this._renderFallback(this._content);
    }

    // ─── 公共 API ─────────────────────────────────

    /**
     * 设置编辑器内容
     * @param {string} script
     */
    setValue(script) {
        this._content = script;
        if (this._cmAvailable && this._cm) {
            this._cm.setValue(script);
        } else if (this._fallbackPre) {
            this._renderFallback(script);
        }
    }

    /**
     * 获取编辑器当前内容
     * @returns {string}
     */
    getValue() {
        if (this._cmAvailable && this._cm) {
            return this._cm.getValue();
        }
        return this._content;
    }

    /**
     * 设置只读状态
     * @param {boolean} readonly
     */
    setReadOnly(readonly) {
        this._options.readonly = readonly;
        if (this._cmAvailable && this._cm) {
            this._cm.setOption('readOnly', readonly ? 'nocursor' : false);
        }
    }

    /**
     * 聚焦编辑器
     */
    focus() {
        if (this._cmAvailable && this._cm) {
            this._cm.focus();
        }
    }

    /**
     * 刷新编辑器布局（容器尺寸变化后调用）
     */
    refresh() {
        if (this._cmAvailable && this._cm) {
            this._cm.refresh();
        }
    }

    /**
     * 销毁编辑器，清理 DOM
     */
    destroy() {
        if (this._cmAvailable && this._cm) {
            this._cm.toTextArea();
            this._cm = null;
        } else {
            this._container.innerHTML = '';
        }
        this._diagnosticsTimer && clearTimeout(this._diagnosticsTimer);
    }

    /**
     * 获取当前行列位置（仅 CodeMirror 模式）
     * @returns {{ line: number, ch: number }}
     */
    getCursor() {
        if (this._cmAvailable && this._cm) {
            return this._cm.getCursor();
        }
        return { line: 0, ch: 0 };
    }

    /**
     * 插入文本到当前光标位置
     * @param {string} text
     */
    insertAtCursor(text) {
        if (this._cmAvailable && this._cm) {
            const cursor = this._cm.getCursor();
            this._cm.replaceRange(text, cursor);
        } else {
            this._content += text;
            this._renderFallback(this._content);
        }
    }

    /**
     * 添加语法诊断标注（错误/警告）
     * @param {Array<{line: number, message: string, severity: 'error'|'warning'}>} diagnostics
     */
    setDiagnostics(diagnostics) {
        this._diagnostics = diagnostics;
        if (this._cmAvailable && this._cm) {
            this._applyDiagnosticsToCodeMirror(diagnostics);
        }
    }

    /**
     * 清除所有语法标注
     */
    clearDiagnostics() {
        this._diagnostics = [];
        if (this._cmAvailable && this._cm) {
            this._cm.clearGutter('CodeMirror-lint-markers');
            this._cm.getAllMarks().forEach(m => m.clear());
        }
    }

    /**
     * 获取当前所有诊断信息
     * @returns {Array<{line: number, message: string, severity: string}>}
     */
    getDiagnostics() {
        return [...this._diagnostics];
    }

    // ─── 诊断标注（私有）─────────────────────────

    /**
     * 防抖调度语法检查（300ms 延迟）
     */
    _scheduleDiagnostics() {
        if (this._diagnosticsTimer) clearTimeout(this._diagnosticsTimer);
        this._diagnosticsTimer = setTimeout(() => {
            const diags = this._runLinter(this._content);
            this.setDiagnostics(diags);
        }, 300);
    }

    /**
     * 简易 STscript Linter（基于规则检查）
     * @param {string} script
     * @returns {Array<{line: number, message: string, severity: 'error'|'warning'}>}
     */
    _runLinter(script) {
        const diagnostics = [];
        const lines       = script.split('\n');

        lines.forEach((line, idx) => {
            const trimmed = line.trim();

            // 跳过注释和空行
            if (!trimmed || trimmed.startsWith('//')) return;

            // 检查 1：命令行是否以 / 开头
            if (trimmed.length > 0 && !trimmed.startsWith('/') && !trimmed.startsWith('{{')) {
                diagnostics.push({
                    line:     idx,
                    message:  `第 ${idx + 1} 行：可能的语法错误（命令应以 / 开头）`,
                    severity: 'warning',
                });
            }

            // 检查 2：/if 语句是否有 left= right=
            if (/^\/if\b/.test(trimmed)) {
                if (!trimmed.includes('left=')) {
                    diagnostics.push({
                        line:     idx,
                        message:  `/if 缺少 left= 参数`,
                        severity: 'error',
                    });
                }
                if (!trimmed.includes('right=')) {
                    diagnostics.push({
                        line:     idx,
                        message:  `/if 缺少 right= 参数`,
                        severity: 'error',
                    });
                }
            }

            // 检查 3：未闭合的 {{ 插值
            const openCount  = (line.match(/\{\{/g)  || []).length;
            const closeCount = (line.match(/\}\}/g) || []).length;
            if (openCount !== closeCount) {
                diagnostics.push({
                    line:     idx,
                    message:  `第 ${idx + 1} 行：{{ }} 插值未正确闭合（开 ${openCount} 个，闭 ${closeCount} 个）`,
                    severity: 'error',
                });
            }

            // 检查 4：/setvar 缺少 key= 参数
            if (/^\/setvar\b/.test(trimmed) && !trimmed.includes('key=')) {
                diagnostics.push({
                    line:     idx,
                    message:  `/setvar 缺少 key= 参数`,
                    severity: 'error',
                });
            }

            // 检查 5：/setvar 缺少 value= 参数
            if (/^\/setvar\b/.test(trimmed) && !trimmed.includes('value=')) {
                diagnostics.push({
                    line:     idx,
                    message:  `/setvar 缺少 value= 参数`,
                    severity: 'warning',
                });
            }
        });

        return diagnostics;
    }

    /**
     * 将诊断信息应用到 CodeMirror gutter 和文本标注
     * @param {Array<{line: number, message: string, severity: string}>} diagnostics
     */
    _applyDiagnosticsToCodeMirror(diagnostics) {
        if (!this._cm) return;

        this._cm.clearGutter('CodeMirror-lint-markers');
        this._cm.getAllMarks().forEach(m => m.clear());

        diagnostics.forEach(diag => {
            // Gutter 图标
            const marker = document.createElement('div');
            marker.className = diag.severity === 'error'
                ? 'cf-lint-error-icon'
                : 'cf-lint-warning-icon';
            marker.title = diag.message;
            marker.textContent = diag.severity === 'error' ? '✖' : '⚠';
            this._cm.setGutterMarker(diag.line, 'CodeMirror-lint-markers', marker);

            // 行内文本标注
            const lineLength = this._cm.getLine(diag.line)?.length ?? 0;
            this._cm.markText(
                { line: diag.line, ch: 0 },
                { line: diag.line, ch: lineLength },
                {
                    className: diag.severity === 'error'
                        ? 'cf-lint-error-line'
                        : 'cf-lint-warning-line',
                    title: diag.message,
                }
            );
        });
    }

    // ─── 键盘快捷键处理（私有）───────────────────

    /**
     * 切换当前行注释
     * @param {object} cm - CodeMirror 实例
     */
    _toggleLineComment(cm) {
        const cursor = cm.getCursor();
        const line   = cm.getLine(cursor.line);
        const trimmed = line.trimStart();

        if (trimmed.startsWith('//')) {
            // 取消注释
            const commentIdx = line.indexOf('//');
            cm.replaceRange(
                line.slice(0, commentIdx) + line.slice(commentIdx + 2).trimStart(),
                { line: cursor.line, ch: 0 },
                { line: cursor.line, ch: line.length }
            );
        } else {
            // 添加注释
            cm.replaceRange(
                '// ' + line,
                { line: cursor.line, ch: 0 },
                { line: cursor.line, ch: line.length }
            );
        }
    }

    /**
     * 复制当前行到下一行
     * @param {object} cm
     */
    _duplicateLine(cm) {
        const cursor = cm.getCursor();
        const line   = cm.getLine(cursor.line);
        cm.replaceRange(
            '\n' + line,
            { line: cursor.line, ch: line.length }
        );
    }

    /**
     * 将当前行上移
     * @param {object} cm
     */
    _moveLineUp(cm) {
        const cursor = cm.getCursor();
        if (cursor.line === 0) return;
        const currentLine = cm.getLine(cursor.line);
        const prevLine    = cm.getLine(cursor.line - 1);
        cm.replaceRange(
            currentLine + '\n' + prevLine,
            { line: cursor.line - 1, ch: 0 },
            { line: cursor.line, ch: prevLine.length }
        );
        cm.setCursor({ line: cursor.line - 1, ch: cursor.ch });
    }

    /**
     * 将当前行下移
     * @param {object} cm
     */
    _moveLineDown(cm) {
        const cursor   = cm.getCursor();
        const lastLine = cm.lastLine();
        if (cursor.line >= lastLine) return;
        const currentLine = cm.getLine(cursor.line);
        const nextLine    = cm.getLine(cursor.line + 1);
        cm.replaceRange(
            nextLine + '\n' + currentLine,
            { line: cursor.line, ch: 0 },
            { line: cursor.line + 1, ch: nextLine.length }
        );
        cm.setCursor({ line: cursor.line + 1, ch: cursor.ch });
    }

    // ─── 降级纯 DOM 高亮（私有）─────────────────

    /**
     * 使用纯正则对脚本进行静态 HTML 高亮渲染（只读模式降级方案）
     * @param {string} script
     */
    _renderFallback(script) {
        if (!this._fallbackPre) return;
        this._fallbackPre.innerHTML = highlightScript(script);
    }
}

// ═══════════════════════════════════════════════
// § 5  纯函数高亮 API（无 CodeMirror 依赖）
// ═══════════════════════════════════════════════

/**
 * 将 STscript 字符串转换为带高亮 span 标签的 HTML 字符串
 * （纯正则实现，性能优先于精确性，适合只读预览场景）
 *
 * @param {string} script - 原始 STscript 文本
 * @returns {string} HTML 字符串（可直接 innerHTML 注入）
 */
export function highlightScript(script) {
    if (!script) return '';

    // 先转义 HTML 特殊字符
    let html = _escapeHTML(script);

    // 按优先级顺序替换（顺序很重要，避免相互干扰）
    // 1. 注释（整行）
    html = html.replace(
        /(\/\/[^\n]*)/g,
        `<span class="${TOKEN_TYPES.COMMENT}">$1</span>`
    );

    // 2. 变量插值 {{...}}
    html = html.replace(
        /(\{\{[^}]+\}\})/g,
        `<span class="${TOKEN_TYPES.INTERPOLATION}">$1</span>`
    );

    // 3. 字符串（双引号，跳过已高亮的插值区域）
    html = html.replace(
        /("(?:[^"\\]|\\.)*")/g,
        `<span class="${TOKEN_TYPES.STRING}">$1</span>`
    );

    // 4. 管道符
    html = html.replace(
        /(\s*\|\s*)/g,
        `<span class="${TOKEN_TYPES.PIPE}">$1</span>`
    );

    // 5. 控制流命令
    const flowPattern = STSCRIPT_COMMANDS.flow
        .map(cmd => cmd.replace('/', '\\/'))
        .join('|');
    html = html.replace(
        new RegExp(`(${flowPattern})(?=\\s|$|<)`, 'g'),
        `<span class="${TOKEN_TYPES.FLOW_CMD}">$1</span>`
    );

    // 6. 变量操作命令
    const varPattern = STSCRIPT_COMMANDS.vars
        .map(cmd => cmd.replace('/', '\\/'))
        .join('|');
    html = html.replace(
        new RegExp(`(${varPattern})(?=\\s|$|<)`, 'g'),
        `<span class="${TOKEN_TYPES.VAR_CMD}">$1</span>`
    );

    // 7. QR 命令
    const qrPattern = STSCRIPT_COMMANDS.qr
        .map(cmd => cmd.replace('/', '\\/'))
        .join('|');
    html = html.replace(
        new RegExp(`(${qrPattern})(?=\\s|$|<)`, 'g'),
        `<span class="${TOKEN_TYPES.QR_CMD}">$1</span>`
    );

    // 8. 其余已知命令
    const otherCmds = [
        ...STSCRIPT_COMMANDS.io,
        ...STSCRIPT_COMMANDS.util,
        ...STSCRIPT_COMMANDS.debug,
    ].map(cmd => cmd.replace('/', '\\/')).join('|');
    html = html.replace(
        new RegExp(`(${otherCmds})(?=\\s|$|<)`, 'g'),
        `<span class="${TOKEN_TYPES.COMMAND}">$1</span>`
    );

    // 9. 关键词参数（key= value= left= right= 等）
    html = html.replace(
        /\b(key|value|left|right|else|times|message|label)=/g,
        `<span class="${TOKEN_TYPES.KEYWORD_PARAM}">$1=</span>`
    );

    // 10. 操作符
    const opPattern = STSCRIPT_OPERATORS.join('|');
    html = html.replace(
        new RegExp(`\\b(${opPattern})\\b`, 'g'),
        `<span class="${TOKEN_TYPES.OPERATOR}">$1</span>`
    );

    // 11. 数字
    html = html.replace(
        /\b(-?\d+(?:\.\d+)?)\b/g,
        `<span class="${TOKEN_TYPES.NUMBER}">$1</span>`
    );

    // 保留换行（pre 标签内会保留，此处确保一致）
    return html;
}

/**
 * 转义 HTML 特殊字符
 * @param {string} str
 * @returns {string}
 */
function _escapeHTML(str) {
    return str
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;');
}

// ═══════════════════════════════════════════════
// § 6  自动补全定义
// ═══════════════════════════════════════════════

/**
 * CodeMirror 自动补全提示列表
 * 在 ScriptForge UI 中通过 hint addon 使用
 * @type {Array<{text: string, displayText: string, description: string}>}
 */
export const AUTOCOMPLETE_HINTS = [
    // 变量操作
    {
        text:        '/setvar key= value=',
        displayText: '/setvar',
        description: '设置变量：/setvar key=变量名 value=值',
    },
    {
        text:        '/getvar ',
        displayText: '/getvar',
        description: '获取变量并注入管道：/getvar 变量名',
    },
    {
        text:        '/addvar key= value=',
        displayText: '/addvar',
        description: '变量加法：/addvar key=变量名 value=增量',
    },
    {
        text:        '/flushvar ',
        displayText: '/flushvar',
        description: '删除变量：/flushvar 变量名',
    },

    // 控制流
    {
        text:        '/if left= right= eq\n    \n/else\n    ',
        displayText: '/if...else',
        description: '条件分支：/if left=值 right=值 操作符',
    },
    {
        text:        '/times 5\n    ',
        displayText: '/times',
        description: '循环 N 次：/times N',
    },
    {
        text:        '/while left= right= lt\n    ',
        displayText: '/while',
        description: '条件循环：/while left= right= 操作符',
    },

    // 输入输出
    {
        text:        '/echo ',
        displayText: '/echo',
        description: '输出文本到对话（不发送给 AI）',
    },
    {
        text:        '/input "提示文本"',
        displayText: '/input',
        description: '弹出输入框，结果注入管道',
    },
    {
        text:        '/send ',
        displayText: '/send',
        description: '以用户身份发送消息',
    },

    // QR 操作
    {
        text:        '/qr-set-enable ',
        displayText: '/qr-set-enable',
        description: '启用指定 QR Set',
    },
    {
        text:        '/qr-set-disable ',
        displayText: '/qr-set-disable',
        description: '禁用指定 QR Set',
    },

    // 常用变量插值
    {
        text:        '{{getvar::}}',
        displayText: '{{getvar::变量名}}',
        description: '内联获取变量值',
    },
    {
        text:        '{{pipe}}',
        displayText: '{{pipe}}',
        description: '获取管道传递的值',
    },
    {
        text:        '{{lastMessage}}',
        displayText: '{{lastMessage}}',
        description: '获取最近一条 AI 消息内容',
    },
    {
        text:        '{{roll::1d6}}',
        displayText: '{{roll::1dN}}',
        description: '掷骰子：{{roll::NdM}}',
    },
    {
        text:        '{{math::}}',
        displayText: '{{math::表达式}}',
        description: '数学计算：{{math::1+2}}',
    },
];

// ═══════════════════════════════════════════════
// § 7  默认导出
// ═══════════════════════════════════════════════

export default SyntaxHighlighter;