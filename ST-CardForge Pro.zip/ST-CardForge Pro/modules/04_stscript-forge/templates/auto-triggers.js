/**
 * @file modules/04_stscript-forge/templates/auto-triggers.js
 * @description 自动触发器 STscript 模板生成器
 *              负责生成在特定条件下自动执行的 STscript 逻辑，
 *              包含：条件触发、定时触发、消息内容触发、属性阈值触发等。
 *              所有生成的触发器均以 QR「执行AI回复后」或「执行用户输入后」的自动执行模式运作。
 * @version 1.0.0
 */

import { EVENTS } from '../../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  触发器类型枚举
// ═══════════════════════════════════════════════

/**
 * 自动触发器类型枚举
 * @enum {string}
 */
export const TRIGGER_TYPES = {
    /** 变量阈值触发：当某变量超过/低于阈值时 */
    VAR_THRESHOLD:      'var_threshold',
    /** 变量等值触发：当某变量等于特定值时 */
    VAR_EQUALS:         'var_equals',
    /** 关键词检测触发：当 AI 回复中包含特定关键词时 */
    KEYWORD_DETECT:     'keyword_detect',
    /** 回合计数触发：每 N 回合触发一次 */
    TURN_COUNT:         'turn_count',
    /** 多条件组合触发：AND / OR 逻辑组合 */
    COMPOUND:           'compound',
    /** 游戏状态触发：当 game_state 变量变化时 */
    GAME_STATE:         'game_state',
    /** 属性归零触发：当某属性降至 0 时 */
    STAT_ZERO:          'stat_zero',
    /** 随机概率触发：以指定概率触发 */
    RANDOM_CHANCE:      'random_chance',
    /** 首次触发：只在生命周期内触发一次 */
    ONCE:               'once',
    /** 周期触发：每 N 回合持续性触发 */
    PERIODIC:           'periodic',
};

/**
 * 触发时机（对应 QR 的 autoExecute 设置）
 * @enum {string}
 */
export const TRIGGER_TIMING = {
    /** 用户每次发送消息后触发 */
    AFTER_USER:   'after_user',
    /** AI 每次回复后触发 */
    AFTER_AI:     'after_ai',
    /** 两者都触发 */
    BOTH:         'both',
};

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} TriggerDef
 * @property {string}        type          - TRIGGER_TYPES 中的值
 * @property {string}        name          - 触发器名称（唯一标识）
 * @property {string}        timing        - TRIGGER_TIMING 中的值
 * @property {string}        actionScript  - 触发成功时执行的 STscript
 * @property {string}        [varKey]      - 监听的变量名（VAR_THRESHOLD / VAR_EQUALS 类型需要）
 * @property {number|string} [threshold]  - 阈值或等值（依类型而定）
 * @property {string}        [operator]   - 比较操作符：'gt'|'lt'|'gte'|'lte'|'eq'|'neq'
 * @property {string[]}      [keywords]   - 关键词列表（KEYWORD_DETECT 类型需要）
 * @property {number}        [interval]   - 触发间隔回合数（TURN_COUNT / PERIODIC 类型需要）
 * @property {number}        [chance]     - 触发概率 0~100（RANDOM_CHANCE 类型需要）
 * @property {TriggerDef[]}  [conditions] - 子条件列表（COMPOUND 类型需要）
 * @property {string}        [logic]      - COMPOUND 类型的逻辑：'AND'|'OR'
 * @property {boolean}       [disabled]   - 是否禁用此触发器
 * @property {string}        [elseScript] - 条件不满足时的备用 STscript
 */

// ═══════════════════════════════════════════════
// § 3  主生成函数
// ═══════════════════════════════════════════════

/**
 * 生成单个自动触发器的完整 STscript
 *
 * @param {TriggerDef} triggerDef
 * @returns {{ script: string, qrEntry: object, description: string }}
 *          script      : 完整的触发器 STscript
 *          qrEntry     : QR Set 中对应的按钮对象（配置为自动执行）
 *          description : 人类可读的触发器说明
 */
export function generateTrigger(triggerDef) {
    _validateTriggerDef(triggerDef);

    const script      = _buildTriggerScript(triggerDef);
    const qrEntry     = _buildQREntry(triggerDef, script);
    const description = _buildDescription(triggerDef);

    return { script, qrEntry, description };
}

/**
 * 批量生成多个触发器，合并为一个 QR Set JSON
 *
 * @param {string}        qrSetName    - QR Set 名称
 * @param {TriggerDef[]}  triggerDefs  - 触发器定义列表
 * @returns {{ qrSetJSON: object, scripts: Object.<string, string>, summary: string }}
 */
export function generateTriggerSet(qrSetName, triggerDefs) {
    const scripts     = {};
    const qrReplies   = [];
    const summaries   = [];

    triggerDefs.forEach((def, idx) => {
        const { script, qrEntry, description } = generateTrigger(def);
        scripts[def.name]   = script;
        qrReplies.push({ ...qrEntry, id: idx + 1 });
        summaries.push(`  [${idx + 1}] ${def.name} — ${description}`);
    });

    const qrSetJSON = {
        version:               '1.0',
        name:                  qrSetName,
        disabledByDefault:     false,
        isGlobal:              false,
        quickReplySetCommands: [],
        quickReplies:          qrReplies,
    };

    const summary = [
        `触发器组：${qrSetName}（共 ${triggerDefs.length} 个）`,
        ...summaries,
    ].join('\n');

    return { qrSetJSON, scripts, summary };
}

/**
 * 快速生成「HP 归零 → 游戏结束」触发器
 *
 * @param {string} hpVarKey        - HP 变量名（如 'player_hp'）
 * @param {string} gameOverScript  - 游戏结束时的自定义 STscript
 * @returns {{ script: string, qrEntry: object, description: string }}
 */
export function generateHPZeroTrigger(hpVarKey, gameOverScript) {
    return generateTrigger({
        type:         TRIGGER_TYPES.STAT_ZERO,
        name:         `${hpVarKey}_zero_trigger`,
        timing:       TRIGGER_TIMING.AFTER_AI,
        varKey:       hpVarKey,
        actionScript: [
            `/setvar key=game_state value=game_over |`,
            `/echo 💀 **${hpVarKey} 归零，游戏结束！** |`,
            gameOverScript || '',
        ].filter(Boolean).join('\n'),
    });
}

/**
 * 快速生成关键词检测触发器
 * 当 AI 回复中包含任意关键词时，自动执行 actionScript
 *
 * @param {string}   name           - 触发器名称
 * @param {string[]} keywords       - 监听的关键词列表
 * @param {string}   actionScript   - 触发时执行的 STscript
 * @param {string}   [timing]       - 触发时机（默认 AFTER_AI）
 * @returns {{ script: string, qrEntry: object, description: string }}
 */
export function generateKeywordTrigger(name, keywords, actionScript, timing = TRIGGER_TIMING.AFTER_AI) {
    return generateTrigger({
        type:   TRIGGER_TYPES.KEYWORD_DETECT,
        name,
        timing,
        keywords,
        actionScript,
    });
}

/**
 * 快速生成回合计数触发器
 * 每 interval 回合执行一次 actionScript
 *
 * @param {string} name           - 触发器名称
 * @param {number} interval       - 触发间隔（回合数）
 * @param {string} actionScript   - 触发时执行的 STscript
 * @returns {{ script: string, qrEntry: object, description: string }}
 */
export function generateTurnCountTrigger(name, interval, actionScript) {
    return generateTrigger({
        type:         TRIGGER_TYPES.TURN_COUNT,
        name,
        timing:       TRIGGER_TIMING.AFTER_AI,
        interval,
        actionScript,
    });
}

/**
 * 快速生成随机概率触发器
 *
 * @param {string} name           - 触发器名称
 * @param {number} chance         - 触发概率（0~100）
 * @param {string} actionScript   - 触发时执行的 STscript
 * @param {string} [elseScript]   - 未触发时的备用 STscript
 * @returns {{ script: string, qrEntry: object, description: string }}
 */
export function generateRandomTrigger(name, chance, actionScript, elseScript) {
    return generateTrigger({
        type:         TRIGGER_TYPES.RANDOM_CHANCE,
        name,
        timing:       TRIGGER_TIMING.AFTER_AI,
        chance,
        actionScript,
        elseScript,
    });
}

// ═══════════════════════════════════════════════
// § 4  STscript 构建器（私有）
// ═══════════════════════════════════════════════

/**
 * 根据触发器类型构建完整的检查 + 执行 STscript
 * @param {TriggerDef} def
 * @returns {string}
 */
function _buildTriggerScript(def) {
    const header   = `// ── 触发器：${def.name} (${def.type}) ──`;
    const disabled = def.disabled ? '// [已禁用]\n/pass |' : '';

    if (disabled) return [header, disabled].join('\n');

    const conditionBlock = _buildConditionBlock(def);
    const actionBlock    = _indentScript(def.actionScript, 1);
    const elseBlock      = def.elseScript ? _indentScript(def.elseScript, 1) : null;

    const lines = [header, conditionBlock];

    if (elseBlock) {
        lines.push(actionBlock, '/else', elseBlock);
    } else {
        lines.push(actionBlock);
    }

    return lines.filter(Boolean).join('\n');
}

/**
 * 根据触发器类型构建条件判断块
 * @param {TriggerDef} def
 * @returns {string}
 */
function _buildConditionBlock(def) {
    switch (def.type) {

        case TRIGGER_TYPES.VAR_THRESHOLD:
        case TRIGGER_TYPES.VAR_EQUALS: {
            const op = _operatorToSTScript(def.operator || 'eq');
            return `/if left={{getvar::${def.varKey}}} right=${def.threshold} ${op}`;
        }

        case TRIGGER_TYPES.STAT_ZERO: {
            return `/if left={{getvar::${def.varKey}}} right=0 lte`;
        }

        case TRIGGER_TYPES.KEYWORD_DETECT: {
            // 多关键词使用 OR 逻辑链：逐一检测，任一匹配即触发
            if (!def.keywords || def.keywords.length === 0) return '';
            if (def.keywords.length === 1) {
                return `/if left={{lastMessage}} right=${def.keywords[0]} contains`;
            }
            // 多关键词：生成嵌套 if 链
            return _buildKeywordChain(def.keywords);
        }

        case TRIGGER_TYPES.TURN_COUNT: {
            const interval = def.interval || 5;
            return [
                `/setvar key=_tc_${def.name} value={{math::{{getvar::_tc_${def.name}}}+1}} |`,
                `/setvar key=_tc_rem_${def.name} value={{math::{{getvar::_tc_${def.name}}} % ${interval}}} |`,
                `/if left={{getvar::_tc_rem_${def.name}}} right=0 eq`,
            ].join('\n');
        }

        case TRIGGER_TYPES.PERIODIC: {
            const interval = def.interval || 3;
            return [
                `/setvar key=_pt_${def.name} value={{math::{{getvar::_pt_${def.name}}}+1}} |`,
                `/if left={{math::{{getvar::_pt_${def.name}}} % ${interval}}} right=0 eq`,
            ].join('\n');
        }

        case TRIGGER_TYPES.RANDOM_CHANCE: {
            const chance = Math.min(100, Math.max(0, def.chance || 50));
            return [
                `/setvar key=_rand_${def.name} value={{roll::1d100}} |`,
                `/if left={{getvar::_rand_${def.name}}} right=${chance} lte`,
            ].join('\n');
        }

        case TRIGGER_TYPES.ONCE: {
            return [
                `/if left={{getvar::_once_${def.name}}} right=true neq`,
            ].join('\n');
        }

        case TRIGGER_TYPES.GAME_STATE: {
            return `/if left={{getvar::game_state}} right=${def.threshold || 'active'} eq`;
        }

        case TRIGGER_TYPES.COMPOUND: {
            return _buildCompoundCondition(def);
        }

        default:
            return `// 未知触发器类型：${def.type}`;
    }
}

/**
 * 构建多关键词 OR 检测链（STscript 嵌套 if）
 * @param {string[]} keywords
 * @returns {string}
 */
function _buildKeywordChain(keywords) {
    // STscript 没有原生 OR，模拟方式：用辅助变量逐一检测后汇总
    const lines = [
        `/setvar key=_kw_match value=false |`,
    ];

    keywords.forEach(kw => {
        lines.push(
            `/if left={{lastMessage}} right=${kw} contains`,
            `    /setvar key=_kw_match value=true |`,
        );
    });

    lines.push(`/if left={{getvar::_kw_match}} right=true eq`);
    return lines.join('\n');
}

/**
 * 构建复合条件（AND / OR 逻辑）
 * @param {TriggerDef} def
 * @returns {string}
 */
function _buildCompoundCondition(def) {
    if (!def.conditions || def.conditions.length === 0) return '';

    const logic = (def.logic || 'AND').toUpperCase();
    const lines  = [`/setvar key=_compound_${def.name} value=${logic === 'AND' ? 'true' : 'false'} |`];

    def.conditions.forEach((subDef, idx) => {
        const subCondition = _buildConditionBlock(subDef);
        if (logic === 'AND') {
            // AND：任一不满足则置 false
            lines.push(
                subCondition,
                `    /pass |`,          // 满足：继续
                `/else`,
                `    /setvar key=_compound_${def.name} value=false |`,
            );
        } else {
            // OR：任一满足则置 true
            lines.push(
                subCondition,
                `    /setvar key=_compound_${def.name} value=true |`,
            );
        }
    });

    lines.push(`/if left={{getvar::_compound_${def.name}}} right=true eq`);
    return lines.join('\n');
}

/**
 * 将操作符字符串转换为 STscript /if 操作符
 * @param {string} op
 * @returns {string}
 */
function _operatorToSTScript(op) {
    const map = {
        'gt':  'gt',
        'gte': 'gte',
        'lt':  'lt',
        'lte': 'lte',
        'eq':  'eq',
        'neq': 'neq',
    };
    return map[op] || 'eq';
}

/**
 * 对脚本内容进行缩进（用于 if/else 块内）
 * @param {string} script
 * @param {number} level  - 缩进级别
 * @returns {string}
 */
function _indentScript(script, level = 1) {
    const indent = '    '.repeat(level);
    return script
        .split('\n')
        .map(line => `${indent}${line}`)
        .join('\n');
}

// ═══════════════════════════════════════════════
// § 5  QR Entry 构建（私有）
// ═══════════════════════════════════════════════

/**
 * 构建 QR Set 中的按钮对象（配置为自动执行）
 * @param {TriggerDef} def
 * @param {string}     script
 * @returns {object}
 */
function _buildQREntry(def, script) {
    const timing = def.timing || TRIGGER_TIMING.AFTER_AI;
    return {
        id:               0,    // 由批量生成时重写
        label:            `🔔 ${def.name}`,
        title:            def.name,
        message:          script,
        contextMenu:      '',
        preventInput:     false,
        isHidden:         true,          // 触发器按钮通常隐藏，不展示给用户
        executeOnUser:    timing === TRIGGER_TIMING.AFTER_USER || timing === TRIGGER_TIMING.BOTH,
        executeOnAi:      timing === TRIGGER_TIMING.AFTER_AI   || timing === TRIGGER_TIMING.BOTH,
        autoExecute:      true,
        extensionPrompt:  '',
        extensionPromptPos: 0,
    };
}

// ═══════════════════════════════════════════════
// § 6  校验与说明（私有）
// ═══════════════════════════════════════════════

/**
 * 校验触发器定义
 * @param {TriggerDef} def
 * @throws {Error}
 */
function _validateTriggerDef(def) {
    if (!def.name)         throw new Error('[AutoTrigger] name 不能为空');
    if (!def.type)         throw new Error('[AutoTrigger] type 不能为空');
    if (!def.actionScript) throw new Error('[AutoTrigger] actionScript 不能为空');

    if (!Object.values(TRIGGER_TYPES).includes(def.type)) {
        throw new Error(`[AutoTrigger] 无效的触发器类型：${def.type}`);
    }

    if ([TRIGGER_TYPES.VAR_THRESHOLD, TRIGGER_TYPES.VAR_EQUALS, TRIGGER_TYPES.STAT_ZERO].includes(def.type)) {
        if (!def.varKey) throw new Error(`[AutoTrigger] type=${def.type} 需要提供 varKey`);
    }

    if (def.type === TRIGGER_TYPES.KEYWORD_DETECT) {
        if (!def.keywords || def.keywords.length === 0) {
            throw new Error('[AutoTrigger] KEYWORD_DETECT 需要提供 keywords 数组');
        }
    }

    if (def.type === TRIGGER_TYPES.RANDOM_CHANCE) {
        if (def.chance === undefined || def.chance < 0 || def.chance > 100) {
            throw new Error('[AutoTrigger] RANDOM_CHANCE 需要提供 0~100 之间的 chance');
        }
    }

    if (def.type === TRIGGER_TYPES.COMPOUND) {
        if (!def.conditions || def.conditions.length === 0) {
            throw new Error('[AutoTrigger] COMPOUND 需要提供 conditions 数组');
        }
    }
}

/**
 * 生成人类可读的触发器说明
 * @param {TriggerDef} def
 * @returns {string}
 */
function _buildDescription(def) {
    const timingLabel = {
        [TRIGGER_TIMING.AFTER_USER]: '用户发言后',
        [TRIGGER_TIMING.AFTER_AI]:   'AI回复后',
        [TRIGGER_TIMING.BOTH]:       '每次消息后',
    }[def.timing] || '未知时机';

    switch (def.type) {
        case TRIGGER_TYPES.VAR_THRESHOLD:
        case TRIGGER_TYPES.VAR_EQUALS:
            return `${timingLabel}：当 ${def.varKey} ${def.operator || 'eq'} ${def.threshold} 时触发`;
        case TRIGGER_TYPES.STAT_ZERO:
            return `${timingLabel}：当 ${def.varKey} ≤ 0 时触发`;
        case TRIGGER_TYPES.KEYWORD_DETECT:
            return `${timingLabel}：检测到关键词 [${def.keywords?.join('|')}] 时触发`;
        case TRIGGER_TYPES.TURN_COUNT:
            return `每 ${def.interval} 回合触发一次`;
        case TRIGGER_TYPES.RANDOM_CHANCE:
            return `${timingLabel}：以 ${def.chance}% 概率触发`;
        case TRIGGER_TYPES.ONCE:
            return `只触发一次的单次触发器`;
        case TRIGGER_TYPES.COMPOUND:
            return `${timingLabel}：复合条件（${def.logic || 'AND'}）`;
        default:
            return `${def.type} 类型触发器`;
    }
}

// ═══════════════════════════════════════════════
// § 7  内置触发器模板库
// ═══════════════════════════════════════════════

/**
 * 开箱即用的触发器模板（需填入 actionScript 和具体参数）
 * @type {Object.<string, TriggerDef>}
 */
export const BUILT_IN_TRIGGERS = {

    /** HP 归零触发器骨架 */
    hp_zero: {
        type:         TRIGGER_TYPES.STAT_ZERO,
        name:         'player_hp_zero',
        timing:       TRIGGER_TIMING.AFTER_AI,
        varKey:       'player_hp',
        actionScript: '/setvar key=game_state value=game_over | /echo 💀 游戏结束！ |',
    },

    /** 每 5 回合触发的随机事件骨架 */
    periodic_event: {
        type:         TRIGGER_TYPES.TURN_COUNT,
        name:         'periodic_random_event',
        timing:       TRIGGER_TIMING.AFTER_AI,
        interval:     5,
        actionScript: '/echo 🎲 随机事件触发！ |',
    },

    /** 检测 AI 说出「任务完成」时触发 */
    quest_complete_detect: {
        type:         TRIGGER_TYPES.KEYWORD_DETECT,
        name:         'quest_complete_detect',
        timing:       TRIGGER_TIMING.AFTER_AI,
        keywords:     ['任务完成', '完成了', '成功了', 'quest complete'],
        actionScript: '/setvar key=quest_status value=done | /echo 🏆 任务已完成！ |',
    },

    /** 30% 概率的意外事件触发器 */
    random_event_30pct: {
        type:         TRIGGER_TYPES.RANDOM_CHANCE,
        name:         'random_event_30pct',
        timing:       TRIGGER_TIMING.AFTER_AI,
        chance:       30,
        actionScript: '/echo 🎲 意外事件发生！ |',
        elseScript:   '',
    },
};