/**
 * @file modules/04_stscript-forge/templates/plot-menu.js
 * @description 剧情菜单 STscript 模板生成器
 *              负责生成可交互的剧情选项菜单、章节切换菜单、NPC 对话菜单等
 *              所有生成结果均为标准 STscript 字符串，可直接注入 SillyTavern 快捷回复集
 * @version 1.0.0
 */

import { EVENTS } from '../../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  菜单类型枚举
// ═══════════════════════════════════════════════

/**
 * 支持的剧情菜单类型
 * @enum {string}
 */
export const MENU_TYPES = {
    /** 玩家行动选择菜单（回合制或自由选择） */
    ACTION_CHOICE:   'action_choice',
    /** 章节/幕切换导航菜单 */
    CHAPTER_NAV:     'chapter_nav',
    /** NPC 对话选项菜单 */
    DIALOGUE:        'dialogue',
    /** 物品/技能使用菜单 */
    ITEM_USE:        'item_use',
    /** 结局触发菜单 */
    ENDING:          'ending',
    /** 自定义多级嵌套菜单 */
    NESTED:          'nested',
};

// ═══════════════════════════════════════════════
// § 2  菜单默认配置
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} MenuOption
 * @property {string}  label       - 显示给玩家的文本（支持 emoji）
 * @property {string}  script      - 该选项触发的 STscript
 * @property {string}  [condition] - 显示条件（STscript 表达式字符串，可为空）
 * @property {string}  [varKey]    - 选中后设置的变量 key
 * @property {string}  [varValue]  - 选中后设置的变量 value
 * @property {boolean} [hidden]    - 是否默认隐藏（条件不满足时）
 */

/**
 * @typedef {Object} PlotMenuDef
 * @property {string}      name        - 菜单名称（用于 QR Set 标识）
 * @property {string}      title       - 菜单标题（显示在菜单顶部）
 * @property {string}      type        - MENU_TYPES 中的值
 * @property {MenuOption[]} options    - 选项列表
 * @property {string}      [header]    - 菜单顶部说明文本
 * @property {string}      [footer]    - 菜单底部说明文本
 * @property {boolean}     [repeatable] - 是否可重复触发（默认 true）
 * @property {string}      [closeLabel] - 关闭/取消按钮文本（为空则不显示）
 */

/** @type {PlotMenuDef} 默认菜单定义骨架 */
export const DEFAULT_MENU_DEF = {
    name:        'plot_menu',
    title:       '📖 剧情选择',
    type:        MENU_TYPES.ACTION_CHOICE,
    header:      '',
    footer:      '',
    repeatable:  true,
    closeLabel:  '❌ 取消',
    options:     [],
};

// ═══════════════════════════════════════════════
// § 3  核心生成函数
// ═══════════════════════════════════════════════

/**
 * 生成剧情选项菜单的完整 STscript
 *
 * @param {PlotMenuDef} menuDef - 菜单定义对象
 * @returns {{ entryScript: string, qrSetJSON: object, preview: string }}
 *          entryScript : 触发菜单的主入口 STscript
 *          qrSetJSON   : SillyTavern 可直接导入的 QR Set JSON 对象
 *          preview     : 人类可读的菜单预览文本
 */
export function generatePlotMenu(menuDef) {
    const def = { ...DEFAULT_MENU_DEF, ...menuDef };
    _validateMenuDef(def);

    const entryScript  = _buildEntryScript(def);
    const qrSetJSON    = _buildQRSetJSON(def);
    const preview      = _buildPreview(def);

    return { entryScript, qrSetJSON, preview };
}

/**
 * 生成章节导航菜单（快捷入口，自动填充默认值）
 *
 * @param {string}   menuName  - QR Set 名称
 * @param {Array<{title: string, script: string}>} chapters - 章节列表
 * @returns {{ entryScript: string, qrSetJSON: object, preview: string }}
 */
export function generateChapterNav(menuName, chapters) {
    /** @type {MenuOption[]} */
    const options = chapters.map((ch, idx) => ({
        label:    `📖 第${_toChineseNum(idx + 1)}章：${ch.title}`,
        script:   ch.script,
        varKey:   'current_chapter',
        varValue: String(idx + 1),
        hidden:   false,
    }));

    return generatePlotMenu({
        name:       menuName,
        title:      '📚 章节导航',
        type:       MENU_TYPES.CHAPTER_NAV,
        header:     '请选择要前往的章节：',
        options,
        closeLabel: '↩️ 返回',
    });
}

/**
 * 生成 NPC 对话选项菜单
 *
 * @param {string}   npcName   - NPC 名称
 * @param {string}   menuName  - QR Set 名称
 * @param {Array<{text: string, response: string, condition?: string}>} dialogues
 * @returns {{ entryScript: string, qrSetJSON: object, preview: string }}
 */
export function generateDialogueMenu(npcName, menuName, dialogues) {
    const options = dialogues.map((d, idx) => ({
        label:     `💬 "${d.text}"`,
        condition: d.condition || '',
        script:    _buildDialogueOptionScript(npcName, d.text, d.response, idx),
        hidden:    !!d.condition,
    }));

    return generatePlotMenu({
        name:      menuName,
        title:     `🗣️ 与 ${npcName} 对话`,
        type:      MENU_TYPES.DIALOGUE,
        header:    `${npcName} 正在看着你，等待你说话。`,
        options,
        closeLabel: '🚶 转身离开',
    });
}

/**
 * 生成带条件分支的高级剧情菜单
 * 每个选项可附带前置条件检查（读取 STscript 变量）
 *
 * @param {PlotMenuDef} menuDef
 * @returns {{ entryScript: string, qrSetJSON: object, preview: string }}
 */
export function generateConditionalMenu(menuDef) {
    // 为每个 option 包裹条件检查逻辑
    const enrichedDef = {
        ...menuDef,
        options: menuDef.options.map(opt => ({
            ...opt,
            script: opt.condition
                ? _wrapWithConditionCheck(opt.condition, opt.script)
                : opt.script,
        })),
    };
    return generatePlotMenu(enrichedDef);
}

/**
 * 生成结局触发菜单
 * 当特定条件满足时，展示可到达的结局
 *
 * @param {Array<{id: string, title: string, desc: string, condition: string, script: string}>} endings
 * @returns {{ entryScript: string, qrSetJSON: object, preview: string }}
 */
export function generateEndingMenu(endings) {
    const options = endings.map(e => ({
        label:     `🔮 ${e.title}`,
        condition: e.condition,
        script:    _buildEndingScript(e),
        hidden:    true,    // 结局默认隐藏，条件达成时由主逻辑更新 QR 可见性
    }));

    return generatePlotMenu({
        name:       'endings_menu',
        title:      '✨ 命运的岔路口',
        type:       MENU_TYPES.ENDING,
        header:     '你的选择将决定故事的走向……',
        options,
        closeLabel: '',     // 结局菜单无关闭按钮
    });
}

// ═══════════════════════════════════════════════
// § 4  STscript 片段构建（私有）
// ═══════════════════════════════════════════════

/**
 * 构建菜单主入口 STscript
 * 负责：① 显示菜单标题和说明 ② 激活对应 QR Set ③ 展示选项按钮
 *
 * @param {PlotMenuDef} def
 * @returns {string}
 */
function _buildEntryScript(def) {
    const lines = [];

    // 1. 激活 QR Set（确保菜单按钮可见）
    lines.push(`/qr-set-enable ${_escapeQRName(def.name)} |`);

    // 2. 显示菜单标题与说明
    const headerBlock = _buildHeaderBlock(def);
    if (headerBlock) {
        lines.push(headerBlock);
    }

    // 3. 处理条件隐藏：逐一检查每个选项的 condition，动态更新 QR 可见性
    def.options.forEach((opt, idx) => {
        if (opt.condition) {
            lines.push(_buildVisibilityToggle(def.name, idx, opt.condition));
        }
    });

    // 4. 注入关闭按钮逻辑（如果配置了 closeLabel）
    if (def.closeLabel) {
        lines.push(_buildCloseScript(def.name));
    }

    return lines.join('\n');
}

/**
 * 构建显示标题和说明的 STscript 片段
 * @param {PlotMenuDef} def
 * @returns {string}
 */
function _buildHeaderBlock(def) {
    const parts = [];
    const divider = '─'.repeat(24);

    parts.push(`/echo ${divider} |`);
    parts.push(`/echo **${def.title}** |`);

    if (def.header) {
        parts.push(`/echo ${def.header} |`);
    }

    parts.push(`/echo ${divider} |`);
    return parts.join('\n');
}

/**
 * 构建单个选项的可见性切换 STscript
 * 当条件满足时显示对应 QR 按钮，不满足时隐藏
 *
 * @param {string} qrSetName   - QR Set 名称
 * @param {number} optionIndex - 选项索引（对应 QR 按钮顺序）
 * @param {string} condition   - STscript 条件表达式
 * @returns {string}
 */
function _buildVisibilityToggle(qrSetName, optionIndex, condition) {
    // STscript if/else 结构控制 QR 按钮可见性
    return [
        `/if left={{${condition}}} right=true else="/qr-hide ${_escapeQRName(qrSetName)} ${optionIndex}"`,
        `    /qr-show ${_escapeQRName(qrSetName)} ${optionIndex} |`,
    ].join('\n');
}

/**
 * 构建关闭菜单的 STscript（禁用整个 QR Set）
 * @param {string} qrSetName
 * @returns {string}
 */
function _buildCloseScript(qrSetName) {
    return `/qr-set-disable ${_escapeQRName(qrSetName)} |`;
}

/**
 * 构建 NPC 对话选项 STscript
 * 模拟玩家说出该句话，并注入 NPC 预设回应（作为 World Info 提示）
 *
 * @param {string} npcName
 * @param {string} playerText
 * @param {string} npcResponse
 * @param {number} idx
 * @returns {string}
 */
function _buildDialogueOptionScript(npcName, playerText, npcResponse, idx) {
    return [
        `// 对话选项 #${idx + 1}：${playerText}`,
        `/setvar key=player_dialogue_choice value="${playerText}" |`,
        `/setvar key=npc_response_hint_${idx} value="${npcResponse}" |`,
        `/send ${playerText} |`,
        `/trigger |`,
    ].join('\n');
}

/**
 * 构建结局触发 STscript
 * @param {{ id: string, title: string, desc: string, script: string }} ending
 * @returns {string}
 */
function _buildEndingScript(ending) {
    return [
        `// 结局触发：${ending.title}`,
        `/setvar key=game_ending value="${ending.id}" |`,
        `/setvar key=game_ended value=true |`,
        `/echo 🎭 **${ending.title}** |`,
        ending.desc ? `/echo ${ending.desc} |` : '',
        `/qr-set-disable all |`,   // 触发结局后禁用所有菜单
        ending.script || '',
    ].filter(Boolean).join('\n');
}

/**
 * 将条件不满足时的脚本包裹在条件检查中
 * @param {string} condition
 * @param {string} script
 * @returns {string}
 */
function _wrapWithConditionCheck(condition, script) {
    return [
        `/if left={{${condition}}} right=true`,
        `    ${script.split('\n').join('\n    ')} |`,
        `/else`,
        `    /echo ⚠️ 当前条件不满足，无法执行此选项。 |`,
    ].join('\n');
}

// ═══════════════════════════════════════════════
// § 5  QR Set JSON 构建（私有）
// ═══════════════════════════════════════════════

/**
 * 构建 SillyTavern 可直接导入的 QR Set JSON 对象
 * @param {PlotMenuDef} def
 * @returns {object}
 */
function _buildQRSetJSON(def) {
    const replies = [];

    // 选项按钮
    def.options.forEach((opt, idx) => {
        replies.push({
            id:             idx + 1,
            label:          opt.label,
            title:          `${def.name}_option_${idx}`,
            message:        opt.script,
            contextMenu:    '',
            preventInput:   true,
            isHidden:       !!opt.hidden,
            executeOnUser:  false,
            executeOnAi:    false,
            autoExecute:    false,
            extensionPrompt: '',
            extensionPromptPos: 0,
        });
    });

    // 关闭按钮（如果配置了）
    if (def.closeLabel) {
        replies.push({
            id:             def.options.length + 1,
            label:          def.closeLabel,
            title:          `${def.name}_close`,
            message:        _buildCloseScript(def.name),
            preventInput:   true,
            isHidden:       false,
            executeOnUser:  false,
            executeOnAi:    false,
            autoExecute:    false,
            contextMenu:    '',
            extensionPrompt: '',
            extensionPromptPos: 0,
        });
    }

    return {
        version:     '1.0',
        name:        def.name,
        disabledByDefault: false,
        isGlobal:    false,
        quickReplySetCommands: [],
        quickReplies: replies,
    };
}

// ═══════════════════════════════════════════════
// § 6  预览文本构建（私有）
// ═══════════════════════════════════════════════

/**
 * 构建人类可读的菜单预览文本
 * @param {PlotMenuDef} def
 * @returns {string}
 */
function _buildPreview(def) {
    const lines = [
        `╔${'═'.repeat(30)}╗`,
        `║  ${def.title.padEnd(28)}║`,
        `╠${'═'.repeat(30)}╣`,
    ];

    if (def.header) {
        lines.push(`║  ${def.header.slice(0, 28).padEnd(28)}║`);
        lines.push(`╠${'═'.repeat(30)}╣`);
    }

    def.options.forEach((opt, idx) => {
        const prefix = opt.condition ? '[?] ' : '    ';
        const text   = `${prefix}${idx + 1}. ${opt.label}`.slice(0, 28);
        lines.push(`║  ${text.padEnd(28)}║`);
    });

    if (def.closeLabel) {
        lines.push(`╠${'═'.repeat(30)}╣`);
        lines.push(`║  ${def.closeLabel.slice(0, 28).padEnd(28)}║`);
    }

    if (def.footer) {
        lines.push(`╠${'═'.repeat(30)}╣`);
        lines.push(`║  ${def.footer.slice(0, 28).padEnd(28)}║`);
    }

    lines.push(`╚${'═'.repeat(30)}╝`);
    lines.push('');
    lines.push(`[?] = 含条件检查的选项`);
    lines.push(`总计 ${def.options.length} 个选项，类型：${def.type}`);

    return lines.join('\n');
}

// ═══════════════════════════════════════════════
// § 7  工具函数（私有）
// ═══════════════════════════════════════════════

/**
 * 校验菜单定义的必要字段
 * @param {PlotMenuDef} def
 * @throws {Error}
 */
function _validateMenuDef(def) {
    if (!def.name || typeof def.name !== 'string') {
        throw new Error('[PlotMenu] menuDef.name 不能为空且必须为字符串');
    }
    if (!Array.isArray(def.options) || def.options.length === 0) {
        throw new Error('[PlotMenu] menuDef.options 不能为空数组');
    }
    if (!Object.values(MENU_TYPES).includes(def.type)) {
        throw new Error(`[PlotMenu] 无效的菜单类型：${def.type}`);
    }
    def.options.forEach((opt, idx) => {
        if (!opt.label) {
            throw new Error(`[PlotMenu] 选项 #${idx} 缺少 label`);
        }
        if (!opt.script) {
            throw new Error(`[PlotMenu] 选项 #${idx} 缺少 script`);
        }
    });
}

/**
 * 转义 QR Set 名称中的特殊字符
 * @param {string} name
 * @returns {string}
 */
function _escapeQRName(name) {
    return name.replace(/[^a-zA-Z0-9_\-\u4e00-\u9fa5]/g, '_');
}

/**
 * 数字转中文数字（1-20）
 * @param {number} n
 * @returns {string}
 */
function _toChineseNum(n) {
    const map = ['零','一','二','三','四','五','六','七','八','九',
                 '十','十一','十二','十三','十四','十五',
                 '十六','十七','十八','十九','二十'];
    return map[n] ?? String(n);
}

// ═══════════════════════════════════════════════
// § 8  内置模板库（开箱即用）
// ═══════════════════════════════════════════════

/**
 * 预置剧情菜单模板（可直接调用 generatePlotMenu() 传入）
 * @type {Object.<string, PlotMenuDef>}
 */
export const BUILT_IN_MENU_TEMPLATES = {

    /** 三选一的经典 RPG 行动菜单 */
    rpg_action_basic: {
        name:    'rpg_action_basic',
        title:   '⚔️ 行动选择',
        type:    MENU_TYPES.ACTION_CHOICE,
        header:  '你要怎么做？',
        options: [
            {
                label:  '⚔️ 战斗',
                script: '/setvar key=player_action value=combat | /trigger |',
            },
            {
                label:  '💬 交涉',
                script: '/setvar key=player_action value=negotiate | /trigger |',
            },
            {
                label:  '🏃 逃跑',
                script: '/setvar key=player_action value=flee | /trigger |',
            },
        ],
        closeLabel: '',
    },

    /** 带条件的探索菜单（示例：仅当 has_key=true 时显示开门选项） */
    exploration_conditional: {
        name:    'exploration_menu',
        title:   '🗺️ 探索行动',
        type:    MENU_TYPES.ACTION_CHOICE,
        header:  '你环顾四周……',
        options: [
            {
                label:  '🔍 仔细搜索',
                script: '/setvar key=player_action value=search | /trigger |',
            },
            {
                label:     '🚪 打开大门',
                condition: 'getvar::has_key',
                script:    '/setvar key=player_action value=open_door | /trigger |',
                hidden:    true,
            },
            {
                label:  '↩️ 原路返回',
                script: '/setvar key=player_action value=go_back | /trigger |',
            },
        ],
        closeLabel: '',
    },

    /** 四结局模板 */
    four_endings: {
        name:    'endings_menu',
        title:   '🌟 命运的终点',
        type:    MENU_TYPES.ENDING,
        header:  '一切走向了终结……',
        options: [
            {
                label:     '☀️ 光明结局',
                condition: 'getvar::flag_good_ending',
                script:    '/setvar key=game_ending value=good | /trigger |',
                hidden:    true,
            },
            {
                label:     '🌙 隐藏结局',
                condition: 'getvar::flag_secret_ending',
                script:    '/setvar key=game_ending value=secret | /trigger |',
                hidden:    true,
            },
            {
                label:     '💀 悲剧结局',
                condition: 'getvar::flag_bad_ending',
                script:    '/setvar key=game_ending value=bad | /trigger |',
                hidden:    true,
            },
            {
                label:     '⚖️ 中立结局',
                condition: 'getvar::flag_neutral_ending',
                script:    '/setvar key=game_ending value=neutral | /trigger |',
                hidden:    true,
            },
        ],
        closeLabel: '',
    },
};