/**
 * @file modules/04_stscript-forge/templates/rpg-status-bar.js
 * @description STscript 模板：RPG 状态栏
 *              生成可直接复制进 SillyTavern Quick Reply 的 STscript 代码
 *              包含：HTML 注入 + CSS 样式 + 属性更新宏 + 初始化调用
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// 默认属性定义（若用户未传入自定义属性时使用）
// ─────────────────────────────────────────────
export const DEFAULT_STATS = [
    { key: 'hp',     label: '❤️ 生命',  min: 0, max: 100, current: 100, color: '#e74c3c' },
    { key: 'mp',     label: '💧 法力',  min: 0, max: 100, current: 100, color: '#3498db' },
    { key: 'stamina',label: '⚡ 体力',  min: 0, max: 100, current: 100, color: '#f39c12' },
    { key: 'sanity', label: '🧠 理智',  min: 0, max: 100, current: 100, color: '#9b59b6' },
];

// ─────────────────────────────────────────────
// 模板元数据
// ─────────────────────────────────────────────
export const TEMPLATE_META = {
    id:          'rpg-status-bar',
    name:        'RPG 状态栏',
    description: '在屏幕角落显示角色属性进度条（HP/MP/体力等），随对话自动更新',
    icon:        '📊',
    category:    'rpg',
    tags:        ['rpg', 'status', '状态栏', 'hp', 'mp'],
    version:     '1.0.0',
};

// ─────────────────────────────────────────────
// 主入口：构建完整 STscript
// ─────────────────────────────────────────────

/**
 * 生成 RPG 状态栏 STscript
 *
 * @param {object}  [options]
 * @param {Array}   [options.stats]          属性定义数组（默认使用 DEFAULT_STATS）
 * @param {string}  [options.containerId]    DOM 容器 id
 * @param {string}  [options.position]       'bottom-left'|'bottom-right'|'top-left'|'top-right'
 * @param {boolean} [options.draggable]      是否允许拖动
 * @param {boolean} [options.collapsible]    是否允许折叠
 * @param {boolean} [options.showPercent]    是否显示百分比
 * @returns {string}  可直接使用的 STscript 代码
 */
export function buildRPGStatusBarTemplate(options = {}) {
    const {
        stats       = DEFAULT_STATS,
        containerId = 'cf_rpg_bar',
        position    = 'bottom-left',
        draggable   = false,
        collapsible = true,
        showPercent = false,
    } = options;

    // 验证属性列表
    if (!Array.isArray(stats) || stats.length === 0) {
        throw new Error('[rpg-status-bar] stats 不能为空数组');
    }

    const validatedStats = stats.map(_validateStat);

    const css        = _buildCSS(containerId, position);
    const html       = _buildHTML(containerId, validatedStats, { collapsible, draggable });
    const initScript = _buildInitScript(containerId, validatedStats);
    const updateMacro = _buildUpdateMacro(containerId, validatedStats, { showPercent });
    const listenerScript = _buildListenerScript(containerId, validatedStats);

    return _assembleScript({
        css, html, initScript, updateMacro, listenerScript,
        containerId, stats: validatedStats,
    });
}

// ─────────────────────────────────────────────
// 构建各部分
// ─────────────────────────────────────────────

/**
 * 生成 CSS 样式字符串
 */
function _buildCSS(containerId, position) {
    const posMap = {
        'bottom-left':  'bottom:14px;left:14px',
        'bottom-right': 'bottom:14px;right:14px',
        'top-left':     'top:14px;left:14px',
        'top-right':    'top:14px;right:14px',
    };
    const posStyle = posMap[position] ?? posMap['bottom-left'];

    return `
#${containerId} {
    position: fixed;
    ${posStyle};
    z-index: 9990;
    width: 210px;
    padding: 10px 12px;
    background: rgba(10,10,20,0.72);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 10px;
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    font-family: system-ui, -apple-system, sans-serif;
    color: rgba(255,255,255,0.90);
    box-shadow: 0 6px 24px rgba(0,0,0,0.45);
    user-select: none;
    transition: opacity 0.2s ease;
}
#${containerId}.cf-bar-collapsed .cf-bar-stats { display: none; }
#${containerId} .cf-bar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
    cursor: pointer;
}
#${containerId} .cf-bar-header-title {
    font-size: 11px;
    font-weight: 700;
    opacity: 0.65;
    text-transform: uppercase;
    letter-spacing: 0.8px;
}
#${containerId} .cf-bar-collapse-btn {
    font-size: 12px;
    opacity: 0.5;
    transition: opacity 0.15s;
    line-height: 1;
}
#${containerId} .cf-bar-stats {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
#${containerId} .cf-bar-stat {
    display: flex;
    flex-direction: column;
    gap: 3px;
}
#${containerId} .cf-bar-stat-row {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
}
#${containerId} .cf-bar-stat-label {
    font-size: 11px;
    font-weight: 600;
    opacity: 0.88;
}
#${containerId} .cf-bar-stat-val {
    font-size: 10px;
    opacity: 0.70;
    font-variant-numeric: tabular-nums;
}
#${containerId} .cf-bar-track {
    height: 5px;
    border-radius: 5px;
    background: rgba(255,255,255,0.09);
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.06);
}
#${containerId} .cf-bar-fill {
    height: 100%;
    border-radius: 5px;
    width: 0%;
    transition: width 0.30s cubic-bezier(0.4,0,0.2,1),
                background-color 0.30s ease;
}
`.trim();
}

/**
 * 生成 HTML 字符串
 */
function _buildHTML(containerId, stats, opts) {
    const { collapsible } = opts;

    const statItems = stats.map(s => `
<div class="cf-bar-stat" id="${containerId}_stat_${s.key}">
  <div class="cf-bar-stat-row">
    <span class="cf-bar-stat-label">${_escHTML(s.label)}</span>
    <span class="cf-bar-stat-val" id="${containerId}_val_${s.key}">
        ${s.current} / ${s.max}
    </span>
  </div>
  <div class="cf-bar-track">
    <div class="cf-bar-fill" id="${containerId}_fill_${s.key}"
         style="width:${_pct(s.current, s.min, s.max)}%;background:${_escAttr(s.color)}">
    </div>
  </div>
</div>`.trim()).join('\n');

    const collapseBtn = collapsible
        ? `<span class="cf-bar-collapse-btn" id="${containerId}_toggle">▲</span>`
        : '';

    return `
<style id="${containerId}_style">
${_buildCSS(containerId, 'bottom-left')}
</style>
<div id="${containerId}">
  <div class="cf-bar-header" id="${containerId}_header">
    <span class="cf-bar-header-title">⚔ 状态</span>
    ${collapseBtn}
  </div>
  <div class="cf-bar-stats" id="${containerId}_stats">
    ${statItems}
  </div>
</div>
`.trim();
}

/**
 * 生成初始化脚本（注入 HTML + CSS，绑定折叠）
 */
function _buildInitScript(containerId, stats) {
    // 将初始值写入 ST 变量
    const initVars = stats.map(s =>
        `/setvar key="${_stKey(s.key)}" ${s.current}`
    ).join('\n');

    return `
// ── 初始化：写入默认属性值 ──
${initVars}
// ── 首次渲染状态栏 ──
/run cf_update_${containerId}
`.trim();
}

/**
 * 生成更新宏（STscript /define 宏）
 * 宏名：cf_update_<containerId>
 */
function _buildUpdateMacro(containerId, stats, opts) {
    const { showPercent } = opts;

    const updates = stats.map(s => {
        const range  = Math.max(1, s.max - s.min);
        const varKey = _stKey(s.key);

        // 读取变量 → 计算百分比 → 更新 DOM
        // SillyTavern STscript 中使用 /getvar /math /dom 等指令
        // 此处采用可读性最高的注释式伪代码，真实执行时由 ScriptForge 语法校验适配
        return `
// 更新 ${s.label}
/setvar key="__tmp_${s.key}" {{getvar::${varKey}}}
/setvar key="__tmp_${s.key}_pct" {{#math}}
    max(0, min(100,
        floor(( {{getvar::__tmp_${s.key}}} - ${s.min} ) / ${range} * 100)
    ))
{{/math}}
/dom id="${containerId}_fill_${s.key}" action=style
     target=width
     value="{{getvar::__tmp_${s.key}_pct}}%"
/dom id="${containerId}_fill_${s.key}" action=style
     target=backgroundColor
     value="${s.color}"
/dom id="${containerId}_val_${s.key}" action=text
     value="${showPercent
        ? '{{getvar::__tmp_' + s.key + '_pct}}%'
        : '{{getvar::__tmp_' + s.key + '}} / ' + s.max
     }"`.trim();
    }).join('\n\n');

    return `
/define cf_update_${containerId}
    ${updates.split('\n').join('\n    ')}
/end-define
`.trim();
}

/**
 * 生成自动监听脚本
 * 每次 AI 回复后自动调用更新宏
 */
function _buildListenerScript(containerId, stats) {
    // 关键词追踪示例（根据对话内容更新属性）
    const examples = stats.slice(0, 2).map(s => `
// 示例：从 AI 回复中提取「${s.label} -10」格式的变化
/regex find="(?i)${s.label.replace(/[^a-zA-Z\u4e00-\u9fff]/g, '')}\\s*([+-]\\d+)"
        replace=""
        all=true
        input={{lastMessage}}
/if {{regex_match_1}}
    /math {{getvar::${_stKey(s.key)}}} + {{regex_match_1}}
    /setvar key="${_stKey(s.key)}" {{math_result}}
/end-if`.trim()).join('\n\n');

    return `
// ── 自动更新监听器（绑定到消息接收事件）──
// 如需每次 AI 回复后自动更新状态栏，
// 请将以下代码放入「Message Received」触发器的 Quick Reply 中：

// /run cf_update_${containerId}

// ── 可选：关键词变化追踪示例 ──
${examples}
`.trim();
}

/**
 * 组装完整 STscript
 */
function _assembleScript({ css, html, initScript, updateMacro, listenerScript, containerId, stats }) {
    const varDeclarations = stats.map(s =>
        `// 变量：${_stKey(s.key)}  默认值：${s.current}  范围：${s.min}~${s.max}`
    ).join('\n');

    return `
// ═══════════════════════════════════════════════════════
//  ST-CardForge Pro · RPG Status Bar
//  生成时间：${new Date().toLocaleString('zh-CN')}
//  容器 ID：${containerId}
// ═══════════════════════════════════════════════════════
//
// 【使用说明】
// 1. 将本脚本放入一个 Quick Reply（QR）中，名称建议：「初始化状态栏」
// 2. 对话开始时触发一次（可绑定到 Chat Started 事件）
// 3. 在「Message Received」事件的 QR 中加入：/run cf_update_${containerId}
//    以实现每次 AI 回复后自动刷新状态栏
//
// 【属性变量说明】
${varDeclarations}
//
// ════════════════════════════════════════════════════════

// ── 1. 注入 HTML 和 CSS ──
/html <![CDATA[
${html}
]]>

// ── 2. 定义更新宏 ──
${updateMacro}

// ── 3. 初始化属性值 + 首次渲染 ──
${initScript}

// ── 4. （可选）自动追踪说明 ──
//
${listenerScript.split('\n').map(l => l ? `// ${l}` : '//').join('\n')}
`.trim();
}

// ─────────────────────────────────────────────
// 辅助工具函数
// ─────────────────────────────────────────────

function _validateStat(s) {
    const min     = Number(s.min     ?? 0);
    const max     = Number(s.max     ?? 100);
    const current = Math.max(min, Math.min(max, Number(s.current ?? max)));
    return {
        key:     String(s.key     ?? 'stat').replace(/\W/g, '_'),
        label:   String(s.label   ?? s.key ?? 'Stat'),
        min,
        max,
        current,
        color:   String(s.color   ?? '#7b68ee'),
    };
}

function _pct(current, min, max) {
    const range = Math.max(1, max - min);
    return Math.round(Math.max(0, Math.min(100, (current - min) / range * 100)));
}

/** 生成 ST 变量名（如 rpg_hp） */
function _stKey(key) {
    return `rpg_${key}`;
}

function _escHTML(s) {
    return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function _escAttr(s) {
    return String(s ?? '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}