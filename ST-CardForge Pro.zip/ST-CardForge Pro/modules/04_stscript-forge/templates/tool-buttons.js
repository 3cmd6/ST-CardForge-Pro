/**
 * @file modules/04_stscript-forge/templates/tool-buttons.js
 * @description 工具按钮 STscript 模板生成器
 *              负责生成角色卡配套的功能性快捷按钮组，
 *              包含：存档/读档、设置面板、帮助手册、Debug 面板、信息卡片等常用工具按钮。
 *              所有生成内容均为 QR Set JSON + 对应 STscript。
 * @version 1.0.0
 */

import { EVENTS } from '../../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  按钮类型枚举
// ═══════════════════════════════════════════════

/**
 * 工具按钮类型枚举
 * @enum {string}
 */
export const TOOL_BTN_TYPES = {
    /** 存档按钮：将当前变量快照写入 World Info */
    SAVE:           'save',
    /** 读档按钮：从 World Info 恢复变量快照 */
    LOAD:           'load',
    /** 重置按钮：清空所有游戏变量 */
    RESET:          'reset',
    /** 状态查看按钮：echo 所有关键变量当前值 */
    SHOW_STATS:     'show_stats',
    /** 帮助按钮：显示操作说明 */
    HELP:           'help',
    /** 设置面板按钮：显示可调整的游戏参数 */
    SETTINGS:       'settings',
    /** DEBUG 按钮：输出所有变量到 echo（开发用） */
    DEBUG:          'debug',
    /** 章节标记按钮：在对话中插入章节分隔符 */
    CHAPTER_MARK:   'chapter_mark',
    /** 时间推进按钮：推进游戏内时间 */
    TIME_ADVANCE:   'time_advance',
    /** 自定义按钮：完全由用户定义 */
    CUSTOM:         'custom',
};

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} ToolButtonDef
 * @property {string}   type        - TOOL_BTN_TYPES 中的值
 * @property {string}   label       - 按钮显示文字（支持 emoji）
 * @property {string}   title       - QR 按钮 title（唯一标识符）
 * @property {string}   [script]    - 覆盖默认生成的 STscript（type=custom 时必填）
 * @property {string[]} [varKeys]   - 此按钮涉及的变量 key 列表（用于存档/读档/显示状态）
 * @property {boolean}  [confirm]   - 触发前是否需要二次确认（用于重置等危险操作）
 * @property {string}   [confirmMsg] - 二次确认的提示文本
 * @property {boolean}  [autoOnUser] - 用户发言后自动执行（默认 false）
 * @property {boolean}  [autoOnAi]   - AI 回复后自动执行（默认 false）
 */

/**
 * @typedef {Object} ToolBarDef
 * @property {string}           name     - QR Set 名称
 * @property {ToolButtonDef[]}  buttons  - 按钮列表
 * @property {boolean}          [isGlobal] - 是否为全局 QR Set（默认 false）
 */

// ═══════════════════════════════════════════════
// § 3  主生成函数
// ═══════════════════════════════════════════════

/**
 * 生成工具按钮栏的完整定义
 *
 * @param {ToolBarDef} toolBarDef - 工具栏定义
 * @returns {{ qrSetJSON: object, scripts: Object.<string, string>, preview: string }}
 *          qrSetJSON : SillyTavern 可直接导入的 QR Set JSON
 *          scripts   : 每个按钮对应的 STscript（key = title）
 *          preview   : 按钮栏预览文本
 */
export function generateToolBar(toolBarDef) {
    _validateToolBarDef(toolBarDef);

    const scripts   = {};
    const qrReplies = [];

    toolBarDef.buttons.forEach((btnDef, idx) => {
        const script = _resolveScript(btnDef);
        scripts[btnDef.title] = script;

        qrReplies.push({
            id:               idx + 1,
            label:            btnDef.label,
            title:            btnDef.title,
            message:          script,
            contextMenu:      '',
            preventInput:     true,
            isHidden:         false,
            executeOnUser:    btnDef.autoOnUser  ?? false,
            executeOnAi:      btnDef.autoOnAi    ?? false,
            autoExecute:      false,
            extensionPrompt:  '',
            extensionPromptPos: 0,
        });
    });

    const qrSetJSON = {
        version:                 '1.0',
        name:                    toolBarDef.name,
        disabledByDefault:       false,
        isGlobal:                toolBarDef.isGlobal ?? false,
        quickReplySetCommands:   [],
        quickReplies:            qrReplies,
    };

    const preview = _buildToolBarPreview(toolBarDef);

    return { qrSetJSON, scripts, preview };
}

/**
 * 快速生成标准「存档 + 读档 + 重置」三件套工具栏
 *
 * @param {string}   name    - QR Set 名称
 * @param {string[]} varKeys - 需要存档/读档的变量 key 列表
 * @returns {{ qrSetJSON: object, scripts: Object.<string, string>, preview: string }}
 */
export function generateSaveLoadBar(name, varKeys) {
    return generateToolBar({
        name,
        buttons: [
            {
                type:       TOOL_BTN_TYPES.SAVE,
                label:      '💾 存档',
                title:      `${name}_save`,
                varKeys,
            },
            {
                type:       TOOL_BTN_TYPES.LOAD,
                label:      '📂 读档',
                title:      `${name}_load`,
                varKeys,
            },
            {
                type:       TOOL_BTN_TYPES.RESET,
                label:      '🔄 重置',
                title:      `${name}_reset`,
                varKeys,
                confirm:    true,
                confirmMsg: '⚠️ 确定要重置所有进度吗？此操作无法撤销。',
            },
        ],
    });
}

/**
 * 快速生成「状态查看 + 帮助 + Debug」三件套工具栏
 *
 * @param {string}   name    - QR Set 名称
 * @param {string[]} statKeys  - 要显示的状态变量 key 列表
 * @param {string}   helpText  - 帮助说明文本
 * @returns {{ qrSetJSON: object, scripts: Object.<string, string>, preview: string }}
 */
export function generateInfoBar(name, statKeys, helpText) {
    return generateToolBar({
        name,
        buttons: [
            {
                type:    TOOL_BTN_TYPES.SHOW_STATS,
                label:   '📊 查看状态',
                title:   `${name}_show_stats`,
                varKeys: statKeys,
            },
            {
                type:    TOOL_BTN_TYPES.HELP,
                label:   '❓ 帮助',
                title:   `${name}_help`,
                script:  _buildHelpScript(helpText),
            },
            {
                type:    TOOL_BTN_TYPES.DEBUG,
                label:   '🐛 Debug',
                title:   `${name}_debug`,
                varKeys: statKeys,
            },
        ],
    });
}

/**
 * 生成章节标记按钮（在对话中插入视觉分隔符）
 *
 * @param {string} name         - QR Set 名称
 * @param {string} chapterTitle - 当前章节标题（可包含变量占位符）
 * @returns {{ qrSetJSON: object, scripts: Object.<string, string>, preview: string }}
 */
export function generateChapterMarkButton(name, chapterTitle) {
    return generateToolBar({
        name,
        buttons: [
            {
                type:    TOOL_BTN_TYPES.CHAPTER_MARK,
                label:   '📑 章节标记',
                title:   `${name}_chapter_mark`,
                script:  _buildChapterMarkScript(chapterTitle),
            },
        ],
    });
}

// ═══════════════════════════════════════════════
// § 4  各类型 STscript 生成器（私有）
// ═══════════════════════════════════════════════

/**
 * 根据按钮类型解析/生成对应的 STscript
 * @param {ToolButtonDef} btnDef
 * @returns {string}
 */
function _resolveScript(btnDef) {
    // 用户提供了自定义 script 则直接使用
    if (btnDef.script) return btnDef.script;

    switch (btnDef.type) {
        case TOOL_BTN_TYPES.SAVE:
            return _buildSaveScript(btnDef.varKeys ?? []);
        case TOOL_BTN_TYPES.LOAD:
            return _buildLoadScript(btnDef.varKeys ?? []);
        case TOOL_BTN_TYPES.RESET:
            return _buildResetScript(btnDef.varKeys ?? [], btnDef.confirm, btnDef.confirmMsg);
        case TOOL_BTN_TYPES.SHOW_STATS:
            return _buildShowStatsScript(btnDef.varKeys ?? []);
        case TOOL_BTN_TYPES.HELP:
            return _buildHelpScript('（未配置帮助文本）');
        case TOOL_BTN_TYPES.SETTINGS:
            return _buildSettingsScript();
        case TOOL_BTN_TYPES.DEBUG:
            return _buildDebugScript(btnDef.varKeys ?? []);
        case TOOL_BTN_TYPES.CHAPTER_MARK:
            return _buildChapterMarkScript('第{{getvar::current_chapter}}章');
        case TOOL_BTN_TYPES.TIME_ADVANCE:
            return _buildTimeAdvanceScript();
        case TOOL_BTN_TYPES.CUSTOM:
            return '// ⚠️ 自定义按钮：请在 ScriptForge 中填写 STscript';
        default:
            return `// 未知按钮类型：${btnDef.type}`;
    }
}

/**
 * 存档 STscript
 * 将当前所有变量序列化后写入名为 save_data 的 World Info 条目
 *
 * @param {string[]} varKeys - 需要保存的变量 key 列表
 * @returns {string}
 */
function _buildSaveScript(varKeys) {
    if (varKeys.length === 0) {
        return [
            '// 存档（无指定变量，跳过）',
            '/echo 💾 没有配置需要存档的变量。 |',
        ].join('\n');
    }

    const saveLines = varKeys.map(key =>
        `/setvar key=save_${key} value={{getvar::${key}}} |`
    );

    return [
        '// ── 存档开始 ──────────────────────────────',
        ...saveLines,
        `/setvar key=save_timestamp value={{date}} |`,
        `/setvar key=has_save value=true |`,
        `/echo 💾 **存档成功！** 已保存 ${varKeys.length} 个变量。 |`,
        '// ── 存档结束 ──────────────────────────────',
    ].join('\n');
}

/**
 * 读档 STscript
 * 从 save_* 变量中恢复所有游戏变量
 *
 * @param {string[]} varKeys
 * @returns {string}
 */
function _buildLoadScript(varKeys) {
    if (varKeys.length === 0) {
        return '/echo 📂 没有配置需要读档的变量。 |';
    }

    const loadLines = varKeys.map(key =>
        `/setvar key=${key} value={{getvar::save_${key}}} |`
    );

    return [
        '// ── 读档开始 ──────────────────────────────',
        `/if left={{getvar::has_save}} right=true`,
        `    ${loadLines.join('\n    ')}`,
        `    /echo 📂 **读档成功！** 已恢复 ${varKeys.length} 个变量。（存档时间：{{getvar::save_timestamp}}）|`,
        `/else`,
        `    /echo ⚠️ 暂无存档，请先存档后再读取。 |`,
        '// ── 读档结束 ──────────────────────────────',
    ].join('\n');
}

/**
 * 重置 STscript
 * 清空所有游戏变量（支持二次确认）
 *
 * @param {string[]} varKeys
 * @param {boolean}  confirm
 * @param {string}   confirmMsg
 * @returns {string}
 */
function _buildResetScript(varKeys, confirm = true, confirmMsg = '') {
    const clearLines = varKeys.map(key => `/flushvar ${key} |`);
    const coreScript = [
        '// ── 重置开始 ──────────────────────────────',
        ...clearLines,
        `/flushvar has_save |`,
        `/flushvar save_timestamp |`,
        `/echo 🔄 **已重置所有进度。** |`,
        '// ── 重置结束 ──────────────────────────────',
    ].join('\n');

    if (!confirm) return coreScript;

    // 带确认弹窗的包装（使用 STscript input 模拟确认）
    const msg = confirmMsg || '⚠️ 确定要重置吗？';
    return [
        `/input "${msg} 输入 YES 确认重置：" |`,
        `/if left={{pipe}} right=YES`,
        `    ${coreScript.split('\n').join('\n    ')}`,
        `/else`,
        `    /echo ❌ 已取消重置。 |`,
    ].join('\n');
}

/**
 * 状态显示 STscript
 * Echo 所有关键变量的当前值，格式化为可读表格
 *
 * @param {string[]} varKeys
 * @returns {string}
 */
function _buildShowStatsScript(varKeys) {
    if (varKeys.length === 0) {
        return '/echo 📊 没有配置需要显示的变量。 |';
    }

    const statLines = varKeys.map(key =>
        `/echo 　${key.padEnd(16)} → {{getvar::${key}}} |`
    );

    return [
        '/echo ╔══════════════════════════╗ |',
        '/echo ║      📊 当前状态          ║ |',
        '/echo ╠══════════════════════════╣ |',
        ...statLines,
        '/echo ╚══════════════════════════╝ |',
    ].join('\n');
}

/**
 * 帮助文本 STscript
 * @param {string} helpText
 * @returns {string}
 */
function _buildHelpScript(helpText) {
    const lines = helpText.split('\n').map(line =>
        `/echo ${line || ' '} |`
    );
    return [
        '/echo ╔══════════════════════════╗ |',
        '/echo ║      ❓ 帮助手册          ║ |',
        '/echo ╠══════════════════════════╣ |',
        ...lines,
        '/echo ╚══════════════════════════╝ |',
    ].join('\n');
}

/**
 * 设置面板 STscript（显示可调参数，允许用户输入修改）
 * @returns {string}
 */
function _buildSettingsScript() {
    return [
        '/echo ⚙️ **游戏设置** |',
        '/input "请输入新的难度（easy/normal/hard）：" |',
        '/setvar key=game_difficulty value={{pipe}} |',
        '/echo ✅ 难度已设置为：{{getvar::game_difficulty}} |',
    ].join('\n');
}

/**
 * Debug 面板 STscript
 * 输出所有变量（包含 save_ 前缀变量）
 *
 * @param {string[]} varKeys
 * @returns {string}
 */
function _buildDebugScript(varKeys) {
    const allKeys  = [...varKeys, ...varKeys.map(k => `save_${k}`)];
    const debugLines = allKeys.map(key =>
        `/echo   [DEBUG] ${key} = {{getvar::${key}}} |`
    );

    return [
        '/echo ┌─── 🐛 DEBUG OUTPUT ──────────────┐ |',
        ...debugLines,
        `/echo   [DEBUG] has_save = {{getvar::has_save}} |`,
        `/echo   [DEBUG] save_timestamp = {{getvar::save_timestamp}} |`,
        '/echo └──────────────────────────────────┘ |',
    ].join('\n');
}

/**
 * 章节标记 STscript
 * 在对话流中插入一段醒目的章节分隔线
 *
 * @param {string} chapterTitle - 支持 {{getvar::xxx}} 变量插值
 * @returns {string}
 */
function _buildChapterMarkScript(chapterTitle) {
    return [
        '/echo  |',
        '/echo ════════════════════════════════ |',
        `/echo          📖 ${chapterTitle} |`,
        '/echo ════════════════════════════════ |',
        '/echo  |',
    ].join('\n');
}

/**
 * 时间推进 STscript
 * 将 game_time 变量递增，并显示新时间
 *
 * @returns {string}
 */
function _buildTimeAdvanceScript() {
    return [
        '// ── 时间推进 ──────────────────────────────',
        '/setvar key=game_time value={{math::{{getvar::game_time}}+1}} |',
        '/echo ⏰ 时间已推进：当前时间 → {{getvar::game_time}} |',
    ].join('\n');
}

// ═══════════════════════════════════════════════
// § 5  工具函数（私有）
// ═══════════════════════════════════════════════

/**
 * 校验工具栏定义
 * @param {ToolBarDef} def
 * @throws {Error}
 */
function _validateToolBarDef(def) {
    if (!def.name) throw new Error('[ToolBar] name 不能为空');
    if (!Array.isArray(def.buttons) || def.buttons.length === 0) {
        throw new Error('[ToolBar] buttons 不能为空数组');
    }
    def.buttons.forEach((btn, idx) => {
        if (!btn.type)  throw new Error(`[ToolBar] 按钮 #${idx} 缺少 type`);
        if (!btn.label) throw new Error(`[ToolBar] 按钮 #${idx} 缺少 label`);
        if (!btn.title) throw new Error(`[ToolBar] 按钮 #${idx} 缺少 title`);
        if (btn.type === TOOL_BTN_TYPES.CUSTOM && !btn.script) {
            throw new Error(`[ToolBar] 自定义按钮 #${idx} 缺少 script`);
        }
    });
}

/**
 * 构建工具栏预览文本
 * @param {ToolBarDef} def
 * @returns {string}
 */
function _buildToolBarPreview(def) {
    const btnRow = def.buttons.map(b => `[ ${b.label} ]`).join('  ');
    return [
        `工具栏名称：${def.name}`,
        `全局：${def.isGlobal ? '是' : '否'}`,
        '─'.repeat(btnRow.length),
        btnRow,
        '─'.repeat(btnRow.length),
        `共 ${def.buttons.length} 个按钮`,
    ].join('\n');
}

// ═══════════════════════════════════════════════
// § 6  内置工具栏模板库
// ═══════════════════════════════════════════════

/**
 * 开箱即用的工具栏模板集合
 */
export const BUILT_IN_TOOLBARS = {

    /** 完整存读档工具栏（需配合 varKeys 使用） */
    save_load_reset: {
        name: 'save_load_toolbar',
        buttons: [
            { type: TOOL_BTN_TYPES.SAVE,       label: '💾 存档', title: 'toolbar_save',       varKeys: [] },
            { type: TOOL_BTN_TYPES.LOAD,       label: '📂 读档', title: 'toolbar_load',       varKeys: [] },
            { type: TOOL_BTN_TYPES.SHOW_STATS, label: '📊 状态', title: 'toolbar_show_stats', varKeys: [] },
            { type: TOOL_BTN_TYPES.RESET,      label: '🔄 重置', title: 'toolbar_reset',      varKeys: [], confirm: true },
            { type: TOOL_BTN_TYPES.HELP,       label: '❓ 帮助', title: 'toolbar_help' },
        ],
    },

    /** 最简工具栏：只有存读档两个按钮 */
    minimal_save_load: {
        name: 'minimal_toolbar',
        buttons: [
            { type: TOOL_BTN_TYPES.SAVE, label: '💾', title: 'min_save', varKeys: [] },
            { type: TOOL_BTN_TYPES.LOAD, label: '📂', title: 'min_load', varKeys: [] },
        ],
    },
};