/**
 * @file modules/04_stscript-forge/visual-builder.js
 * @description STscript 可视化构建器
 *              提供拖拽式节点编辑界面，将可视化节点树编译为 STscript。
 *              节点类型覆盖：命令块、条件分支、循环块、变量操作、输出块、管道连接。
 *              注意：不依赖 D3 以保持轻量，使用纯 DOM + CSS Grid/Flex 实现拖拽。
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import { ALL_COMMANDS, STSCRIPT_COMMANDS } from './syntax-highlighter.js';

// ═══════════════════════════════════════════════
// § 1  节点类型定义
// ═══════════════════════════════════════════════

/**
 * 可视化节点类型枚举
 * @enum {string}
 */
export const NODE_TYPES = {
    START:      'start',        // 入口节点（每个脚本只有一个）
    END:        'end',          // 结束节点
    COMMAND:    'command',      // 通用命令节点（/echo /send 等）
    VAR_SET:    'var_set',      // 变量赋值节点（/setvar）
    VAR_GET:    'var_get',      // 变量读取节点（/getvar）
    IF:         'if',           // 条件判断节点（/if）
    ELSE:       'else',         // else 分支节点
    WHILE:      'while',        // while 循环节点
    TIMES:      'times',        // 次数循环节点（/times N）
    ECHO:       'echo',         // 输出节点（/echo）
    INPUT:      'input',        // 输入节点（/input）
    PIPE:       'pipe',         // 管道节点（|）
    NOTE:       'note',         // 注释/备注节点
    GROUP:      'group',        // 节点组（折叠/展开）
};

/**
 * 节点类型元信息（图标、颜色、说明）
 * @type {Object.<string, {icon: string, color: string, label: string, outputs: string[]}>}
 */
export const NODE_META = {
    [NODE_TYPES.START]:   { icon: '▶',  color: '#2ecc71', label: '开始',    outputs: ['next'] },
    [NODE_TYPES.END]:     { icon: '⏹',  color: '#e74c3c', label: '结束',    outputs: [] },
    [NODE_TYPES.COMMAND]: { icon: '⚙️', color: '#7b68ee', label: '命令',    outputs: ['next'] },
    [NODE_TYPES.VAR_SET]: { icon: '✏️', color: '#3498db', label: '设置变量', outputs: ['next'] },
    [NODE_TYPES.VAR_GET]: { icon: '📖', color: '#3498db', label: '读取变量', outputs: ['next'] },
    [NODE_TYPES.IF]:      { icon: '🔀', color: '#f39c12', label: '条件判断', outputs: ['true', 'false'] },
    [NODE_TYPES.ELSE]:    { icon: '↩️', color: '#f39c12', label: 'else',    outputs: ['next'] },
    [NODE_TYPES.WHILE]:   { icon: '🔁', color: '#e67e22', label: '循环',    outputs: ['body', 'exit'] },
    [NODE_TYPES.TIMES]:   { icon: '🔢', color: '#e67e22', label: '次数循环', outputs: ['body', 'exit'] },
    [NODE_TYPES.ECHO]:    { icon: '💬', color: '#1abc9c', label: '输出文本', outputs: ['next'] },
    [NODE_TYPES.INPUT]:   { icon: '⌨️', color: '#1abc9c', label: '弹出输入', outputs: ['next'] },
    [NODE_TYPES.PIPE]:    { icon: '→',  color: '#95a5a6', label: '管道',    outputs: ['next'] },
    [NODE_TYPES.NOTE]:    { icon: '📝', color: '#bdc3c7', label: '备注',    outputs: [] },
    [NODE_TYPES.GROUP]:   { icon: '📦', color: '#8e44ad', label: '节点组',  outputs: ['next'] },
};

// ═══════════════════════════════════════════════
// § 2  节点数据结构
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} VisualNode
 * @property {string}   id       - 唯一 ID
 * @property {string}   type     - NODE_TYPES 中的值
 * @property {number}   x        - 画布 X 坐标（像素）
 * @property {number}   y        - 画布 Y 坐标（像素）
 * @property {number}   width    - 节点宽度
 * @property {number}   height   - 节点高度
 * @property {object}   data     - 节点业务数据（因类型而异）
 * @property {string[]} children - 子节点 ID 列表（按 outputs 顺序）
 * @property {string}   [parentId] - 父节点 ID（如有）
 * @property {boolean}  [collapsed] - 节点组是否折叠
 */

/**
 * @typedef {Object} Connection
 * @property {string} fromId    - 源节点 ID
 * @property {string} fromPort  - 源输出端口名（'next'|'true'|'false'|'body'|'exit'）
 * @property {string} toId      - 目标节点 ID
 */

/**
 * @typedef {Object} BuilderState
 * @property {VisualNode[]}   nodes       - 所有节点
 * @property {Connection[]}   connections - 所有连接
 * @property {string[]}       selected    - 被选中的节点 ID 列表
 * @property {number}         zoom        - 画布缩放比例（0.5~2.0）
 * @property {{ x: number, y: number }} pan - 画布偏移
 */

// ═══════════════════════════════════════════════
// § 3  VisualBuilder 主类
// ═══════════════════════════════════════════════

/**
 * STscript 可视化构建器主类
 */
export class VisualBuilder {
    /**
     * @param {HTMLElement} canvasElement  - 画布容器（div）
     * @param {object}      [eventBus]     - EventBus 实例
     * @param {object}      [options]
     * @param {boolean}     [options.readonly=false]
     * @param {Function}    [options.onChange]   - 节点树变化时的回调
     */
    constructor(canvasElement, eventBus, options = {}) {
        this._canvas    = canvasElement;
        this._eventBus  = eventBus;
        this._options   = {
            readonly:   false,
            onChange:   null,
            gridSize:   20,         // 磁吸网格大小（像素）
            ...options,
        };

        /** @type {BuilderState} */
        this._state = {
            nodes:       [],
            connections: [],
            selected:    [],
            zoom:        1.0,
            pan:         { x: 0, y: 0 },
        };

        this._nodeIdCounter  = 0;
        this._isDragging     = false;
        this._dragTarget     = null;
        this._dragOffset     = { x: 0, y: 0 };
        this._connectingFrom = null;    // 正在拖拽的连线起点

        /** @type {HTMLElement} 节点层 */
        this._nodeLayer      = null;
        /** @type {SVGElement} 连线层 */
        this._svgLayer       = null;
    }

    // ─── 初始化 ───────────────────────────────────

    /**
     * 初始化画布 DOM 和事件监听
     */
    init() {
        this._buildCanvasDOM();
        this._bindCanvasEvents();
        this._renderAll();

        // 添加默认的 START 节点
        if (this._state.nodes.length === 0) {
            this.addNode(NODE_TYPES.START, 60, 60);
        }
    }

    /**
     * 构建画布 DOM 结构
     */
    _buildCanvasDOM() {
        this._canvas.classList.add('cf-vb-canvas');
        this._canvas.innerHTML = `
            <div class="cf-vb-viewport" style="transform-origin: 0 0;">
                <svg class="cf-vb-svg-layer" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <marker id="cf-vb-arrow" markerWidth="8" markerHeight="6"
                                refX="8" refY="3" orient="auto">
                            <polygon points="0 0, 8 3, 0 6" fill="#7b68ee"/>
                        </marker>
                    </defs>
                </svg>
                <div class="cf-vb-node-layer"></div>
            </div>
        `;
        this._viewport  = this._canvas.querySelector('.cf-vb-viewport');
        this._svgLayer  = this._canvas.querySelector('.cf-vb-svg-layer');
        this._nodeLayer = this._canvas.querySelector('.cf-vb-node-layer');
    }

    // ─── 节点 CRUD ────────────────────────────────

    /**
     * 添加新节点
     * @param {string} type  - NODE_TYPES 中的值
     * @param {number} x     - 画布 X 坐标
     * @param {number} y     - 画布 Y 坐标
     * @param {object} [data] - 初始业务数据
     * @returns {VisualNode}
     */
    addNode(type, x, y, data = {}) {
        const id   = `node_${++this._nodeIdCounter}`;
        const meta = NODE_META[type] || NODE_META[NODE_TYPES.COMMAND];

        /** @type {VisualNode} */
        const node = {
            id,
            type,
            x:         this._snapToGrid(x),
            y:         this._snapToGrid(y),
            width:     _getDefaultWidth(type),
            height:    _getDefaultHeight(type),
            data:      { ...this._getDefaultData(type), ...data },
            children:  [],
            parentId:  null,
            collapsed: false,
        };

        this._state.nodes.push(node);
        this._renderNode(node);
        this._notifyChange();

        return node;
    }

    /**
     * 更新节点数据
     * @param {string} id      - 节点 ID
     * @param {object} changes - 要合并的变更（支持深度 data 合并）
     */
    updateNode(id, changes) {
        const node = this._findNode(id);
        if (!node) return;

        if (changes.data) {
            node.data = { ...node.data, ...changes.data };
            delete changes.data;
        }

        Object.assign(node, changes);
        this._reRenderNode(node);
        this._notifyChange();
    }

    /**
     * 删除节点（同时删除相关连线）
     * @param {string} id
     */
    deleteNode(id) {
        const idx = this._state.nodes.findIndex(n => n.id === id);
        if (idx === -1) return;

        // 删除相关连线
        this._state.connections = this._state.connections.filter(
            c => c.fromId !== id && c.toId !== id
        );

        // 从父节点的 children 中移除
        const node = this._state.nodes[idx];
        if (node.parentId) {
            const parent = this._findNode(node.parentId);
            if (parent) {
                parent.children = parent.children.filter(cid => cid !== id);
            }
        }

        this._state.nodes.splice(idx, 1);

        // 移除 DOM
        const el = this._nodeLayer.querySelector(`[data-id="${id}"]`);
        el?.remove();

        this._renderConnections();
        this._notifyChange();
    }

    /**
     * 移动节点
     * @param {string} id
     * @param {number} x
     * @param {number} y
     */
    moveNode(id, x, y) {
        const node = this._findNode(id);
        if (!node) return;
        node.x = this._snapToGrid(x);
        node.y = this._snapToGrid(y);
        this._updateNodePosition(node);
        this._renderConnections();
    }

    /**
     * 获取节点
     * @param {string} id
     * @returns {VisualNode|null}
     */
    getNode(id) {
        return this._findNode(id) ?? null;
    }

    // ─── 连线管理 ─────────────────────────────────

    /**
     * 连接两个节点
     * @param {string} fromId   - 源节点 ID
     * @param {string} fromPort - 源端口名（'next'|'true'|'false'|'body'|'exit'）
     * @param {string} toId     - 目标节点 ID
     * @returns {Connection|null}
     */
    connect(fromId, fromPort, toId) {
        const from = this._findNode(fromId);
        const to   = this._findNode(toId);
        if (!from || !to) return null;

        // 避免重复连线
        const exists = this._state.connections.some(
            c => c.fromId === fromId && c.fromPort === fromPort && c.toId === toId
        );
        if (exists) return null;

        const conn = { fromId, fromPort, toId };
        this._state.connections.push(conn);

        // 更新节点 children
        if (!from.children.includes(toId)) {
            from.children.push(toId);
        }

        this._renderConnections();
        this._notifyChange();
        return conn;
    }

    /**
     * 断开连线
     * @param {string} fromId
     * @param {string} fromPort
     * @param {string} toId
     */
    disconnect(fromId, fromPort, toId) {
        const before = this._state.connections.length;
        this._state.connections = this._state.connections.filter(
            c => !(c.fromId === fromId && c.fromPort === fromPort && c.toId === toId)
        );
        if (this._state.connections.length < before) {
            const from = this._findNode(fromId);
            if (from) from.children = from.children.filter(cid => cid !== toId);
            this._renderConnections();
            this._notifyChange();
        }
    }

    // ─── 选择管理 ─────────────────────────────────

    /**
     * 选中节点
     * @param {string}  id      - 节点 ID
     * @param {boolean} [multi] - 是否多选（默认单选）
     */
    selectNode(id, multi = false) {
        if (!multi) {
            // 取消旧选中
            this._state.selected.forEach(selId => {
                const el = this._nodeLayer.querySelector(`[data-id="${selId}"]`);
                el?.classList.remove('cf-vb-node-selected');
            });
            this._state.selected = [];
        }

        if (!this._state.selected.includes(id)) {
            this._state.selected.push(id);
            const el = this._nodeLayer.querySelector(`[data-id="${id}"]`);
            el?.classList.add('cf-vb-node-selected');
        }
    }

    /**
     * 清除所有选中
     */
    clearSelection() {
        this._state.selected.forEach(id => {
            const el = this._nodeLayer.querySelector(`[data-id="${id}"]`);
            el?.classList.remove('cf-vb-node-selected');
        });
        this._state.selected = [];
    }

    // ─── 视图控制 ─────────────────────────────────

    /**
     * 设置画布缩放比例
     * @param {number} zoom - 0.25 ~ 2.0
     */
    setZoom(zoom) {
        this._state.zoom = Math.max(0.25, Math.min(2.0, zoom));
        this._applyTransform();
    }

    /**
     * 重置视图（缩放=1，平移=0）
     */
    resetView() {
        this._state.zoom = 1.0;
        this._state.pan  = { x: 0, y: 0 };
        this._applyTransform();
    }

    /**
     * 自动布局（纵向排列所有节点）
     */
    autoLayout() {
        const sorted = this._topologicalSort();
        let y = 60;
        const colWidth = 280;

        sorted.forEach((node, idx) => {
            node.x = 60 + (idx % 3) * colWidth;
            node.y = y;
            y += node.height + 40;
            if ((idx + 1) % 3 === 0) y += 20;
            this._updateNodePosition(node);
        });

        this._renderConnections();
    }

    // ─── 编译器 ───────────────────────────────────

    /**
     * 将可视化节点树编译为 STscript 字符串
     * @returns {string}
     */
    compile() {
        const startNode = this._state.nodes.find(n => n.type === NODE_TYPES.START);
        if (!startNode) return '// ⚠️ 没有找到开始节点';

        const lines  = [];
        const visited = new Set();

        this._compileNode(startNode, lines, visited, 0);

        return lines.join('\n');
    }

    /**
     * 递归编译单个节点
     * @param {VisualNode} node
     * @param {string[]}   lines   - 输出行数组
     * @param {Set<string>} visited - 已访问节点 ID
     * @param {number}     depth   - 缩进深度
     */
    _compileNode(node, lines, visited, depth) {
        if (!node || visited.has(node.id)) return;
        visited.add(node.id);

        const indent = '    '.repeat(depth);

        switch (node.type) {

            case NODE_TYPES.START:
                lines.push(`${indent}// ── 脚本开始 ── 由 VisualBuilder 编译生成 ──`);
                break;

            case NODE_TYPES.END:
                lines.push(`${indent}// ── 脚本结束 ──`);
                return;

            case NODE_TYPES.VAR_SET: {
                const { key, value } = node.data;
                lines.push(`${indent}/setvar key=${key || 'myVar'} value=${_quoteValue(value || '')} |`);
                break;
            }

            case NODE_TYPES.VAR_GET: {
                const { key } = node.data;
                lines.push(`${indent}/getvar ${key || 'myVar'} |`);
                break;
            }

            case NODE_TYPES.ECHO: {
                const { text } = node.data;
                lines.push(`${indent}/echo ${_quoteValue(text || '')} |`);
                break;
            }

            case NODE_TYPES.INPUT: {
                const { prompt } = node.data;
                lines.push(`${indent}/input ${_quoteValue(prompt || '请输入：')} |`);
                break;
            }

            case NODE_TYPES.IF: {
                const { left, right, op } = node.data;
                lines.push(`${indent}/if left=${_quoteValue(left || '')} right=${_quoteValue(right || '')} ${op || 'eq'}`);

                // 编译 true 分支
                const trueConn = this._state.connections.find(
                    c => c.fromId === node.id && c.fromPort === 'true'
                );
                if (trueConn) {
                    const trueNode = this._findNode(trueConn.toId);
                    if (trueNode) this._compileNode(trueNode, lines, visited, depth + 1);
                }

                // else 分支
                const falseConn = this._state.connections.find(
                    c => c.fromId === node.id && c.fromPort === 'false'
                );
                if (falseConn) {
                    lines.push(`${indent}/else`);
                    const falseNode = this._findNode(falseConn.toId);
                    if (falseNode) this._compileNode(falseNode, lines, visited, depth + 1);
                }
                // next 节点由 if 链外部处理，跳过 children 的 next 连接
                return;
            }

            case NODE_TYPES.WHILE: {
                const { left, right, op } = node.data;
                lines.push(`${indent}/while left=${_quoteValue(left || '')} right=${_quoteValue(right || '')} ${op || 'lt'}`);

                const bodyConn = this._state.connections.find(
                    c => c.fromId === node.id && c.fromPort === 'body'
                );
                if (bodyConn) {
                    const bodyNode = this._findNode(bodyConn.toId);
                    if (bodyNode) this._compileNode(bodyNode, lines, visited, depth + 1);
                }
                break;
            }

            case NODE_TYPES.TIMES: {
                const { count } = node.data;
                lines.push(`${indent}/times ${count || 3}`);

                const bodyConn = this._state.connections.find(
                    c => c.fromId === node.id && c.fromPort === 'body'
                );
                if (bodyConn) {
                    const bodyNode = this._findNode(bodyConn.toId);
                    if (bodyNode) this._compileNode(bodyNode, lines, visited, depth + 1);
                }
                break;
            }

            case NODE_TYPES.COMMAND: {
                const { command, args } = node.data;
                const argsStr = args ? ` ${args}` : '';
                lines.push(`${indent}${command || '/pass'}${argsStr} |`);
                break;
            }

            case NODE_TYPES.NOTE:
                lines.push(`${indent}// ${node.data.text || ''}`);
                break;

            case NODE_TYPES.PIPE:
                lines.push(`${indent}// [管道节点]`);
                break;

            case NODE_TYPES.GROUP:
                // 编译组内子节点
                lines.push(`${indent}// ── 节点组：${node.data.label || ''} ──`);
                break;

            default:
                lines.push(`${indent}// [未知节点类型：${node.type}]`);
        }

        // 编译 next 连接
        const nextConn = this._state.connections.find(
            c => c.fromId === node.id && c.fromPort === 'next'
        );
        if (nextConn) {
            const nextNode = this._findNode(nextConn.toId);
            if (nextNode) this._compileNode(nextNode, lines, visited, depth);
        }
    }

    // ─── 序列化 / 反序列化 ───────────────────────

    /**
     * 将构建器状态序列化为 JSON
     * @returns {object}
     */
    toJSON() {
        return {
            version:     '1.0',
            nodes:       this._state.nodes,
            connections: this._state.connections,
            zoom:        this._state.zoom,
            pan:         this._state.pan,
        };
    }

    /**
     * 从 JSON 恢复构建器状态
     * @param {object} json
     */
    fromJSON(json) {
        if (!json?.nodes) return;
        this._state.nodes       = json.nodes       || [];
        this._state.connections = json.connections || [];
        this._state.zoom        = json.zoom        ?? 1.0;
        this._state.pan         = json.pan         ?? { x: 0, y: 0 };
        this._nodeIdCounter     = Math.max(0, ...this._state.nodes.map(n =>
            parseInt(n.id.replace('node_', '')) || 0
        ));
        this._renderAll();
    }

    /**
     * 清空画布
     */
    clear() {
        this._state = {
            nodes: [], connections: [], selected: [],
            zoom: 1.0, pan: { x: 0, y: 0 },
        };
        this._nodeIdCounter = 0;
        this._nodeLayer.innerHTML = '';
        this._svgLayer.innerHTML  = `<defs>
            <marker id="cf-vb-arrow" markerWidth="8" markerHeight="6"
                    refX="8" refY="3" orient="auto">
                <polygon points="0 0, 8 3, 0 6" fill="#7b68ee"/>
            </marker>
        </defs>`;
        this.addNode(NODE_TYPES.START, 60, 60);
    }

    /**
     * 销毁构建器
     */
    destroy() {
        this._canvas.innerHTML = '';
        this._canvas.classList.remove('cf-vb-canvas');
    }

    // ─── 渲染（私有）────────────────────────────

    /**
     * 全量渲染：所有节点 + 所有连线
     */
    _renderAll() {
        this._nodeLayer.innerHTML = '';
        this._state.nodes.forEach(node => this._renderNode(node));
        this._renderConnections();
        this._applyTransform();
    }

    /**
     * 渲染单个节点为 DOM 元素
     * @param {VisualNode} node
     */
    _renderNode(node) {
        const meta    = NODE_META[node.type] || NODE_META[NODE_TYPES.COMMAND];
        const el      = document.createElement('div');
        el.className  = 'cf-vb-node';
        el.dataset.id = node.id;
        el.style.cssText = `
            left: ${node.x}px;
            top:  ${node.y}px;
            width: ${node.width}px;
            border-left: 3px solid ${meta.color};
        `;

        el.innerHTML = `
            <div class="cf-vb-node-header" style="background: ${meta.color}22;">
                <span class="cf-vb-node-icon">${meta.icon}</span>
                <span class="cf-vb-node-label">${meta.label}</span>
                <span class="cf-vb-node-id">${node.id}</span>
                ${!this._options.readonly ? `<button class="cf-vb-node-delete" title="删除节点">✖</button>` : ''}
            </div>
            <div class="cf-vb-node-body">
                ${this._buildNodeBodyHTML(node)}
            </div>
            <div class="cf-vb-node-ports">
                <div class="cf-vb-port-in" data-node="${node.id}" data-port="in" title="输入端口"></div>
                ${meta.outputs.map(port =>
                    `<div class="cf-vb-port-out" data-node="${node.id}" data-port="${port}" title="→ ${port}">
                        <span class="cf-vb-port-label">${port}</span>
                    </div>`
                ).join('')}
            </div>
        `;

        // 绑定节点事件
        this._bindNodeEvents(el, node);
        this._nodeLayer.appendChild(el);
    }

    /**
     * 根据节点类型生成节点内容 HTML
     * @param {VisualNode} node
     * @returns {string}
     */
    _buildNodeBodyHTML(node) {
        const d = node.data;
        const ro = this._options.readonly;

        switch (node.type) {
            case NODE_TYPES.START:
            case NODE_TYPES.END:
                return `<span class="cf-vb-node-hint">（${NODE_META[node.type].label}）</span>`;

            case NODE_TYPES.VAR_SET:
                return ro
                    ? `<code>/setvar key=${d.key||''} value=${d.value||''}</code>`
                    : `<div class="cf-vb-field-row">
                           <input class="cf-vb-field" data-field="key"   placeholder="变量名" value="${d.key   || ''}">
                           <input class="cf-vb-field" data-field="value" placeholder="值"    value="${d.value || ''}">
                       </div>`;

            case NODE_TYPES.VAR_GET:
                return ro
                    ? `<code>/getvar ${d.key||''}</code>`
                    : `<input class="cf-vb-field" data-field="key" placeholder="变量名" value="${d.key || ''}">`;

            case NODE_TYPES.ECHO:
                return ro
                    ? `<code>/echo ${d.text||''}</code>`
                    : `<input class="cf-vb-field" data-field="text" placeholder="输出文本" value="${d.text || ''}">`;

            case NODE_TYPES.INPUT:
                return ro
                    ? `<code>/input "${d.prompt||''}"</code>`
                    : `<input class="cf-vb-field" data-field="prompt" placeholder="提示文本" value="${d.prompt || ''}">`;

            case NODE_TYPES.IF:
            case NODE_TYPES.WHILE:
                return ro
                    ? `<code>${d.left||''} ${d.op||'eq'} ${d.right||''}</code>`
                    : `<div class="cf-vb-field-row">
                           <input class="cf-vb-field cf-vb-field-sm" data-field="left"  placeholder="left"  value="${d.left  || ''}">
                           <select class="cf-vb-select" data-field="op">
                               ${['eq','neq','gt','gte','lt','lte','contains'].map(op =>
                                   `<option value="${op}" ${d.op===op?'selected':''}>${op}</option>`
                               ).join('')}
                           </select>
                           <input class="cf-vb-field cf-vb-field-sm" data-field="right" placeholder="right" value="${d.right || ''}">
                       </div>`;

            case NODE_TYPES.TIMES:
                return ro
                    ? `<code>/times ${d.count||3}</code>`
                    : `<input class="cf-vb-field cf-vb-field-sm" data-field="count"
                              type="number" min="1" max="100" placeholder="次数" value="${d.count || 3}">`;

            case NODE_TYPES.COMMAND:
                return ro
                    ? `<code>${d.command||''} ${d.args||''}</code>`
                    : `<div class="cf-vb-field-row">
                           <input class="cf-vb-field cf-vb-field-cmd" data-field="command"
                                  placeholder="/命令" list="cf-vb-cmds" value="${d.command || ''}">
                           <datalist id="cf-vb-cmds">
                               ${ALL_COMMANDS.map(cmd => `<option value="${cmd}">`).join('')}
                           </datalist>
                           <input class="cf-vb-field" data-field="args" placeholder="参数" value="${d.args || ''}">
                       </div>`;

            case NODE_TYPES.NOTE:
                return ro
                    ? `<span class="cf-vb-note-text">${d.text||''}</span>`
                    : `<textarea class="cf-vb-textarea" data-field="text" placeholder="备注内容" rows="2">${d.text || ''}</textarea>`;

            default:
                return `<span class="cf-vb-node-hint">${node.type}</span>`;
        }
    }

    /**
     * 重新渲染单个节点（原地更新）
     * @param {VisualNode} node
     */
    _reRenderNode(node) {
        const el = this._nodeLayer.querySelector(`[data-id="${node.id}"]`);
        if (el) {
            el.remove();
        }
        this._renderNode(node);
    }

    /**
     * 更新节点 DOM 位置（不重建 DOM）
     * @param {VisualNode} node
     */
    _updateNodePosition(node) {
        const el = this._nodeLayer.querySelector(`[data-id="${node.id}"]`);
        if (!el) return;
        el.style.left = `${node.x}px`;
        el.style.top  = `${node.y}px`;
    }

    /**
     * 渲染所有连线（SVG path）
     */
    _renderConnections() {
        // 清除旧连线（保留 defs）
        const paths = this._svgLayer.querySelectorAll('path, line');
        paths.forEach(p => p.remove());

        this._state.connections.forEach(conn => {
            const fromNode = this._findNode(conn.fromId);
            const toNode   = this._findNode(conn.toId);
            if (!fromNode || !toNode) return;

            const { x: x1, y: y1 } = _getPortPosition(fromNode, conn.fromPort, 'out');
            const { x: x2, y: y2 } = _getPortPosition(toNode,   'in',           'in');

            const dx  = Math.abs(x2 - x1) * 0.5;
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');

            path.setAttribute('d', `M ${x1} ${y1} C ${x1+dx} ${y1}, ${x2-dx} ${y2}, ${x2} ${y2}`);
            path.setAttribute('stroke',       conn.fromPort === 'false' ? '#e74c3c' : '#7b68ee');
            path.setAttribute('stroke-width', '2');
            path.setAttribute('fill',         'none');
            path.setAttribute('marker-end',   'url(#cf-vb-arrow)');
            path.dataset.from = conn.fromId;
            path.dataset.to   = conn.toId;

            this._svgLayer.appendChild(path);
        });
    }

    /**
     * 应用缩放和平移变换
     */
    _applyTransform() {
        const { zoom, pan } = this._state;
        this._viewport.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
    }

    // ─── 事件绑定（私有）────────────────────────

    /**
     * 绑定画布全局事件（拖拽、缩放、空白区域点击）
     */
    _bindCanvasEvents() {
        // 画布点击（取消选中）
        this._canvas.addEventListener('click', (e) => {
            if (e.target === this._canvas || e.target === this._viewport) {
                this.clearSelection();
            }
        });

        // 鼠标滚轮缩放
        this._canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const delta = e.deltaY > 0 ? -0.1 : 0.1;
            this.setZoom(this._state.zoom + delta);
        }, { passive: false });

        // 画布拖拽（中键或空格+左键）
        let panStart = null;
        this._canvas.addEventListener('mousedown', (e) => {
            if (e.button === 1 || (e.button === 0 && e.altKey)) {
                panStart = { x: e.clientX - this._state.pan.x, y: e.clientY - this._state.pan.y };
            }
        });
        document.addEventListener('mousemove', (e) => {
            if (!panStart) return;
            this._state.pan = { x: e.clientX - panStart.x, y: e.clientY - panStart.y };
            this._applyTransform();
        });
        document.addEventListener('mouseup', () => { panStart = null; });
    }

    /**
     * 绑定单个节点 DOM 的事件（拖拽、字段编辑、删除）
     * @param {HTMLElement} el
     * @param {VisualNode}  node
     */
    _bindNodeEvents(el, node) {
        const header = el.querySelector('.cf-vb-node-header');

        // 节点拖拽
        if (!this._options.readonly) {
            header.addEventListener('mousedown', (e) => {
                if (e.target.classList.contains('cf-vb-node-delete')) return;
                e.preventDefault();
                this._isDragging = true;
                this._dragTarget = node;
                const rect = el.getBoundingClientRect();
                this._dragOffset = {
                    x: (e.clientX - rect.left) / this._state.zoom,
                    y: (e.clientY - rect.top)  / this._state.zoom,
                };
            });
        }

        document.addEventListener('mousemove', (e) => {
            if (!this._isDragging || this._dragTarget?.id !== node.id) return;
            const canvasRect = this._canvas.getBoundingClientRect();
            const newX = (e.clientX - canvasRect.left) / this._state.zoom
                         - this._state.pan.x / this._state.zoom
                         - this._dragOffset.x;
            const newY = (e.clientY - canvasRect.top)  / this._state.zoom
                         - this._state.pan.y / this._state.zoom
                         - this._dragOffset.y;
            this.moveNode(node.id, newX, newY);
        });

        document.addEventListener('mouseup', () => {
            if (this._dragTarget?.id === node.id) {
                this._isDragging = false;
                this._dragTarget = null;
                this._notifyChange();
            }
        });

        // 选中节点
        el.addEventListener('click', (e) => {
            if (e.target.classList.contains('cf-vb-node-delete')) return;
            this.selectNode(node.id, e.ctrlKey || e.metaKey);
        });

        // 删除按钮
        const delBtn = el.querySelector('.cf-vb-node-delete');
        delBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.deleteNode(node.id);
        });

        // 字段编辑
        el.querySelectorAll('.cf-vb-field, .cf-vb-select, .cf-vb-textarea').forEach(input => {
            input.addEventListener('change', (e) => {
                const field = e.target.dataset.field;
                if (!field) return;
                this.updateNode(node.id, { data: { [field]: e.target.value } });
            });
        });

        // 端口拖拽连线（输出端口）
        el.querySelectorAll('.cf-vb-port-out').forEach(port => {
            port.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                this._connectingFrom = {
                    nodeId: port.dataset.node,
                    port:   port.dataset.port,
                };
            });
        });

        // 输入端口：接受连线
        const inPort = el.querySelector('.cf-vb-port-in');
        inPort?.addEventListener('mouseup', () => {
            if (this._connectingFrom) {
                const { nodeId, port } = this._connectingFrom;
                if (nodeId !== node.id) {
                    this.connect(nodeId, port, node.id);
                }
                this._connectingFrom = null;
            }
        });
    }

    // ─── 工具方法（私有）────────────────────────

    _findNode(id) {
        return this._state.nodes.find(n => n.id === id);
    }

    _snapToGrid(val) {
        const g = this._options.gridSize;
        return Math.round(val / g) * g;
    }

    _notifyChange() {
        if (this._options.onChange) {
            this._options.onChange(this._state, this.compile());
        }
    }

    /**
     * 获取节点类型的默认业务数据
     * @param {string} type
     * @returns {object}
     */
    _getDefaultData(type) {
        const defaults = {
            [NODE_TYPES.VAR_SET]:  { key: '',      value: '' },
            [NODE_TYPES.VAR_GET]:  { key: '' },
            [NODE_TYPES.ECHO]:     { text: '' },
            [NODE_TYPES.INPUT]:    { prompt: '请输入：' },
            [NODE_TYPES.IF]:       { left: '', right: '', op: 'eq' },
            [NODE_TYPES.WHILE]:    { left: '', right: '0', op: 'gt' },
            [NODE_TYPES.TIMES]:    { count: 3 },
            [NODE_TYPES.COMMAND]:  { command: '/pass', args: '' },
            [NODE_TYPES.NOTE]:     { text: '' },
            [NODE_TYPES.GROUP]:    { label: '节点组', collapsed: false },
        };
        return defaults[type] || {};
    }

    /**
     * 拓扑排序（用于自动布局）
     * @returns {VisualNode[]}
     */
    _topologicalSort() {
        const visited = new Set();
        const result  = [];

        const visit = (node) => {
            if (!node || visited.has(node.id)) return;
            visited.add(node.id);
            const nexts = this._state.connections
                .filter(c => c.fromId === node.id)
                .map(c => this._findNode(c.toId))
                .filter(Boolean);
            nexts.forEach(visit);
            result.unshift(node);
        };

        const start = this._state.nodes.find(n => n.type === NODE_TYPES.START);
        if (start) visit(start);

        // 未连接的孤立节点
        this._state.nodes.forEach(n => {
            if (!visited.has(n.id)) result.push(n);
        });

        return result;
    }

    /**
     * 获取当前完整状态
     * @returns {BuilderState}
     */
    getState() {
        return { ...this._state };
    }
}

// ═══════════════════════════════════════════════
// § 4  工具函数（私有）
// ═══════════════════════════════════════════════

function _getDefaultWidth(type) {
    const wide = [NODE_TYPES.IF, NODE_TYPES.WHILE, NODE_TYPES.COMMAND];
    return wide.includes(type) ? 280 : 200;
}

function _getDefaultHeight(type) {
    return type === NODE_TYPES.NOTE ? 100 : 80;
}

/**
 * 计算节点端口的画布坐标（用于绘制连线）
 * @param {VisualNode} node
 * @param {string}     port  - 端口名
 * @param {'in'|'out'} dir   - 方向
 * @returns {{ x: number, y: number }}
 */
function _getPortPosition(node, port, dir) {
    const meta    = NODE_META[node.type] || NODE_META[NODE_TYPES.COMMAND];
    const outputs = meta.outputs;

    if (dir === 'in') {
        return { x: node.x, y: node.y + node.height / 2 };
    }

    const portIdx = outputs.indexOf(port);
    const total   = outputs.length;
    const offsetY = total > 1
        ? node.height * ((portIdx + 1) / (total + 1))
        : node.height / 2;

    return { x: node.x + node.width, y: node.y + offsetY };
}

/**
 * 对字符串值添加引号（如果包含空格则加引号）
 * @param {string} val
 * @returns {string}
 */
function _quoteValue(val) {
    if (!val) return '""';
    if (/\s/.test(val)) return `"${val}"`;
    return val;
}

export default VisualBuilder;