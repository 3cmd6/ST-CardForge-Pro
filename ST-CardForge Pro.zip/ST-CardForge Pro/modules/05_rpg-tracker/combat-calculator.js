/**
 * @file modules/05_rpg-tracker/combat-calculator.js
 * @description RPG 战斗计算器
 *              提供：伤害/治疗/防御公式引擎、骰子解析器、属性修正链、
 *              暴击/闪避/命中计算、状态效果结算、战斗回合管理、
 *              以及将战斗逻辑编译为 STscript 的导出功能。
 * @version 1.0.0
 */

import { STAT_TYPES, clampStatValue } from './stat-definitions.js';

// ═══════════════════════════════════════════════
// § 1  枚举与常量
// ═══════════════════════════════════════════════

/**
 * 战斗动作类型
 * @enum {string}
 */
export const ACTION_TYPES = {
    ATTACK:     'attack',       // 普通攻击
    SKILL:      'skill',        // 技能（魔法/特技）
    HEAL:       'heal',         // 治疗
    DEFEND:     'defend',       // 防御
    FLEE:       'flee',         // 逃跑
    ITEM:       'item',         // 使用道具
};

/**
 * 伤害类型
 * @enum {string}
 */
export const DAMAGE_TYPES = {
    PHYSICAL:   'physical',     // 物理伤害（受防御减免）
    MAGICAL:    'magical',      // 魔法伤害（受魔防减免）
    PURE:       'pure',         // 真实伤害（无视防御）
    HEAL:       'heal',         // 治疗（负伤害）
};

/**
 * 战斗结果类型
 * @enum {string}
 */
export const RESULT_TYPES = {
    HIT:        'hit',          // 命中
    MISS:       'miss',         // 未命中
    CRITICAL:   'critical',     // 暴击
    DODGE:      'dodge',        // 闪避
    BLOCK:      'block',        // 格挡
};

/**
 * 内置公式名称
 * @enum {string}
 */
export const FORMULA_NAMES = {
    BASIC_DAMAGE:   'basic_damage',     // 基础伤害：ATK - DEF
    DND_DAMAGE:     'dnd_damage',       // D&D 风格：骰子 + 修正值
    PERCENT_DAMAGE: 'percent_damage',   // 百分比伤害：目标 HP 的 N%
    FIXED_DAMAGE:   'fixed_damage',     // 固定伤害：固定数值
    HEAL_FORMULA:   'heal_formula',     // 治疗公式：INT * 系数 + 骰子
    COC_SKILL:      'coc_skill',        // CoC 技能检定：d100 vs 技能值
};

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} CombatContext
 * @property {object}  attacker       - 攻击方属性快照（key→value）
 * @property {object}  defender       - 防御方属性快照（key→value）
 * @property {string}  [skillId]      - 使用的技能 ID
 * @property {object}  [skillData]    - 技能数据
 * @property {object}  [itemData]     - 道具数据
 * @property {number}  [turnIndex]    - 当前回合数
 * @property {object}  [environment]  - 环境变量（地形、天气等）
 */

/**
 * @typedef {Object} CombatResult
 * @property {RESULT_TYPES} resultType    - 命中/暴击/闪避等
 * @property {DAMAGE_TYPES} damageType    - 伤害类型
 * @property {number}  rawDamage          - 计算前的原始伤害
 * @property {number}  finalDamage        - 扣除防御后的最终伤害
 * @property {number}  hpAfter            - 目标 HP 变化后的值
 * @property {boolean} isCritical         - 是否暴击
 * @property {boolean} isMiss             - 是否未命中
 * @property {number}  [healAmount]       - 治疗量（heal 动作）
 * @property {object}  [statusEffects]    - 附加的状态效果
 * @property {string}  log               - 战斗文字描述
 * @property {string[]} stscript          - 对应的 STscript 语句数组
 */

/**
 * @typedef {Object} SkillDef
 * @property {string} id           - 技能 ID
 * @property {string} name         - 技能名称
 * @property {string} damageType   - DAMAGE_TYPES
 * @property {string} formula      - 使用的公式名称
 * @property {object} params       - 公式参数
 * @property {number} [mpCost]     - MP 消耗
 * @property {number} [cooldown]   - 冷却回合
 * @property {object} [statusEffect] - 附加状态效果定义
 */

// ═══════════════════════════════════════════════
// § 3  骰子解析器
// ═══════════════════════════════════════════════

/**
 * 解析骰子表达式并返回投掷结果
 * 支持格式：NdM、NdM+K、NdM-K、NdM*K、d20、4d6kh3（保留最高3个）
 *
 * @param {string} notation  - 骰子表达式（如 '2d6+3'、'4d6kh3'）
 * @returns {{
 *   total:   number,
 *   rolls:   number[],
 *   kept:    number[],
 *   notation: string,
 *   breakdown: string
 * }}
 */
export function rollDice(notation) {
    if (!notation || typeof notation !== 'string') {
        return { total: 0, rolls: [], kept: [], notation, breakdown: '0' };
    }

    const n = notation.trim().toLowerCase();

    // ── 纯数字（固定值）──
    if (/^-?\d+$/.test(n)) {
        const val = parseInt(n);
        return { total: val, rolls: [val], kept: [val], notation, breakdown: String(val) };
    }

    // ── 标准骰子解析 ──
    // 支持：[N]dM[+/-/*/K modifier]
    // kh = keep highest, kl = keep lowest
    const diceRegex = /^(\d*)d(\d+)(kh\d+|kl\d+)?([+\-*/]\d+)?$/;
    const match     = n.match(diceRegex);

    if (!match) {
        // 尝试解析纯数字作为固定值
        const fixed = parseFloat(n);
        return {
            total:     isNaN(fixed) ? 0 : fixed,
            rolls:     [],
            kept:      [],
            notation,
            breakdown: isNaN(fixed) ? `[无效:${notation}]` : String(fixed),
        };
    }

    const count     = parseInt(match[1] || '1');
    const sides     = parseInt(match[2]);
    const keepMod   = match[3] || '';
    const addMod    = match[4] || '';

    // 投掷骰子
    const rolls = Array.from({ length: Math.min(count, 100) }, () =>
        Math.floor(Math.random() * sides) + 1
    );

    let kept = [...rolls];

    // 保留最高/最低 N 个
    if (keepMod) {
        const keepCount = parseInt(keepMod.slice(2));
        if (keepMod.startsWith('kh')) {
            kept = [...rolls].sort((a, b) => b - a).slice(0, keepCount);
        } else if (keepMod.startsWith('kl')) {
            kept = [...rolls].sort((a, b) => a - b).slice(0, keepCount);
        }
    }

    let total = kept.reduce((sum, v) => sum + v, 0);

    // 加减乘除修正
    if (addMod) {
        const op  = addMod[0];
        const val = parseFloat(addMod.slice(1));
        switch (op) {
            case '+': total += val; break;
            case '-': total -= val; break;
            case '*': total  = Math.round(total * val); break;
            case '/': total  = Math.round(total / val); break;
        }
    }

    const breakdown = `[${kept.join('+')}]${addMod || ''} = ${total}`;

    return { total, rolls, kept, notation, breakdown };
}

/**
 * 解析包含多个骰子表达式的复合表达式
 * 例：'2d6 + 1d4 + 3' → 分别计算后求和
 *
 * @param {string} expr
 * @returns {{ total: number, breakdown: string }}
 */
export function rollExpression(expr) {
    if (!expr) return { total: 0, breakdown: '0' };

    // 分割为 token（数字、骰子表达式、运算符）
    const tokens = expr.replace(/\s+/g, '').match(/[+\-]?[\d]*d[\d]+(kh\d+|kl\d+)?([+\-*/]\d+)?|[+\-]?\d+/gi) || [];

    let total     = 0;
    const parts   = [];

    tokens.forEach(token => {
        const sign    = token.startsWith('-') ? -1 : 1;
        const cleaned = token.replace(/^[+\-]/, '');
        const result  = rollDice(cleaned);
        total += sign * result.total;
        parts.push(`${sign < 0 ? '-' : ''}${result.breakdown}`);
    });

    return { total, breakdown: parts.join(' + ') + ` = ${total}` };
}

// ═══════════════════════════════════════════════
// § 4  公式引擎
// ═══════════════════════════════════════════════

/**
 * CombatCalculator 主类
 */
export class CombatCalculator {
    /**
     * @param {object} [options]
     * @param {number} [options.critMultiplier=2.0]    - 暴击伤害倍率
     * @param {number} [options.critChanceBase=0.05]   - 基础暴击概率（0~1）
     * @param {number} [options.missChanceBase=0.05]   - 基础未命中概率
     * @param {number} [options.minDamage=1]           - 最低伤害值（不计治疗）
     * @param {boolean}[options.allowNegativeHeal=false] - 是否允许治疗超出上限
     */
    constructor(options = {}) {
        this._options = {
            critMultiplier:    2.0,
            critChanceBase:    0.05,
            missChanceBase:    0.05,
            minDamage:         1,
            allowNegativeHeal: false,
            ...options,
        };

        /**
         * 自定义公式注册表
         * @type {Map<string, Function>}
         */
        this._formulas = new Map();

        // 注册内置公式
        this._registerBuiltinFormulas();
    }

    // ─── 核心计算 API ─────────────────────────────

    /**
     * 计算攻击/技能伤害
     *
     * @param {CombatContext} ctx
     * @param {string} [formulaName]  - 使用的公式（默认 basic_damage）
     * @param {object} [params]       - 公式额外参数
     * @returns {CombatResult}
     */
    calculateDamage(ctx, formulaName = FORMULA_NAMES.BASIC_DAMAGE, params = {}) {
        const formula = this._formulas.get(formulaName);
        if (!formula) {
            throw new Error(`[CombatCalculator] 未知公式：${formulaName}`);
        }

        // 计算命中/闪避/暴击
        const hitResult  = this._resolveHit(ctx);
        if (hitResult === RESULT_TYPES.MISS || hitResult === RESULT_TYPES.DODGE) {
            return this._buildMissResult(ctx, hitResult);
        }
        const isCritical = hitResult === RESULT_TYPES.CRITICAL;

        // 计算原始伤害
        let rawDamage = formula(ctx, params);
        if (isCritical) rawDamage = Math.round(rawDamage * this._options.critMultiplier);

        // 计算防御减免
        const finalDamage = this._applyDefense(rawDamage, ctx, params.damageType || DAMAGE_TYPES.PHYSICAL);

        // 计算目标 HP 变化
        const targetHpKey   = params.hpKey      || 'hp';
        const targetHpMaxKey = params.hpMaxKey  || `${targetHpKey}_max`;
        const currentHp     = parseFloat(ctx.defender[targetHpKey] ?? 100);
        const maxHp         = parseFloat(ctx.defender[targetHpMaxKey] ?? 100);
        const hpAfter       = Math.max(0, Math.min(maxHp, currentHp - finalDamage));

        // 附加状态效果
        const statusEffects = this._resolveStatusEffects(ctx, params, isCritical);

        const log = this._buildDamageLog(ctx, rawDamage, finalDamage, isCritical, statusEffects);

        return {
            resultType:    isCritical ? RESULT_TYPES.CRITICAL : RESULT_TYPES.HIT,
            damageType:    params.damageType || DAMAGE_TYPES.PHYSICAL,
            rawDamage,
            finalDamage,
            hpAfter,
            isCritical,
            isMiss:        false,
            statusEffects,
            log,
            stscript:      this._buildDamageScript(targetHpKey, hpAfter, finalDamage, log),
        };
    }

    /**
     * 计算治疗量
     *
     * @param {CombatContext} ctx
     * @param {string} [formulaName]
     * @param {object} [params]
     * @returns {CombatResult}
     */
    calculateHeal(ctx, formulaName = FORMULA_NAMES.HEAL_FORMULA, params = {}) {
        const formula = this._formulas.get(formulaName);
        if (!formula) throw new Error(`[CombatCalculator] 未知公式：${formulaName}`);

        const rawHeal   = Math.max(0, formula(ctx, params));
        const targetHpKey    = params.hpKey    || 'hp';
        const targetHpMaxKey = params.hpMaxKey || `${targetHpKey}_max`;
        const currentHp = parseFloat(ctx.defender?.[targetHpKey] ?? ctx.attacker[targetHpKey] ?? 100);
        const maxHp     = parseFloat(ctx.defender?.[targetHpMaxKey] ?? ctx.attacker[targetHpMaxKey] ?? 100);
        const hpAfter   = this._options.allowNegativeHeal
            ? currentHp + rawHeal
            : Math.min(maxHp, currentHp + rawHeal);

        const actualHeal = hpAfter - currentHp;
        const log        = `💚 治疗 ${actualHeal} 点 HP（${currentHp} → ${hpAfter}）`;

        return {
            resultType:  RESULT_TYPES.HIT,
            damageType:  DAMAGE_TYPES.HEAL,
            rawDamage:   0,
            finalDamage: 0,
            healAmount:  actualHeal,
            hpAfter,
            isCritical:  false,
            isMiss:      false,
            statusEffects: {},
            log,
            stscript:    this._buildHealScript(targetHpKey, targetHpMaxKey, hpAfter, actualHeal, log),
        };
    }

    /**
     * CoC 技能检定
     *
     * @param {number} skillValue  - 技能值（1~100）
     * @param {number} [modifier]  - 修正值（正值有利，负值不利）
     * @returns {{
     *   roll: number,
     *   skillValue: number,
     *   success: boolean,
     *   successLevel: 'critical'|'hard'|'normal'|'fail'|'fumble',
     *   log: string
     * }}
     */
    cocSkillCheck(skillValue, modifier = 0) {
        const effective = Math.max(1, Math.min(100, skillValue + modifier));
        const roll      = Math.floor(Math.random() * 100) + 1;

        let successLevel;
        if (roll <= Math.floor(effective / 5))  successLevel = 'critical';   // 极难（1/5）
        else if (roll <= Math.floor(effective / 2)) successLevel = 'hard';   // 困难（1/2）
        else if (roll <= effective)             successLevel = 'normal';      // 普通
        else if (roll >= 96)                    successLevel = 'fumble';      // 大失败
        else                                    successLevel = 'fail';

        const labels = {
            critical: '🎯 极难成功',
            hard:     '✅ 困难成功',
            normal:   '✔️ 成功',
            fail:     '❌ 失败',
            fumble:   '💀 大失败',
        };

        const log = `🎲 技能检定：d100 = ${roll} / ${effective} → ${labels[successLevel]}`;

        return {
            roll,
            skillValue: effective,
            success:    successLevel !== 'fail' && successLevel !== 'fumble',
            successLevel,
            log,
        };
    }

    /**
     * 属性修正链（按顺序叠加多个修正值）
     *
     * @param {number}   base      - 基础值
     * @param {Array<{ type: 'flat'|'percent', value: number, label: string }>} modifiers
     * @returns {{ final: number, breakdown: string }}
     */
    applyModifiers(base, modifiers = []) {
        let current = base;
        const parts  = [`基础：${base}`];

        modifiers.forEach(mod => {
            if (mod.type === 'flat') {
                const sign  = mod.value >= 0 ? '+' : '';
                current    += mod.value;
                parts.push(`${mod.label}：${sign}${mod.value}`);
            } else if (mod.type === 'percent') {
                const bonus = Math.round(base * mod.value / 100);
                current    += bonus;
                parts.push(`${mod.label}：${mod.value >= 0 ? '+' : ''}${mod.value}% (${bonus >= 0 ? '+' : ''}${bonus})`);
            }
        });

        parts.push(`最终：${Math.round(current)}`);
        return { final: Math.round(current), breakdown: parts.join(' → ') };
    }

    // ─── 公式注册 ─────────────────────────────────

    /**
     * 注册自定义公式
     * @param {string}   name       - 公式名称（唯一标识）
     * @param {Function} formulaFn  - (ctx: CombatContext, params: object) => number
     */
    registerFormula(name, formulaFn) {
        if (typeof formulaFn !== 'function') {
            throw new Error('[CombatCalculator] formulaFn 必须是函数');
        }
        this._formulas.set(name, formulaFn);
    }

    /**
     * 对给定上下文执行公式，返回计算结果
     * @param {string}         name   - 公式名称
     * @param {CombatContext}  ctx
     * @param {object}         [params]
     * @returns {number}
     */
    evaluateFormula(name, ctx, params = {}) {
        const formula = this._formulas.get(name);
        if (!formula) throw new Error(`[CombatCalculator] 未知公式：${name}`);
        return formula(ctx, params);
    }

    /**
     * 获取所有已注册公式的名称列表
     * @returns {string[]}
     */
    listFormulas() {
        return [...this._formulas.keys()];
    }

    // ─── STscript 生成 ────────────────────────────

    /**
     * 将一套战斗定义编译为完整的 STscript
     *
     * @param {object} combatDef
     * @param {string}   combatDef.attackerHpKey  - 攻击方 HP 变量名
     * @param {string}   combatDef.defenderHpKey  - 防御方 HP 变量名
     * @param {string}   combatDef.attackFormula  - 攻击公式名
     * @param {string}   combatDef.atkKey         - 攻击力变量名
     * @param {string}   combatDef.defKey         - 防御力变量名
     * @param {string}   [combatDef.critChance]   - 暴击率变量名或固定值
     * @param {boolean}  [combatDef.twoWay]       - 是否生成双向对战（玩家攻击+敌人反击）
     * @returns {string}
     */
    generateCombatScript(combatDef) {
        const {
            attackerHpKey = 'player_hp',
            defenderHpKey = 'enemy_hp',
            atkKey        = 'player_str',
            defKey        = 'enemy_def',
            critChance    = '5',
            twoWay        = true,
        } = combatDef;

        const lines = [
            '// ══ 战斗脚本 · 由 CombatCalculator 生成 ══',
            '',
            '// § 1 计算玩家攻击伤害',
            `/setvar key=_raw_dmg value={{math::{{getvar::${atkKey}}} - {{getvar::${defKey}}}}} |`,
            `/if left={{getvar::_raw_dmg}} right=1 lt`,
            `    /setvar key=_raw_dmg value=1 |`,
            '',
            '// § 2 暴击判定',
            `/setvar key=_crit_roll value={{roll::1d100}} |`,
            `/if left={{getvar::_crit_roll}} right=${critChance} lte`,
            `    /setvar key=_raw_dmg value={{math::{{getvar::_raw_dmg}} * 2}} |`,
            `    /echo 💥 **暴击！** 伤害翻倍！ |`,
            '',
            '// § 3 扣除防御方 HP',
            `/setvar key=${defenderHpKey} value={{math::{{getvar::${defenderHpKey}}} - {{getvar::_raw_dmg}}}} |`,
            `/if left={{getvar::${defenderHpKey}}} right=0 lt`,
            `    /setvar key=${defenderHpKey} value=0 |`,
            `/echo ⚔️ 造成 {{getvar::_raw_dmg}} 点伤害！敌方 HP：{{getvar::${defenderHpKey}}} |`,
            '',
            '// § 4 检查敌方是否阵亡',
            `/if left={{getvar::${defenderHpKey}}} right=0 lte`,
            `    /setvar key=combat_result value=player_win |`,
            `    /echo 🏆 **敌人已被击倒！** |`,
        ];

        if (twoWay) {
            lines.push(
                '',
                '// § 5 敌方反击（仅在存活时）',
                `/if left={{getvar::combat_result}} right=player_win neq`,
                `    /setvar key=_enemy_dmg value={{math::{{getvar::enemy_str}} - {{getvar::player_def}}}} |`,
                `    /if left={{getvar::_enemy_dmg}} right=1 lt`,
                `        /setvar key=_enemy_dmg value=1 |`,
                `    /setvar key=${attackerHpKey} value={{math::{{getvar::${attackerHpKey}}} - {{getvar::_enemy_dmg}}}} |`,
                `    /if left={{getvar::${attackerHpKey}}} right=0 lt`,
                `        /setvar key=${attackerHpKey} value=0 |`,
                `    /echo 💢 敌人反击！你受到 {{getvar::_enemy_dmg}} 点伤害！HP：{{getvar::${attackerHpKey}}} |`,
                '',
                `// § 6 检查玩家是否阵亡`,
                `/if left={{getvar::${attackerHpKey}}} right=0 lte`,
                `    /setvar key=combat_result value=enemy_win |`,
                `    /setvar key=game_state value=game_over |`,
                `    /echo 💀 **你已倒下……** |`,
            );
        }

        lines.push(
            '',
            '// § 7 清理临时变量',
            '/flushvar _raw_dmg |',
            '/flushvar _enemy_dmg |',
            '/flushvar _crit_roll |',
            '// ══ 战斗脚本结束 ══',
        );

        return lines.join('\n');
    }

    // ═══════════════════════════════════════════════
    // § 5  私有方法
    // ═══════════════════════════════════════════════

    /**
     * 注册所有内置公式
     */
    _registerBuiltinFormulas() {

        // ── 基础伤害：ATK - DEF，最低 1 ──
        this.registerFormula(FORMULA_NAMES.BASIC_DAMAGE, (ctx, params) => {
            const atkKey = params.atkKey || 'player_str';
            const defKey = params.defKey || 'enemy_def';
            const atk    = parseFloat(ctx.attacker[atkKey] || 0);
            const def    = parseFloat(ctx.defender[defKey] || 0);
            return Math.max(this._options.minDamage, atk - def);
        });

        // ── D&D 风格：骰子 + ATK 修正 ──
        this.registerFormula(FORMULA_NAMES.DND_DAMAGE, (ctx, params) => {
            const dice  = params.dice   || '1d8';
            const atkKey = params.atkKey || 'player_str';
            const mod   = parseFloat(ctx.attacker[atkKey] || 0);
            const bonus  = params.bonus  || 0;
            const { total } = rollDice(dice);
            return Math.max(this._options.minDamage, total + Math.floor(mod / 2) + bonus);
        });

        // ── 百分比伤害：目标当前 HP 的 N% ──
        this.registerFormula(FORMULA_NAMES.PERCENT_DAMAGE, (ctx, params) => {
            const hpKey  = params.hpKey  || 'hp';
            const pct    = params.percent || 10;
            const curHp  = parseFloat(ctx.defender[hpKey] || 100);
            return Math.max(this._options.minDamage, Math.round(curHp * pct / 100));
        });

        // ── 固定伤害 ──
        this.registerFormula(FORMULA_NAMES.FIXED_DAMAGE, (ctx, params) => {
            return Math.max(this._options.minDamage, params.value || 0);
        });

        // ── 治疗公式：INT * 系数 + 骰子 ──
        this.registerFormula(FORMULA_NAMES.HEAL_FORMULA, (ctx, params) => {
            const intKey = params.intKey  || 'player_int';
            const dice   = params.dice    || '1d6';
            const factor = params.factor  || 0.5;
            const intVal = parseFloat(ctx.attacker[intKey] || 0);
            const { total } = rollDice(dice);
            return Math.max(0, Math.round(intVal * factor) + total);
        });

        // ── CoC 技能检定（返回 0 或 1，配合 calculateDamage 使用） ──
        this.registerFormula(FORMULA_NAMES.COC_SKILL, (ctx, params) => {
            const skillKey = params.skillKey || 'skill_value';
            const skill    = parseFloat(ctx.attacker[skillKey] || 50);
            const result   = this.cocSkillCheck(skill, params.modifier || 0);
            return result.success ? (params.successValue || 1) : 0;
        });
    }

    /**
     * 解算命中/闪避/暴击
     * @param {CombatContext} ctx
     * @returns {RESULT_TYPES}
     */
    _resolveHit(ctx) {
        // 未命中判定
        const missChance = parseFloat(ctx.attacker?.miss_chance ?? this._options.missChanceBase * 100) / 100;
        if (Math.random() < missChance) return RESULT_TYPES.MISS;

        // 闪避判定（防御方的闪避率）
        const dodgeChance = parseFloat(ctx.defender?.dodge_chance ?? 0) / 100;
        if (Math.random() < dodgeChance) return RESULT_TYPES.DODGE;

        // 暴击判定
        const critChance = parseFloat(ctx.attacker?.crit_chance ?? this._options.critChanceBase * 100) / 100;
        if (Math.random() < critChance) return RESULT_TYPES.CRITICAL;

        return RESULT_TYPES.HIT;
    }

    /**
     * 根据伤害类型计算防御减免后的最终伤害
     * @param {number}       raw
     * @param {CombatContext} ctx
     * @param {string}       damageType
     * @returns {number}
     */
    _applyDefense(raw, ctx, damageType) {
        switch (damageType) {
            case DAMAGE_TYPES.PURE:
                return Math.max(this._options.minDamage, raw);
            case DAMAGE_TYPES.MAGICAL: {
                const mdef = parseFloat(ctx.defender?.m_def || ctx.defender?.player_int || 0);
                return Math.max(this._options.minDamage, raw - Math.floor(mdef * 0.5));
            }
            case DAMAGE_TYPES.PHYSICAL:
            default: {
                const def = parseFloat(ctx.defender?.def || ctx.defender?.player_def || 0);
                return Math.max(this._options.minDamage, raw - def);
            }
        }
    }

    /**
     * 解算并返回附加状态效果
     * @param {CombatContext} ctx
     * @param {object}        params
     * @param {boolean}       isCritical
     * @returns {object}
     */
    _resolveStatusEffects(ctx, params, isCritical) {
        const effects = {};
        if (!params.statusEffect) return effects;

        const { key, value, chance = 100, critBonus = 0 } = params.statusEffect;
        const effectiveChance = Math.min(100, chance + (isCritical ? critBonus : 0));

        if (Math.random() * 100 < effectiveChance) {
            effects[key] = value;
        }

        return effects;
    }

    /**
     * 构建伤害文字日志
     */
    _buildDamageLog(ctx, rawDamage, finalDamage, isCritical, statusEffects) {
        const prefix   = isCritical ? '💥 暴击！' : '⚔️';
        const reduction = rawDamage - finalDamage;
        let log = `${prefix} 造成 ${finalDamage} 点伤害`;
        if (reduction > 0) log += `（原始 ${rawDamage}，减免 ${reduction}）`;

        const statusKeys = Object.keys(statusEffects);
        if (statusKeys.length > 0) {
            log += ` + 附加状态：${statusKeys.join(', ')}`;
        }

        return log;
    }

    /**
     * 构建伤害结算 STscript
     */
    _buildDamageScript(hpKey, hpAfter, damage, log) {
        return [
            `/setvar key=${hpKey} value=${hpAfter} |`,
            `/echo ${log} |`,
        ];
    }

    /**
     * 构建治疗结算 STscript
     */
    _buildHealScript(hpKey, hpMaxKey, hpAfter, healAmount, log) {
        return [
            `/setvar key=${hpKey} value=${hpAfter} |`,
            `/echo ${log} |`,
        ];
    }

    /**
     * 构建未命中结果
     */
    _buildMissResult(ctx, resultType) {
        const label = resultType === RESULT_TYPES.DODGE ? '🌀 闪避！' : '💨 未命中！';
        return {
            resultType,
            damageType:   DAMAGE_TYPES.PHYSICAL,
            rawDamage:    0,
            finalDamage:  0,
            hpAfter:      parseFloat(ctx.defender?.hp || 100),
            isCritical:   false,
            isMiss:       true,
            statusEffects: {},
            log:          label,
            stscript:     [`/echo ${label} |`],
        };
    }
}