/**
 * @file modules/05_rpg-tracker/history-logger.js
 * @description RPG 属性变化历史记录器
 *              负责：记录每次属性值变化的完整快照、提供时间轴查询、
 *              生成变化摘要报告、支持回滚到历史状态、导出日志为 JSON/CSV。
 * @version 1.0.0
 */

// ═══════════════════════════════════════════════
// § 1  常量与类型定义
// ═══════════════════════════════════════════════

/**
 * 历史记录条目类型
 * @enum {string}
 */
export const LOG_ENTRY_TYPES = {
    /** 手动修改 */
    MANUAL:      'manual',
    /** 来自 AI 消息的自动追踪 */
    AI_TRACKED:  'ai_tracked',
    /** 来自 STscript 变量同步 */
    SCRIPT_SYNC: 'script_sync',
    /** 正则提取 */
    REGEX:       'regex',
    /** 系统初始化 */
    INIT:        'init',
    /** 批量重置 */
    RESET:       'reset',
    /** 战斗计算器结算 */
    COMBAT:      'combat',
};

/**
 * @typedef {Object} LogEntry
 * @property {string}  id          - 唯一记录 ID
 * @property {number}  timestamp   - 时间戳（Date.now()）
 * @property {string}  type        - LOG_ENTRY_TYPES 中的值
 * @property {string}  statKey     - 属性 key
 * @property {string}  statLabel   - 属性显示名（记录时快照，防止重命名后丢失）
 * @property {*}       valueBefore - 变化前的值
 * @property {*}       valueAfter  - 变化后的值
 * @property {number}  [delta]     - 数值变化量（仅数值类型属性）
 * @property {string}  reason      - 变化原因（自然语言描述）
 * @property {string}  [source]    - 来源（AI 消息片段、脚本名等）
 * @property {number}  [turnIndex] - 对应的对话轮次（如可获取）
 * @property {object}  [snapshot]  - 该时刻所有属性的完整快照（可选，占空间大）
 */

/**
 * @typedef {Object} StatHistory
 * @property {string}     statKey  - 属性 key
 * @property {LogEntry[]} entries  - 该属性的所有记录（按时间排序）
 */

// ═══════════════════════════════════════════════
// § 2  HistoryLogger 主类
// ═══════════════════════════════════════════════

/**
 * RPG 属性变化历史记录器
 */
export class HistoryLogger {
    /**
     * @param {object} [options]
     * @param {number} [options.maxEntriesPerStat=200] - 每个属性最多保留的记录条数
     * @param {number} [options.maxTotalEntries=2000]  - 全局最多保留的记录总数
     * @param {boolean}[options.snapshotOnChange=false] - 每次变化时是否保存全量快照（会增加内存用量）
     * @param {Function}[options.onEntryAdded]         - 新记录加入时的回调
     */
    constructor(options = {}) {
        this._options = {
            maxEntriesPerStat:  200,
            maxTotalEntries:    2000,
            snapshotOnChange:   false,
            onEntryAdded:       null,
            ...options,
        };

        /**
         * 按属性 key 组织的历史记录
         * @type {Map<string, LogEntry[]>}
         */
        this._logs = new Map();

        /**
         * 全局时间轴（所有属性的记录合并排序）
         * @type {LogEntry[]}
         */
        this._timeline = [];

        /**
         * 当前所有属性的最新值快照（key→value）
         * @type {Map<string, *>}
         */
        this._currentSnapshot = new Map();

        /** @type {number} 全局记录计数器（用于生成唯一 ID） */
        this._idCounter = 0;
    }

    // ─── 记录写入 ─────────────────────────────────

    /**
     * 记录一次属性变化
     *
     * @param {object} params
     * @param {string} params.statKey      - 属性 key
     * @param {string} params.statLabel    - 属性显示名
     * @param {*}      params.valueBefore  - 变化前的值
     * @param {*}      params.valueAfter   - 变化后的值
     * @param {string} [params.reason]     - 变化原因
     * @param {string} [params.type]       - LOG_ENTRY_TYPES
     * @param {string} [params.source]     - 来源描述
     * @param {number} [params.turnIndex]  - 对话轮次
     * @param {object} [params.allStats]   - 当前所有属性（用于生成快照）
     * @returns {LogEntry}
     */
    log(params) {
        const {
            statKey, statLabel, valueBefore, valueAfter,
            reason = '', type = LOG_ENTRY_TYPES.MANUAL,
            source = '', turnIndex = null,
            allStats = null,
        } = params;

        // 计算数值变化量（仅数值类型）
        const numBefore = parseFloat(valueBefore);
        const numAfter  = parseFloat(valueAfter);
        const delta     = (!isNaN(numBefore) && !isNaN(numAfter))
            ? numAfter - numBefore
            : null;

        /** @type {LogEntry} */
        const entry = {
            id:          `log_${++this._idCounter}_${Date.now()}`,
            timestamp:   Date.now(),
            type,
            statKey,
            statLabel:   statLabel || statKey,
            valueBefore,
            valueAfter,
            delta,
            reason:      reason || this._inferReason(type, delta),
            source,
            turnIndex,
            snapshot:    (this._options.snapshotOnChange && allStats)
                            ? { ...allStats }
                            : null,
        };

        // 写入属性级日志
        if (!this._logs.has(statKey)) {
            this._logs.set(statKey, []);
        }
        const statLogs = this._logs.get(statKey);
        statLogs.push(entry);

        // 裁剪超出上限的旧记录
        if (statLogs.length > this._options.maxEntriesPerStat) {
            statLogs.splice(0, statLogs.length - this._options.maxEntriesPerStat);
        }

        // 写入全局时间轴
        this._timeline.push(entry);
        if (this._timeline.length > this._options.maxTotalEntries) {
            this._timeline.shift();
        }

        // 更新快照
        this._currentSnapshot.set(statKey, valueAfter);

        // 触发回调
        if (this._options.onEntryAdded) {
            this._options.onEntryAdded(entry, this);
        }

        return entry;
    }

    /**
     * 批量记录（用于初始化或批量重置）
     * @param {Array<Omit<Parameters<HistoryLogger['log']>[0], never>>} paramsList
     * @returns {LogEntry[]}
     */
    logBatch(paramsList) {
        return paramsList.map(p => this.log(p));
    }

    /**
     * 记录初始化事件（在首次加载属性配置时调用）
     * @param {StatDef[]} statDefs
     */
    logInit(statDefs) {
        statDefs.forEach(stat => {
            this.log({
                statKey:     stat.key,
                statLabel:   stat.label,
                valueBefore: null,
                valueAfter:  stat.current,
                type:        LOG_ENTRY_TYPES.INIT,
                reason:      '属性初始化',
            });
        });
    }

    /**
     * 记录重置事件
     * @param {StatDef[]} statDefs
     */
    logReset(statDefs) {
        statDefs.forEach(stat => {
            const before = this._currentSnapshot.get(stat.key);
            this.log({
                statKey:     stat.key,
                statLabel:   stat.label,
                valueBefore: before ?? stat.current,
                valueAfter:  stat.current,
                type:        LOG_ENTRY_TYPES.RESET,
                reason:      '属性重置',
            });
        });
    }

    // ─── 查询接口 ─────────────────────────────────

    /**
     * 获取指定属性的完整历史记录
     * @param {string} statKey
     * @returns {LogEntry[]}
     */
    getHistory(statKey) {
        return [...(this._logs.get(statKey) || [])];
    }

    /**
     * 获取指定属性的最近 N 条记录
     * @param {string} statKey
     * @param {number} [limit=10]
     * @returns {LogEntry[]}
     */
    getRecentHistory(statKey, limit = 10) {
        const logs = this._logs.get(statKey) || [];
        return logs.slice(-limit);
    }

    /**
     * 获取全局时间轴（所有属性的记录，按时间排序）
     * @param {number} [limit]  - 最多返回条数（不传则返回全部）
     * @returns {LogEntry[]}
     */
    getTimeline(limit) {
        const tl = [...this._timeline].reverse();  // 最新的在前
        return limit ? tl.slice(0, limit) : tl;
    }

    /**
     * 按时间范围查询
     * @param {number} fromTs - 开始时间戳
     * @param {number} toTs   - 结束时间戳
     * @returns {LogEntry[]}
     */
    getByTimeRange(fromTs, toTs) {
        return this._timeline.filter(e => e.timestamp >= fromTs && e.timestamp <= toTs);
    }

    /**
     * 按记录类型查询
     * @param {string} type - LOG_ENTRY_TYPES 中的值
     * @returns {LogEntry[]}
     */
    getByType(type) {
        return this._timeline.filter(e => e.type === type);
    }

    /**
     * 按对话轮次查询（需要记录时传入 turnIndex）
     * @param {number} turnIndex
     * @returns {LogEntry[]}
     */
    getByTurn(turnIndex) {
        return this._timeline.filter(e => e.turnIndex === turnIndex);
    }

    /**
     * 获取指定属性在某时刻的值（最接近的历史记录）
     * @param {string} statKey
     * @param {number} timestamp
     * @returns {*}  该时刻的属性值（null 表示无记录）
     */
    getValueAt(statKey, timestamp) {
        const logs = this._logs.get(statKey) || [];
        // 找到 timestamp 之前最近的一条记录
        for (let i = logs.length - 1; i >= 0; i--) {
            if (logs[i].timestamp <= timestamp) {
                return logs[i].valueAfter;
            }
        }
        return null;
    }

    /**
     * 获取所有有记录的属性 key 列表
     * @returns {string[]}
     */
    getTrackedStats() {
        return [...this._logs.keys()];
    }

    /**
     * 获取当前所有属性的最新值快照
     * @returns {object}  key → value 映射
     */
    getCurrentSnapshot() {
        const result = {};
        this._currentSnapshot.forEach((val, key) => { result[key] = val; });
        return result;
    }

    // ─── 统计与分析 ───────────────────────────────

    /**
     * 生成指定属性的变化统计报告
     *
     * @param {string} statKey
     * @returns {{
     *   statKey: string,
     *   totalChanges: number,
     *   totalIncrease: number,
     *   totalDecrease: number,
     *   maxValue: number,
     *   minValue: number,
     *   currentValue: *,
     *   firstChangedAt: number|null,
     *   lastChangedAt: number|null,
     *   changesByType: Object.<string, number>,
     * }}
     */
    getStatReport(statKey) {
        const logs = this._logs.get(statKey) || [];

        let totalIncrease = 0;
        let totalDecrease = 0;
        let maxValue      = -Infinity;
        let minValue      =  Infinity;
        const changesByType = {};

        logs.forEach(entry => {
            if (entry.delta !== null) {
                if (entry.delta > 0) totalIncrease += entry.delta;
                if (entry.delta < 0) totalDecrease += Math.abs(entry.delta);
            }
            const v = parseFloat(entry.valueAfter);
            if (!isNaN(v)) {
                maxValue = Math.max(maxValue, v);
                minValue = Math.min(minValue, v);
            }
            changesByType[entry.type] = (changesByType[entry.type] || 0) + 1;
        });

        return {
            statKey,
            totalChanges:    logs.length,
            totalIncrease,
            totalDecrease,
            maxValue:        maxValue === -Infinity ? null : maxValue,
            minValue:        minValue ===  Infinity ? null : minValue,
            currentValue:    this._currentSnapshot.get(statKey) ?? null,
            firstChangedAt:  logs.length > 0 ? logs[0].timestamp          : null,
            lastChangedAt:   logs.length > 0 ? logs[logs.length-1].timestamp : null,
            changesByType,
        };
    }

    /**
     * 生成全局变化摘要（用于 AI 注入或调试面板）
     * @param {number} [recentCount=10] - 摘要包含的最近记录数
     * @returns {string}
     */
    generateSummary(recentCount = 10) {
        const recent  = this.getTimeline(recentCount);
        if (recent.length === 0) return '（暂无属性变化记录）';

        const lines = ['📊 最近属性变化：'];
        recent.forEach(entry => {
            const timeStr = new Date(entry.timestamp).toLocaleTimeString();
            const delta   = entry.delta !== null
                ? (entry.delta > 0 ? `+${entry.delta}` : String(entry.delta))
                : '';
            const arrow   = `${entry.valueBefore} → ${entry.valueAfter}`;
            lines.push(
                `  [${timeStr}] ${entry.statLabel}：${arrow}${delta ? ` (${delta})` : ''}`
                + (entry.reason ? ` — ${entry.reason}` : '')
            );
        });

        return lines.join('\n');
    }

    /**
     * 统计指定回合范围内各属性的净变化量
     * @param {number} fromTurn
     * @param {number} toTurn
     * @returns {Object.<string, { net: number, changes: number }>}
     */
    getTurnRangeSummary(fromTurn, toTurn) {
        const entries  = this._timeline.filter(
            e => e.turnIndex != null && e.turnIndex >= fromTurn && e.turnIndex <= toTurn
        );
        const result   = {};

        entries.forEach(entry => {
            if (!result[entry.statKey]) {
                result[entry.statKey] = { label: entry.statLabel, net: 0, changes: 0 };
            }
            if (entry.delta !== null) result[entry.statKey].net += entry.delta;
            result[entry.statKey].changes++;
        });

        return result;
    }

    // ─── 回滚 ─────────────────────────────────────

    /**
     * 获取回滚到某条历史记录所需的变化列表
     * 返回的列表可传给 RPGTracker 逐一应用
     *
     * @param {string} logEntryId - 目标历史记录 ID
     * @returns {Array<{ statKey: string, targetValue: * }>|null}
     */
    getRollbackPlan(logEntryId) {
        const target = this._timeline.find(e => e.id === logEntryId);
        if (!target) return null;

        // 找出每个属性在 target 时间点之前的最新值
        const plan = [];
        const affectedKeys = new Set(
            this._timeline
                .filter(e => e.timestamp >= target.timestamp)
                .map(e => e.statKey)
        );

        affectedKeys.forEach(key => {
            const valueAtTarget = this.getValueAt(key, target.timestamp);
            if (valueAtTarget !== null) {
                plan.push({ statKey: key, targetValue: valueAtTarget });
            }
        });

        return plan;
    }

    // ─── 序列化 / 导出 ────────────────────────────

    /**
     * 导出全部日志为 JSON
     * @returns {object}
     */
    exportJSON() {
        const logsObj = {};
        this._logs.forEach((entries, key) => {
            logsObj[key] = entries;
        });

        return {
            version:          '1.0',
            exportedAt:       Date.now(),
            totalEntries:     this._timeline.length,
            trackedStats:     [...this._logs.keys()],
            currentSnapshot:  this.getCurrentSnapshot(),
            logs:             logsObj,
        };
    }

    /**
     * 将全局时间轴导出为 CSV 字符串
     * @returns {string}
     */
    exportCSV() {
        const header = ['id', 'timestamp', 'datetime', 'type', 'statKey', 'statLabel',
                        'valueBefore', 'valueAfter', 'delta', 'reason', 'turnIndex'];
        const rows   = this._timeline.map(e => [
            e.id,
            e.timestamp,
            new Date(e.timestamp).toISOString(),
            e.type,
            e.statKey,
            e.statLabel,
            e.valueBefore ?? '',
            e.valueAfter  ?? '',
            e.delta        ?? '',
            (e.reason || '').replace(/,/g, '，'),
            e.turnIndex   ?? '',
        ]);

        return [header, ...rows]
            .map(row => row.join(','))
            .join('\n');
    }

    /**
     * 从 JSON 恢复日志（导入）
     * @param {object} json - exportJSON() 的返回值
     */
    importJSON(json) {
        if (!json?.logs) return;

        this._logs.clear();
        this._timeline = [];
        this._idCounter = 0;

        Object.entries(json.logs).forEach(([key, entries]) => {
            this._logs.set(key, entries);
            this._timeline.push(...entries);
            this._idCounter = Math.max(
                this._idCounter,
                ...entries.map(e => parseInt(e.id.split('_')[1]) || 0)
            );
        });

        // 按时间排序时间轴
        this._timeline.sort((a, b) => a.timestamp - b.timestamp);

        // 恢复快照
        if (json.currentSnapshot) {
            Object.entries(json.currentSnapshot).forEach(([k, v]) => {
                this._currentSnapshot.set(k, v);
            });
        }
    }

    // ─── 清理 ─────────────────────────────────────

    /**
     * 清空指定属性的历史记录
     * @param {string} statKey
     */
    clearStat(statKey) {
        this._logs.delete(statKey);
        this._timeline = this._timeline.filter(e => e.statKey !== statKey);
        this._currentSnapshot.delete(statKey);
    }

    /**
     * 清空所有历史记录
     */
    clearAll() {
        this._logs.clear();
        this._timeline   = [];
        this._idCounter  = 0;
        this._currentSnapshot.clear();
    }

    /**
     * 获取当前记录总数
     * @returns {{ total: number, perStat: Object.<string, number> }}
     */
    getSize() {
        const perStat = {};
        this._logs.forEach((entries, key) => { perStat[key] = entries.length; });
        return { total: this._timeline.length, perStat };
    }

    // ─── 私有方法 ─────────────────────────────────

    /**
     * 根据记录类型和变化量推断变化原因描述
     * @param {string}      type
     * @param {number|null} delta
     * @returns {string}
     */
    _inferReason(type, delta) {
        const deltaStr = delta !== null
            ? (delta > 0 ? `增加 ${delta}` : `减少 ${Math.abs(delta)}`)
            : '变化';

        switch (type) {
            case LOG_ENTRY_TYPES.AI_TRACKED:  return `AI 消息追踪（${deltaStr}）`;
            case LOG_ENTRY_TYPES.SCRIPT_SYNC: return `STscript 变量同步（${deltaStr}）`;
            case LOG_ENTRY_TYPES.REGEX:       return `正则提取（${deltaStr}）`;
            case LOG_ENTRY_TYPES.COMBAT:      return `战斗结算（${deltaStr}）`;
            case LOG_ENTRY_TYPES.INIT:        return '初始化';
            case LOG_ENTRY_TYPES.RESET:       return '重置为初始值';
            default:                          return `手动修改（${deltaStr}）`;
        }
    }
}

// ═══════════════════════════════════════════════
// § 3  独立工具函数
// ═══════════════════════════════════════════════

/**
 * 格式化时间戳为可读字符串
 * @param {number} timestamp
 * @returns {string}
 */
export function formatTimestamp(timestamp) {
    const d = new Date(timestamp);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getMonth()+1}/${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

/**
 * 根据 delta 生成带颜色标记的变化文本（用于 UI 渲染）
 * @param {number|null} delta
 * @returns {{ text: string, className: string }}
 */
export function formatDelta(delta) {
    if (delta === null || delta === undefined) {
        return { text: '', className: '' };
    }
    if (delta > 0) return { text: `+${delta}`,      className: 'cf-delta-up' };
    if (delta < 0) return { text: String(delta),    className: 'cf-delta-down' };
    return             { text: '±0',               className: 'cf-delta-zero' };
}

/**
 * 将历史记录数组渲染为简洁的文字时间轴（用于 echo 输出或 WorldInfo 注入）
 * @param {LogEntry[]} entries
 * @param {object}     [options]
 * @param {boolean}    [options.showTime=true]
 * @param {boolean}    [options.showDelta=true]
 * @param {boolean}    [options.showReason=true]
 * @returns {string}
 */
export function renderHistoryText(entries, options = {}) {
    const { showTime = true, showDelta = true, showReason = true } = options;

    if (!entries || entries.length === 0) return '（无记录）';

    return entries.map(entry => {
        const parts = [];
        if (showTime) parts.push(`[${formatTimestamp(entry.timestamp)}]`);
        parts.push(`${entry.statLabel}：${entry.valueBefore ?? '?'} → ${entry.valueAfter}`);
        if (showDelta && entry.delta !== null) {
            const { text } = formatDelta(entry.delta);
            if (text) parts.push(`(${text})`);
        }
        if (showReason && entry.reason) parts.push(`— ${entry.reason}`);
        return parts.join(' ');
    }).join('\n');
}

export default HistoryLogger;