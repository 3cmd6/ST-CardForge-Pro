/**
 * @file modules/05_rpg-tracker/rpg-tracker.js
 * @description RPG 追踪器主模块
 *              整合属性定义、历史记录、战斗计算、World Info 同步、STscript 构建，
 *              提供统一的属性管理 API 和 UI 挂载接口。
 *              实现 IModule 接口，由 index.js 统一管理生命周期。
 * @version 1.0.0
 */

import { EVENTS, MODULE_INTERFACE }           from '../../contracts.js';
import {
    STAT_TYPES, STAT_DISPLAY, TRACKING_MODE,
    createStatDef, createStatDefs,
    validateStatDef, validateStatValue,
    clampStatValue, formatStatValue,
    getStatPercent, getPercentColor,
    cloneStatDefs, statsToInitScript,
    STAT_PRESETS, getPreset, listPresets,
}                                              from './stat-definitions.js';
import { HistoryLogger, LOG_ENTRY_TYPES }      from './history-logger.js';
import { CombatCalculator, rollDice }          from './combat-calculator.js';
import { WorldInfoSync, formatStatsForAI }     from './worldinfo-sync.js';
import { RPGSTScriptBuilder }                  from './stscript-builder.js';

// ═══════════════════════════════════════════════
// § 1  RPGTracker 主类
// ═══════════════════════════════════════════════

/**
 * RPG 追踪器主模块
 * @implements {MODULE_INTERFACE}
 */
export class RPGTracker {
    /**
     * @param {object} aiEngine   - AIEngine 实例
     * @param {object} eventBus   - EventBus 实例
     * @param {object} settings   - SettingsManager 实例
     * @param {object} dbStore    - IndexedDBStore 实例
     */
    constructor(aiEngine, eventBus, settings, dbStore) {
        this._ai       = aiEngine;
        this._bus      = eventBus;
        this._settings = settings;
        this._db       = dbStore;

        /** @type {boolean} */
        this._ready    = false;

        /**
         * 当前属性定义列表
         * @type {StatDef[]}
         */
        this._statDefs = [];

        /**
         * 当前属性值快照（key→value）
         * 与 statDef.current 分离，避免修改原始定义
         * @type {Map<string, *>}
         */
        this._values   = new Map();

        /** @type {HistoryLogger} */
        this._history  = new HistoryLogger({
            maxEntriesPerStat: 200,
            onEntryAdded:      (entry) => this._onHistoryEntryAdded(entry),
        });

        /** @type {CombatCalculator} */
        this._combat   = new CombatCalculator();

        /** @type {WorldInfoSync} */
        this._wiSync   = new WorldInfoSync(eventBus);

        /** @type {RPGSTScriptBuilder|null} */
        this._scriptBuilder = null;

        /** @type {boolean} 是否开启 AI 自动追踪 */
        this._autoTrackEnabled = false;

        /** @type {string[]} 订阅取消函数 */
        this._unsubs   = [];
    }

    // ─── IModule 接口 ─────────────────────────────

    /**
     * 模块初始化
     * @returns {Promise<void>}
     */
    async init() {
        try {
            await this._wiSync.init();
            await this._loadPersistedState();
            this._subscribeEvents();
            this._ready = true;
            this._bus.emit(EVENTS.MODULE_READY, { module: 'RPGTracker' });
        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module: 'RPGTracker', method: 'init', error, context: {},
            });
            throw error;
        }
    }

    /**
     * 模块销毁
     */
    destroy() {
        this._unsubs.forEach(fn => fn());
        this._unsubs = [];
        this._wiSync.destroy();
        this._ready  = false;
    }

    /**
     * 获取当前模块状态
     * @returns {object}
     */
    getState() {
        return {
            ready:           this._ready,
            statCount:       this._statDefs.length,
            autoTrack:       this._autoTrackEnabled,
            historySize:     this._history.getSize().total,
            currentValues:   this.getAllStats(),
        };
    }

    /**
     * @returns {boolean}
     */
    isReady() {
        return this._ready;
    }

    // ─── 属性定义管理 ─────────────────────────────

    /**
     * 从预设加载属性定义列表
     * @param {string} presetId - STAT_PRESETS 中的 id
     * @returns {StatDef[]}
     */
    loadPreset(presetId) {
        const preset = getPreset(presetId);
        if (!preset) throw new Error(`[RPGTracker] 未知预设：${presetId}`);

        this.defineStats(cloneStatDefs(preset.stats));
        return this._statDefs;
    }

    /**
     * 直接设置属性定义列表（全量替换）
     * @param {StatDef[]} statDefs
     */
    defineStats(statDefs) {
        // 校验每个属性定义
        statDefs.forEach((stat, idx) => {
            const { valid, errors } = validateStatDef(stat);
            if (!valid) {
                throw new Error(`[RPGTracker] 属性 #${idx}（${stat.key}）定义无效：${errors.join(', ')}`);
            }
        });

        this._statDefs = statDefs;

        // 重建值映射（保留已有值，新属性使用 current 初始化）
        statDefs.forEach(stat => {
            if (!this._values.has(stat.key)) {
                this._values.set(stat.key, stat.current);
            }
            if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                if (!this._values.has(stat.maxKey)) {
                    this._values.set(stat.maxKey, stat.max);
                }
            }
        });

        // 重建 STscript 构建器
        this._scriptBuilder = new RPGSTScriptBuilder(this._statDefs, {
            statusBarTitle: this._settings?.get('rpgStatusBarTitle', '📊 角色状态'),
        });

        // 记录初始化历史
        this._history.logInit(statDefs);

        this._bus.emit(EVENTS.RPG_STAT_CHANGED, {
            action: 'defined',
            stats:  this.getAllStats(),
        });
    }

    /**
     * 追加单个属性定义
     * @param {object} statOptions - createStatDef 的参数
     * @returns {StatDef}
     */
    addStat(statOptions) {
        const stat = createStatDef(statOptions);
        const { valid, errors } = validateStatDef(stat);
        if (!valid) throw new Error(`[RPGTracker] 属性定义无效：${errors.join(', ')}`);

        this._statDefs.push(stat);
        this._values.set(stat.key, stat.current);
        if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
            this._values.set(stat.maxKey, stat.max);
        }

        this._scriptBuilder?.updateStatDefs(this._statDefs);
        return stat;
    }

    /**
     * 更新属性定义（仅修改 meta 信息，不影响当前值）
     * @param {string} key
     * @param {object} changes
     */
    updateStatDef(key, changes) {
        const idx = this._statDefs.findIndex(s => s.key === key);
        if (idx === -1) throw new Error(`[RPGTracker] 未找到属性：${key}`);

        this._statDefs[idx] = { ...this._statDefs[idx], ...changes, key };
        this._scriptBuilder?.updateStatDefs(this._statDefs);
    }

    /**
     * 移除属性定义
     * @param {string} key
     */
    removeStat(key) {
        this._statDefs = this._statDefs.filter(s => s.key !== key);
        this._values.delete(key);
        this._scriptBuilder?.updateStatDefs(this._statDefs);
    }

    /**
     * 获取属性定义列表（深克隆）
     * @returns {StatDef[]}
     */
    getStatDefs() {
        return cloneStatDefs(this._statDefs);
    }

    // ─── 属性值操作 ───────────────────────────────

    /**
     * 获取单个属性当前值
     * @param {string} key
     * @returns {*}
     */
    getStat(key) {
        return this._values.get(key) ?? this._findStatDef(key)?.current ?? null;
    }

    /**
     * 设置属性值（带校验 + 历史记录 + 事件广播）
     *
     * @param {string} key
     * @param {*}      value
     * @param {string} [reason] - 变化原因
     * @param {string} [type]   - LOG_ENTRY_TYPES
     * @param {string} [source] - 来源描述
     * @returns {{ ok: boolean, value: *, error: string|null }}
     */
    setStat(key, value, reason = '', type = LOG_ENTRY_TYPES.MANUAL, source = '') {
        const statDef = this._findStatDef(key);

        if (!statDef) {
            // 未定义的属性：允许动态创建（宽松模式）
            const before = this._values.get(key);
            this._values.set(key, value);
            this._emitStatChanged(key, before, value);
            return { ok: true, value, error: null };
        }

        // 校验并 coerce 值
        const { valid, coerced, error } = validateStatValue(statDef, value);
        if (!valid) {
            this._bus.emit(EVENTS.ERROR, {
                module: 'RPGTracker', method: 'setStat',
                error:  new Error(error),
                context: { key, value },
            });
            return { ok: false, value: this._values.get(key), error };
        }

        const before = this._values.get(key);
        this._values.set(key, coerced);

        // 记录历史
        this._history.log({
            statKey:     key,
            statLabel:   statDef.label,
            valueBefore: before,
            valueAfter:  coerced,
            reason,
            type,
            source,
            allStats:    this.getCurrentSnapshot(),
        });

        this._emitStatChanged(key, before, coerced);
        this._schedulePersist();

        return { ok: true, value: coerced, error: null };
    }

    /**
     * 修改属性值（在当前值基础上增减）
     *
     * @param {string} key
     * @param {number} delta   - 变化量（正/负）
     * @param {string} [reason]
     * @param {string} [type]
     * @returns {{ ok: boolean, value: *, delta: number, error: string|null }}
     */
    modifyStat(key, delta, reason = '', type = LOG_ENTRY_TYPES.MANUAL) {
        const current = parseFloat(this._values.get(key) ?? 0);
        const newVal  = current + delta;
        const result  = this.setStat(key, newVal, reason || `${delta > 0 ? '+' : ''}${delta}`, type);

        return {
            ...result,
            delta: result.ok ? (parseFloat(result.value) - current) : 0,
        };
    }

    /**
     * 获取所有属性的当前值（返回普通对象）
     * @returns {Object.<string, *>}
     */
    getAllStats() {
        const result = {};
        this._values.forEach((val, key) => { result[key] = val; });
        return result;
    }

    /**
     * 获取当前值快照（别名，与 getAllStats 相同）
     * @returns {Object.<string, *>}
     */
    getCurrentSnapshot() {
        return this.getAllStats();
    }

    /**
     * 重置所有属性到初始值
     * @param {string} [reason]
     */
    resetStats(reason = '属性重置') {
        this._history.logReset(this._statDefs);

        this._statDefs.forEach(stat => {
            this._values.set(stat.key, stat.current);
            if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                this._values.set(stat.maxKey, stat.max);
            }
        });

        this._bus.emit(EVENTS.RPG_STAT_RESET, { stats: this.getAllStats() });
        this._schedulePersist();
    }

    /**
     * 重置单个属性到初始值
     * @param {string} key
     */
    resetStat(key) {
        const statDef = this._findStatDef(key);
        if (!statDef) return;

        this.setStat(key, statDef.current, '重置为初始值', LOG_ENTRY_TYPES.RESET);

        if (statDef.type === STAT_TYPES.COMPOSITE && statDef.maxKey) {
            this._values.set(statDef.maxKey, statDef.max);
        }
    }

    // ─── AI 自动追踪 ──────────────────────────────

    /**
     * 开启或关闭 AI 自动追踪
     * @param {boolean} enabled
     */
    enableAutoTracking(enabled) {
        this._autoTrackEnabled = enabled;
    }

    /**
     * 从 AI 消息中扫描并提取属性变化
     * 调用 AI 接口分析消息，识别属性的增减
     *
     * @param {string} message  - AI 回复的消息内容
     * @returns {Promise<Array<{ key: string, delta: number, reason: string }>>}
     *          提取出的属性变化列表
     */
    async scanMessage(message) {
        if (!this._autoTrackEnabled || !message) return [];

        try {
            const prompt  = this._buildScanPrompt(message);
            const rawResp = await this._ai.generateCard(
                '你是一个 RPG 游戏状态解析器，只输出 JSON 格式的结果。',
                prompt
            );

            const changes = this._parseStatChanges(rawResp);

            // 应用提取出的变化
            changes.forEach(change => {
                if (change.key && change.delta !== undefined) {
                    this.modifyStat(
                        change.key,
                        change.delta,
                        change.reason || 'AI 消息追踪',
                        LOG_ENTRY_TYPES.AI_TRACKED
                    );
                }
            });

            if (changes.length > 0) {
                this._bus.emit(EVENTS.RPG_HISTORY_UPDATED, { changes });
            }

            return changes;

        } catch (error) {
            this._bus.emit(EVENTS.ERROR, {
                module: 'RPGTracker', method: 'scanMessage', error, context: {},
            });
            return [];
        }
    }

    // ─── 战斗计算器代理 ───────────────────────────

    /**
     * 执行一次战斗计算（使用当前属性快照作为战斗上下文）
     *
     * @param {object} [defenderValues] - 对手的属性快照（不传则用空对象）
     * @param {string} [formulaName]    - 使用的公式名
     * @param {object} [params]         - 公式参数
     * @returns {CombatResult}
     */
    combat(defenderValues = {}, formulaName, params = {}) {
        const ctx = {
            attacker: this.getCurrentSnapshot(),
            defender: defenderValues,
        };
        return this._combat.calculateDamage(ctx, formulaName, params);
    }

    /**
     * 直接访问战斗计算器实例（用于注册自定义公式等高级操作）
     * @returns {CombatCalculator}
     */
    getCombatCalculator() {
        return this._combat;
    }

    // ─── STscript 生成代理 ────────────────────────

    /**
     * 生成状态条显示 STscript
     * @returns {string}
     */
    generateStatusBarHTML() {
        this._ensureScriptBuilder();
        return this._scriptBuilder.buildStatusBarScript();
    }

    /**
     * 生成完整的追踪用 STscript
     * @returns {string}
     */
    generateTrackingScript() {
        this._ensureScriptBuilder();
        return this._scriptBuilder.buildTrackingScript();
    }

    /**
     * 生成初始化 STscript
     * @param {object} [overrides]
     * @returns {string}
     */
    generateInitScript(overrides = {}) {
        this._ensureScriptBuilder();
        return this._scriptBuilder.buildInitScript(overrides);
    }

    /**
     * 生成完整 QR Set JSON
     * @param {string} [qrSetName]
     * @returns {object}
     */
    generateQRSet(qrSetName = 'rpg_tracker') {
        this._ensureScriptBuilder();
        return this._scriptBuilder.buildFullQRSet(qrSetName);
    }

    /**
     * 一次性生成所有脚本
     * @param {string} [qrSetName]
     * @returns {object}
     */
    generateAll(qrSetName = 'rpg_tracker') {
        this._ensureScriptBuilder();
        return this._scriptBuilder.buildAll(qrSetName);
    }

    // ─── World Info 同步代理 ──────────────────────

    /**
     * 立即同步当前属性到 World Info
     * @returns {Promise<{ success: boolean, uid: number|null, error: string|null }>}
     */
    async syncToWorldInfo() {
        return this._wiSync.syncToWorldInfo(
            this._statDefs,
            this.getCurrentSnapshot(),
            this._history
        );
    }

    /**
     * 获取适合注入 World Info 的 AI 可读属性文本
     * @param {object} [options]
     * @returns {string}
     */
    getAIReadableStats(options = {}) {
        return formatStatsForAI(
            this._statDefs,
            this.getCurrentSnapshot(),
            options
        );
    }

    // ─── 历史记录代理 ─────────────────────────────

    /**
     * 获取指定属性的历史记录
     * @param {string} key
     * @param {number} [limit]
     * @returns {LogEntry[]}
     */
    getHistory(key, limit) {
        return limit
            ? this._history.getRecentHistory(key, limit)
            : this._history.getHistory(key);
    }

    /**
     * 获取全局时间轴
     * @param {number} [limit]
     * @returns {LogEntry[]}
     */
    getTimeline(limit) {
        return this._history.getTimeline(limit);
    }

    /**
     * 获取历史变化摘要文本
     * @param {number} [lines]
     * @returns {string}
     */
    getHistorySummary(lines = 10) {
        return this._history.generateSummary(lines);
    }

    /**
     * 清除指定属性的历史记录
     * @param {string} key
     */
    clearHistory(key) {
        this._history.clearStat(key);
    }

    /**
     * 清除所有历史记录
     */
    clearAllHistory() {
        this._history.clearAll();
    }

    // ─── 预设查询 ─────────────────────────────────

    /**
     * 获取所有可用预设列表
     * @returns {Array<{ id, label, description, icon, count }>}
     */
    listPresets() {
        return listPresets();
    }

    // ─── 序列化 / 持久化 ──────────────────────────

    /**
     * 导出当前所有数据为 JSON
     * @returns {object}
     */
    exportData() {
        return {
            version:    '1.0',
            exportedAt: Date.now(),
            statDefs:   this._statDefs,
            values:     this.getCurrentSnapshot(),
            history:    this._history.exportJSON(),
        };
    }

    /**
     * 从 JSON 导入数据
     * @param {object} json
     */
    importData(json) {
        if (!json) return;

        if (json.statDefs) {
            this.defineStats(json.statDefs);
        }

        if (json.values) {
            Object.entries(json.values).forEach(([key, val]) => {
                this._values.set(key, val);
            });
        }

        if (json.history) {
            this._history.importJSON(json.history);
        }
    }

    // ═══════════════════════════════════════════════
    // § 2  私有方法
    // ═══════════════════════════════════════════════

    /**
     * 查找属性定义
     * @param {string} key
     * @returns {StatDef|null}
     */
    _findStatDef(key) {
        return this._statDefs.find(s => s.key === key) ?? null;
    }

    /**
     * 广播属性变化事件
     * @param {string} key
     * @param {*}      before
     * @param {*}      after
     */
    _emitStatChanged(key, before, after) {
        this._bus.emit(EVENTS.RPG_STAT_CHANGED, {
            key,
            before,
            after,
            delta:    (typeof after === 'number' && typeof before === 'number')
                          ? after - before
                          : null,
            snapshot: this.getCurrentSnapshot(),
        });
    }

    /**
     * 历史记录新增时的回调（触发 World Info 防抖同步）
     * @param {LogEntry} entry
     */
    _onHistoryEntryAdded(entry) {
        this._bus.emit(EVENTS.RPG_HISTORY_UPDATED, { entry });
    }

    /**
     * 订阅全局事件
     */
    _subscribeEvents() {
        // 监听 AI 消息（用于自动追踪）
        const unsubMsg = this._bus.on(EVENTS.CARD_UPDATED, async (data) => {
            if (this._autoTrackEnabled && data?.lastMessage) {
                await this.scanMessage(data.lastMessage);
            }
        });
        this._unsubs.push(unsubMsg);

        // 监听 World Info 同步请求
        const unsubSync = this._bus.on(EVENTS.RPG_STAT_CHANGED, async (data) => {
            if (data?._requestSync) {
                await this.syncToWorldInfo();
            }
        });
        this._unsubs.push(unsubSync);
    }

    /**
     * 防抖持久化（延迟 2s 写入 IndexedDB）
     */
    _schedulePersist() {
        if (this._persistTimer) clearTimeout(this._persistTimer);
        this._persistTimer = setTimeout(() => this._persistState(), 2000);
    }

    /**
     * 将当前状态持久化到 IndexedDB
     */
    async _persistState() {
        if (!this._db) return;
        try {
            await this._db.set('rpg_tracker_state', {
                statDefs: this._statDefs,
                values:   this.getCurrentSnapshot(),
                savedAt:  Date.now(),
            });
        } catch (err) {
            console.warn('[RPGTracker] 持久化失败：', err.message);
        }
    }

    /**
     * 从 IndexedDB 加载已持久化的状态
     */
    async _loadPersistedState() {
        if (!this._db) return;
        try {
            const saved = await this._db.get('rpg_tracker_state');
            if (saved?.statDefs?.length > 0) {
                this.defineStats(saved.statDefs);
                if (saved.values) {
                    Object.entries(saved.values).forEach(([k, v]) => this._values.set(k, v));
                }
            }
        } catch (_) { /* 首次运行或 DB 为空时忽略 */ }
    }

    /**
     * 确保 STscript 构建器已初始化
     */
    _ensureScriptBuilder() {
        if (!this._scriptBuilder) {
            this._scriptBuilder = new RPGSTScriptBuilder(this._statDefs);
        }
    }

    /**
     * 构建属性扫描的 AI Prompt
     * @param {string} message
     * @returns {string}
     */
    _buildScanPrompt(message) {
        const statList = this._statDefs
            .filter(s => s.tracking === TRACKING_MODE.AUTO_AI)
            .map(s => `  - ${s.key}（${s.label}，类型：${s.type}，范围：${s.min}~${s.max}）`)
            .join('\n');

        return [
            '请从以下游戏消息中提取角色属性的变化，以 JSON 数组格式返回。',
            '只返回 JSON，不要解释。如果没有属性变化，返回 []。',
            '',
            '属性列表：',
            statList,
            '',
            '返回格式：[{"key":"属性key","delta":变化量,"reason":"原因"}]',
            '',
            '消息内容：',
            message,
        ].join('\n');
    }

    /**
     * 解析 AI 返回的属性变化 JSON
     * @param {string} raw
     * @returns {Array<{ key: string, delta: number, reason: string }>}
     */
    _parseStatChanges(raw) {
        if (!raw) return [];

        try {
            // 提取 JSON 数组
            const match = raw.match(/\[[\s\S]*\]/);
            if (!match) return [];

            const parsed = JSON.parse(match[0]);
            if (!Array.isArray(parsed)) return [];

            return parsed.filter(item =>
                item && typeof item.key === 'string' && typeof item.delta === 'number'
            );
        } catch (_) {
            return [];
        }
    }
}

export default RPGTracker;