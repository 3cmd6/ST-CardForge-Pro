/**
 * @file modules/05_rpg-tracker/stat-definitions.js
 * @description RPG 属性系统定义文件
 *              包含：属性类型枚举、预置属性模板集、属性 Schema 验证、
 *              属性工厂函数、内置游戏类型预设（奇幻/现代/科幻/克苏鲁等）。
 *              此文件是 rpg-tracker.js 和 stscript-builder.js 的共同依赖。
 * @version 1.0.0
 */

import { STAT_DEF_SCHEMA } from '../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  属性类型枚举
// ═══════════════════════════════════════════════

/**
 * 属性值类型枚举
 * @enum {string}
 */
export const STAT_TYPES = {
    /** 整数/小数属性，支持加减运算，可设置上下限 */
    NUMBER:   'number',
    /** 百分比属性（0~100），自动限制在 [0,100] 范围内，显示为进度条 */
    PERCENT:  'percent',
    /** 枚举属性，值为预设选项列表中的一个 */
    ENUM:     'enum',
    /** 布尔属性，值为 true/false，显示为开关 */
    BOOLEAN:  'boolean',
    /** 文本属性，值为任意字符串（如角色名、职业、状态文字） */
    TEXT:     'text',
    /** 等级属性，整数且有明确的等级上限，显示为星级或进度 */
    LEVEL:    'level',
    /** 复合属性（当前值/最大值），如 HP（50/100），显示为双值进度条 */
    COMPOSITE: 'composite',
};

/**
 * 属性显示位置枚举
 * @enum {string}
 */
export const STAT_DISPLAY = {
    /** 在状态条（status bar）中显示 */
    STATUS_BAR: 'status_bar',
    /** 在悬浮卡片中显示 */
    TOOLTIP:    'tooltip',
    /** 不显示（仅作内部追踪变量） */
    HIDDEN:     'hidden',
    /** 在角色信息卡中显示 */
    CHAR_CARD:  'char_card',
};

/**
 * 属性变化追踪方式枚举
 * @enum {string}
 */
export const TRACKING_MODE = {
    /** 不自动追踪，仅手动设置 */
    MANUAL:    'manual',
    /** 从 AI 回复中自动提取数值变化 */
    AUTO_AI:   'auto_ai',
    /** 从特定 STscript 变量同步 */
    STG_VAR:   'stg_var',
    /** 通过正则从消息中提取 */
    REGEX:     'regex',
};

// ═══════════════════════════════════════════════
// § 2  属性工厂函数
// ═══════════════════════════════════════════════

/**
 * 创建一个标准属性定义对象
 * 基于 STAT_DEF_SCHEMA，自动填充缺省值
 *
 * @param {Partial<StatDef>} options
 * @returns {StatDef}
 */
export function createStatDef(options = {}) {
    const base = { ...STAT_DEF_SCHEMA };

    const stat = {
        ...base,
        ...options,
        // 确保必要字段有值
        key:         options.key     || `stat_${Date.now()}`,
        label:       options.label   || options.key || '未命名属性',
        type:        options.type    || STAT_TYPES.NUMBER,
        display:     options.display || STAT_DISPLAY.STATUS_BAR,
        tracking:    options.tracking || TRACKING_MODE.MANUAL,
    };

    // 类型特定的默认值补充
    if (stat.type === STAT_TYPES.PERCENT) {
        stat.min     = 0;
        stat.max     = 100;
        stat.current = options.current ?? 100;
    }

    if (stat.type === STAT_TYPES.BOOLEAN) {
        stat.min     = 0;
        stat.max     = 1;
        stat.current = options.current ?? false;
    }

    if (stat.type === STAT_TYPES.ENUM && !stat.enumValues) {
        stat.enumValues = options.enumValues || [];
        stat.current    = options.current    ?? (stat.enumValues[0] || '');
    }

    if (stat.type === STAT_TYPES.COMPOSITE) {
        stat.current = options.current ?? stat.max;
        stat.maxKey  = options.maxKey  ?? `${stat.key}_max`;
    }

    if (stat.type === STAT_TYPES.LEVEL) {
        stat.min     = options.min     ?? 1;
        stat.max     = options.max     ?? 100;
        stat.current = options.current ?? stat.min;
    }

    return stat;
}

/**
 * 批量创建属性定义列表
 * @param {Array<Partial<StatDef>>} defList
 * @returns {StatDef[]}
 */
export function createStatDefs(defList) {
    return defList.map(d => createStatDef(d));
}

// ═══════════════════════════════════════════════
// § 3  属性 Schema 验证
// ═══════════════════════════════════════════════

/**
 * 验证属性定义对象是否合法
 *
 * @param {object} stat
 * @returns {{ valid: boolean, errors: string[] }}
 */
export function validateStatDef(stat) {
    const errors = [];

    if (!stat.key || typeof stat.key !== 'string') {
        errors.push('key 不能为空且必须为字符串');
    }
    if (!stat.label || typeof stat.label !== 'string') {
        errors.push('label 不能为空');
    }
    if (!Object.values(STAT_TYPES).includes(stat.type)) {
        errors.push(`type "${stat.type}" 无效，必须为 STAT_TYPES 中的值`);
    }

    // 数值类型的上下限检查
    if ([STAT_TYPES.NUMBER, STAT_TYPES.PERCENT, STAT_TYPES.LEVEL, STAT_TYPES.COMPOSITE]
            .includes(stat.type)) {
        if (typeof stat.min !== 'number') errors.push('min 必须为数字');
        if (typeof stat.max !== 'number') errors.push('max 必须为数字');
        if (stat.min >= stat.max)         errors.push('min 必须小于 max');
    }

    // 枚举类型：枚举值列表检查
    if (stat.type === STAT_TYPES.ENUM) {
        if (!Array.isArray(stat.enumValues) || stat.enumValues.length === 0) {
            errors.push('ENUM 类型必须提供非空的 enumValues 数组');
        }
    }

    // key 命名规范（仅允许字母数字和下划线）
    if (stat.key && !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(stat.key)) {
        errors.push(`key "${stat.key}" 包含非法字符，只允许字母、数字和下划线，且不能以数字开头`);
    }

    return { valid: errors.length === 0, errors };
}

/**
 * 验证属性值是否合法（用于 setStat 之前的检查）
 *
 * @param {StatDef} statDef  - 属性定义
 * @param {*}       value    - 待设置的值
 * @returns {{ valid: boolean, coerced: *, error: string|null }}
 *          coerced: 经过类型矫正的值（如超出范围则 clamp 到边界）
 */
export function validateStatValue(statDef, value) {
    switch (statDef.type) {

        case STAT_TYPES.NUMBER:
        case STAT_TYPES.PERCENT:
        case STAT_TYPES.LEVEL:
        case STAT_TYPES.COMPOSITE: {
            const num = parseFloat(value);
            if (isNaN(num)) {
                return { valid: false, coerced: statDef.current, error: `"${value}" 不是有效数字` };
            }
            const clamped = Math.min(statDef.max, Math.max(statDef.min, num));
            return { valid: true, coerced: clamped, error: null };
        }

        case STAT_TYPES.BOOLEAN: {
            const b = value === true || value === 'true' || value === 1 || value === '1';
            return { valid: true, coerced: b, error: null };
        }

        case STAT_TYPES.ENUM: {
            const opts = statDef.enumValues || [];
            if (!opts.includes(String(value))) {
                return {
                    valid:   false,
                    coerced: statDef.current,
                    error:   `"${value}" 不在枚举值 [${opts.join(', ')}] 中`,
                };
            }
            return { valid: true, coerced: String(value), error: null };
        }

        case STAT_TYPES.TEXT:
            return { valid: true, coerced: String(value ?? ''), error: null };

        default:
            return { valid: true, coerced: value, error: null };
    }
}

// ═══════════════════════════════════════════════
// § 4  内置游戏预设属性组
// ═══════════════════════════════════════════════

/**
 * 奇幻 RPG 属性预设（基础六维 + HP/MP + 战斗状态）
 * @type {StatDef[]}
 */
export const PRESET_FANTASY_BASIC = createStatDefs([
    { key: 'player_hp',      label: '❤️ HP',    type: STAT_TYPES.COMPOSITE, min: 0, max: 100, current: 100, color: '#e74c3c', maxKey: 'player_hp_max' },
    { key: 'player_mp',      label: '💙 MP',    type: STAT_TYPES.COMPOSITE, min: 0, max: 100, current: 100, color: '#3498db', maxKey: 'player_mp_max' },
    { key: 'player_level',   label: '⭐ 等级',  type: STAT_TYPES.LEVEL,     min: 1, max: 99,  current: 1,   color: '#f1c40f' },
    { key: 'player_exp',     label: '✨ 经验',  type: STAT_TYPES.PERCENT,   min: 0, max: 100, current: 0,   color: '#9b59b6' },
    { key: 'player_gold',    label: '💰 金币',  type: STAT_TYPES.NUMBER,    min: 0, max: 999999, current: 0, color: '#f39c12' },
    { key: 'player_str',     label: '⚔️ 力量',  type: STAT_TYPES.NUMBER,    min: 1, max: 99,  current: 10,  color: '#e67e22' },
    { key: 'player_def',     label: '🛡️ 防御',  type: STAT_TYPES.NUMBER,    min: 1, max: 99,  current: 10,  color: '#2ecc71' },
    { key: 'player_spd',     label: '💨 速度',  type: STAT_TYPES.NUMBER,    min: 1, max: 99,  current: 10,  color: '#1abc9c' },
    { key: 'player_int',     label: '📚 智力',  type: STAT_TYPES.NUMBER,    min: 1, max: 99,  current: 10,  color: '#3498db' },
    { key: 'player_luck',    label: '🍀 幸运',  type: STAT_TYPES.NUMBER,    min: 1, max: 99,  current: 10,  color: '#27ae60' },
]);

/**
 * 奇幻 RPG 属性预设（扩展版，加入道德、信仰等社交属性）
 * @type {StatDef[]}
 */
export const PRESET_FANTASY_EXTENDED = createStatDefs([
    ...PRESET_FANTASY_BASIC,
    { key: 'player_morality', label: '⚖️ 道德', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 50, color: '#bdc3c7', display: STAT_DISPLAY.TOOLTIP },
    { key: 'player_fame',     label: '🏆 声望', type: STAT_TYPES.NUMBER,  min: 0, max: 9999, current: 0,  color: '#f1c40f', display: STAT_DISPLAY.TOOLTIP },
    { key: 'player_status',   label: '🔮 状态', type: STAT_TYPES.ENUM,
      enumValues: ['正常', '中毒', '灼烧', '冰冻', '麻痹', '混乱', '石化'],
      current: '正常', color: '#8e44ad' },
]);

/**
 * 恋爱 / 日常互动属性预设
 * @type {StatDef[]}
 */
export const PRESET_ROMANCE = createStatDefs([
    { key: 'affection',     label: '💗 好感度', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 50, color: '#e91e63' },
    { key: 'trust',         label: '🤝 信任度', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 30, color: '#2196f3' },
    { key: 'intimacy',      label: '🌸 亲密度', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 0,  color: '#ff4081' },
    { key: 'relationship',  label: '💑 关系',   type: STAT_TYPES.ENUM,
      enumValues: ['陌生人', '相识', '朋友', '好友', '挚友', '恋人', '伴侣'],
      current: '陌生人', color: '#ff69b4' },
    { key: 'mood',          label: '😊 心情',   type: STAT_TYPES.ENUM,
      enumValues: ['愉快', '平静', '忧郁', '开心', '激动', '愤怒', '悲伤'],
      current: '平静', color: '#ffeb3b' },
    { key: 'energy',        label: '⚡ 精力',   type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 80, color: '#ff9800' },
]);

/**
 * 克苏鲁/恐怖属性预设
 * @type {StatDef[]}
 */
export const PRESET_HORROR = createStatDefs([
    { key: 'sanity',         label: '🧠 理智',   type: STAT_TYPES.COMPOSITE, min: 0, max: 100, current: 100, color: '#9c27b0', maxKey: 'sanity_max' },
    { key: 'hp',             label: '❤️ HP',     type: STAT_TYPES.COMPOSITE, min: 0, max: 100, current: 100, color: '#f44336', maxKey: 'hp_max' },
    { key: 'luck_coc',       label: '🎲 幸运',   type: STAT_TYPES.PERCENT,   min: 0, max: 100, current: 50,  color: '#4caf50' },
    { key: 'fear_level',     label: '😨 恐惧',   type: STAT_TYPES.PERCENT,   min: 0, max: 100, current: 0,   color: '#607d8b' },
    { key: 'knowledge',      label: '📖 禁忌知识', type: STAT_TYPES.NUMBER,  min: 0, max: 99,  current: 0,   color: '#795548', display: STAT_DISPLAY.TOOLTIP },
    { key: 'corruption',     label: '🌀 腐化',   type: STAT_TYPES.PERCENT,   min: 0, max: 100, current: 0,   color: '#4a148c' },
    { key: 'physical_state', label: '🩹 身体状态', type: STAT_TYPES.ENUM,
      enumValues: ['健康', '轻伤', '中伤', '重伤', '濒死'],
      current: '健康', color: '#ef5350' },
]);

/**
 * 现代/都市背景属性预设
 * @type {StatDef[]}
 */
export const PRESET_MODERN = createStatDefs([
    { key: 'health',       label: '❤️ 体力',   type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 100, color: '#e74c3c' },
    { key: 'stress',       label: '😰 压力',   type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 0,   color: '#e67e22' },
    { key: 'money',        label: '💵 金钱',   type: STAT_TYPES.NUMBER,  min: 0, max: 9999999, current: 1000, color: '#27ae60' },
    { key: 'reputation',   label: '🌟 名誉',   type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 50,  color: '#f1c40f' },
    { key: 'connections',  label: '🤝 人脉',   type: STAT_TYPES.NUMBER,  min: 0, max: 999, current: 0,   color: '#3498db' },
    { key: 'skill_level',  label: '🎯 技能',   type: STAT_TYPES.LEVEL,   min: 1, max: 10,  current: 1,   color: '#9b59b6' },
    { key: 'time_day',     label: '📅 当前时间', type: STAT_TYPES.ENUM,
      enumValues: ['清晨', '上午', '中午', '下午', '傍晚', '深夜'],
      current: '上午', color: '#1abc9c' },
]);

/**
 * 极简生存属性预设（仅 HP + 饥饿 + 口渴 + 时间）
 * @type {StatDef[]}
 */
export const PRESET_SURVIVAL = createStatDefs([
    { key: 'hp',       label: '❤️ 生命', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 100, color: '#e74c3c' },
    { key: 'hunger',   label: '🍖 饥饿', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 0,   color: '#e67e22' },
    { key: 'thirst',   label: '💧 口渴', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 0,   color: '#3498db' },
    { key: 'stamina',  label: '⚡ 体力', type: STAT_TYPES.PERCENT, min: 0, max: 100, current: 100, color: '#2ecc71' },
    { key: 'day',      label: '📆 第几天', type: STAT_TYPES.NUMBER, min: 1, max: 9999, current: 1,  color: '#f1c40f' },
]);

/**
 * 自定义空白属性预设（用于完全从零构建）
 * @type {StatDef[]}
 */
export const PRESET_BLANK = [];

// ═══════════════════════════════════════════════
// § 5  预设注册表
// ═══════════════════════════════════════════════

/**
 * 所有内置预设的注册表
 * @type {Array<{ id: string, label: string, description: string, icon: string, stats: StatDef[] }>}
 */
export const STAT_PRESETS = [
    {
        id:          'fantasy_basic',
        label:       '⚔️ 奇幻 RPG（基础）',
        description: '经典 HP/MP/等级 + 六维属性，适合大多数奇幻冒险故事',
        icon:        '⚔️',
        stats:       PRESET_FANTASY_BASIC,
    },
    {
        id:          'fantasy_extended',
        label:       '🏰 奇幻 RPG（扩展）',
        description: '在基础版上增加道德、声望、状态异常等社交属性',
        icon:        '🏰',
        stats:       PRESET_FANTASY_EXTENDED,
    },
    {
        id:          'romance',
        label:       '💗 恋爱 / 互动',
        description: '好感度、信任度、亲密度、关系状态，适合恋爱/日常互动类故事',
        icon:        '💗',
        stats:       PRESET_ROMANCE,
    },
    {
        id:          'horror',
        label:       '🕯️ 克苏鲁 / 恐怖',
        description: '理智值、恐惧值、禁忌知识、腐化度，适合 CoC 及恐怖题材',
        icon:        '🕯️',
        stats:       PRESET_HORROR,
    },
    {
        id:          'modern',
        label:       '🏙️ 现代 / 都市',
        description: '体力、压力、金钱、名誉、人脉，适合现代都市背景故事',
        icon:        '🏙️',
        stats:       PRESET_MODERN,
    },
    {
        id:          'survival',
        label:       '🌲 生存 / 末世',
        description: '极简生存四维（饥饿/口渴/体力/生命），适合荒野或末日题材',
        icon:        '🌲',
        stats:       PRESET_SURVIVAL,
    },
    {
        id:          'blank',
        label:       '📋 空白（自定义）',
        description: '从零开始，完全自定义所有属性',
        icon:        '📋',
        stats:       PRESET_BLANK,
    },
];

/**
 * 根据 ID 获取预设
 * @param {string} id
 * @returns {{ id, label, description, icon, stats }|null}
 */
export function getPreset(id) {
    return STAT_PRESETS.find(p => p.id === id) ?? null;
}

/**
 * 获取所有预设的简要信息（不含 stats 数组，用于 UI 列表显示）
 * @returns {Array<{ id, label, description, icon, count }>}
 */
export function listPresets() {
    return STAT_PRESETS.map(p => ({
        id:          p.id,
        label:       p.label,
        description: p.description,
        icon:        p.icon,
        count:       p.stats.length,
    }));
}

// ═══════════════════════════════════════════════
// § 6  属性工具函数
// ═══════════════════════════════════════════════

/**
 * 将属性值 clamp 到合法范围内
 * @param {StatDef} statDef
 * @param {number}  value
 * @returns {number}
 */
export function clampStatValue(statDef, value) {
    const num = parseFloat(value);
    if (isNaN(num)) return statDef.current;
    return Math.min(statDef.max, Math.max(statDef.min, num));
}

/**
 * 计算属性的百分比（用于进度条渲染）
 * @param {StatDef} statDef
 * @returns {number}  0~100
 */
export function getStatPercent(statDef) {
    const range = statDef.max - statDef.min;
    if (range <= 0) return 0;
    return Math.round(((statDef.current - statDef.min) / range) * 100);
}

/**
 * 根据当前百分比获取颜色（红→黄→绿渐变，用于 HP 等生命属性）
 * @param {number} pct  - 0~100
 * @returns {string}    - CSS 颜色字符串
 */
export function getPercentColor(pct) {
    if (pct > 60) return '#2ecc71';   // 绿
    if (pct > 30) return '#f1c40f';   // 黄
    return '#e74c3c';                  // 红
}

/**
 * 格式化属性值用于 UI 显示
 * @param {StatDef} statDef
 * @returns {string}
 */
export function formatStatValue(statDef) {
    switch (statDef.type) {
        case STAT_TYPES.PERCENT:
            return `${statDef.current}%`;
        case STAT_TYPES.COMPOSITE:
            return `${statDef.current} / ${statDef.max}`;
        case STAT_TYPES.BOOLEAN:
            return statDef.current ? '✅ 是' : '❌ 否';
        case STAT_TYPES.LEVEL:
            return `Lv.${statDef.current}`;
        default:
            return String(statDef.current ?? '');
    }
}

/**
 * 深克隆属性定义列表（防止预设被修改）
 * @param {StatDef[]} defs
 * @returns {StatDef[]}
 */
export function cloneStatDefs(defs) {
    return JSON.parse(JSON.stringify(defs));
}

/**
 * 将属性定义列表转换为 STscript 初始化变量语句
 * （用于在脚本中预设所有变量的初始值）
 *
 * @param {StatDef[]} statDefs
 * @returns {string}  STscript 字符串
 */
export function statsToInitScript(statDefs) {
    const lines = [
        '// ── 属性初始化 ── 由 RPG Tracker 自动生成 ──',
    ];

    statDefs.forEach(stat => {
        lines.push(`/setvar key=${stat.key} value=${stat.current} |`);

        // COMPOSITE 类型同时初始化 maxKey
        if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
            lines.push(`/setvar key=${stat.maxKey} value=${stat.max} |`);
        }
    });

    lines.push('// ── 初始化完成 ──');
    return lines.join('\n');
}