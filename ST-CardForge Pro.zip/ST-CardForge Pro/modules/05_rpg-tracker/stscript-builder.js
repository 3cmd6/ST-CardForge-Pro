/**
 * @file modules/05_rpg-tracker/stscript-builder.js
 * @description RPG Tracker 专用 STscript 构建器
 *              基于当前属性定义，自动生成：
 *              ① 属性初始化脚本  ② 状态条显示脚本  ③ 属性追踪触发器
 *              ④ 存档/读档脚本  ⑤ 属性修改快捷脚本  ⑥ 完整 QR Set JSON
 *              是 RPGTracker 和 ScriptForge 之间的桥梁。
 * @version 1.0.0
 */

import { STAT_TYPES, TRACKING_MODE, STAT_DISPLAY, getStatPercent, formatStatValue } from './stat-definitions.js';

// ═══════════════════════════════════════════════
// § 1  常量
// ═══════════════════════════════════════════════

/** 生成脚本的注释标记（用于识别和更新） */
const SCRIPT_HEADER = '// ══ 由 RPG Tracker · STscript Builder 自动生成 ══';

// ═══════════════════════════════════════════════
// § 2  RPGSTScriptBuilder 主类
// ═══════════════════════════════════════════════

/**
 * RPG Tracker 专用 STscript 构建器主类
 */
export class RPGSTScriptBuilder {
    /**
     * @param {StatDef[]} statDefs  - 属性定义列表
     * @param {object}    [options]
     * @param {string}    [options.statusBarTitle='📊 角色状态']  - 状态条标题
     * @param {boolean}   [options.useEmoji=true]               - 是否使用 emoji
     * @param {string}    [options.savePrefix='save_']          - 存档变量前缀
     */
    constructor(statDefs, options = {}) {
        this._statDefs = statDefs || [];
        this._options  = {
            statusBarTitle: '📊 角色状态',
            useEmoji:       true,
            savePrefix:     'save_',
            ...options,
        };
    }

    /**
     * 更新属性定义列表（属性配置变更后调用）
     * @param {StatDef[]} statDefs
     */
    updateStatDefs(statDefs) {
        this._statDefs = statDefs || [];
    }

    // ─── ① 初始化脚本 ────────────────────────────

    /**
     * 生成属性初始化 STscript
     * 将所有属性的初始值写入 STscript 变量
     *
     * @param {object} [overrides] - key→value，覆盖 statDef 中的默认值
     * @returns {string}
     */
    buildInitScript(overrides = {}) {
        const lines = [
            SCRIPT_HEADER,
            '// § 初始化：将所有属性写入 STscript 变量',
            '',
        ];

        this._statDefs.forEach(stat => {
            const initVal = overrides[stat.key] !== undefined
                ? overrides[stat.key]
                : stat.current;

            lines.push(`/setvar key=${stat.key} value=${initVal} |`);

            // COMPOSITE 类型同时初始化最大值变量
            if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                const maxVal = overrides[stat.maxKey] !== undefined
                    ? overrides[stat.maxKey]
                    : stat.max;
                lines.push(`/setvar key=${stat.maxKey} value=${maxVal} |`);
            }
        });

        lines.push('', `/setvar key=game_state value=active |`);
        lines.push(`/setvar key=turn_count value=0 |`);
        lines.push('', '/echo ✅ 属性已初始化完毕。 |');
        lines.push('// ══ 初始化结束 ══');

        return lines.join('\n');
    }

    // ─── ② 状态条显示脚本 ────────────────────────

    /**
     * 生成状态条显示 STscript（调用时 echo 出当前所有属性）
     * @returns {string}
     */
    buildStatusBarScript() {
        const lines = [
            SCRIPT_HEADER,
            '// § 状态条：显示所有可见属性当前值',
            '',
        ];

        const divider = '─'.repeat(28);

        lines.push(`/echo ${divider} |`);
        lines.push(`/echo ${this._options.statusBarTitle} |`);
        lines.push(`/echo ${divider} |`);

        // 显示各属性
        const visibleStats = this._statDefs.filter(
            s => s.visible !== false && s.display !== STAT_DISPLAY.HIDDEN
        );

        visibleStats.forEach(stat => {
            lines.push(this._buildStatDisplayLine(stat));
        });

        lines.push(`/echo ${divider} |`);
        lines.push(`/echo 回合：{{getvar::turn_count}} |`);

        return lines.join('\n');
    }

    /**
     * 构建单个属性的 echo 显示行
     * @param {StatDef} stat
     * @returns {string}
     */
    _buildStatDisplayLine(stat) {
        switch (stat.type) {
            case STAT_TYPES.COMPOSITE:
                return `/echo ${stat.label}：{{getvar::${stat.key}}} / {{getvar::${stat.maxKey || stat.key + '_max'}}} |`;

            case STAT_TYPES.PERCENT:
                return `/echo ${stat.label}：{{getvar::${stat.key}}}% |`;

            case STAT_TYPES.BOOLEAN:
                return [
                    `/if left={{getvar::${stat.key}}} right=true eq`,
                    `    /echo ${stat.label}：✅ 是 |`,
                    `/else`,
                    `    /echo ${stat.label}：❌ 否 |`,
                ].join('\n');

            case STAT_TYPES.LEVEL:
                return `/echo ${stat.label}：Lv.{{getvar::${stat.key}}} |`;

            default:
                return `/echo ${stat.label}：{{getvar::${stat.key}}} |`;
        }
    }

    // ─── ③ 属性追踪触发器 ────────────────────────

    /**
     * 生成 AI 消息追踪触发器脚本
     * 每次 AI 回复后自动运行，尝试从消息内容中提取属性变化
     *
     * @param {StatDef[]} [trackedStats] - 指定追踪哪些属性（不传则追踪所有设为 AUTO_AI 的属性）
     * @returns {string}
     */
    buildTrackingScript(trackedStats) {
        const targets = (trackedStats || this._statDefs).filter(
            s => s.tracking === TRACKING_MODE.AUTO_AI
        );

        if (targets.length === 0) {
            return '// （无需 AI 追踪的属性）';
        }

        const lines = [
            SCRIPT_HEADER,
            '// § 自动追踪：从 AI 消息中提取属性变化',
            '// 注意：此脚本应设为「AI 回复后自动执行」',
            '',
            '// 回合计数递增',
            '/setvar key=turn_count value={{math::{{getvar::turn_count}}+1}} |',
            '',
        ];

        targets.forEach(stat => {
            lines.push(...this._buildSingleStatTracking(stat));
            lines.push('');
        });

        // 属性归零检查（生命值等关键属性）
        const criticalStats = targets.filter(s =>
            s.type === STAT_TYPES.COMPOSITE || s.type === STAT_TYPES.PERCENT
        );

        if (criticalStats.length > 0) {
            lines.push('// § 关键属性归零检查');
            criticalStats.forEach(stat => {
                lines.push(
                    `/if left={{getvar::${stat.key}}} right=0 lte`,
                    `    /setvar key=${stat.key} value=0 |`,
                    `    /setvar key=${stat.key}_zeroed value=true |`,
                );
            });
        }

        lines.push('', '// ══ 追踪脚本结束 ══');
        return lines.join('\n');
    }

    /**
     * 为单个属性生成追踪逻辑
     * @param {StatDef} stat
     * @returns {string[]}
     */
    _buildSingleStatTracking(stat) {
        const varName = `_track_${stat.key}`;

        // 使用正则或关键词从最后一条 AI 消息提取变化量
        // 检测格式：「${属性名}+N」「${属性名}-N」「${属性名}: N」等
        const patterns = [
            stat.key,
            stat.label.replace(/[^\w\u4e00-\u9fa5]/g, ''),  // 去除非字母/汉字字符
        ].filter(Boolean);

        const lines = [
            `// 追踪：${stat.label}（${stat.key}）`,
        ];

        // 尝试从 lastMessage 中检测关键词变化
        // 简化实现：检测「+N」和「-N」在属性名附近
        patterns.forEach(pattern => {
            lines.push(
                `/if left={{lastMessage}} right=${pattern} contains`,
                `    // 检测到属性变化关键词：${pattern}`,
                `    // 实际值由 AI 变量追踪插件（如 LALib）处理`,
                `    /setvar key=${varName}_mentioned value=true |`,
            );
        });

        return lines;
    }

    // ─── ④ 存档/读档脚本 ─────────────────────────

    /**
     * 生成存档脚本
     * 将所有当前属性值复制到 save_* 变量
     *
     * @returns {string}
     */
    buildSaveScript() {
        const prefix = this._options.savePrefix;
        const lines  = [
            SCRIPT_HEADER,
            '// § 存档：保存当前所有属性值',
            '',
        ];

        this._statDefs.forEach(stat => {
            lines.push(`/setvar key=${prefix}${stat.key} value={{getvar::${stat.key}}} |`);

            if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                lines.push(`/setvar key=${prefix}${stat.maxKey} value={{getvar::${stat.maxKey}}} |`);
            }
        });

        lines.push(`/setvar key=${prefix}turn_count  value={{getvar::turn_count}} |`);
        lines.push(`/setvar key=${prefix}game_state  value={{getvar::game_state}} |`);
        lines.push(`/setvar key=${prefix}saved_at    value={{date}} |`);
        lines.push(`/setvar key=has_save value=true |`);
        lines.push('', '/echo 💾 **存档成功！** 已保存所有属性。 |');
        lines.push('// ══ 存档结束 ══');

        return lines.join('\n');
    }

    /**
     * 生成读档脚本
     * 从 save_* 变量恢复所有属性值
     *
     * @returns {string}
     */
    buildLoadScript() {
        const prefix = this._options.savePrefix;
        const lines  = [
            SCRIPT_HEADER,
            '// § 读档：恢复所有属性值',
            '',
            '/if left={{getvar::has_save}} right=true eq',
        ];

        const indentLines = [];
        this._statDefs.forEach(stat => {
            indentLines.push(`    /setvar key=${stat.key} value={{getvar::${prefix}${stat.key}}} |`);

            if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                indentLines.push(`    /setvar key=${stat.maxKey} value={{getvar::${prefix}${stat.maxKey}}} |`);
            }
        });

        indentLines.push(`    /setvar key=turn_count value={{getvar::${prefix}turn_count}} |`);
        indentLines.push(`    /setvar key=game_state value={{getvar::${prefix}game_state}} |`);
        indentLines.push(`    /echo 📂 **读档成功！** 已恢复存档（${prefix}saved_at 时间）。 |`);

        lines.push(...indentLines);
        lines.push('/else');
        lines.push('    /echo ⚠️ 暂无存档，请先存档。 |');
        lines.push('// ══ 读档结束 ══');

        return lines.join('\n');
    }

    // ─── ⑤ 属性修改快捷脚本 ──────────────────────

    /**
     * 生成属性增减的快捷 STscript 片段
     *
     * @param {string} statKey  - 属性 key
     * @param {number} delta    - 变化量（正数增加，负数减少）
     * @param {string} [reason] - 变化原因（用于 echo 说明）
     * @returns {string}
     */
    buildModifyScript(statKey, delta, reason = '') {
        const stat    = this._statDefs.find(s => s.key === statKey);
        const label   = stat?.label || statKey;
        const sign    = delta >= 0 ? '+' : '';
        const op      = delta >= 0 ? '+' : '-';
        const absVal  = Math.abs(delta);

        const lines = [
            `// ${label} ${sign}${delta}${reason ? `（${reason}）` : ''}`,
            `/setvar key=${statKey} value={{math::{{getvar::${statKey}}} ${op} ${absVal}}} |`,
        ];

        // 加入上下限限制
        if (stat) {
            if (stat.max !== undefined) {
                lines.push(
                    `/if left={{getvar::${statKey}}} right=${stat.max} gt`,
                    `    /setvar key=${statKey} value=${stat.max} |`,
                );
            }
            if (stat.min !== undefined) {
                lines.push(
                    `/if left={{getvar::${statKey}}} right=${stat.min} lt`,
                    `    /setvar key=${statKey} value=${stat.min} |`,
                );
            }
        }

        lines.push(
            `/echo ${label}：${sign}${delta}${reason ? `（${reason}）` : ''} → {{getvar::${statKey}}} |`
        );

        return lines.join('\n');
    }

    /**
     * 生成属性直接设置脚本
     * @param {string} statKey
     * @param {number|string} value
     * @param {string}        [reason]
     * @returns {string}
     */
    buildSetScript(statKey, value, reason = '') {
        const stat  = this._statDefs.find(s => s.key === statKey);
        const label = stat?.label || statKey;

        return [
            `// 设置 ${label} = ${value}${reason ? `（${reason}）` : ''}`,
            `/setvar key=${statKey} value=${value} |`,
            `/echo ${label} 已设置为 ${value}${reason ? `（${reason}）` : ''} |`,
        ].join('\n');
    }

    // ─── ⑥ 完整 QR Set 生成 ─────────────────────

    /**
     * 生成包含所有 RPG Tracker 功能按钮的完整 QR Set JSON
     *
     * @param {string} qrSetName - QR Set 名称
     * @returns {object}  SillyTavern 可直接导入的 QR Set JSON
     */
    buildFullQRSet(qrSetName = 'rpg_tracker') {
        const replies = [];
        let   idx     = 1;

        const addReply = (label, title, script, autoOnAi = false, hidden = false) => {
            replies.push({
                id:               idx++,
                label,
                title,
                message:          script,
                contextMenu:      '',
                preventInput:     true,
                isHidden:         hidden,
                executeOnUser:    false,
                executeOnAi:      autoOnAi,
                autoExecute:      autoOnAi,
                extensionPrompt:  '',
                extensionPromptPos: 0,
            });
        };

        // 核心功能按钮
        addReply('📊 查看状态',   `${qrSetName}_status`,   this.buildStatusBarScript());
        addReply('💾 存档',       `${qrSetName}_save`,     this.buildSaveScript());
        addReply('📂 读档',       `${qrSetName}_load`,     this.buildLoadScript());
        addReply('🔄 重置属性',   `${qrSetName}_init`,     this.buildInitScript());

        // 自动追踪触发器（隐藏，AI 回复后自动执行）
        const trackScript = this.buildTrackingScript();
        if (trackScript !== '// （无需 AI 追踪的属性）') {
            addReply('🔔 自动追踪',  `${qrSetName}_track`,   trackScript, true, true);
        }

        // 每个属性生成快捷修改按钮（仅数值类型、显示在状态条的）
        const numericStats = this._statDefs.filter(s =>
            [STAT_TYPES.NUMBER, STAT_TYPES.COMPOSITE, STAT_TYPES.PERCENT].includes(s.type) &&
            s.display === STAT_DISPLAY.STATUS_BAR
        );

        numericStats.forEach(stat => {
            // +1 按钮
            addReply(
                `${stat.label} +1`,
                `${qrSetName}_${stat.key}_plus`,
                this.buildModifyScript(stat.key, 1),
            );
            // -1 按钮（如果 min < 当前值）
            if (stat.min < stat.current) {
                addReply(
                    `${stat.label} -1`,
                    `${qrSetName}_${stat.key}_minus`,
                    this.buildModifyScript(stat.key, -1),
                );
            }
        });

        return {
            version:               '1.0',
            name:                  qrSetName,
            disabledByDefault:     false,
            isGlobal:              false,
            quickReplySetCommands: [],
            quickReplies:          replies,
        };
    }

    // ─── ⑦ 完整脚本包 ────────────────────────────

    /**
     * 一次性生成所有脚本（返回命名脚本集合）
     * @param {string} qrSetName
     * @returns {{
     *   initScript:        string,
     *   statusBarScript:   string,
     *   trackingScript:    string,
     *   saveScript:        string,
     *   loadScript:        string,
     *   qrSetJSON:         object,
     * }}
     */
    buildAll(qrSetName = 'rpg_tracker') {
        return {
            initScript:       this.buildInitScript(),
            statusBarScript:  this.buildStatusBarScript(),
            trackingScript:   this.buildTrackingScript(),
            saveScript:       this.buildSaveScript(),
            loadScript:       this.buildLoadScript(),
            qrSetJSON:        this.buildFullQRSet(qrSetName),
        };
    }
}

// ═══════════════════════════════════════════════
// § 3  独立脚本工具函数
// ═══════════════════════════════════════════════

/**
 * 生成单个属性的 clamp 保护脚本片段（防止超出范围）
 * @param {string} key
 * @param {number} min
 * @param {number} max
 * @returns {string}
 */
export function buildClampScript(key, min, max) {
    return [
        `/if left={{getvar::${key}}} right=${max} gt`,
        `    /setvar key=${key} value=${max} |`,
        `/if left={{getvar::${key}}} right=${min} lt`,
        `    /setvar key=${key} value=${min} |`,
    ].join('\n');
}

/**
 * 生成属性条件检查脚本
 * 如果属性满足条件，执行指定脚本
 *
 * @param {string} key
 * @param {string} operator    - 'eq'|'neq'|'gt'|'gte'|'lt'|'lte'
 * @param {number|string} value
 * @param {string} thenScript
 * @param {string} [elseScript]
 * @returns {string}
 */
export function buildStatConditionScript(key, operator, value, thenScript, elseScript = '') {
    const lines = [
        `/if left={{getvar::${key}}} right=${value} ${operator}`,
        ...thenScript.split('\n').map(l => `    ${l}`),
    ];

    if (elseScript) {
        lines.push('/else');
        lines.push(...elseScript.split('\n').map(l => `    ${l}`));
    }

    return lines.join('\n');
}