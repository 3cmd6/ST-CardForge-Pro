/**
 * @file modules/05_rpg-tracker/worldinfo-sync.js
 * @description RPG Tracker ↔ SillyTavern World Info 同步器
 *              负责将当前 RPG 属性状态持久化到 World Info 条目，
 *              并在每次属性变化后自动更新，确保 AI 能感知到最新的游戏状态。
 *              同时支持从已有 World Info 读取属性初始值，实现双向同步。
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import { STAT_TYPES, formatStatValue } from './stat-definitions.js';

// ═══════════════════════════════════════════════
// § 1  常量
// ═══════════════════════════════════════════════

/** World Info 条目关键词（用于识别和更新） */
export const WI_KEYWORDS = {
    /** 所有属性状态的主条目关键词 */
    STATS_ENTRY:     ['__rpg_stats__', 'rpg_tracker_status'],
    /** 历史变化摘要条目关键词 */
    HISTORY_ENTRY:   ['__rpg_history__', 'rpg_tracker_history'],
    /** 事件日志条目关键词 */
    EVENT_ENTRY:     ['__rpg_events__', 'rpg_tracker_events'],
};

/** World Info 条目固定 UID 范围（避免与用户条目冲突） */
const RESERVED_UID_BASE = 900000;

/** ST World Info API 挂载路径（通过 window 访问） */
const ST_WI_API_PATH = 'SillyTavern.getContext';

// ═══════════════════════════════════════════════
// § 2  WorldInfoSync 主类
// ═══════════════════════════════════════════════

/**
 * RPG 属性 ↔ World Info 同步器
 */
export class WorldInfoSync {
    /**
     * @param {object} eventBus - EventBus 实例
     * @param {object} [options]
     * @param {boolean} [options.autoSync=true]          - 属性变化时是否自动同步
     * @param {number}  [options.debounceMs=1000]        - 自动同步防抖延迟（毫秒）
     * @param {boolean} [options.includeHistory=true]    - 是否同步历史摘要
     * @param {number}  [options.historyLines=5]         - 历史摘要显示的条数
     * @param {boolean} [options.constantEntry=true]     - 是否设为常驻条目（constant）
     * @param {number}  [options.insertionOrder=999]     - 条目插入优先级
     * @param {string}  [options.position='before_char'] - 条目注入位置
     * @param {Function}[options.onSyncComplete]         - 同步完成回调
     * @param {Function}[options.onSyncError]            - 同步失败回调
     */
    constructor(eventBus, options = {}) {
        this._bus     = eventBus;
        this._options = {
            autoSync:       true,
            debounceMs:     1000,
            includeHistory: true,
            historyLines:   5,
            constantEntry:  true,
            insertionOrder: 999,
            position:       'before_char',
            onSyncComplete: null,
            onSyncError:    null,
            ...options,
        };

        /** @type {boolean} World Info API 是否可用 */
        this._wiAvailable   = false;

        /** @type {Map<string, number>} 已创建条目的 WI UID 缓存 */
        this._entryUIDCache = new Map();

        /** @type {number|null} 防抖定时器 */
        this._debounceTimer = null;

        /** @type {boolean} 是否正在同步 */
        this._syncing       = false;

        /** @type {string[]} 订阅取消函数 */
        this._unsubs        = [];
    }

    // ─── 初始化 ───────────────────────────────────

    /**
     * 初始化同步器，检测 ST World Info API 可用性
     * @returns {Promise<boolean>}  true 表示 API 可用
     */
    async init() {
        this._wiAvailable = this._detectWIAPI();

        if (!this._wiAvailable) {
            console.warn('[WorldInfoSync] SillyTavern World Info API 不可用，同步功能降级为仅控制台输出');
        }

        if (this._options.autoSync) {
            this._subscribeStatChanges();
        }

        return this._wiAvailable;
    }

    /**
     * 销毁同步器，清理订阅和定时器
     */
    destroy() {
        this._unsubs.forEach(fn => fn());
        this._unsubs = [];
        if (this._debounceTimer) clearTimeout(this._debounceTimer);
    }

    // ─── 核心同步 API ─────────────────────────────

    /**
     * 立即将所有属性状态同步到 World Info
     *
     * @param {StatDef[]} statDefs      - 当前属性定义列表
     * @param {object}    currentValues - 当前属性值快照（key→value）
     * @param {object}    [historyLogger] - HistoryLogger 实例（可选，用于获取历史摘要）
     * @returns {Promise<{ success: boolean, uid: number|null, error: string|null }>}
     */
    async syncToWorldInfo(statDefs, currentValues, historyLogger = null) {
        if (this._syncing) return { success: false, uid: null, error: '上一次同步尚未完成' };

        this._syncing = true;

        try {
            // 构建 World Info 条目内容
            const content = this._buildWIContent(statDefs, currentValues, historyLogger);

            if (!this._wiAvailable) {
                // 降级：仅打印日志
                console.log('[WorldInfoSync] 模拟同步（WI API 不可用）：\n' + content);
                return { success: true, uid: null, error: null };
            }

            // 写入 World Info 条目
            const uid = await this._writeWIEntry(
                'stats',
                WI_KEYWORDS.STATS_ENTRY,
                content
            );

            // 同步历史摘要（如果开启）
            if (this._options.includeHistory && historyLogger) {
                const historySummary = historyLogger.generateSummary(this._options.historyLines);
                await this._writeWIEntry(
                    'history',
                    WI_KEYWORDS.HISTORY_ENTRY,
                    historySummary
                );
            }

            if (this._options.onSyncComplete) {
                this._options.onSyncComplete({ uid, content });
            }

            this._bus.emit(EVENTS.MODULE_READY, {
                module: 'WorldInfoSync', action: 'synced', uid,
            });

            return { success: true, uid, error: null };

        } catch (error) {
            const errMsg = error?.message || String(error);
            console.error('[WorldInfoSync] 同步失败：', errMsg);

            if (this._options.onSyncError) {
                this._options.onSyncError(error);
            }

            return { success: false, uid: null, error: errMsg };

        } finally {
            this._syncing = false;
        }
    }

    /**
     * 从 World Info 读取属性初始值
     * 扫描关键词匹配的条目，解析其中的 key=value 格式
     *
     * @returns {Promise<object>}  key→value 的初始值映射
     */
    async readFromWorldInfo() {
        if (!this._wiAvailable) return {};

        try {
            const entries = await this._getAllWIEntries();
            const statsEntry = entries.find(e =>
                e.keys?.some(k => WI_KEYWORDS.STATS_ENTRY.includes(k))
            );

            if (!statsEntry?.content) return {};

            return this._parseWIContent(statsEntry.content);

        } catch (error) {
            console.error('[WorldInfoSync] 读取 World Info 失败：', error.message);
            return {};
        }
    }

    /**
     * 删除所有由 RPG Tracker 创建的 World Info 条目
     * @returns {Promise<number>}  删除的条目数量
     */
    async cleanupWIEntries() {
        if (!this._wiAvailable) return 0;

        let count = 0;
        for (const [entryType, uid] of this._entryUIDCache) {
            try {
                await this._deleteWIEntry(uid);
                count++;
            } catch (_) { /* 忽略单条删除失败 */ }
        }
        this._entryUIDCache.clear();
        return count;
    }

    // ─── 内容构建 ─────────────────────────────────

    /**
     * 构建 World Info 条目的文本内容
     * 格式对 AI 友好，便于理解当前游戏状态
     *
     * @param {StatDef[]} statDefs
     * @param {object}    values   - key→value 映射
     * @param {object}    [historyLogger]
     * @returns {string}
     */
    _buildWIContent(statDefs, values, historyLogger) {
        const lines = [
            '【当前游戏状态】',
            `更新时间：${new Date().toLocaleString()}`,
            '',
        ];

        // 按显示分组组织属性
        const statusBarStats = statDefs.filter(s => s.display !== 'hidden' && s.visible !== false);

        if (statusBarStats.length > 0) {
            lines.push('— 角色属性 —');
            statusBarStats.forEach(stat => {
                const val = values[stat.key] ?? stat.current;
                const display = this._formatForWI(stat, val);
                lines.push(`${stat.label}：${display}`);

                // COMPOSITE 类型同时显示最大值
                if (stat.type === STAT_TYPES.COMPOSITE && stat.maxKey) {
                    const maxVal = values[stat.maxKey] ?? stat.max;
                    lines[lines.length - 1] = `${stat.label}：${val} / ${maxVal}`;
                }
            });
        }

        // 游戏状态变量
        const gameStateKeys = ['game_state', 'current_chapter', 'quest_status', 'game_difficulty'];
        const gameStateLines = gameStateKeys
            .filter(k => values[k] !== undefined)
            .map(k => `${k}：${values[k]}`);

        if (gameStateLines.length > 0) {
            lines.push('', '— 游戏进度 —');
            lines.push(...gameStateLines);
        }

        // 最近历史摘要
        if (historyLogger && this._options.includeHistory) {
            const summary = historyLogger.generateSummary(this._options.historyLines);
            lines.push('', summary);
        }

        return lines.join('\n');
    }

    /**
     * 将 World Info 内容解析为 key→value 映射
     * @param {string} content
     * @returns {object}
     */
    _parseWIContent(content) {
        const result = {};
        const lines  = content.split('\n');

        lines.forEach(line => {
            // 匹配 "key：value" 或 "key: value" 格式
            const match = line.match(/^(.+?)[：:]\s*(.+)$/);
            if (!match) return;

            const key   = match[1].trim();
            const value = match[2].trim();

            // 尝试解析数字
            const num = parseFloat(value);
            result[key] = isNaN(num) ? value : num;
        });

        return result;
    }

    /**
     * 格式化属性值用于 World Info 显示
     * @param {StatDef} stat
     * @param {*}       value
     * @returns {string}
     */
    _formatForWI(stat, value) {
        switch (stat.type) {
            case STAT_TYPES.PERCENT:
                return `${value}%`;
            case STAT_TYPES.BOOLEAN:
                return value ? '是' : '否';
            case STAT_TYPES.LEVEL:
                return `Lv.${value}`;
            case STAT_TYPES.COMPOSITE:
                return String(value);
            default:
                return String(value ?? '');
        }
    }

    // ─── ST World Info API 调用（私有）─────────────

    /**
     * 检测 SillyTavern World Info API 是否可用
     * @returns {boolean}
     */
    _detectWIAPI() {
        try {
            // ST 通过 window.SillyTavern 或 jQuery 插件暴露 API
            return typeof window !== 'undefined' &&
                (typeof window.SillyTavern !== 'undefined' ||
                 typeof window.createWorldInfoEntry === 'function' ||
                 typeof window.getWorldInfoBookEntries === 'function');
        } catch (_) {
            return false;
        }
    }

    /**
     * 写入 World Info 条目（创建或更新）
     *
     * @param {string}   entryType  - 条目类型标识（'stats'|'history'|'events'）
     * @param {string[]} keywords   - 条目关键词列表
     * @param {string}   content    - 条目内容
     * @returns {Promise<number>}   UID
     */
    async _writeWIEntry(entryType, keywords, content) {
        // 尝试调用 ST 全局 API
        const ctx = this._getSTContext();

        if (!ctx) throw new Error('SillyTavern Context 不可用');

        const existingUID = this._entryUIDCache.get(entryType);

        if (existingUID !== undefined) {
            // 更新已有条目
            await this._updateEntry(ctx, existingUID, content);
            return existingUID;
        } else {
            // 创建新条目
            const uid = await this._createEntry(ctx, keywords, content);
            this._entryUIDCache.set(entryType, uid);
            return uid;
        }
    }

    /**
     * 获取所有 World Info 条目
     * @returns {Promise<object[]>}
     */
    async _getAllWIEntries() {
        const ctx = this._getSTContext();
        if (!ctx) return [];

        try {
            // ST 1.12+ API
            if (typeof ctx.getWorldInfoEntries === 'function') {
                return await ctx.getWorldInfoEntries() || [];
            }
            // 降级尝试
            if (typeof window.getWorldInfoBookEntries === 'function') {
                return await window.getWorldInfoBookEntries() || [];
            }
        } catch (_) { /* ignore */ }

        return [];
    }

    /**
     * 创建新 World Info 条目
     * @param {object}   ctx
     * @param {string[]} keywords
     * @param {string}   content
     * @returns {Promise<number>}  新条目的 UID
     */
    async _createEntry(ctx, keywords, content) {
        const entryData = {
            keys:           keywords,
            secondary_keys: [],
            content,
            enabled:        true,
            insertion_order: this._options.insertionOrder,
            priority:        10,
            position:        this._options.position,
            depth:           4,
            selective:       false,
            constant:        this._options.constantEntry,
            category:        'RPG Tracker（自动）',
            extensions:      { cardforge_managed: true },
        };

        try {
            if (typeof ctx.createWorldInfoEntry === 'function') {
                return await ctx.createWorldInfoEntry(entryData);
            }
            if (typeof window.createWorldInfoEntry === 'function') {
                return await window.createWorldInfoEntry(entryData);
            }
        } catch (err) {
            throw new Error(`创建 World Info 条目失败：${err.message}`);
        }

        // 降级：生成一个假 UID（不会真正写入）
        return RESERVED_UID_BASE + Date.now() % 100000;
    }

    /**
     * 更新已有 World Info 条目内容
     * @param {object} ctx
     * @param {number} uid
     * @param {string} content
     */
    async _updateEntry(ctx, uid, content) {
        try {
            if (typeof ctx.updateWorldInfoEntry === 'function') {
                await ctx.updateWorldInfoEntry(uid, { content });
                return;
            }
            if (typeof window.updateWorldInfoEntry === 'function') {
                await window.updateWorldInfoEntry(uid, { content });
            }
        } catch (err) {
            // 更新失败时从缓存中移除，下次重新创建
            for (const [key, val] of this._entryUIDCache) {
                if (val === uid) { this._entryUIDCache.delete(key); break; }
            }
            throw err;
        }
    }

    /**
     * 删除 World Info 条目
     * @param {number} uid
     */
    async _deleteWIEntry(uid) {
        const ctx = this._getSTContext();
        if (!ctx) return;

        try {
            if (typeof ctx.deleteWorldInfoEntry === 'function') {
                await ctx.deleteWorldInfoEntry(uid);
            } else if (typeof window.deleteWorldInfoEntry === 'function') {
                await window.deleteWorldInfoEntry(uid);
            }
        } catch (_) { /* 忽略删除失败 */ }
    }

    /**
     * 获取 SillyTavern 上下文对象
     * @returns {object|null}
     */
    _getSTContext() {
        try {
            if (typeof window.SillyTavern?.getContext === 'function') {
                return window.SillyTavern.getContext();
            }
        } catch (_) { /* ignore */ }
        return null;
    }

    // ─── 自动同步订阅（私有）────────────────────

    /**
     * 订阅属性变化事件，触发防抖同步
     */
    _subscribeStatChanges() {
        const unsub = this._bus.on(EVENTS.RPG_STAT_CHANGED, () => {
            this._scheduleSyncDebounced();
        });
        this._unsubs.push(unsub);
    }

    /**
     * 防抖调度同步
     * 在最后一次属性变化后等待 debounceMs 毫秒才真正同步
     */
    _scheduleSyncDebounced() {
        if (this._debounceTimer) clearTimeout(this._debounceTimer);
        this._debounceTimer = setTimeout(() => {
            // 触发全量同步信号（由 RPGTracker 收到后调用 syncToWorldInfo）
            this._bus.emit(EVENTS.RPG_STAT_CHANGED, { _requestSync: true });
        }, this._options.debounceMs);
    }
}

// ═══════════════════════════════════════════════
// § 3  独立工具函数
// ═══════════════════════════════════════════════

/**
 * 将属性列表格式化为适合注入 World Info 的 AI 可读文本
 * （可单独使用，不需要 WorldInfoSync 实例）
 *
 * @param {StatDef[]} statDefs
 * @param {object}    values   - key→value 快照
 * @param {object}    [options]
 * @param {boolean}   [options.compact=false]  - 紧凑模式（单行）
 * @param {boolean}   [options.onlyVisible=true] - 仅包含可见属性
 * @returns {string}
 */
export function formatStatsForAI(statDefs, values, options = {}) {
    const { compact = false, onlyVisible = true } = options;

    const filtered = onlyVisible
        ? statDefs.filter(s => s.visible !== false && s.display !== 'hidden')
        : statDefs;

    if (filtered.length === 0) return '（无属性）';

    if (compact) {
        // 紧凑模式：全部拼在一行
        return filtered.map(stat => {
            const val = values[stat.key] ?? stat.current;
            const max = stat.type === STAT_TYPES.COMPOSITE
                ? `/${values[stat.maxKey] ?? stat.max}`
                : '';
            return `${stat.label}${val}${max}`;
        }).join('  ');
    }

    // 详细模式：每行一个属性
    return filtered.map(stat => {
        const val = values[stat.key] ?? stat.current;
        if (stat.type === STAT_TYPES.COMPOSITE) {
            const maxVal = values[stat.maxKey] ?? stat.max;
            const pct    = Math.round((val / maxVal) * 100);
            return `${stat.label}：${val}/${maxVal}（${pct}%）`;
        }
        if (stat.type === STAT_TYPES.PERCENT) return `${stat.label}：${val}%`;
        return `${stat.label}：${val}`;
    }).join('\n');
}