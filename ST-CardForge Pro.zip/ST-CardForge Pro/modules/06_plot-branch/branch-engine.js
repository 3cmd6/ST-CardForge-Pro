/**
 * @file branch-engine.js
 * @description 剧情分支系统主引擎
 *              整合 EndingSystem / STScriptExporter / VisualTreeEditor
 *              提供统一的 IModule 接口供 index.js 使用
 * @module BranchEngine
 * @version 1.0.0
 */

import {
    EVENTS,
    BRANCH_NODE_SCHEMA,
    MODULE_INTERFACE,
} from '../../contracts.js';

import { evaluateCondition, parseCondition } from './condition-parser.js';
import { EndingSystem, ENDING_TYPES }         from './ending-system.js';
import { STScriptExporter }                   from './stscript-exporter.js';
import { VisualTreeEditor }                   from './visual-tree-editor.js';

// ─────────────────────────────────────────────
// § 内部常量
// ─────────────────────────────────────────────

/**
 * 新节点时的默认内容
 */
const DEFAULT_NODE_CONTENT = {
    normal:    '（在此填写剧情内容）',
    condition: '（条件分支节点）',
    choice:    '（玩家选择节点）',
    ending:    '（结局剧情文本）',
};

// ─────────────────────────────────────────────
// § BranchEngine 类
// ─────────────────────────────────────────────

/**
 * 剧情分支系统主引擎
 * @implements {IModule}
 */
export class BranchEngine {

    /**
     * @param {import('../../core/ai-engine.js').AIEngine}           aiEngine
     * @param {import('../../core/event-bus.js').EventBus}            eventBus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     * @param {import('../../utils/indexeddb-store.js').IndexedDBStore}  dbStore
     */
    constructor(aiEngine, eventBus, settings, dbStore) {
        /** @type {import('../../core/ai-engine.js').AIEngine} */
        this._ai = aiEngine;

        /** @type {import('../../core/event-bus.js').EventBus} */
        this._eventBus = eventBus;

        /** @type {import('../../core/settings-manager.js').SettingsManager} */
        this._settings = settings;

        /** @type {import('../../utils/indexeddb-store.js').IndexedDBStore} */
        this._dbStore = dbStore;

        /**
         * 所有节点 Map，key = node.id
         * @type {Map<string, Object>}
         */
        this._nodes = new Map();

        /** 根节点 ID @type {string|null} */
        this._rootId = null;

        /** 节点 ID 自增计数器 @type {number} */
        this._idCounter = 0;

        /** 结局系统实例 @type {EndingSystem} */
        this._endingSystem = new EndingSystem(eventBus, dbStore);

        /** STScript 导出器实例 @type {STScriptExporter} */
        this._exporter = new STScriptExporter();

        /** 可视化编辑器实例（懒创建） @type {VisualTreeEditor|null} */
        this._visualEditor = null;

        /** 是否已初始化 @type {boolean} */
        this._ready = false;

        /** 事件订阅取消函数 @type {Function[]} */
        this._unsubscribers = [];
    }

    // ── IModule 接口 ─────────────────────────

    /**
     * 模块初始化
     * @returns {Promise<void>}
     */
    async init() {
        try {
            // 初始化结局系统（恢复持久化状态）
            await this._endingSystem.init();

            // 尝试从 IDB 恢复上次会话的分支树
            await this._loadTreeFromDB();

            // 注册事件监听
            this._registerEventListeners();

            this._ready = true;

            this._eventBus.emit(EVENTS.MODULE_READY, { module: 'BranchEngine' });
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  'init',
                error,
                context: {},
            });
            throw error;
        }
    }

    /**
     * 模块销毁
     */
    destroy() {
        this._unsubscribers.forEach(fn => fn());
        this._unsubscribers = [];

        if (this._visualEditor) {
            this._visualEditor.destroy();
            this._visualEditor = null;
        }

        this._endingSystem.destroy();
        this._nodes.clear();
        this._ready = false;
    }

    /**
     * 获取当前模块状态（用于接力文档）
     * @returns {Object}
     */
    getState() {
        return {
            nodeCount:  this._nodes.size,
            rootId:     this._rootId,
            endings:    this._endingSystem.getStats(),
            isReady:    this._ready,
        };
    }

    /**
     * @returns {boolean}
     */
    isReady() {
        return this._ready;
    }

    // ── 树结构管理 ───────────────────────────

    /**
     * 创建新节点
     * @param {'normal'|'condition'|'choice'|'ending'} type
     * @param {string|null} [parentId]  父节点 ID（null 表示创建根节点）
     * @param {string}      [label]     节点标签
     * @returns {string}  新节点 ID
     */
    createNode(type, parentId = null, label = '') {
        const id = this._generateId();

        const node = {
            ...JSON.parse(JSON.stringify(BRANCH_NODE_SCHEMA)),
            id,
            type,
            label:   label || `${this._typeLabel(type)} #${this._idCounter}`,
            content: DEFAULT_NODE_CONTENT[type] || '',
        };

        this._nodes.set(id, node);

        // 无根节点时，第一个节点成为根节点
        if (!this._rootId) {
            this._rootId = id;
        }

        // 挂到父节点下
        if (parentId) {
            this._attachToParent(id, parentId);
        }

        this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
            action: 'create',
            nodeId: id,
            node:   { ...node },
        });

        this._persistTree();
        return id;
    }

    /**
     * 更新节点数据
     * @param {string} id
     * @param {Partial<Object>} changes
     * @returns {boolean}
     */
    updateNode(id, changes) {
        const node = this._nodes.get(id);
        if (!node) return false;

        Object.assign(node, changes, { id }); // id 不可覆盖

        // 若是 ending 节点，同步到结局系统
        if (node.type === 'ending') {
            this._syncEndingNode(node);
        }

        this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
            action: 'update',
            nodeId: id,
            node:   { ...node },
        });

        if (this._visualEditor) {
            this._visualEditor.updateNode(id, node);
        }

        this._persistTree();
        return true;
    }

    /**
     * 删除节点（同时移除所有指向它的连线）
     * @param {string} id
     * @returns {boolean}
     */
    deleteNode(id) {
        if (!this._nodes.has(id)) return false;

        // 从所有父节点的 children / choices 中解除引用
        for (const node of this._nodes.values()) {
            if (node.children) {
                node.children = node.children.filter(cid => cid !== id);
            }
            if (node.choices) {
                node.choices = node.choices.filter(c => c.targetId !== id);
            }
        }

        this._nodes.delete(id);

        if (this._rootId === id) {
            // 根节点删除后，取第一个节点作为新根
            this._rootId = this._nodes.keys().next().value || null;
        }

        this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
            action: 'delete',
            nodeId: id,
        });

        if (this._visualEditor) {
            this._visualEditor.removeNode(id);
        }

        this._persistTree();
        return true;
    }

    /**
     * 移动节点（改变父子关系）
     * @param {string} id
     * @param {string} newParentId
     * @returns {boolean}
     */
    moveNode(id, newParentId) {
        if (!this._nodes.has(id) || !this._nodes.has(newParentId)) return false;
        if (id === newParentId) return false;

        // 先从旧父节点中解除
        for (const node of this._nodes.values()) {
            if (node.children) {
                const idx = node.children.indexOf(id);
                if (idx !== -1) node.children.splice(idx, 1);
            }
        }

        // 挂到新父节点
        this._attachToParent(id, newParentId);

        this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
            action:      'move',
            nodeId:      id,
            newParentId,
        });

        this._persistTree();
        return true;
    }

    /**
     * 获取节点
     * @param {string} id
     * @returns {Object|undefined}
     */
    getNode(id) {
        return this._nodes.get(id);
    }

    /**
     * 获取完整树（扁平数组）
     * @returns {Object[]}
     */
    getTree() {
        return Array.from(this._nodes.values());
    }

    /**
     * 获取根节点
     * @returns {Object|null}
     */
    getRootNode() {
        return this._rootId ? this._nodes.get(this._rootId) : null;
    }

    /**
     * 清空整棵树
     */
    clearTree() {
        this._nodes.clear();
        this._rootId = null;
        this._persistTree();

        this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
            action: 'clear',
        });
    }

    // ── 条件与结局 ───────────────────────────

    /**
     * 在给定变量集下对单个条件求值
     * @param {Object} condition
     * @param {Object} variables
     * @returns {boolean}
     */
    evaluateCondition(condition, variables) {
        try {
            return evaluateCondition(condition, variables);
        } catch {
            return false;
        }
    }

    /**
     * 检测当前变量集是否触发任何结局
     * @param {Object} variables
     * @returns {Object[]}  触发的结局列表
     */
    checkEndingConditions(variables) {
        return this._endingSystem.checkTriggers(variables);
    }

    /**
     * 获取结局系统实例（供外部面板访问）
     * @returns {EndingSystem}
     */
    getEndingSystem() {
        return this._endingSystem;
    }

    // ── AI 辅助功能 ──────────────────────────

    /**
     * AI 扩写指定节点的剧情内容
     * @param {string} nodeId
     * @returns {Promise<string>}  扩写后的内容
     */
    async expandNode(nodeId) {
        const node = this._nodes.get(nodeId);
        if (!node) throw new Error(`节点 ${nodeId} 不存在`);

        try {
            this._eventBus.emit(EVENTS.LOADING_START, { msg: `正在扩写节点「${node.label}」...` });

            const prompt = this._buildExpansionPrompt(node);
            const result = await this._ai.generateCard(
                '你是一位擅长互动小说写作的剧情编辑，请扩写以下分支节点的剧情内容。',
                prompt
            );

            const expanded = result?.trim() || node.content;
            this.updateNode(nodeId, { content: expanded });

            this._eventBus.emit(EVENTS.LOADING_END, {});
            return expanded;
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  'expandNode',
                error,
                context: { nodeId },
            });
            this._eventBus.emit(EVENTS.LOADING_END, {});
            throw error;
        }
    }

    /**
     * AI 为指定节点生成玩家选项
     * @param {string} nodeId
     * @param {number} [count=3]
     * @returns {Promise<string[]>}  选项标签数组
     */
    async generateChoices(nodeId, count = 3) {
        const node = this._nodes.get(nodeId);
        if (!node) throw new Error(`节点 ${nodeId} 不存在`);

        try {
            this._eventBus.emit(EVENTS.LOADING_START, { msg: '正在生成剧情选项...' });

            const prompt = [
                `当前剧情场景：\n${node.content}`,
                ``,
                `请为玩家生成 ${count} 个不同的选择选项。`,
                `每个选项一行，格式为：「选项文本」`,
                `选项应当有明显的方向性差异（勇敢/谨慎/机智/强攻 等）`,
            ].join('\n');

            const raw = await this._ai.generateCard(
                '你是互动小说设计师，请生成有趣的玩家选项。',
                prompt
            );

            const choices = this._parseChoicesResponse(raw, count);

            this._eventBus.emit(EVENTS.LOADING_END, {});
            return choices;
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  'generateChoices',
                error,
                context: { nodeId, count },
            });
            this._eventBus.emit(EVENTS.LOADING_END, {});
            throw error;
        }
    }

    // ── 导出功能 ─────────────────────────────

    /**
     * 将分支树导出为 STscript
     * @param {Object} [options]  ExportOptions
     * @returns {Promise<{script:string, qrSet:object|null, warnings:string[]}>}
     */
    async exportToSTScript(options = {}) {
        try {
            if (!this._rootId) {
                return {
                    script:   '// [CardForge] 分支树为空\n',
                    qrSet:    null,
                    warnings: ['分支树没有任何节点'],
                };
            }

            const nodes  = this.getTree();
            const result = this._exporter.exportTree(nodes, this._rootId, options);

            this._eventBus.emit(EVENTS.SCRIPT_GENERATED, {
                source: 'branch_engine',
                length: result.script.length,
            });

            return result;
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  'exportToSTScript',
                error,
                context: { options },
            });
            throw error;
        }
    }

    /**
     * 将分支树导出为世界书条目组合
     * @returns {Object[]}  WB_ENTRY_SCHEMA 数组
     */
    async exportToWorldBook() {
        const nodes = this.getTree();
        return this._exporter.exportToWorldBook(nodes);
    }

    /**
     * 序列化为 JSON（用于保存/导出）
     * @returns {Object}
     */
    exportJSON() {
        return {
            version:    '1.0.0',
            rootId:     this._rootId,
            nodes:      Array.from(this._nodes.values()),
            endings:    this._endingSystem.toJSON(),
            exportedAt: Date.now(),
        };
    }

    /**
     * 从 JSON 恢复（用于导入）
     * @param {Object} json
     */
    importJSON(json) {
        try {
            this._nodes.clear();
            this._rootId = json.rootId || null;

            for (const node of (json.nodes || [])) {
                this._nodes.set(node.id, node);
            }

            if (json.endings) {
                this._endingSystem.fromJSON(json.endings);
            }

            this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
                action: 'import',
                count:  this._nodes.size,
            });

            if (this._visualEditor && this._rootId) {
                this._visualEditor.loadNodes(this.getTree(), this._rootId);
            }

            this._persistTree();
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  'importJSON',
                error,
                context: {},
            });
            throw error;
        }
    }

    // ── 可视化编辑器 ─────────────────────────

    /**
     * 挂载可视化编辑器到指定容器
     * @param {HTMLElement} container
     * @param {Object} [options]
     */
    mountVisualEditor(container, options = {}) {
        if (this._visualEditor) {
            this._visualEditor.destroy();
        }

        this._visualEditor = new VisualTreeEditor(container, this._eventBus, options);
        this._visualEditor.init();

        // 节点变更同步回引擎
        this._visualEditor.onChange((nodeId, changes) => {
            // 仅同步位置信息，不触发 persistTree（位置只存内存）
            const node = this._nodes.get(nodeId);
            if (node && changes._pos) {
                node._pos = changes._pos;
            }
        });

        // 加载当前树
        if (this._rootId && this._nodes.size > 0) {
            this._visualEditor.loadNodes(this.getTree(), this._rootId);
        }

        return this._visualEditor;
    }

    /**
     * 卸载可视化编辑器
     */
    unmountVisualEditor() {
        if (this._visualEditor) {
            this._visualEditor.destroy();
            this._visualEditor = null;
        }
    }

    /**
     * 适配视口（让所有节点可见）
     */
    fitView() {
        this._visualEditor?.fitView();
    }

    // ── 私有方法 ─────────────────────────────

    /**
     * 注册内部事件监听
     * @private
     */
    _registerEventListeners() {
        // 监听节点选中事件（视觉编辑器 → 面板联动）
        const unsub1 = this._eventBus.on(EVENTS.BRANCH_TREE_UPDATED, (data) => {
            if (data?.action === 'select') {
                // 外部面板可监听此事件来展示属性编辑器
            }
        });

        this._unsubscribers.push(unsub1);
    }

    /**
     * 从 IndexedDB 恢复分支树
     * @returns {Promise<void>}
     * @private
     */
    async _loadTreeFromDB() {
        try {
            const saved = await this._dbStore.get('branch_engine_tree');
            if (saved && saved.nodes && saved.nodes.length > 0) {
                this.importJSON(saved);
            }
        } catch {
            // 首次使用，无历史数据，忽略错误
        }
    }

    /**
     * 将分支树持久化到 IndexedDB
     * @returns {Promise<void>}
     * @private
     */
    async _persistTree() {
        try {
            await this._dbStore.set('branch_engine_tree', this.exportJSON());
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'BranchEngine',
                method:  '_persistTree',
                error,
                context: {},
            });
        }
    }

    /**
     * 将节点挂到父节点下
     * @param {string} childId
     * @param {string} parentId
     * @private
     */
    _attachToParent(childId, parentId) {
        const parent = this._nodes.get(parentId);
        if (!parent) return;

        if (parent.type === 'choice') {
            // choice 节点通过 choices 数组管理子节点
            if (!parent.choices) parent.choices = [];
            if (!parent.choices.find(c => c.targetId === childId)) {
                parent.choices.push({
                    label:    `选项 ${parent.choices.length + 1}`,
                    targetId: childId,
                });
            }
        } else {
            // 其他节点通过 children 数组
            if (!parent.children) parent.children = [];
            if (!parent.children.includes(childId)) {
                parent.children.push(childId);
            }
        }
    }

    /**
     * 将 ending 类型节点的条件同步到 EndingSystem
     * @param {Object} node
     * @private
     */
    _syncEndingNode(node) {
        const existing = this._endingSystem.getEnding(node.id);
        if (existing) {
            this._endingSystem.updateEnding(node.id, {
                label:      node.label,
                content:    node.content,
                stscript:   node.stscript,
                conditions: node.condition ? [parseCondition(node.condition)] : [],
            });
        } else {
            this._endingSystem.addEnding({
                id:         node.id,
                label:      node.label,
                content:    node.content,
                stscript:   node.stscript || '',
                conditions: node.condition ? [parseCondition(node.condition)] : [],
                type:       node.endingType || ENDING_TYPES.NORMAL,
            });
        }
    }

    /**
     * 构建节点扩写 Prompt
     * @param {Object} node
     * @returns {string}
     * @private
     */
    _buildExpansionPrompt(node) {
        const lines = [
            `节点类型：${this._typeLabel(node.type)}`,
            `节点标签：${node.label}`,
            '',
            '当前内容：',
            node.content || '（空）',
            '',
            '请扩写这个剧情节点，使其更加生动、沉浸。',
            '要求：',
            '- 保持原有的情节走向和人物关系',
            '- 加入感官描写（视觉/听觉/触觉）',
            '- 长度控制在 200~400 字之间',
            '- 直接输出扩写内容，不需要额外说明',
        ];
        return lines.join('\n');
    }

    /**
     * 解析 AI 返回的选项文本
     * @param {string} raw
     * @param {number} count
     * @returns {string[]}
     * @private
     */
    _parseChoicesResponse(raw, count) {
        const lines = raw
            .split('\n')
            .map(l => l.replace(/^[「『【\d\.\-\*\s]+/, '').replace(/[」』】]+$/, '').trim())
            .filter(l => l.length > 0);

        return lines.slice(0, count);
    }

    /**
     * 生成唯一节点 ID
     * @returns {string}
     * @private
     */
    _generateId() {
        this._idCounter++;
        return `node_${Date.now()}_${this._idCounter}`;
    }

    /**
     * 获取节点类型的中文标签
     * @param {string} type
     * @returns {string}
     * @private
     */
    _typeLabel(type) {
        const labels = {
            normal:    '剧情',
            condition: '条件',
            choice:    '选择',
            ending:    '结局',
        };
        return labels[type] || type;
    }
}