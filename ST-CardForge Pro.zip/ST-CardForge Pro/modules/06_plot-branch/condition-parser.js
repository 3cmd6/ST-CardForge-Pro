/**
 * @file modules/06_plot-branch/condition-parser.js
 * @description 剧情分支条件解析器
 *              将人类可读的条件表达式（字符串或对象）解析为可执行的条件对象，
 *              支持求值、编译为 STscript、序列化/反序列化。
 *              是 branch-engine.js 和 ending-system.js 的核心依赖。
 * @version 1.0.0
 */

import { BRANCH_NODE_SCHEMA } from '../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  操作符定义
// ═══════════════════════════════════════════════

/**
 * 支持的条件操作符完整定义
 * @type {Object.<string, { label: string, stscript: string, eval: Function }>}
 */
export const OPERATORS = {
    // ── 数值比较 ──
    'eq':   {
        label:    '等于',
        stscript: 'eq',
        eval:     (a, b) => _coerce(a) === _coerce(b),
    },
    'neq':  {
        label:    '不等于',
        stscript: 'neq',
        eval:     (a, b) => _coerce(a) !== _coerce(b),
    },
    'gt':   {
        label:    '大于',
        stscript: 'gt',
        eval:     (a, b) => parseFloat(a) >  parseFloat(b),
    },
    'gte':  {
        label:    '大于等于',
        stscript: 'gte',
        eval:     (a, b) => parseFloat(a) >= parseFloat(b),
    },
    'lt':   {
        label:    '小于',
        stscript: 'lt',
        eval:     (a, b) => parseFloat(a) <  parseFloat(b),
    },
    'lte':  {
        label:    '小于等于',
        stscript: 'lte',
        eval:     (a, b) => parseFloat(a) <= parseFloat(b),
    },

    // ── 字符串操作 ──
    'contains': {
        label:    '包含',
        stscript: 'contains',
        eval:     (a, b) => String(a).includes(String(b)),
    },
    'not_contains': {
        label:    '不包含',
        stscript: 'not-contains',
        eval:     (a, b) => !String(a).includes(String(b)),
    },
    'starts_with': {
        label:    '开头为',
        stscript: 'starts-with',
        eval:     (a, b) => String(a).startsWith(String(b)),
    },
    'ends_with': {
        label:    '结尾为',
        stscript: 'ends-with',
        eval:     (a, b) => String(a).endsWith(String(b)),
    },
    'matches': {
        label:    '正则匹配',
        stscript: 'eq',     // STscript 无原生正则，退化为 eq
        eval:     (a, b) => {
            try { return new RegExp(b).test(String(a)); }
            catch (_) { return false; }
        },
    },

    // ── 范围操作 ──
    'between': {
        label:    '在范围内',
        stscript: 'gte',    // 需要生成两条 if（见 compileToSTScript）
        eval:     (a, b) => {
            // b 格式：'min,max'
            const [min, max] = String(b).split(',').map(parseFloat);
            const num = parseFloat(a);
            return num >= min && num <= max;
        },
    },
    'not_between': {
        label:    '不在范围内',
        stscript: 'lt',
        eval:     (a, b) => {
            const [min, max] = String(b).split(',').map(parseFloat);
            const num = parseFloat(a);
            return num < min || num > max;
        },
    },

    // ── 存在性判断 ──
    'exists': {
        label:    '已定义（非空）',
        stscript: 'neq',
        eval:     (a) => a !== undefined && a !== null && a !== '',
    },
    'not_exists': {
        label:    '未定义（空）',
        stscript: 'eq',
        eval:     (a) => a === undefined || a === null || a === '',
    },

    // ── 布尔 ──
    'is_true': {
        label:    '为真',
        stscript: 'eq',
        eval:     (a) => a === true || a === 'true' || a === '1' || a === 1,
    },
    'is_false': {
        label:    '为假',
        stscript: 'neq',
        eval:     (a) => !(a === true || a === 'true' || a === '1' || a === 1),
    },
};

/** 所有操作符的 key 列表（用于 UI 下拉选择） */
export const OPERATOR_KEYS = Object.keys(OPERATORS);

// ═══════════════════════════════════════════════
// § 2  条件对象类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} SimpleCondition
 * @property {'simple'} kind         - 条件种类标识
 * @property {string}   variable     - 变量名（对应 STscript getvar key）
 * @property {string}   operator     - OPERATORS 中的 key
 * @property {string}   value        - 比较值
 * @property {boolean}  [negate]     - 是否取反（默认 false）
 */

/**
 * @typedef {Object} CompoundCondition
 * @property {'compound'} kind       - 条件种类标识
 * @property {'AND'|'OR'} logic      - 逻辑关系
 * @property {Condition[]} conditions - 子条件列表（至少 2 个）
 * @property {boolean}  [negate]     - 是否取反整个组合
 */

/**
 * @typedef {SimpleCondition|CompoundCondition} Condition
 */

// ═══════════════════════════════════════════════
// § 3  解析函数
// ═══════════════════════════════════════════════

/**
 * 将字符串或原始对象解析为标准 Condition 对象
 *
 * 支持的字符串格式：
 *   "player_hp > 50"
 *   "player_hp >= 50"
 *   "relationship == 恋人"
 *   "game_state != game_over"
 *   "NOT player_hp > 50"
 *   "(player_hp > 50) AND (player_mp > 20)"
 *
 * @param {string|object} raw
 * @returns {Condition}
 * @throws {Error} 无法解析时抛出
 */
export function parseCondition(raw) {
    if (!raw) throw new Error('[ConditionParser] 条件不能为空');

    // 已经是标准对象
    if (typeof raw === 'object' && raw.kind) {
        return _normalizeCondition(raw);
    }

    // 字符串解析
    if (typeof raw === 'string') {
        return _parseString(raw.trim());
    }

    throw new Error(`[ConditionParser] 不支持的条件类型：${typeof raw}`);
}

/**
 * 安全解析（不抛出，失败返回 null）
 * @param {string|object} raw
 * @returns {Condition|null}
 */
export function tryParseCondition(raw) {
    try { return parseCondition(raw); }
    catch (_) { return null; }
}

// ═══════════════════════════════════════════════
// § 4  求值函数
// ═══════════════════════════════════════════════

/**
 * 在给定变量集中对条件求值
 *
 * @param {Condition}  condition  - 标准条件对象
 * @param {object}     variables  - key→value 的变量映射
 * @returns {boolean}
 */
export function evaluateCondition(condition, variables = {}) {
    if (!condition) return false;

    if (condition.kind === 'simple') {
        return _evalSimple(condition, variables);
    }

    if (condition.kind === 'compound') {
        return _evalCompound(condition, variables);
    }

    return false;
}

/**
 * 批量求值：返回每个条件的结果
 * @param {Condition[]} conditions
 * @param {object}      variables
 * @returns {boolean[]}
 */
export function evaluateAll(conditions, variables = {}) {
    return conditions.map(c => evaluateCondition(c, variables));
}

// ═══════════════════════════════════════════════
// § 5  STscript 编译器
// ═══════════════════════════════════════════════

/**
 * 将 Condition 对象编译为 STscript /if 语句字符串
 *
 * @param {Condition} condition
 * @param {string}    thenScript       - 条件成立时执行的脚本
 * @param {string}    [elseScript='']  - 条件不成立时执行的脚本
 * @param {number}    [indentLevel=0]  - 缩进级别（用于嵌套）
 * @returns {string}
 */
export function compileToSTScript(condition, thenScript, elseScript = '', indentLevel = 0) {
    if (!condition) return '';

    const indent = '    '.repeat(indentLevel);

    if (condition.kind === 'simple') {
        return _compileSimple(condition, thenScript, elseScript, indent);
    }

    if (condition.kind === 'compound') {
        return _compileCompound(condition, thenScript, elseScript, indent);
    }

    return `${indent}// [未知条件类型]`;
}

/**
 * 将 Condition 编译为仅包含条件判断的 STscript 片段
 * （不包含 then/else 块，用于嵌入更大的 if 结构）
 *
 * @param {Condition} condition
 * @returns {string}  形如 '/if left=... right=... eq'
 */
export function compileConditionOnly(condition) {
    if (!condition || condition.kind !== 'simple') return '';
    const op     = OPERATORS[condition.operator];
    const stOp   = op?.stscript || 'eq';
    const left   = `{{getvar::${condition.variable}}}`;
    const right  = condition.value ?? '';
    return `/if left=${left} right=${right} ${stOp}`;
}

// ═══════════════════════════════════════════════
// § 6  序列化工具
// ═══════════════════════════════════════════════

/**
 * 将 Condition 转换为人类可读的自然语言描述
 * @param {Condition} condition
 * @returns {string}
 */
export function describeCondition(condition) {
    if (!condition) return '（无条件）';

    if (condition.kind === 'simple') {
        const op    = OPERATORS[condition.operator];
        const label = op?.label || condition.operator;
        const neg   = condition.negate ? '（取反）' : '';

        // 特殊操作符（exists/is_true 等单操作数）
        if (['exists', 'not_exists', 'is_true', 'is_false'].includes(condition.operator)) {
            return `${neg}${condition.variable} ${label}`;
        }

        return `${neg}${condition.variable} ${label} ${condition.value}`;
    }

    if (condition.kind === 'compound') {
        const parts  = condition.conditions.map(c => `（${describeCondition(c)}）`);
        const joined = parts.join(` ${condition.logic} `);
        return condition.negate ? `NOT（${joined}）` : joined;
    }

    return '（未知条件）';
}

/**
 * 将 Condition 序列化为 JSON 字符串
 * @param {Condition} condition
 * @returns {string}
 */
export function serializeCondition(condition) {
    return JSON.stringify(condition);
}

/**
 * 从 JSON 字符串反序列化 Condition
 * @param {string} json
 * @returns {Condition|null}
 */
export function deserializeCondition(json) {
    try {
        const raw = JSON.parse(json);
        return parseCondition(raw);
    } catch (_) {
        return null;
    }
}

// ═══════════════════════════════════════════════
// § 7  条件构建器（工厂函数）
// ═══════════════════════════════════════════════

/**
 * 创建简单条件
 * @param {string}  variable
 * @param {string}  operator
 * @param {string}  value
 * @param {boolean} [negate=false]
 * @returns {SimpleCondition}
 */
export function simple(variable, operator, value, negate = false) {
    if (!OPERATORS[operator]) {
        throw new Error(`[ConditionParser] 未知操作符：${operator}`);
    }
    return { kind: 'simple', variable, operator, value: String(value), negate };
}

/**
 * 创建 AND 复合条件
 * @param {...Condition} conditions
 * @returns {CompoundCondition}
 */
export function and(...conditions) {
    if (conditions.length < 2) {
        throw new Error('[ConditionParser] AND 条件至少需要 2 个子条件');
    }
    return { kind: 'compound', logic: 'AND', conditions, negate: false };
}

/**
 * 创建 OR 复合条件
 * @param {...Condition} conditions
 * @returns {CompoundCondition}
 */
export function or(...conditions) {
    if (conditions.length < 2) {
        throw new Error('[ConditionParser] OR 条件至少需要 2 个子条件');
    }
    return { kind: 'compound', logic: 'OR', conditions, negate: false };
}

/**
 * 对条件取反
 * @param {Condition} condition
 * @returns {Condition}
 */
export function not(condition) {
    return { ...condition, negate: !condition.negate };
}

// ═══════════════════════════════════════════════
// § 8  校验函数
// ═══════════════════════════════════════════════

/**
 * 校验 Condition 对象是否合法
 * @param {Condition} condition
 * @returns {{ valid: boolean, errors: string[] }}
 */
export function validateCondition(condition) {
    const errors = [];

    if (!condition) {
        return { valid: false, errors: ['条件对象不能为 null'] };
    }

    if (condition.kind === 'simple') {
        if (!condition.variable) errors.push('variable 不能为空');
        if (!condition.operator) errors.push('operator 不能为空');
        if (!OPERATORS[condition.operator]) {
            errors.push(`operator "${condition.operator}" 不在支持列表中`);
        }
        // exists/is_true 等单操作数操作符不需要 value
        const noValueOps = ['exists', 'not_exists', 'is_true', 'is_false'];
        if (!noValueOps.includes(condition.operator) && condition.value === undefined) {
            errors.push('value 不能为 undefined');
        }
    } else if (condition.kind === 'compound') {
        if (!['AND', 'OR'].includes(condition.logic)) {
            errors.push(`logic "${condition.logic}" 必须为 AND 或 OR`);
        }
        if (!Array.isArray(condition.conditions) || condition.conditions.length < 2) {
            errors.push('compound 条件至少需要 2 个子条件');
        } else {
            condition.conditions.forEach((sub, idx) => {
                const { valid, errors: subErrors } = validateCondition(sub);
                if (!valid) {
                    errors.push(`子条件 #${idx}：${subErrors.join(', ')}`);
                }
            });
        }
    } else {
        errors.push(`未知的 condition.kind：${condition.kind}`);
    }

    return { valid: errors.length === 0, errors };
}

// ═══════════════════════════════════════════════
// § 9  私有辅助函数
// ═══════════════════════════════════════════════

/**
 * 解析条件字符串
 * @param {string} str
 * @returns {Condition}
 */
function _parseString(str) {
    // ── 复合条件：包含 AND / OR ──
    const compoundMatch = str.match(/^(.*?)\s+(AND|OR)\s+(.*?)$/is);
    if (compoundMatch) {
        const logic = compoundMatch[2].toUpperCase();
        // 递归解析两侧（支持多层嵌套）
        const parts = _splitByLogic(str, logic);
        const conditions = parts.map(p => _parseString(p.trim().replace(/^\(|\)$/g, '')));
        return { kind: 'compound', logic, conditions, negate: false };
    }

    // ── 取反前缀：NOT ──
    const notMatch = str.match(/^NOT\s+(.+)$/i);
    if (notMatch) {
        const inner = parseCondition(notMatch[1].trim());
        return { ...inner, negate: !inner.negate };
    }

    // ── 括号包裹：去括号后递归解析 ──
    if (str.startsWith('(') && str.endsWith(')')) {
        return _parseString(str.slice(1, -1).trim());
    }

    // ── 简单条件：variable operator value ──
    return _parseSimpleString(str);
}

/**
 * 解析简单条件字符串
 * 格式：`variable operator value`
 * 例：`player_hp > 50`、`relationship == 恋人`
 *
 * @param {string} str
 * @returns {SimpleCondition}
 */
function _parseSimpleString(str) {
    // 操作符优先级：长操作符优先（>=、<=、!=、==）
    const opPatterns = [
        { regex: /^(.+?)\s*>=\s*(.+)$/,   op: 'gte' },
        { regex: /^(.+?)\s*<=\s*(.+)$/,   op: 'lte' },
        { regex: /^(.+?)\s*!=\s*(.+)$/,   op: 'neq' },
        { regex: /^(.+?)\s*==\s*(.+)$/,   op: 'eq'  },
        { regex: /^(.+?)\s*>\s*(.+)$/,    op: 'gt'  },
        { regex: /^(.+?)\s*<\s*(.+)$/,    op: 'lt'  },
        // 关键词形式
        { regex: /^(.+?)\s+contains\s+(.+)$/i,     op: 'contains' },
        { regex: /^(.+?)\s+not_contains\s+(.+)$/i, op: 'not_contains' },
        { regex: /^(.+?)\s+starts_with\s+(.+)$/i,  op: 'starts_with' },
        { regex: /^(.+?)\s+ends_with\s+(.+)$/i,    op: 'ends_with' },
        { regex: /^(.+?)\s+between\s+(.+)$/i,      op: 'between' },
        { regex: /^(.+?)\s+matches\s+(.+)$/i,      op: 'matches' },
        // 单操作数
        { regex: /^(.+?)\s+exists$/i,               op: 'exists',     single: true },
        { regex: /^(.+?)\s+not_exists$/i,            op: 'not_exists', single: true },
        { regex: /^(.+?)\s+is_true$/i,               op: 'is_true',    single: true },
        { regex: /^(.+?)\s+is_false$/i,              op: 'is_false',   single: true },
    ];

    for (const { regex, op, single } of opPatterns) {
        const match = str.match(regex);
        if (match) {
            return {
                kind:     'simple',
                variable: match[1].trim(),
                operator: op,
                value:    single ? '' : match[2].trim(),
                negate:   false,
            };
        }
    }

    throw new Error(`[ConditionParser] 无法解析条件表达式："${str}"`);
}

/**
 * 按逻辑操作符分割复合条件字符串
 * 尊重括号嵌套层级
 * @param {string} str
 * @param {string} logic  - 'AND' 或 'OR'
 * @returns {string[]}
 */
function _splitByLogic(str, logic) {
    const parts    = [];
    let   depth    = 0;
    let   current  = '';
    const keyword  = ` ${logic} `;
    const upper    = str.toUpperCase();
    let   i        = 0;

    while (i < str.length) {
        if (str[i] === '(') { depth++; current += str[i++]; continue; }
        if (str[i] === ')') { depth--; current += str[i++]; continue; }

        if (depth === 0 && upper.startsWith(keyword, i)) {
            parts.push(current.trim());
            current = '';
            i += keyword.length;
            continue;
        }

        current += str[i++];
    }

    if (current.trim()) parts.push(current.trim());
    return parts;
}

/**
 * 规范化条件对象（确保必要字段存在）
 * @param {object} raw
 * @returns {Condition}
 */
function _normalizeCondition(raw) {
    if (raw.kind === 'simple') {
        return {
            kind:     'simple',
            variable: String(raw.variable || ''),
            operator: raw.operator || 'eq',
            value:    String(raw.value ?? ''),
            negate:   Boolean(raw.negate),
        };
    }

    if (raw.kind === 'compound') {
        return {
            kind:       'compound',
            logic:      (raw.logic || 'AND').toUpperCase(),
            conditions: (raw.conditions || []).map(c => _normalizeCondition(c)),
            negate:     Boolean(raw.negate),
        };
    }

    throw new Error(`[ConditionParser] 未知 condition.kind：${raw.kind}`);
}

/**
 * 对简单条件求值
 * @param {SimpleCondition} condition
 * @param {object}          variables
 * @returns {boolean}
 */
function _evalSimple(condition, variables) {
    const opDef  = OPERATORS[condition.operator];
    if (!opDef) return false;

    const actual  = variables[condition.variable];
    const result  = opDef.eval(actual, condition.value);
    return condition.negate ? !result : result;
}

/**
 * 对复合条件求值
 * @param {CompoundCondition} condition
 * @param {object}            variables
 * @returns {boolean}
 */
function _evalCompound(condition, variables) {
    const results = condition.conditions.map(c => evaluateCondition(c, variables));
    let   result;

    if (condition.logic === 'AND') {
        result = results.every(Boolean);
    } else {
        result = results.some(Boolean);
    }

    return condition.negate ? !result : result;
}

/**
 * 编译简单条件为 STscript
 * @param {SimpleCondition} cond
 * @param {string}          thenScript
 * @param {string}          elseScript
 * @param {string}          indent
 * @returns {string}
 */
function _compileSimple(cond, thenScript, elseScript, indent) {
    const op    = OPERATORS[cond.operator];
    const stOp  = cond.negate ? _invertSTOp(op?.stscript) : (op?.stscript || 'eq');

    const left  = `{{getvar::${cond.variable}}}`;
    const right = cond.value ?? '';

    // between 需要两条 if
    if (cond.operator === 'between') {
        const [min, max] = String(right).split(',');
        return [
            `${indent}/setvar key=_cond_between value=false |`,
            `${indent}/if left=${left} right=${min} gte`,
            `${indent}    /if left=${left} right=${max} lte`,
            `${indent}        /setvar key=_cond_between value=true |`,
            `${indent}/if left={{getvar::_cond_between}} right=${cond.negate ? 'true' : 'false'} ${cond.negate ? 'eq' : 'neq'}`,
            _indentBlock(thenScript, indent + '    '),
            elseScript ? `${indent}/else\n${_indentBlock(elseScript, indent + '    ')}` : '',
        ].filter(Boolean).join('\n');
    }

    // 单操作数（exists/is_true 等）：right 使用特殊值
    const isExistsType = ['exists', 'not_exists'].includes(cond.operator);
    const isBoolType   = ['is_true', 'is_false'].includes(cond.operator);
    const resolvedRight = isExistsType ? '' : (isBoolType ? 'true' : right);
    const resolvedOp    = isExistsType ? (cond.operator === 'exists' ? 'neq' : 'eq')
                        : isBoolType   ? (cond.operator === 'is_true' ? 'eq'  : 'neq')
                        : stOp;

    const lines = [
        `${indent}/if left=${left} right=${resolvedRight} ${resolvedOp}`,
        _indentBlock(thenScript, indent + '    '),
    ];

    if (elseScript) {
        lines.push(`${indent}/else`);
        lines.push(_indentBlock(elseScript, indent + '    '));
    }

    return lines.join('\n');
}

/**
 * 编译复合条件为 STscript
 * @param {CompoundCondition} cond
 * @param {string}            thenScript
 * @param {string}            elseScript
 * @param {string}            indent
 * @returns {string}
 */
function _compileCompound(cond, thenScript, elseScript, indent) {
    const tempVar = `_cond_${Date.now() % 100000}`;

    const lines = [
        `${indent}// 复合条件（${cond.logic}）`,
        `${indent}/setvar key=${tempVar} value=${cond.logic === 'AND' ? 'true' : 'false'} |`,
    ];

    cond.conditions.forEach((sub, idx) => {
        if (sub.kind !== 'simple') {
            // 嵌套复合条件：递归生成辅助变量
            lines.push(compileToSTScript(
                sub,
                `/setvar key=${tempVar}_sub${idx} value=true |`,
                `/setvar key=${tempVar}_sub${idx} value=false |`,
                0
            ));
            const subOp = cond.logic === 'AND' ? 'eq' : 'neq';
            lines.push(
                `${indent}/if left={{getvar::${tempVar}_sub${idx}}} right=false ${subOp}`,
                `${indent}    /setvar key=${tempVar} value=${cond.logic === 'AND' ? 'false' : 'true'} |`,
            );
        } else {
            // 简单子条件
            const subOp    = OPERATORS[sub.operator];
            const stSubOp  = sub.negate ? _invertSTOp(subOp?.stscript) : (subOp?.stscript || 'eq');
            const leftVal  = `{{getvar::${sub.variable}}}`;
            const rightVal = sub.value ?? '';

            if (cond.logic === 'AND') {
                // AND：任一不满足则置 false
                lines.push(
                    `${indent}/if left=${leftVal} right=${rightVal} ${_invertSTOp(stSubOp)}`,
                    `${indent}    /setvar key=${tempVar} value=false |`,
                );
            } else {
                // OR：任一满足则置 true
                lines.push(
                    `${indent}/if left=${leftVal} right=${rightVal} ${stSubOp}`,
                    `${indent}    /setvar key=${tempVar} value=true |`,
                );
            }
        }
    });

    // 最终判断
    const finalRight = cond.negate ? 'false' : 'true';
    lines.push(
        `${indent}/if left={{getvar::${tempVar}}} right=${finalRight} eq`,
        _indentBlock(thenScript, indent + '    '),
    );

    if (elseScript) {
        lines.push(`${indent}/else`);
        lines.push(_indentBlock(elseScript, indent + '    '));
    }

    lines.push(`${indent}/flushvar ${tempVar} |`);

    return lines.join('\n');
}

/**
 * 反转 STscript 操作符（用于 NOT 逻辑）
 * @param {string} op
 * @returns {string}
 */
function _invertSTOp(op) {
    const map = {
        'eq':           'neq',
        'neq':          'eq',
        'gt':           'lte',
        'gte':          'lt',
        'lt':           'gte',
        'lte':          'gt',
        'contains':     'not-contains',
        'not-contains': 'contains',
        'starts-with':  'neq',
        'ends-with':    'neq',
    };
    return map[op] || 'neq';
}

/**
 * 对脚本块内所有行加缩进
 * @param {string} script
 * @param {string} indent
 * @returns {string}
 */
function _indentBlock(script, indent) {
    if (!script) return '';
    return script.split('\n').map(l => `${indent}${l}`).join('\n');
}

/**
 * 强制类型转换：如果两边都像数字就转为数字，否则保持字符串
 * @param {*} val
 * @returns {number|string}
 */
function _coerce(val) {
    const num = parseFloat(val);
    return isNaN(num) ? String(val ?? '') : num;
}