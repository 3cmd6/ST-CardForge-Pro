/**
 * @file modules/06_plot-branch/ending-system.js
 * @description 剧情分支结局系统
 *              负责：结局定义管理、结局触发条件求值、结局解锁追踪、
 *              多结局路由、结局内容生成、结局历史记录、以及
 *              将结局系统编译为 STscript 的完整导出。
 * @version 1.0.0
 */

import { EVENTS }                                       from '../../contracts.js';
import { parseCondition, evaluateCondition,
         describeCondition, compileToSTScript,
         serializeCondition }                           from './condition-parser.js';

// ═══════════════════════════════════════════════
// § 1  枚举与常量
// ═══════════════════════════════════════════════

/**
 * 结局类型枚举
 * @enum {string}
 */
export const ENDING_TYPES = {
    /** 好结局：目标达成，积极收场 */
    GOOD:    'good',
    /** 坏结局：失败或悲剧 */
    BAD:     'bad',
    /** 中立结局：模糊收场 */
    NEUTRAL: 'neutral',
    /** 隐藏结局：需要特殊条件触发 */
    SECRET:  'secret',
    /** 真结局：所有主线完成后才可触发 */
    TRUE:    'true',
    /** 支线结局：非主线触发 */
    SIDE:    'side',
    /** 游戏结束（Game Over）：通常由死亡触发 */
    GAME_OVER: 'game_over',
};

/**
 * 结局状态枚举
 * @enum {string}
 */
export const ENDING_STATUS = {
    /** 未触发、条件未满足 */
    LOCKED:    'locked',
    /** 条件已满足但尚未触发 */
    UNLOCKED:  'unlocked',
    /** 已触发并播放 */
    TRIGGERED: 'triggered',
    /** 已跳过（路由到其他结局） */
    SKIPPED:   'skipped',
};

/**
 * 结局触发优先级（数字越大越优先检查）
 * @type {Object.<string, number>}
 */
export const ENDING_PRIORITY = {
    [ENDING_TYPES.GAME_OVER]: 100,   // 最高优先：死亡立即检查
    [ENDING_TYPES.TRUE]:       80,
    [ENDING_TYPES.SECRET]:     70,
    [ENDING_TYPES.GOOD]:       50,
    [ENDING_TYPES.BAD]:        50,
    [ENDING_TYPES.NEUTRAL]:    40,
    [ENDING_TYPES.SIDE]:       30,
};

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} EndingDef
 * @property {string}    id             - 唯一 ID（如 'good_ending_1'）
 * @property {string}    title          - 结局标题（显示给玩家）
 * @property {string}    type           - ENDING_TYPES 中的值
 * @property {string}    description    - 结局简介（用于预览）
 * @property {string}    content        - 结局正文（可包含 {{变量}} 插值）
 * @property {object}    condition      - 触发条件（Condition 对象）
 * @property {number}    [priority]     - 自定义优先级（覆盖默认）
 * @property {string[]}  [requires]     - 前置结局 ID 列表（必须先触发这些结局）
 * @property {string[]}  [excludes]     - 互斥结局 ID 列表（触发这些结局后不可触发此结局）
 * @property {string}    [worldInfoKey] - 关联的 World Info 条目关键词
 * @property {string}    [bgmHint]      - 建议 BGM（提示性字段）
 * @property {string}    [imageHint]    - 建议插图（提示性字段）
 * @property {object}    [afterEffects] - 结局后效果（变量变更等）
 * @property {boolean}   [repeatable]   - 是否可重复触发（默认 false）
 * @property {string}    [unlockHint]   - 未解锁时显示的提示文字
 */

/**
 * @typedef {Object} EndingRecord
 * @property {string}       endingId   - 结局 ID
 * @property {ENDING_STATUS} status    - 当前状态
 * @property {number|null}  triggeredAt - 触发时间戳
 * @property {object}       snapshot   - 触发时的变量快照
 */

// ═══════════════════════════════════════════════
// § 3  EndingSystem 主类
// ═══════════════════════════════════════════════

/**
 * 剧情分支结局系统
 */
export class EndingSystem {
    /**
     * @param {object} eventBus - EventBus 实例
     * @param {object} [options]
     * @param {boolean} [options.autoCheck=true]      - 是否在变量变化时自动检查触发条件
     * @param {boolean} [options.allowMultiple=false] - 是否允许同时触发多个结局
     * @param {Function}[options.onEndingUnlocked]    - 结局解锁时的回调
     * @param {Function}[options.onEndingTriggered]   - 结局触发时的回调
     */
    constructor(eventBus, options = {}) {
        this._bus     = eventBus;
        this._options = {
            autoCheck:       true,
            allowMultiple:   false,
            onEndingUnlocked:  null,
            onEndingTriggered: null,
            ...options,
        };

        /**
         * 结局定义列表（按优先级排序）
         * @type {EndingDef[]}
         */
        this._endings = [];

        /**
         * 结局状态记录
         * @type {Map<string, EndingRecord>}
         */
        this._records = new Map();

        /**
         * 已触发结局的有序列表
         * @type {string[]}
         */
        this._triggeredOrder = [];

        /** @type {string[]} 订阅取消函数 */
        this._unsubs = [];
    }

    // ─── 生命周期 ─────────────────────────────────

    /**
     * 初始化（订阅全局事件）
     */
    init() {
        if (this._options.autoCheck) {
            this._subscribeEvents();
        }
    }

    /**
     * 销毁，清理订阅
     */
    destroy() {
        this._unsubs.forEach(fn => fn());
        this._unsubs = [];
    }

    // ─── 结局定义管理 ─────────────────────────────

    /**
     * 注册单个结局定义
     * @param {EndingDef} endingDef
     * @returns {EndingDef}
     */
    registerEnding(endingDef) {
        const def = this._normalizeEnding(endingDef);
        this._validateEnding(def);

        // 解析条件字符串
        if (def.condition && typeof def.condition === 'string') {
            def.condition = parseCondition(def.condition);
        }

        // 移除同 ID 的旧定义
        this._endings = this._endings.filter(e => e.id !== def.id);
        this._endings.push(def);

        // 按优先级降序排序
        this._endings.sort((a, b) =>
            (b.priority ?? ENDING_PRIORITY[b.type] ?? 50) -
            (a.priority ?? ENDING_PRIORITY[a.type] ?? 50)
        );

        // 初始化状态记录
        if (!this._records.has(def.id)) {
            this._records.set(def.id, {
                endingId:    def.id,
                status:      ENDING_STATUS.LOCKED,
                triggeredAt: null,
                snapshot:    {},
            });
        }

        return def;
    }

    /**
     * 批量注册结局
     * @param {EndingDef[]} endingDefs
     */
    registerEndings(endingDefs) {
        endingDefs.forEach(def => this.registerEnding(def));
    }

    /**
     * 移除结局定义
     * @param {string} id
     */
    removeEnding(id) {
        this._endings    = this._endings.filter(e => e.id !== id);
        this._records.delete(id);
    }

    /**
     * 更新结局定义（部分更新）
     * @param {string} id
     * @param {Partial<EndingDef>} changes
     */
    updateEnding(id, changes) {
        const idx = this._endings.findIndex(e => e.id === id);
        if (idx === -1) throw new Error(`[EndingSystem] 未找到结局：${id}`);
        this._endings[idx] = { ...this._endings[idx], ...changes, id };
    }

    /**
     * 获取所有结局定义（按优先级排序）
     * @returns {EndingDef[]}
     */
    getEndings() {
        return [...this._endings];
    }

    /**
     * 按类型获取结局列表
     * @param {string} type - ENDING_TYPES
     * @returns {EndingDef[]}
     */
    getEndingsByType(type) {
        return this._endings.filter(e => e.type === type);
    }

    /**
     * 获取单个结局定义
     * @param {string} id
     * @returns {EndingDef|null}
     */
    getEnding(id) {
        return this._endings.find(e => e.id === id) ?? null;
    }

    // ─── 条件检查与触发 ───────────────────────────

    /**
     * 检查所有结局的触发条件，返回当前应触发的结局
     *
     * @param {object} variables  - 当前变量快照
     * @returns {EndingDef[]}     满足条件且可触发的结局列表（已按优先级排序）
     */
    checkAllConditions(variables) {
        const triggerable = [];

        for (const ending of this._endings) {
            const record = this._records.get(ending.id);

            // 已触发且不可重复的跳过
            if (record?.status === ENDING_STATUS.TRIGGERED && !ending.repeatable) continue;

            // 检查互斥
            if (this._isExcluded(ending)) continue;

            // 检查前置
            if (!this._requirementsMet(ending)) continue;

            // 检查触发条件
            if (!ending.condition) continue;

            const condMet = evaluateCondition(ending.condition, variables);
            if (condMet) {
                triggerable.push(ending);

                // 更新状态为 UNLOCKED（如果之前是 LOCKED）
                if (record?.status === ENDING_STATUS.LOCKED) {
                    record.status = ENDING_STATUS.UNLOCKED;
                    this._onUnlocked(ending);
                }
            }
        }

        return triggerable;
    }

    /**
     * 触发指定结局
     *
     * @param {string} id        - 结局 ID
     * @param {object} variables - 当前变量快照（用于内容插值和快照存档）
     * @returns {{ success: boolean, ending: EndingDef|null, content: string, error: string|null }}
     */
    triggerEnding(id, variables = {}) {
        const ending = this.getEnding(id);
        if (!ending) {
            return { success: false, ending: null, content: '', error: `未找到结局：${id}` };
        }

        const record = this._records.get(id);

        // 检查是否可触发
        if (record?.status === ENDING_STATUS.TRIGGERED && !ending.repeatable) {
            return { success: false, ending, content: '', error: '该结局已触发且不可重复' };
        }

        if (this._isExcluded(ending)) {
            return { success: false, ending, content: '', error: '该结局被互斥结局阻止' };
        }

        // 插值处理结局内容
        const content = this._interpolateContent(ending.content, variables);

        // 更新记录
        this._records.set(id, {
            endingId:    id,
            status:      ENDING_STATUS.TRIGGERED,
            triggeredAt: Date.now(),
            snapshot:    { ...variables },
        });

        this._triggeredOrder.push(id);

        // 如果不允许多结局，将其余 UNLOCKED 状态的结局标记为 SKIPPED
        if (!this._options.allowMultiple) {
            this._records.forEach((rec, eid) => {
                if (eid !== id && rec.status === ENDING_STATUS.UNLOCKED) {
                    rec.status = ENDING_STATUS.SKIPPED;
                }
            });
        }

        // 触发回调和事件
        this._onTriggered(ending, content, variables);

        return { success: true, ending, content, error: null };
    }

    /**
     * 自动路由：根据当前变量检查所有条件，触发优先级最高的结局
     *
     * @param {object} variables
     * @returns {{ success: boolean, ending: EndingDef|null, content: string, error: string|null }}
     */
    autoTrigger(variables) {
        const candidates = this.checkAllConditions(variables);
        if (candidates.length === 0) {
            return { success: false, ending: null, content: '', error: '当前没有满足条件的结局' };
        }

        // 取优先级最高的一个
        const best = candidates[0];
        return this.triggerEnding(best.id, variables);
    }

    /**
     * 手动解锁结局（绕过条件检查，用于脚本强制触发）
     * @param {string} id
     * @param {object} [variables]
     * @returns {boolean}
     */
    forceUnlock(id, variables = {}) {
        const ending = this.getEnding(id);
        if (!ending) return false;

        const record = this._records.get(id);
        if (record) record.status = ENDING_STATUS.UNLOCKED;

        this._onUnlocked(ending);
        return true;
    }

    // ─── 状态查询 ─────────────────────────────────

    /**
     * 获取结局当前状态
     * @param {string} id
     * @returns {EndingRecord|null}
     */
    getRecord(id) {
        return this._records.get(id) ?? null;
    }

    /**
     * 获取所有结局的状态快照
     * @returns {Array<{ ending: EndingDef, record: EndingRecord }>}
     */
    getAllRecords() {
        return this._endings.map(e => ({
            ending: e,
            record: this._records.get(e.id) ?? {
                endingId: e.id, status: ENDING_STATUS.LOCKED,
                triggeredAt: null, snapshot: {},
            },
        }));
    }

    /**
     * 获取已触发的结局列表
     * @returns {EndingDef[]}
     */
    getTriggeredEndings() {
        return this._triggeredOrder
            .map(id => this.getEnding(id))
            .filter(Boolean);
    }

    /**
     * 获取已解锁（满足条件但未触发）的结局列表
     * @returns {EndingDef[]}
     */
    getUnlockedEndings() {
        return this._endings.filter(e =>
            this._records.get(e.id)?.status === ENDING_STATUS.UNLOCKED
        );
    }

    /**
     * 是否已触发任意结局
     * @returns {boolean}
     */
    hasTriggered() {
        return this._triggeredOrder.length > 0;
    }

    /**
     * 获取完成度统计
     * @returns {{ total: number, locked: number, unlocked: number, triggered: number, percent: number }}
     */
    getCompletionStats() {
        let locked = 0, unlocked = 0, triggered = 0;

        this._records.forEach(r => {
            if (r.status === ENDING_STATUS.LOCKED)    locked++;
            if (r.status === ENDING_STATUS.UNLOCKED)  unlocked++;
            if (r.status === ENDING_STATUS.TRIGGERED) triggered++;
        });

        const total   = this._endings.length;
        const percent = total > 0 ? Math.round((triggered / total) * 100) : 0;

        return { total, locked, unlocked, triggered, percent };
    }

    // ─── AI 辅助内容生成 ──────────────────────────

    /**
     * 生成结局的触发条件描述文本（供 UI 显示或 AI Prompt 使用）
     * @param {string} id
     * @returns {string}
     */
    describeEndingCondition(id) {
        const ending = this.getEnding(id);
        if (!ending) return '（结局不存在）';
        if (!ending.condition) return '（无触发条件，需手动触发）';
        return describeCondition(ending.condition);
    }

    /**
     * 生成用于 AI 生成结局内容的 Prompt
     * @param {string} id
     * @param {object} [cardData] - 角色卡数据（提供背景信息）
     * @returns {string}
     */
    buildEndingPrompt(id, cardData = {}) {
        const ending = this.getEnding(id);
        if (!ending) return '';

        const d = cardData?.data || {};
        const typeLabels = {
            [ENDING_TYPES.GOOD]:    '好结局（温馨、积极、圆满）',
            [ENDING_TYPES.BAD]:     '坏结局（悲剧、失落、遗憾）',
            [ENDING_TYPES.NEUTRAL]: '中立结局（模糊、开放、余韵）',
            [ENDING_TYPES.SECRET]:  '隐藏结局（出乎意料、特殊）',
            [ENDING_TYPES.TRUE]:    '真结局（揭示核心真相）',
            [ENDING_TYPES.SIDE]:    '支线结局（相对独立的支线故事）',
            [ENDING_TYPES.GAME_OVER]: '游戏结束（失败、死亡）',
        };

        return [
            `你是一位互动小说作者，请为以下角色创作「${ending.title}」的结局内容。`,
            '',
            `结局类型：${typeLabels[ending.type] || ending.type}`,
            `结局简介：${ending.description || '（未提供简介）'}`,
            d.name ? `角色名称：${d.name}` : '',
            d.description ? `角色背景：${d.description.slice(0, 200)}` : '',
            '',
            '要求：',
            '  1. 字数：300~600 字',
            '  2. 以「第二人称」叙述，称呼玩家为「你」',
            '  3. 包含情感共鸣的细节描写',
            '  4. 结尾留有余韵，不要过于生硬',
            '  5. 直接输出正文，不需要标题',
        ].filter(Boolean).join('\n');
    }

    // ─── 序列化 ───────────────────────────────────

    /**
     * 导出所有结局定义为 JSON
     * @returns {object}
     */
    exportJSON() {
        return {
            version:  '1.0',
            endings:  this._endings.map(e => ({
                ...e,
                condition: e.condition ? serializeCondition(e.condition) : null,
            })),
            records:  Object.fromEntries(this._records),
            triggered: this._triggeredOrder,
        };
    }

    /**
     * 从 JSON 导入结局定义（不覆盖已有记录）
     * @param {object} json
     */
    importJSON(json) {
        if (!json?.endings) return;

        json.endings.forEach(raw => {
            // 反序列化条件
            if (raw.condition && typeof raw.condition === 'string') {
                try {
                    raw.condition = JSON.parse(raw.condition);
                } catch (_) { raw.condition = null; }
            }
            this.registerEnding(raw);
        });

        // 恢复状态记录
        if (json.records) {
            Object.entries(json.records).forEach(([id, rec]) => {
                this._records.set(id, rec);
            });
        }

        if (json.triggered) {
            this._triggeredOrder = [...json.triggered];
        }
    }

    /**
     * 重置所有结局状态（清空触发记录，恢复 LOCKED）
     */
    resetAll() {
        this._records.forEach((rec, id) => {
            rec.status      = ENDING_STATUS.LOCKED;
            rec.triggeredAt = null;
            rec.snapshot    = {};
        });
        this._triggeredOrder = [];
    }

    // ═══════════════════════════════════════════════
    // § 4  私有方法
    // ═══════════════════════════════════════════════

    /**
     * 规范化结局定义，填充默认值
     * @param {object} raw
     * @returns {EndingDef}
     */
    _normalizeEnding(raw) {
        return {
            id:          raw.id          || `ending_${Date.now()}`,
            title:       raw.title       || '未命名结局',
            type:        raw.type        || ENDING_TYPES.NEUTRAL,
            description: raw.description || '',
            content:     raw.content     || '',
            condition:   raw.condition   || null,
            priority:    raw.priority    !== undefined
                            ? raw.priority
                            : (ENDING_PRIORITY[raw.type] ?? 50),
            requires:    raw.requires    || [],
            excludes:    raw.excludes    || [],
            worldInfoKey: raw.worldInfoKey || null,
            bgmHint:     raw.bgmHint     || null,
            imageHint:   raw.imageHint   || null,
            afterEffects: raw.afterEffects || null,
            repeatable:  raw.repeatable  || false,
            unlockHint:  raw.unlockHint  || '达成特定条件后解锁',
        };
    }

    /**
     * 校验结局定义
     * @param {EndingDef} def
     */
    _validateEnding(def) {
        if (!def.id)    throw new Error('[EndingSystem] 结局 id 不能为空');
        if (!def.title) throw new Error('[EndingSystem] 结局 title 不能为空');
        if (!Object.values(ENDING_TYPES).includes(def.type)) {
            throw new Error(`[EndingSystem] 无效结局类型：${def.type}`);
        }
    }

    /**
     * 检查结局是否被互斥（因已触发的互斥结局而无法触发）
     * @param {EndingDef} ending
     * @returns {boolean}
     */
    _isExcluded(ending) {
        if (!ending.excludes?.length) return false;
        return ending.excludes.some(eid =>
            this._records.get(eid)?.status === ENDING_STATUS.TRIGGERED
        );
    }

    /**
     * 检查前置结局是否都已满足
     * @param {EndingDef} ending
     * @returns {boolean}
     */
    _requirementsMet(ending) {
        if (!ending.requires?.length) return true;
        return ending.requires.every(eid =>
            this._records.get(eid)?.status === ENDING_STATUS.TRIGGERED
        );
    }

    /**
     * 对结局内容字符串进行变量插值
     * @param {string} content
     * @param {object} variables
     * @returns {string}
     */
    _interpolateContent(content, variables) {
        if (!content) return '';
        return content.replace(/\{\{(\w+)\}\}/g, (_, key) =>
            variables[key] !== undefined ? String(variables[key]) : `{{${key}}}`
        );
    }

    /**
     * 结局解锁回调
     * @param {EndingDef} ending
     */
    _onUnlocked(ending) {
        if (this._options.onEndingUnlocked) {
            this._options.onEndingUnlocked(ending);
        }
        this._bus?.emit(EVENTS.BRANCH_TRIGGERED, {
            action: 'ending_unlocked',
            ending,
        });
    }

    /**
     * 结局触发回调
     * @param {EndingDef} ending
     * @param {string}    content
     * @param {object}    variables
     */
    _onTriggered(ending, content, variables) {
        if (this._options.onEndingTriggered) {
            this._options.onEndingTriggered(ending, content, variables);
        }
        this._bus?.emit(EVENTS.BRANCH_TRIGGERED, {
            action:    'ending_triggered',
            endingId:  ending.id,
            type:      ending.type,
            title:     ending.title,
            content,
        });
    }

    /**
     * 订阅全局事件（用于自动触发检查）
     */
    _subscribeEvents() {
        const unsub = this._bus?.on(EVENTS.RPG_STAT_CHANGED, (data) => {
            if (data?.snapshot) {
                this.checkAllConditions(data.snapshot);
            }
        });
        if (unsub) this._unsubs.push(unsub);
    }
}

// ═══════════════════════════════════════════════
// § 5  内置结局��板
// ═══════════════════════════════════════════════

/**
 * 生成标准四结局模板（好/坏/隐藏/中立）
 * 可直接传入 registerEndings() 使用
 *
 * @param {object} [overrides] - 各结局的内容覆盖（key = ending id）
 * @returns {EndingDef[]}
 */
export function createFourEndingTemplate(overrides = {}) {
    const defaults = [
        {
            id:          'ending_good',
            title:       '☀️ 光明结局',
            type:        ENDING_TYPES.GOOD,
            description: '一切都有了美好的结果。',
            content:     '{{player_name}} 终于迎来了属于自己的光明……',
            condition:   { kind: 'simple', variable: 'flag_good_ending', operator: 'eq', value: 'true', negate: false },
            priority:    60,
        },
        {
            id:          'ending_bad',
            title:       '💀 悲剧结局',
            type:        ENDING_TYPES.BAD,
            description: '一切都走向了最坏的方向。',
            content:     '一切就这样结束了……',
            condition:   { kind: 'simple', variable: 'flag_bad_ending', operator: 'eq', value: 'true', negate: false },
            priority:    50,
        },
        {
            id:          'ending_secret',
            title:       '🌙 隐藏结局',
            type:        ENDING_TYPES.SECRET,
            description: '触发了特殊的隐藏路线。',
            content:     '没有人预料到会有这样的结局……',
            condition:   {
                kind:  'compound',
                logic: 'AND',
                conditions: [
                    { kind: 'simple', variable: 'flag_secret_route', operator: 'eq', value: 'true', negate: false },
                    { kind: 'simple', variable: 'turn_count', operator: 'gte', value: '20', negate: false },
                ],
                negate: false,
            },
            priority:    70,
        },
        {
            id:          'ending_neutral',
            title:       '⚖️ 中立结局',
            type:        ENDING_TYPES.NEUTRAL,
            description: '故事以模糊的方式落幕。',
            content:     '也许这就是最真实的结局……',
            condition:   { kind: 'simple', variable: 'game_state', operator: 'eq', value: 'ending_neutral', negate: false },
            priority:    40,
        },
    ];

    return defaults.map(def => ({
        ...def,
        ...(overrides[def.id] || {}),
    }));
}

/**
 * 生成 Game Over 结局（HP 归零时触发）
 * @param {string} [hpKey='player_hp']
 * @param {string} [content]
 * @returns {EndingDef}
 */
export function createGameOverEnding(hpKey = 'player_hp', content = '') {
    return {
        id:          'ending_game_over',
        title:       '💀 Game Over',
        type:        ENDING_TYPES.GAME_OVER,
        description: '角色死亡，游戏结束。',
        content:     content || '你倒下了……一切就此终结。',
        condition:   { kind: 'simple', variable: hpKey, operator: 'lte', value: '0', negate: false },
        priority:    100,
        repeatable:  false,
    };
}