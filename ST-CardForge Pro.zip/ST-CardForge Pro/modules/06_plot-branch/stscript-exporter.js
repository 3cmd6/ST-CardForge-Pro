/**
 * @file modules/06_plot-branch/stscript-exporter.js
 * @description 剧情分支系统 STscript 导出器
 *              将分支树节点、条件判断、结局系统、选项菜单
 *              统一编译为可在 SillyTavern 中直接运行的 STscript，
 *              并生成配套的 QR Set JSON。
 * @version 1.0.0
 */

import { compileToSTScript, compileConditionOnly,
         describeCondition }          from './condition-parser.js';
import { ENDING_TYPES, ENDING_STATUS } from './ending-system.js';
import { BRANCH_NODE_SCHEMA }          from '../../contracts.js';

// ═══════════════════════════════════════════════
// § 1  常量
// ═══════════════════════════════════════════════

const EXPORT_HEADER = '// ══ 剧情分支脚本 · 由 BranchEngine STscript Exporter 生成 ══';
const EXPORT_FOOTER = '// ══ 脚本结束 ══';

// ═══════════════════════════════════════════════
// § 2  类型定义
// ═══════════════════════════════════════════════

/**
 * @typedef {Object} ExportOptions
 * @property {boolean} [includeComments=true]    - 是否包含注释
 * @property {boolean} [includeEchoFeedback=true]- 是否在关键节点输出 echo 反馈
 * @property {boolean} [useQRSet=true]           - 是否生成 QR Set（否则仅生成脚本）
 * @property {string}  [qrSetName='branch_menu'] - QR Set 名称
 * @property {number}  [maxDepth=20]             - 最大递归深度（防止死循环）
 * @property {boolean} [wrapInFunction=false]    - 是否将脚本包在命名函数中
 */

/**
 * @typedef {Object} ExportResult
 * @property {string}       script      - 主脚本（STscript 字符串）
 * @property {object|null}  qrSetJSON   - QR Set JSON（若 useQRSet=false 则为 null）
 * @property {string[]}     warnings    - 导出过程中的警告信息
 * @property {number}       nodeCount   - 编译的节点数量
 * @property {number}       lineCount   - 生成的代码行数
 */

// ═══════════════════════════════════════════════
// § 3  STScriptExporter 主类
// ═══════════════════════════════════════════════

/**
 * 剧情分支 STscript 导出器
 */
export class STScriptExporter {
    /**
     * @param {object} [options] - 默认导出选项（可被每次调用覆盖）
     */
    constructor(options = {}) {
        this._defaultOptions = {
            includeComments:     true,
            includeEchoFeedback: true,
            useQRSet:            true,
            qrSetName:           'branch_menu',
            maxDepth:            20,
            wrapInFunction:      false,
            ...options,
        };
    }

    // ─── 主导出入口 ───────────────────────────────

    /**
     * 将完整的分支树导出为 STscript + QR Set
     *
     * @param {BranchNode}   rootNode   - 分支树根节点
     * @param {object}       [nodes]    - 所有节点的 id→node 映射（用于快速查找）
     * @param {ExportOptions}[options]
     * @returns {ExportResult}
     */
    exportBranchTree(rootNode, nodes = {}, options = {}) {
        const opts     = { ...this._defaultOptions, ...options };
        const warnings = [];
        const lines    = [];
        const visited  = new Set();

        lines.push(EXPORT_HEADER);
        if (opts.includeComments) {
            lines.push(`// 生成时间：${new Date().toLocaleString()}`);
            lines.push(`// 根节点：${rootNode.id} — ${rootNode.label || ''}`);
        }
        lines.push('');

        // 初始化分支状态变量
        lines.push('// § 初始化分支状态');
        lines.push('/setvar key=branch_current value="" |');
        lines.push('/setvar key=branch_depth value=0 |');
        lines.push('');

        // 递归编译节点树
        this._compileNode(rootNode, nodes, lines, visited, opts, warnings, 0);

        lines.push('');
        lines.push(EXPORT_FOOTER);

        const script    = lines.join('\n');
        const qrSetJSON = opts.useQRSet
            ? this._buildQRSetFromTree(rootNode, nodes, opts)
            : null;

        return {
            script,
            qrSetJSON,
            warnings,
            nodeCount: visited.size,
            lineCount: lines.length,
        };
    }

    /**
     * 将结局系统导出为 STscript
     *
     * @param {EndingDef[]}  endings     - 结局定义列表
     * @param {ExportOptions}[options]
     * @returns {ExportResult}
     */
    exportEndingSystem(endings, options = {}) {
        const opts     = { ...this._defaultOptions, ...options };
        const warnings = [];
        const lines    = [];

        lines.push(EXPORT_HEADER);
        if (opts.includeComments) {
            lines.push(`// 结局系统脚本 — 共 ${endings.length} 个结局`);
            lines.push('// 此脚本应设为「AI 回复后自动执行」触发器');
        }
        lines.push('');

        // 按优先级从高到低检查
        const sorted = [...endings].sort((a, b) =>
            (b.priority ?? 50) - (a.priority ?? 50)
        );

        lines.push('// § 检查所有结局触发条件（按优先级）');
        lines.push('/if left={{getvar::game_ended}} right=true eq');
        lines.push('    /pass |');
        lines.push('/else');
        lines.push('');

        sorted.forEach((ending, idx) => {
            if (!ending.condition) {
                warnings.push(`结局 "${ending.id}" 没有触发条件，已跳过`);
                return;
            }

            lines.push(this._compileEndingCheck(ending, idx, opts));
            lines.push('');
        });

        lines.push(EXPORT_FOOTER);

        const script = lines.join('\n');
        const qrSetJSON = opts.useQRSet
            ? this._buildEndingQRSet(endings, opts)
            : null;

        return {
            script,
            qrSetJSON,
            warnings,
            nodeCount: endings.length,
            lineCount: lines.length,
        };
    }

    /**
     * 将单个节点的选项菜单导出为 STscript + QR Set
     *
     * @param {BranchNode}   node    - 包含 choices 的节点
     * @param {object}       [nodes] - 节点 id→node 映射
     * @param {ExportOptions}[options]
     * @returns {ExportResult}
     */
    exportChoiceMenu(node, nodes = {}, options = {}) {
        const opts     = { ...this._defaultOptions, ...options };
        const warnings = [];
        const lines    = [];
        const qrName   = opts.qrSetName || `choice_${node.id}`;

        if (!node.choices?.length) {
            warnings.push(`节点 "${node.id}" 没有选项，跳过菜单生成`);
            return { script: '', qrSetJSON: null, warnings, nodeCount: 0, lineCount: 0 };
        }

        lines.push(EXPORT_HEADER);
        if (opts.includeComments) {
            lines.push(`// 选项菜单：${node.label || node.id}`);
        }
        lines.push('');

        // 激活对应 QR Set
        lines.push(`/qr-set-enable ${qrName} |`);

        if (opts.includeEchoFeedback) {
            lines.push('/echo ─────────────────────── |');
            lines.push(`/echo 　${node.label || '请选择'} |`);
            lines.push('/echo ─────────────────────── |');
        }

        // 为每个选项检查显示条件
        node.choices.forEach((choice, idx) => {
            if (choice.condition) {
                lines.push(
                    `// 选项 #${idx + 1} 条件检查：${choice.label}`,
                    ...this._buildChoiceVisibility(qrName, idx, choice)
                );
            }
        });

        lines.push('');
        lines.push(EXPORT_FOOTER);

        const script    = lines.join('\n');
        const qrSetJSON = opts.useQRSet
            ? this._buildChoiceQRSet(node, nodes, qrName)
            : null;

        return {
            script,
            qrSetJSON,
            warnings,
            nodeCount: node.choices.length,
            lineCount: lines.length,
        };
    }

    // ─── 节点编译（私有）─────────────────────────

    /**
     * 递归编译单个节点及其子节点
     * @param {BranchNode}  node
     * @param {object}      nodes
     * @param {string[]}    lines
     * @param {Set<string>} visited
     * @param {ExportOptions} opts
     * @param {string[]}    warnings
     * @param {number}      depth
     */
    _compileNode(node, nodes, lines, visited, opts, warnings, depth) {
        if (!node || visited.has(node.id)) return;
        if (depth > opts.maxDepth) {
            warnings.push(`超过最大深度 ${opts.maxDepth}，节点 ${node.id} 已跳过`);
            return;
        }

        visited.add(node.id);

        const indent = '    '.repeat(depth);

        if (opts.includeComments) {
            lines.push(`${indent}// ── 节点：${node.id} [${node.type}] ${node.label || ''} ──`);
        }

        switch (node.type) {

            case 'normal':
                this._compileNormalNode(node, nodes, lines, visited, opts, warnings, depth);
                break;

            case 'condition':
                this._compileConditionNode(node, nodes, lines, visited, opts, warnings, depth);
                break;

            case 'choice':
                this._compileChoiceNode(node, nodes, lines, visited, opts, warnings, depth);
                break;

            case 'ending':
                this._compileEndingNode(node, lines, opts, depth);
                break;

            default:
                warnings.push(`未知节点类型：${node.type}（id: ${node.id}）`);
                lines.push(`${indent}// [未知节点类型：${node.type}]`);
        }
    }

    /**
     * 编译普通叙事节点
     * @param {BranchNode} node
     * @param {object}     nodes
     * @param {string[]}   lines
     * @param {Set<string>}visited
     * @param {ExportOptions} opts
     * @param {string[]}   warnings
     * @param {number}     depth
     */
    _compileNormalNode(node, nodes, lines, visited, opts, warnings, depth) {
        const indent = '    '.repeat(depth);

        // 设置当前节点标记
        lines.push(`${indent}/setvar key=branch_current value="${node.id}" |`);

        // 内容输出
        if (node.content && opts.includeEchoFeedback) {
            const contentLines = node.content.split('\n');
            contentLines.forEach(cl => {
                if (cl.trim()) lines.push(`${indent}/echo ${cl} |`);
            });
        }

        // 附带的 STscript
        if (node.stscript) {
            lines.push(`${indent}// 节点附带脚本`);
            node.stscript.split('\n').forEach(l => lines.push(`${indent}${l}`));
        }

        // 继续编译子节点
        if (node.children?.length) {
            node.children.forEach(childId => {
                const child = nodes[childId];
                if (child) {
                    lines.push('');
                    this._compileNode(child, nodes, lines, visited, opts, warnings, depth);
                } else {
                    warnings.push(`找不到子节点：${childId}`);
                }
            });
        }
    }

    /**
     * 编译条件分支节点（带 if/else）
     * @param {BranchNode} node
     * @param {object}     nodes
     * @param {string[]}   lines
     * @param {Set<string>}visited
     * @param {ExportOptions} opts
     * @param {string[]}   warnings
     * @param {number}     depth
     */
    _compileConditionNode(node, nodes, lines, visited, opts, warnings, depth) {
        const indent = '    '.repeat(depth);

        if (!node.condition) {
            warnings.push(`条件节点 ${node.id} 没有设置条件，视为无条件通过`);
            // 无条件：直接执行子节点
            if (node.children?.length) {
                const child = nodes[node.children[0]];
                if (child) this._compileNode(child, nodes, lines, visited, opts, warnings, depth);
            }
            return;
        }

        if (opts.includeComments) {
            lines.push(`${indent}// 条件：${describeCondition(node.condition)}`);
        }

        // 构建 true 分支脚本
        const trueBranchLines  = [];
        const falseBranchLines = [];

        const trueChild  = node.children?.[0] ? nodes[node.children[0]] : null;
        const falseChild = node.children?.[1] ? nodes[node.children[1]] : null;

        if (trueChild) {
            this._compileNode(trueChild, nodes, trueBranchLines, visited, opts, warnings, depth + 1);
        } else {
            trueBranchLines.push(`${indent}    /pass |`);
        }

        if (falseChild) {
            this._compileNode(falseChild, nodes, falseBranchLines, visited, opts, warnings, depth + 1);
        }

        // 编译 if/else 结构
        const compiledIf = compileToSTScript(
            node.condition,
            trueBranchLines.join('\n'),
            falseBranchLines.join('\n'),
            depth
        );

        lines.push(compiledIf);
    }

    /**
     * 编译选项节点（触发选择菜单）
     * @param {BranchNode} node
     * @param {object}     nodes
     * @param {string[]}   lines
     * @param {Set<string>}visited
     * @param {ExportOptions} opts
     * @param {string[]}   warnings
     * @param {number}     depth
     */
    _compileChoiceNode(node, nodes, lines, visited, opts, warnings, depth) {
        const indent  = '    '.repeat(depth);
        const qrName  = `choice_${node.id}`;

        lines.push(`${indent}/setvar key=branch_current value="${node.id}" |`);
        lines.push(`${indent}/qr-set-enable ${qrName} |`);

        if (opts.includeEchoFeedback) {
            lines.push(`${indent}/echo ─────────────────────── |`);
            lines.push(`${indent}/echo 　${node.label || '请做出选择'} |`);
            lines.push(`${indent}/echo ─────────────────────── |`);
        }

        // 为有条件的选项生成可见性切换
        node.choices?.forEach((choice, idx) => {
            if (choice.condition) {
                const vis = this._buildChoiceVisibility(qrName, idx, choice);
                vis.forEach(l => lines.push(`${indent}${l}`));
            }
        });

        // 选项的实际跳转脚本单独注入到 QR Set 中，此处不直接编译
        // （因为选项触发是异步的，依赖用户点击）
        if (opts.includeComments) {
            lines.push(`${indent}// 等待用户选择（QR Set: ${qrName}）`);
        }
    }

    /**
     * 编译结局节点
     * @param {BranchNode}   node
     * @param {string[]}     lines
     * @param {ExportOptions}opts
     * @param {number}       depth
     */
    _compileEndingNode(node, lines, opts, depth) {
        const indent  = '    '.repeat(depth);
        const typeMap = {
            [ENDING_TYPES.GOOD]:    '☀️ 好结局',
            [ENDING_TYPES.BAD]:     '💀 坏结局',
            [ENDING_TYPES.SECRET]:  '🌙 隐藏结局',
            [ENDING_TYPES.TRUE]:    '✨ 真结局',
            [ENDING_TYPES.NEUTRAL]: '⚖️ 中立结局',
            [ENDING_TYPES.SIDE]:    '🌿 支线结局',
            [ENDING_TYPES.GAME_OVER]: '💀 Game Over',
        };

        lines.push(`${indent}/setvar key=game_ended value=true |`);
        lines.push(`${indent}/setvar key=game_ending value="${node.id}" |`);
        lines.push(`${indent}/qr-set-disable all |`);

        if (opts.includeEchoFeedback) {
            const label = typeMap[node.data?.endingType] || '🔮 结局';
            lines.push(`${indent}/echo ════════════════════════════ |`);
            lines.push(`${indent}/echo          ${label} |`);
            lines.push(`${indent}/echo          ${node.label || ''} |`);
            lines.push(`${indent}/echo ════════════════════════════ |`);
        }

        if (node.content && opts.includeEchoFeedback) {
            node.content.split('\n')
                .filter(l => l.trim())
                .forEach(l => lines.push(`${indent}/echo ${l} |`));
        }

        if (node.stscript) {
            node.stscript.split('\n').forEach(l => lines.push(`${indent}${l}`));
        }
    }

    // ─── 结局检查编译（私有）────────────────────

    /**
     * 编译单个结局的触发条件检查脚本
     * @param {EndingDef}    ending
     * @param {number}       idx
     * @param {ExportOptions}opts
     * @returns {string}
     */
    _compileEndingCheck(ending, idx, opts) {
        const triggerScript = [
            `    /setvar key=game_ended value=true |`,
            `    /setvar key=game_ending value="${ending.id}" |`,
            `    /qr-set-disable all |`,
            opts.includeEchoFeedback
                ? `    /echo 🌟 **${ending.title}** |`
                : '',
            ending.content
                ? `    /echo ${ending.content.split('\n')[0]} |`
                : '',
        ].filter(Boolean).join('\n');

        return compileToSTScript(ending.condition, triggerScript, '', 1);
    }

    // ─── 选项可见性（私有）───────────────────────

    /**
     * 为带条件的选项生成可见性切换 STscript
     * @param {string} qrSetName
     * @param {number} optionIndex
     * @param {object} choice
     * @returns {string[]}
     */
    _buildChoiceVisibility(qrSetName, optionIndex, choice) {
        if (!choice.condition) return [];
        const condLine = compileConditionOnly(choice.condition);
        return [
            `${condLine}`,
            `    /qr-show ${qrSetName} ${optionIndex} |`,
            `/else`,
            `    /qr-hide ${qrSetName} ${optionIndex} |`,
        ];
    }

    // ─── QR Set 构建（私有）─────────────────────

    /**
     * 从分支树构建 QR Set JSON
     * @param {BranchNode}   rootNode
     * @param {object}       nodes
     * @param {ExportOptions}opts
     * @returns {object}
     */
    _buildQRSetFromTree(rootNode, nodes, opts) {
        const replies = [];
        let   id      = 1;
        const visited = new Set();

        const collectChoiceNodes = (node) => {
            if (!node || visited.has(node.id)) return;
            visited.add(node.id);

            if (node.type === 'choice' && node.choices?.length) {
                const qrName = `choice_${node.id}`;
                node.choices.forEach((choice, idx) => {
                    const targetNode = nodes[choice.targetId];
                    const childLines = [];

                    // 关闭当前选择菜单
                    childLines.push(`/qr-set-disable ${qrName} |`);
                    childLines.push(`/setvar key=player_choice value="${idx}" |`);

                    // 执行选项脚本（如有）
                    if (choice.script) {
                        choice.script.split('\n')
                            .filter(l => l.trim())
                            .forEach(l => childLines.push(l));
                    }

                    // 跳转到目标节点（通过 run）
                    if (choice.targetId) {
                        childLines.push(`/run ${choice.targetId}_entry |`);
                    }

                    replies.push({
                        id:               id++,
                        label:            choice.label || `选项 ${idx + 1}`,
                        title:            `${qrName}_opt${idx}`,
                        message:          childLines.join('\n'),
                        contextMenu:      '',
                        preventInput:     true,
                        isHidden:         !!choice.condition,
                        executeOnUser:    false,
                        executeOnAi:      false,
                        autoExecute:      false,
                        extensionPrompt:  '',
                        extensionPromptPos: 0,
                    });
                });
            }

            // 递归子节点
            node.children?.forEach(childId => {
                const child = nodes[childId];
                if (child) collectChoiceNodes(child);
            });
        };

        collectChoiceNodes(rootNode);

        return {
            version:               '1.0',
            name:                  opts.qrSetName,
            disabledByDefault:     false,
            isGlobal:              false,
            quickReplySetCommands: [],
            quickReplies:          replies,
        };
    }

    /**
     * 构建结局系统的 QR Set（手动触发结局按钮）
     * @param {EndingDef[]}  endings
     * @param {ExportOptions}opts
     * @returns {object}
     */
    _buildEndingQRSet(endings, opts) {
        const replies = endings.map((ending, idx) => ({
            id:              idx + 1,
            label:           ending.title,
            title:           `ending_trigger_${ending.id}`,
            message:         [
                `/setvar key=game_ended value=true |`,
                `/setvar key=game_ending value="${ending.id}" |`,
                `/qr-set-disable all |`,
                `/echo 🌟 **${ending.title}** |`,
            ].join('\n'),
            contextMenu:     '',
            preventInput:    true,
            isHidden:        true,    // 默认隐藏，由条件触发时显示
            executeOnUser:   false,
            executeOnAi:     false,
            autoExecute:     false,
            extensionPrompt: '',
            extensionPromptPos: 0,
        }));

        return {
            version:               '1.0',
            name:                  opts.qrSetName,
            disabledByDefault:     false,
            isGlobal:              false,
            quickReplySetCommands: [],
            quickReplies:          replies,
        };
    }

    /**
     * 构建单个选项菜单的 QR Set
     * @param {BranchNode} node
     * @param {object}     nodes
     * @param {string}     qrName
     * @returns {object}
     */
    _buildChoiceQRSet(node, nodes, qrName) {
        const replies = (node.choices || []).map((choice, idx) => {
            const lines = [
                `/qr-set-disable ${qrName} |`,
                `/setvar key=player_choice value="${idx}" |`,
            ];

            if (choice.script) {
                choice.script.split('\n')
                    .filter(l => l.trim())
                    .forEach(l => lines.push(l));
            }

            if (choice.targetId) {
                lines.push(`/run ${choice.targetId}_entry |`);
            }

            return {
                id:              idx + 1,
                label:           choice.label || `选项 ${idx + 1}`,
                title:           `${qrName}_opt${idx}`,
                message:         lines.join('\n'),
                contextMenu:     '',
                preventInput:    true,
                isHidden:        !!choice.condition,
                executeOnUser:   false,
                executeOnAi:     false,
                autoExecute:     false,
                extensionPrompt: '',
                extensionPromptPos: 0,
            };
        });

        return {
            version:               '1.0',
            name:                  qrName,
            disabledByDefault:     false,
            isGlobal:              false,
            quickReplySetCommands: [],
            quickReplies:          replies,
        };
    }
}

// ═══════════════════════════════════════════════
// § 4  独立导出工具函数
// ═══════════════════════════════════════════════

/**
 * 将单条结局定义快速编译为触发脚本
 * @param {EndingDef} ending
 * @param {object}    [options]
 * @param {boolean}   [options.withConditionCheck=false] - 是否包含条件检查
 * @returns {string}
 */
export function exportEndingScript(ending, options = {}) {
    const { withConditionCheck = false } = options;

    const body = [
        `/setvar key=game_ended  value=true |`,
        `/setvar key=game_ending value="${ending.id}" |`,
        `/qr-set-disable all |`,
        `/echo ════════════════════════════ |`,
        `/echo 　　🌟 ${ending.title} |`,
        `/echo ════════════════════════════ |`,
        ending.content
            ? ending.content.split('\n')
                  .filter(l => l.trim())
                  .map(l => `/echo ${l} |`)
                  .join('\n')
            : '',
    ].filter(Boolean).join('\n');

    if (!withConditionCheck || !ending.condition) return body;

    return compileToSTScript(ending.condition, body, '', 0);
}

/**
 * 将选项数组快速导出为 QR Set JSON
 * @param {string} qrSetName
 * @param {Array<{ label: string, script: string, hidden?: boolean }>} choices
 * @returns {object}
 */
export function exportChoicesAsQRSet(qrSetName, choices) {
    return {
        version:               '1.0',
        name:                  qrSetName,
        disabledByDefault:     false,
        isGlobal:              false,
        quickReplySetCommands: [],
        quickReplies:          choices.map((c, idx) => ({
            id:              idx + 1,
            label:           c.label,
            title:           `${qrSetName}_opt${idx}`,
            message:         c.script || '/pass |',
            contextMenu:     '',
            preventInput:    true,
            isHidden:        c.hidden ?? false,
            executeOnUser:   false,
            executeOnAi:     false,
            autoExecute:     false,
            extensionPrompt: '',
            extensionPromptPos: 0,
        })),
    };
}

/**
 * 生成完整的分支系统初始化脚本
 * （在故事开始时运行一次，初始化所有分支相关变量）
 *
 * @param {EndingDef[]} endings  - 所有结局定义
 * @param {string[]}    [flags]  - 额外的布尔旗标变量名列表
 * @returns {string}
 */
export function buildBranchInitScript(endings, flags = []) {
    const lines = [
        EXPORT_HEADER,
        '// § 分支系统初始化',
        '',
        '/setvar key=game_ended    value=false |',
        '/setvar key=game_ending   value="" |',
        '/setvar key=branch_current value="" |',
        '/setvar key=branch_depth  value=0 |',
        '/setvar key=player_choice value="" |',
        '',
        '// § 结局旗标初始化',
    ];

    endings.forEach(e => {
        lines.push(`/setvar key=flag_${e.id} value=false |`);
    });

    if (flags.length > 0) {
        lines.push('');
        lines.push('// § 自定义旗标初始化');
        flags.forEach(f => {
            lines.push(`/setvar key=${f} value=false |`);
        });
    }

    lines.push('');
    lines.push('/echo ✅ 分支系统已初始化。 |');
    lines.push(EXPORT_FOOTER);

    return lines.join('\n');
}