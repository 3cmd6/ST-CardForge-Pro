/**
 * @file visual-tree-editor.js
 * @description 剧情分支可视化树形编辑器
 *              基于 Canvas + SVG 实现节点拖拽、连线、缩放、平移
 *              提供纯 DOM 方案（无 d3 强依赖），可选接入 d3-hierarchy 优化布局
 * @module VisualTreeEditor
 * @version 1.0.0
 */

import { EVENTS, BRANCH_NODE_SCHEMA } from '../../contracts.js';
import { ENDING_TYPES }               from './ending-system.js';

// ─────────────────────────────────────────────
// § 布局常量
// ─────────────────────────────────────────────

/** 节点默认尺寸 */
const NODE_WIDTH  = 160;
const NODE_HEIGHT = 60;

/** 层级间距（纵向） */
const LEVEL_GAP   = 100;

/** 同层节点间距（横向） */
const SIBLING_GAP = 40;

/** 画布内边距 */
const CANVAS_PADDING = 60;

/** 节点类型颜色映射 */
const NODE_COLORS = {
    normal:    '#5b6ab5',
    condition: '#e67e22',
    choice:    '#2ecc71',
    ending:    '#e74c3c',
};

/** 结局类型补色 */
const ENDING_COLORS = {
    good:    '#27ae60',
    bad:     '#c0392b',
    true:    '#8e44ad',
    neutral: '#7f8c8d',
    secret:  '#16a085',
    normal:  '#e74c3c',
};

// ─────────────────────────────────────────────
// § VisualTreeEditor 类
// ─────────────────────────────────────────────

/**
 * 可视化剧情树编辑器
 * 在给定容器内渲染可交互的节点树
 */
export class VisualTreeEditor {

    /**
     * @param {HTMLElement} container       承载编辑器的 DOM 元素
     * @param {import('../../core/event-bus.js').EventBus} eventBus
     * @param {Object} [options]
     * @param {boolean} [options.readonly=false]   只读模式
     * @param {boolean} [options.minimap=true]     显示缩略地图
     * @param {boolean} [options.snapToGrid=true]  吸附网格
     */
    constructor(container, eventBus, options = {}) {
        /** @type {HTMLElement} */
        this._container = container;

        /** @type {import('../../core/event-bus.js').EventBus} */
        this._eventBus = eventBus;

        this._opts = {
            readonly:   false,
            minimap:    true,
            snapToGrid: true,
            gridSize:   20,
            ...options,
        };

        /**
         * 节点数据 Map，key = node.id
         * @type {Map<string, Object>}
         */
        this._nodes = new Map();

        /**
         * 节点位置 Map，key = node.id，value = { x, y }
         * @type {Map<string, {x:number, y:number}>}
         */
        this._positions = new Map();

        /** 当前选中节点 ID @type {string|null} */
        this._selectedId = null;

        /** 当前拖拽状态 @type {Object|null} */
        this._drag = null;

        /** 视口变换 @type {{x:number, y:number, scale:number}} */
        this._viewport = { x: 0, y: 0, scale: 1 };

        /** SVG 根元素 @type {SVGSVGElement|null} */
        this._svg = null;

        /** 节点层 group @type {SVGGElement|null} */
        this._nodeLayer = null;

        /** 连线层 group @type {SVGGElement|null} */
        this._edgeLayer = null;

        /** 变换 group @type {SVGGElement|null} */
        this._transformGroup = null;

        /** 事件监听取消函数集合 @type {Function[]} */
        this._listeners = [];

        /** 外部变更回调 @type {Function|null} */
        this._onChangeCallback = null;

        /** minimap Canvas @type {HTMLCanvasElement|null} */
        this._minimapCanvas = null;
    }

    // ── 生命周期 ─────────────────────────────

    /**
     * 初始化编辑器，构建 SVG 骨架
     * @returns {void}
     */
    init() {
        this._container.innerHTML = '';
        this._container.style.position = 'relative';
        this._container.style.overflow = 'hidden';
        this._container.style.background = 'var(--cf-bg-panel)';

        this._buildSVG();

        if (this._opts.minimap) {
            this._buildMinimap();
        }

        this._bindEvents();
    }

    /**
     * 销毁编辑器，移除所有监听
     */
    destroy() {
        this._listeners.forEach(fn => fn());
        this._listeners = [];
        this._container.innerHTML = '';
        this._nodes.clear();
        this._positions.clear();
    }

    // ── 数据 ─────────────────────────────────

    /**
     * 加载节点数组（替换现有数据并重绘）
     * @param {Object[]} nodes    节点数组
     * @param {string}   rootId  根节点 ID
     */
    loadNodes(nodes, rootId) {
        this._nodes.clear();
        this._positions.clear();

        for (const node of nodes) {
            this._nodes.set(node.id, { ...node });
        }

        // 自动布局
        this._autoLayout(rootId);
        this._render();
    }

    /**
     * 更新单个节点数据（保留位置，仅重绘该节点）
     * @param {string} nodeId
     * @param {Object} changes
     */
    updateNode(nodeId, changes) {
        const node = this._nodes.get(nodeId);
        if (!node) return;
        Object.assign(node, changes, { id: nodeId });
        this._renderNode(nodeId);
        this._renderEdges();
        this._refreshMinimap();
    }

    /**
     * 添加节点（需指定初始位置或父节点）
     * @param {Object} node
     * @param {string|null} [parentId]
     */
    addNode(node, parentId = null) {
        this._nodes.set(node.id, { ...node });

        if (parentId && this._positions.has(parentId)) {
            const pp = this._positions.get(parentId);
            // 放在父节点正下方
            this._positions.set(node.id, {
                x: pp.x,
                y: pp.y + NODE_HEIGHT + LEVEL_GAP,
            });
        } else {
            this._positions.set(node.id, {
                x: CANVAS_PADDING,
                y: CANVAS_PADDING,
            });
        }

        this._render();
    }

    /**
     * 移除节点及其连线
     * @param {string} nodeId
     */
    removeNode(nodeId) {
        this._nodes.delete(nodeId);
        this._positions.delete(nodeId);
        if (this._selectedId === nodeId) this._selectedId = null;
        this._render();
    }

    /**
     * 获取所有节点数据（含位置）
     * @returns {Object[]}
     */
    getNodes() {
        return Array.from(this._nodes.values()).map(node => ({
            ...node,
            _pos: this._positions.get(node.id) || { x: 0, y: 0 },
        }));
    }

    /**
     * 获取当前选中节点
     * @returns {Object|null}
     */
    getSelectedNode() {
        return this._selectedId
            ? this._nodes.get(this._selectedId)
            : null;
    }

    /**
     * 选中节点（可传 null 取消选中）
     * @param {string|null} nodeId
     */
    selectNode(nodeId) {
        const prev = this._selectedId;
        this._selectedId = nodeId || null;

        // 更新视觉状态
        if (prev) this._renderNode(prev);
        if (nodeId) this._renderNode(nodeId);
    }

    /**
     * 注册节点变更回调
     * @param {Function} callback  (nodeId, changes) => void
     */
    onChange(callback) {
        this._onChangeCallback = callback;
    }

    // ── 视口操作 ─────────────────────────────

    /**
     * 居中并适配所有节点到视口
     */
    fitView() {
        if (this._positions.size === 0) return;

        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

        for (const pos of this._positions.values()) {
            minX = Math.min(minX, pos.x);
            minY = Math.min(minY, pos.y);
            maxX = Math.max(maxX, pos.x + NODE_WIDTH);
            maxY = Math.max(maxY, pos.y + NODE_HEIGHT);
        }

        const cw = this._container.clientWidth;
        const ch = this._container.clientHeight;
        const tw = maxX - minX + CANVAS_PADDING * 2;
        const th = maxY - minY + CANVAS_PADDING * 2;

        const scaleX = cw / tw;
        const scaleY = ch / th;
        const scale  = Math.min(scaleX, scaleY, 1.5);

        this._viewport = {
            scale,
            x: (cw - tw * scale) / 2 - (minX - CANVAS_PADDING) * scale,
            y: (ch - th * scale) / 2 - (minY - CANVAS_PADDING) * scale,
        };

        this._applyTransform();
        this._refreshMinimap();
    }

    /**
     * 缩放（以画布中心为基准）
     * @param {number} delta  正值放大，负值缩小
     */
    zoom(delta) {
        const newScale = Math.max(0.2, Math.min(3, this._viewport.scale + delta));
        this._viewport.scale = newScale;
        this._applyTransform();
    }

    /**
     * 重置视口
     */
    resetView() {
        this._viewport = { x: 0, y: 0, scale: 1 };
        this._applyTransform();
    }

    // ── 内部渲染 ─────────────────────────────

    /**
     * 构建 SVG 骨架
     * @private
     */
    _buildSVG() {
        const ns = 'http://www.w3.org/2000/svg';

        this._svg = document.createElementNS(ns, 'svg');
        this._svg.setAttribute('width', '100%');
        this._svg.setAttribute('height', '100%');
        this._svg.style.display = 'block';
        this._svg.style.cursor = 'grab';

        // defs：箭头标记
        const defs    = document.createElementNS(ns, 'defs');
        const marker  = document.createElementNS(ns, 'marker');
        marker.setAttribute('id', 'cf-arrow');
        marker.setAttribute('viewBox', '0 0 10 10');
        marker.setAttribute('refX', '10');
        marker.setAttribute('refY', '5');
        marker.setAttribute('markerWidth', '6');
        marker.setAttribute('markerHeight', '6');
        marker.setAttribute('orient', 'auto-start-reverse');
        const arrowPath = document.createElementNS(ns, 'path');
        arrowPath.setAttribute('d', 'M 0 0 L 10 5 L 0 10 z');
        arrowPath.setAttribute('fill', 'var(--cf-text-muted)');
        marker.appendChild(arrowPath);
        defs.appendChild(marker);
        this._svg.appendChild(defs);

        // 背景网格
        const bgGrid = this._buildGridPattern();
        this._svg.appendChild(bgGrid);

        // 变换容器
        this._transformGroup = document.createElementNS(ns, 'g');
        this._transformGroup.setAttribute('class', 'cf-transform-group');
        this._svg.appendChild(this._transformGroup);

        // 连线层（在节点层下方）
        this._edgeLayer = document.createElementNS(ns, 'g');
        this._edgeLayer.setAttribute('class', 'cf-edge-layer');
        this._transformGroup.appendChild(this._edgeLayer);

        // 节点层
        this._nodeLayer = document.createElementNS(ns, 'g');
        this._nodeLayer.setAttribute('class', 'cf-node-layer');
        this._transformGroup.appendChild(this._nodeLayer);

        this._container.appendChild(this._svg);
    }

    /**
     * 构建网格背景 pattern
     * @returns {SVGRectElement}
     * @private
     */
    _buildGridPattern() {
        const ns  = 'http://www.w3.org/2000/svg';
        const g   = this._opts.gridSize;

        // 通过 defs 中已有的 defs 补充 pattern
        const defs = this._svg.querySelector('defs');

        const pattern = document.createElementNS(ns, 'pattern');
        pattern.setAttribute('id', 'cf-grid-pattern');
        pattern.setAttribute('width', String(g));
        pattern.setAttribute('height', String(g));
        pattern.setAttribute('patternUnits', 'userSpaceOnUse');

        const path = document.createElementNS(ns, 'path');
        path.setAttribute('d', `M ${g} 0 L 0 0 0 ${g}`);
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke', 'rgba(255,255,255,0.04)');
        path.setAttribute('stroke-width', '0.5');
        pattern.appendChild(path);
        defs.appendChild(pattern);

        const rect = document.createElementNS(ns, 'rect');
        rect.setAttribute('width', '200%');
        rect.setAttribute('height', '200%');
        rect.setAttribute('fill', 'url(#cf-grid-pattern)');
        return rect;
    }

    /**
     * 构建 minimap
     * @private
     */
    _buildMinimap() {
        const wrap = document.createElement('div');
        wrap.className = 'cardforge-branch-minimap';
        wrap.style.cssText = `
            position: absolute;
            right: 12px;
            bottom: 12px;
            width: 140px;
            height: 100px;
            border: 1px solid var(--cf-border);
            border-radius: var(--cf-radius);
            overflow: hidden;
            background: var(--cf-bg-card);
            opacity: 0.85;
        `;

        this._minimapCanvas = document.createElement('canvas');
        this._minimapCanvas.width  = 140;
        this._minimapCanvas.height = 100;
        this._minimapCanvas.style.width  = '100%';
        this._minimapCanvas.style.height = '100%';
        wrap.appendChild(this._minimapCanvas);
        this._container.appendChild(wrap);
    }

    /**
     * 自动层次布局（Reingold-Tilford 简化版）
     * @param {string} rootId
     * @private
     */
    _autoLayout(rootId) {
        const nodeMap = this._nodes;
        const visited = new Set();

        // BFS 分层
        const levels = [];
        let queue = [rootId];

        while (queue.length > 0) {
            levels.push([...queue]);
            const next = [];
            for (const id of queue) {
                if (visited.has(id)) continue;
                visited.add(id);
                const node = nodeMap.get(id);
                if (!node) continue;

                const children = [
                    ...(node.children || []),
                    ...(node.choices || []).map(c => c.targetId),
                ].filter(Boolean);

                for (const cid of children) {
                    if (!visited.has(cid)) next.push(cid);
                }
            }
            queue = [...new Set(next)];
        }

        // 按层分配坐标
        for (let lvl = 0; lvl < levels.length; lvl++) {
            const nodesInLevel = levels[lvl];
            const totalWidth   = nodesInLevel.length * NODE_WIDTH
                               + (nodesInLevel.length - 1) * SIBLING_GAP;
            const startX       = CANVAS_PADDING + Math.max(0, (800 - totalWidth) / 2);

            for (let idx = 0; idx < nodesInLevel.length; idx++) {
                const id = nodesInLevel[idx];
                this._positions.set(id, {
                    x: startX + idx * (NODE_WIDTH + SIBLING_GAP),
                    y: CANVAS_PADDING + lvl * (NODE_HEIGHT + LEVEL_GAP),
                });
            }
        }

        // 未被 BFS 遍历的孤立节点
        let orphanX = CANVAS_PADDING;
        const orphanY = CANVAS_PADDING + levels.length * (NODE_HEIGHT + LEVEL_GAP);
        for (const id of nodeMap.keys()) {
            if (!this._positions.has(id)) {
                this._positions.set(id, { x: orphanX, y: orphanY });
                orphanX += NODE_WIDTH + SIBLING_GAP;
            }
        }
    }

    /**
     * 全量重新渲染
     * @private
     */
    _render() {
        this._edgeLayer.innerHTML = '';
        this._nodeLayer.innerHTML = '';

        this._renderEdges();

        for (const id of this._nodes.keys()) {
            this._renderNode(id);
        }

        this._refreshMinimap();
    }

    /**
     * 渲染所有连线
     * @private
     */
    _renderEdges() {
        this._edgeLayer.innerHTML = '';
        const ns = 'http://www.w3.org/2000/svg';

        for (const node of this._nodes.values()) {
            const fromPos = this._positions.get(node.id);
            if (!fromPos) continue;

            // children 连线
            const targets = [
                ...(node.children || []),
                ...(node.choices  || []).map(c => c.targetId),
            ].filter(Boolean);

            for (const targetId of targets) {
                const toPos = this._positions.get(targetId);
                if (!toPos) continue;

                const path = document.createElementNS(ns, 'path');
                path.setAttribute('d', this._bezierPath(fromPos, toPos));
                path.setAttribute('stroke', 'var(--cf-text-muted)');
                path.setAttribute('stroke-width', '1.5');
                path.setAttribute('fill', 'none');
                path.setAttribute('marker-end', 'url(#cf-arrow)');
                path.setAttribute('opacity', '0.6');
                this._edgeLayer.appendChild(path);
            }
        }
    }

    /**
     * 渲染单个节点
     * @param {string} nodeId
     * @private
     */
    _renderNode(nodeId) {
        const ns   = 'http://www.w3.org/2000/svg';
        const node = this._nodes.get(nodeId);
        const pos  = this._positions.get(nodeId);
        if (!node || !pos) return;

        // 移除旧节点 DOM
        const existing = this._nodeLayer.querySelector(`[data-node-id="${nodeId}"]`);
        if (existing) existing.remove();

        const g = document.createElementNS(ns, 'g');
        g.setAttribute('data-node-id', nodeId);
        g.setAttribute('transform', `translate(${pos.x}, ${pos.y})`);
        g.style.cursor = this._opts.readonly ? 'pointer' : 'grab';

        // 背景矩形
        const rect = document.createElementNS(ns, 'rect');
        rect.setAttribute('width',  String(NODE_WIDTH));
        rect.setAttribute('height', String(NODE_HEIGHT));
        rect.setAttribute('rx',     '8');
        rect.setAttribute('ry',     '8');
        rect.setAttribute('fill',   this._nodeColor(node));
        rect.setAttribute('stroke', this._selectedId === nodeId ? '#fff' : 'transparent');
        rect.setAttribute('stroke-width', '2');
        rect.setAttribute('opacity', '0.9');
        g.appendChild(rect);

        // 节点类型图标
        const icon = document.createElementNS(ns, 'text');
        icon.setAttribute('x', '12');
        icon.setAttribute('y', '22');
        icon.setAttribute('font-size', '14');
        icon.textContent = this._nodeIcon(node);
        g.appendChild(icon);

        // 标签文本
        const label = document.createElementNS(ns, 'text');
        label.setAttribute('x', '32');
        label.setAttribute('y', '22');
        label.setAttribute('fill', '#fff');
        label.setAttribute('font-size', '12');
        label.setAttribute('font-weight', '600');
        label.textContent = this._truncate(node.label || node.id, 14);
        g.appendChild(label);

        // 子信息（节点 ID）
        const subLabel = document.createElementNS(ns, 'text');
        subLabel.setAttribute('x', '12');
        subLabel.setAttribute('y', '42');
        subLabel.setAttribute('fill', 'rgba(255,255,255,0.6)');
        subLabel.setAttribute('font-size', '10');
        subLabel.textContent = `#${this._truncate(nodeId, 18)}`;
        g.appendChild(subLabel);

        // 子节点数量徽章
        const childCount = (node.children?.length || 0) + (node.choices?.length || 0);
        if (childCount > 0) {
            const badge = this._buildBadge(ns, String(childCount), NODE_WIDTH - 18, 2);
            g.appendChild(badge);
        }

        // 事件绑定
        this._bindNodeEvents(g, nodeId);

        this._nodeLayer.appendChild(g);
    }

    /**
     * 构建数字徽章
     * @private
     */
    _buildBadge(ns, text, x, y) {
        const g = document.createElementNS(ns, 'g');

        const circle = document.createElementNS(ns, 'circle');
        circle.setAttribute('cx', String(x + 8));
        circle.setAttribute('cy', String(y + 8));
        circle.setAttribute('r', '8');
        circle.setAttribute('fill', '#7b68ee');
        g.appendChild(circle);

        const t = document.createElementNS(ns, 'text');
        t.setAttribute('x', String(x + 8));
        t.setAttribute('y', String(y + 12));
        t.setAttribute('text-anchor', 'middle');
        t.setAttribute('fill', '#fff');
        t.setAttribute('font-size', '9');
        t.setAttribute('font-weight', 'bold');
        t.textContent = text;
        g.appendChild(t);

        return g;
    }

    /**
     * 为节点 DOM 绑定交互事件
     * @private
     */
    _bindNodeEvents(nodeGroup, nodeId) {
        // 点击选中
        nodeGroup.addEventListener('click', (e) => {
            e.stopPropagation();
            this.selectNode(nodeId);
            this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
                action:   'select',
                nodeId,
                node:     this._nodes.get(nodeId),
            });
        });

        if (!this._opts.readonly) {
            // 拖拽开始
            nodeGroup.addEventListener('mousedown', (e) => {
                if (e.button !== 0) return;
                e.stopPropagation();

                const pos  = this._positions.get(nodeId);
                const svgP = this._svgPoint(e.clientX, e.clientY);

                this._drag = {
                    nodeId,
                    startSvgX:  svgP.x,
                    startSvgY:  svgP.y,
                    startNodeX: pos.x,
                    startNodeY: pos.y,
                };
                nodeGroup.style.cursor = 'grabbing';
            });

            // 双击编辑
            nodeGroup.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                this._eventBus.emit(EVENTS.BRANCH_TREE_UPDATED, {
                    action:  'edit',
                    nodeId,
                    node:    this._nodes.get(nodeId),
                });
            });
        }
    }

    // ── 事件绑定 ─────────────────────────────

    /**
     * 绑定画布级别的鼠标/滚轮事件
     * @private
     */
    _bindEvents() {
        // 画布拖拽（平移视口）
        const onMouseDown = (e) => {
            if (e.button !== 0 || this._drag) return;
            const startX = e.clientX - this._viewport.x;
            const startY = e.clientY - this._viewport.y;

            const onMove = (e2) => {
                this._viewport.x = e2.clientX - startX;
                this._viewport.y = e2.clientY - startY;
                this._applyTransform();
            };

            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup',  onUp);
                this._svg.style.cursor = 'grab';
            };

            this._svg.style.cursor = 'grabbing';
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup',  onUp);
        };

        // 节点拖拽（移动节点）
        const onMouseMove = (e) => {
            if (!this._drag) return;

            const svgP  = this._svgPoint(e.clientX, e.clientY);
            let   newX  = this._drag.startNodeX + (svgP.x - this._drag.startSvgX);
            let   newY  = this._drag.startNodeY + (svgP.y - this._drag.startSvgY);

            if (this._opts.snapToGrid) {
                const g = this._opts.gridSize;
                newX = Math.round(newX / g) * g;
                newY = Math.round(newY / g) * g;
            }

            this._positions.set(this._drag.nodeId, { x: newX, y: newY });
            this._renderNode(this._drag.nodeId);
            this._renderEdges();
        };

        const onMouseUp = (e) => {
            if (this._drag) {
                // 触发位置变更回调
                const pos = this._positions.get(this._drag.nodeId);
                if (this._onChangeCallback) {
                    this._onChangeCallback(this._drag.nodeId, { _pos: pos });
                }
                this._drag = null;
                this._refreshMinimap();
            }
        };

        // 滚轮缩放
        const onWheel = (e) => {
            e.preventDefault();
            const delta = e.deltaY > 0 ? -0.08 : 0.08;
            this.zoom(delta);
        };

        // 画布点击取消选中
        const onSvgClick = () => {
            if (this._selectedId) {
                const prev = this._selectedId;
                this._selectedId = null;
                this._renderNode(prev);
            }
        };

        this._svg.addEventListener('mousedown', onMouseDown);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup',   onMouseUp);
        this._svg.addEventListener('wheel',     onWheel, { passive: false });
        this._svg.addEventListener('click',     onSvgClick);

        // 记录取消函数
        this._listeners.push(
            () => this._svg.removeEventListener('mousedown', onMouseDown),
            () => document.removeEventListener('mousemove',  onMouseMove),
            () => document.removeEventListener('mouseup',    onMouseUp),
            () => this._svg.removeEventListener('wheel',     onWheel),
            () => this._svg.removeEventListener('click',     onSvgClick),
        );
    }

    // ── 工具方法 ─────────────────────────────

    /**
     * 应用当前视口变换
     * @private
     */
    _applyTransform() {
        const { x, y, scale } = this._viewport;
        this._transformGroup.setAttribute(
            'transform', `translate(${x}, ${y}) scale(${scale})`
        );
    }

    /**
     * 刷新 minimap
     * @private
     */
    _refreshMinimap() {
        if (!this._minimapCanvas || this._positions.size === 0) return;

        const ctx = this._minimapCanvas.getContext('2d');
        const cw  = this._minimapCanvas.width;
        const ch  = this._minimapCanvas.height;
        ctx.clearRect(0, 0, cw, ch);

        // 计算包围盒
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const pos of this._positions.values()) {
            minX = Math.min(minX, pos.x);
            minY = Math.min(minY, pos.y);
            maxX = Math.max(maxX, pos.x + NODE_WIDTH);
            maxY = Math.max(maxY, pos.y + NODE_HEIGHT);
        }

        const scaleX = cw / (maxX - minX + 20);
        const scaleY = ch / (maxY - minY + 20);
        const sc     = Math.min(scaleX, scaleY);

        // 绘制节点
        for (const [id, pos] of this._positions.entries()) {
            const node = this._nodes.get(id);
            if (!node) continue;

            const x = (pos.x - minX + 10) * sc;
            const y = (pos.y - minY + 10) * sc;
            const w = NODE_WIDTH  * sc;
            const h = NODE_HEIGHT * sc;

            ctx.fillStyle = this._nodeColor(node);
            ctx.globalAlpha = id === this._selectedId ? 1 : 0.7;
            ctx.beginPath();
            ctx.roundRect?.(x, y, w, h, 2) || ctx.rect(x, y, w, h);
            ctx.fill();
        }

        ctx.globalAlpha = 1;
    }

    /**
     * 将屏幕坐标转换为 SVG 局部坐标（考虑视口变换）
     * @param {number} clientX
     * @param {number} clientY
     * @returns {{x:number, y:number}}
     * @private
     */
    _svgPoint(clientX, clientY) {
        const rect = this._svg.getBoundingClientRect();
        return {
            x: (clientX - rect.left - this._viewport.x) / this._viewport.scale,
            y: (clientY - rect.top  - this._viewport.y) / this._viewport.scale,
        };
    }

    /**
     * 生成贝塞尔曲线路径（从节点底部中心到目标顶部中心）
     * @param {{x:number,y:number}} from
     * @param {{x:number,y:number}} to
     * @returns {string}
     * @private
     */
    _bezierPath(from, to) {
        const x1 = from.x + NODE_WIDTH  / 2;
        const y1 = from.y + NODE_HEIGHT;
        const x2 = to.x   + NODE_WIDTH  / 2;
        const y2 = to.y;
        const mid = (y1 + y2) / 2;
        return `M ${x1} ${y1} C ${x1} ${mid}, ${x2} ${mid}, ${x2} ${y2}`;
    }

    /**
     * 获取节点颜色
     * @param {Object} node
     * @returns {string}
     * @private
     */
    _nodeColor(node) {
        if (node.type === 'ending') {
            return ENDING_COLORS[node.endingType] || NODE_COLORS.ending;
        }
        return NODE_COLORS[node.type] || NODE_COLORS.normal;
    }

    /**
     * 获取节点图标
     * @param {Object} node
     * @returns {string}
     * @private
     */
    _nodeIcon(node) {
        const icons = {
            normal:    '📖',
            condition: '⚙️',
            choice:    '🔀',
            ending:    '🏁',
        };
        return icons[node.type] || '📖';
    }

    /**
     * 截断字符串
     * @param {string} str
     * @param {number} max
     * @returns {string}
     * @private
     */
    _truncate(str, max) {
        if (!str) return '';
        return str.length > max ? str.slice(0, max) + '…' : str;
    }
}