/**
 * @file preset-library.js
 * @description 正则锻造器 · 预设规则库
 * @version 1.0.0
 */

import { REGEX_RULE_SCHEMA } from '../../contracts.js';

// ─────────────────────────────────────────────
// § 预设分类
// ─────────────────────────────────────────────

export const PRESET_CATEGORIES = {
    purify:   { id: 'purify',   label: '🧹 净化类',   desc: '移除不需要的标记和注记'    },
    beautify: { id: 'beautify', label: '✨ 美化类',   desc: '格式美化与动作样式增强'    },
    cn_typo:  { id: 'cn_typo',  label: '📝 中文排版', desc: '中文标点、间距、引号修正'  },
    format:   { id: 'format',   label: '🔄 格式转换', desc: 'Markdown / HTML 互转'     },
    advanced: { id: 'advanced', label: '⚙️ 高级技巧', desc: '命名捕获组、回溯引用等'   },
    rpg:      { id: 'rpg',      label: '🎲 RPG 专用', desc: '属性变化、骰子结果格式化' },
};

// ─────────────────────────────────────────────
// § 预设规则库
// ─────────────────────────────────────────────

export const REGEX_PRESETS = {

    // ── 净化类 ──────────────────────────────

    remove_ooc_bracket: {
        id: 'remove_ooc_bracket', name: '移除 OOC 括号内容',
        category: 'purify', find: '\\(OOC:.*?\\)', flags: 'gi',
        replace: '', scope: 'output', enabled: true, priority: 10,
        description: '移除 AI 输出中 (OOC: ...) 格式的出戏注记',
        example: { input: '她微笑着说。(OOC: 这里应该更温柔一些)', output: '她微笑着说。' },
    },

    remove_ooc_square: {
        id: 'remove_ooc_square', name: '移除 OOC 方括号内容',
        category: 'purify', find: '\\[OOC:.*?\\]', flags: 'gi',
        replace: '', scope: 'output', enabled: true, priority: 10,
        description: '移除 AI 输出中 [OOC: ...] 格式的出戏注记',
        example: { input: '战斗开始了。[OOC: 请注意属性设定]', output: '战斗开始了。' },
    },

    remove_author_note: {
        id: 'remove_author_note', name: '移除作者注记标签',
        category: 'purify', find: "\\[Author's Note:.*?\\]", flags: 'gis',
        replace: '', scope: 'output', enabled: true, priority: 10,
        description: "移除 [Author's Note: ...] 形式的标记",
        example: { input: "故事继续。[Author's Note: 保持黑暗风格]", output: '故事继续。' },
    },

    remove_system_tag: {
        id: 'remove_system_tag', name: '移除 <system> 标签',
        category: 'purify', find: '<system>.*?<\\/system>', flags: 'gis',
        replace: '', scope: 'output', enabled: true, priority: 10,
        description: '移除 AI 插入的 <system>...</system> 块',
        example: { input: '角色开口说话。<system>提示</system>', output: '角色开口说话。' },
    },

    remove_disclaimer: {
        id: 'remove_disclaimer', name: '移除免责声明段落',
        category: 'purify',
        find: '^(As an AI|I\'m an AI|请注意，我是|作为AI).+$', flags: 'gim',
        replace: '', scope: 'output', enabled: true, priority: 5,
        description: '移除 AI 输出开头的免责声明类语句',
        example: { input: '作为AI，我需要提醒你...\n\n她转身离去。', output: '\n\n她转身离去。' },
    },

    remove_thinking_block: {
        id: 'remove_thinking_block', name: '移除 <thinking> 思考块',
        category: 'purify', find: '<thinking>[\\s\\S]*?<\\/thinking>', flags: 'gi',
        replace: '', scope: 'output', enabled: true, priority: 10,
        description: '移除部分模型输出的 <thinking>...</thinking> 推理块',
        example: { input: '<thinking>思考...</thinking>\n她说：「你好。」', output: '\n她说：「你好。」' },
    },

    // ── 美化类 ──────────────────────────────

    beautify_action_star: {
        id: 'beautify_action_star', name: '动作描写星号 → 斜体',
        category: 'beautify', find: '\\*([^*\\n]+)\\*', flags: 'g',
        replace: '<em>$1</em>', scope: 'output', enabled: true, priority: 20,
        description: '将 *动作描写* 转换为 HTML 斜体标签',
        example: { input: '她 *微微低头* 然后说话。', output: '她 <em>微微低头</em> 然后说话。' },
    },

    beautify_thought_italic: {
        id: 'beautify_thought_italic', name: '内心独白 → 斜体加色',
        category: 'beautify', find: '_(.*?)_', flags: 'g',
        replace: '<i style="color:var(--cf-info)">$1</i>',
        scope: 'output', enabled: true, priority: 20,
        description: '将 _独白内容_ 转换为蓝色斜体',
        example: { input: '她看着他，_这个人想干什么？_', output: '她看着他，<i style="color:var(--cf-info)">这个人想干什么？</i>' },
    },

    beautify_bold_double_star: {
        id: 'beautify_bold_double_star', name: '**重要内容** → 加粗',
        category: 'beautify', find: '\\*\\*([^*\\n]+)\\*\\*', flags: 'g',
        replace: '<strong>$1</strong>', scope: 'output', enabled: true, priority: 25,
        description: '将 **重要内容** 转换为 HTML 粗体标签',
        example: { input: '这是 **非常重要** 的信息。', output: '这是 <strong>非常重要</strong> 的信息。' },
    },

    beautify_separator: {
        id: 'beautify_separator', name: '--- 分隔线 → HR',
        category: 'beautify', find: '^---+$', flags: 'gm',
        replace: '<hr style="border-color:var(--cf-border);margin:12px 0">',
        scope: 'output', enabled: true, priority: 15,
        description: '将三个以上连字符单独一行转换为水平分割线',
        example: { input: '第一幕\n\n---\n\n第二幕', output: '第一幕\n\n<hr ...>\n\n第二幕' },
    },

    beautify_scene_header: {
        id: 'beautify_scene_header', name: '场景标题样式化',
        category: 'beautify', find: '^【(.*?)】$', flags: 'gm',
        replace: '<div style="text-align:center;font-weight:700;color:var(--cf-primary);margin:8px 0">【$1】</div>',
        scope: 'output', enabled: true, priority: 20,
        description: '将独占一行的【场景名】转换为居中粗体标题',
        example: { input: '【第三章：决战】', output: '<div ...>【第三章：决战】</div>' },
    },

    beautify_quote_box: {
        id: 'beautify_quote_box', name: '引用段落样式化',
        category: 'beautify', find: '^> (.+)$', flags: 'gm',
        replace: '<blockquote style="border-left:3px solid var(--cf-primary);padding:6px 12px;margin:6px 0;color:var(--cf-text-muted)">$1</blockquote>',
        scope: 'output', enabled: true, priority: 15,
        description: '将 Markdown 引用格式（> 内容）转换为样式化引用块',
        example: { input: '> 古老的传说这样说道。', output: '<blockquote ...>古老的传说这样说道。</blockquote>' },
    },

    // ── 中文排版类 ───────────────────────────

    cn_comma_fix: {
        id: 'cn_comma_fix', name: '英文逗号 → 中文逗号',
        category: 'cn_typo',
        find: '(?<=[\\u4e00-\\u9fff]),(?=[\\u4e00-\\u9fff\\s])', flags: 'g',
        replace: '，', scope: 'output', enabled: true, priority: 30,
        description: '在中文字符前后的英文逗号替换为全角逗号',
        example: { input: '她走了,他留下。', output: '她走了，他留下。' },
    },

    cn_period_fix: {
        id: 'cn_period_fix', name: '英文句点 → 中文句号',
        category: 'cn_typo', find: '(?<=[\\u4e00-\\u9fff])\\.', flags: 'g',
        replace: '。', scope: 'output', enabled: true, priority: 30,
        description: '将中文字符后直接跟随的英文句点替换为中文句号',
        example: { input: '她点头同意.', output: '她点头同意。' },
    },

    cn_exclaim_fix: {
        id: 'cn_exclaim_fix', name: '中文语境感叹号统一',
        category: 'cn_typo', find: '(?<=[\\u4e00-\\u9fff])!', flags: 'g',
        replace: '！', scope: 'output', enabled: true, priority: 30,
        description: '将中文字符后的英文感叹号替换为全角感叹号',
        example: { input: '太好了!', output: '太好了！' },
    },

    cn_question_fix: {
        id: 'cn_question_fix', name: '中文语境问号统一',
        category: 'cn_typo', find: '(?<=[\\u4e00-\\u9fff])\\?', flags: 'g',
        replace: '？', scope: 'output', enabled: true, priority: 30,
        description: '将中文字符后的英文问号替换为全角问号',
        example: { input: '你在哪里?', output: '你在哪里？' },
    },

    cn_space_between: {
        id: 'cn_space_between', name: '中英文之间添加空格',
        category: 'cn_typo', find: '([\\u4e00-\\u9fff])([A-Za-z0-9])', flags: 'g',
        replace: '$1 $2', scope: 'output', enabled: true, priority: 28,
        description: '在中文字符和英文/数字之间自动添加空格',
        example: { input: '这是一个Test案例', output: '这是一个 Test 案例' },
    },

    cn_space_between_reverse: {
        id: 'cn_space_between_reverse', name: '英文/数字后接中文添加空格',
        category: 'cn_typo', find: '([A-Za-z0-9])([\\u4e00-\\u9fff])', flags: 'g',
        replace: '$1 $2', scope: 'output', enabled: true, priority: 28,
        description: '在英文/数字和中文字符之间自动添加空格',
        example: { input: 'API调用成功', output: 'API 调用成功' },
    },

    cn_double_quote_convert: {
        id: 'cn_double_quote_convert', name: '英文双引号 → 中文双引号',
        category: 'cn_typo', find: '"(.*?)"', flags: 'gs',
        replace: '\u201c$1\u201d', scope: 'output', enabled: true, priority: 25,
        description: '将英文双引号转换为中文弯引号',
        example: { input: '他说"你好"并离去。', output: '他说\u201c你好\u201d并离去。' },
    },

    cn_single_quote_convert: {
        id: 'cn_single_quote_convert', name: '英文单引号 → 中文单引号',
        category: 'cn_typo', find: "'(.*?)'", flags: 'gs',
        replace: '\u2018$1\u2019', scope: 'output', enabled: true, priority: 25,
        description: '将英文单引号转换为中文单引号',
        example: { input: "她心想'这不对'。", output: '\u2018她心想这不对\u2019。' },
    },

    cn_ellipsis_fix: {
        id: 'cn_ellipsis_fix', name: '三个点 → 中文省略号',
        category: 'cn_typo', find: '\\.{3}', flags: 'g',
        replace: '……', scope: 'output', enabled: true, priority: 28,
        description: '将三个英文点号替换为中文省略号',
        example: { input: '她犹豫了...最终还是说了。', output: '她犹豫了……最终还是说了。' },
    },

    cn_dash_fix: {
        id: 'cn_dash_fix', name: '双连字符 → 中文破折号',
        category: 'cn_typo', find: '--', flags: 'g',
        replace: '——', scope: 'output', enabled: true, priority: 27,
        description: '将两个连字符替换为中文破折号',
        example: { input: '她说--这很重要。', output: '她说——这很重要。' },
    },

    cn_remove_extra_blank_lines: {
        id: 'cn_remove_extra_blank_lines', name: '移除多余空行',
        category: 'cn_typo', find: '\\n{3,}', flags: 'g',
        replace: '\n\n', scope: 'output', enabled: true, priority: 5,
        description: '将连续3行以上的空行压缩为最多2行',
        example: { input: '段落一\n\n\n\n段落二', output: '段落一\n\n段落二' },
    },

    cn_trim_trailing_space: {
        id: 'cn_trim_trailing_space', name: '移除行尾空格',
        category: 'cn_typo', find: '[ \\t]+$', flags: 'gm',
        replace: '', scope: 'output', enabled: true, priority: 4,
        description: '移除每行末尾多余的空格和制表符',
        example: { input: '她说话。   \n他回答。  ', output: '她说话。\n他回答。' },
    },

    // ── 格式转换类 ───────────────────────────

    format_h1_to_html: {
        id: 'format_h1_to_html', name: 'Markdown H1 → HTML h2',
        category: 'format', find: '^# (.+)$', flags: 'gm',
        replace: '<h2 style="color:var(--cf-primary);margin:12px 0 6px">$1</h2>',
        scope: 'output', enabled: true, priority: 18,
        description: '将 Markdown 一级标题转换为带样式的 HTML h2',
        example: { input: '# 第一章', output: '<h2 ...>第一章</h2>' },
    },

    format_h2_to_html: {
        id: 'format_h2_to_html', name: 'Markdown H2 → HTML h3',
        category: 'format', find: '^## (.+)$', flags: 'gm',
        replace: '<h3 style="color:var(--cf-text);margin:10px 0 4px">$1</h3>',
        scope: 'output', enabled: true, priority: 18,
        description: '将 Markdown 二级标题转换为带样式的 HTML h3',
        example: { input: '## 第一节', output: '<h3 ...>第一节</h3>' },
    },

    format_code_inline: {
        id: 'format_code_inline', name: '行内代码 → 样式化 span',
        category: 'format', find: '`([^`]+)`', flags: 'g',
        replace: '<code style="background:var(--cf-bg-panel);padding:1px 5px;border-radius:3px;font-family:monospace;font-size:0.9em">$1</code>',
        scope: 'output', enabled: true, priority: 15,
        description: '将行内代码转换为带背景色的 code 标签',
        example: { input: '使用 `setvar` 命令。', output: '使用 <code ...>setvar</code> 命令。' },
    },

    format_unordered_list: {
        id: 'format_unordered_list', name: 'Markdown 无序列表 → 美化样式',
        category: 'format', find: '^[\\-\\*] (.+)$', flags: 'gm',
        replace: '<div style="padding:2px 0 2px 12px;border-left:2px solid var(--cf-primary)">$1</div>',
        scope: 'output', enabled: true, priority: 16,
        description: '将 Markdown 无序列表项转换为带左边框的 div 样式',
        example: { input: '- 第一项\n- 第二项', output: '<div ...>第一项</div>\n<div ...>第二项</div>' },
    },

    format_newline_to_br: {
        id: 'format_newline_to_br', name: '换行符 → <br> 标签',
        category: 'format', find: '\\n', flags: 'g',
        replace: '<br>',
        scope: 'output', enabled: false, priority: 1,
        description: '将所有换行符转换为 HTML <br> 标签（按需启用）',
        example: { input: '第一行\n第二行', output: '第一行<br>第二行' },
    },

    // ── 高级技巧类 ───────────────────────────

    advanced_named_capture_speech: {
        id: 'advanced_named_capture_speech', name: '命名捕获：对话人物名高亮',
        category: 'advanced',
        find: '(?<name>[A-Z\\u4e00-\\u9fff][\\u4e00-\\u9fff\\w]*?)\uff1a\u300c(?<speech>.+?)\u300d',
        flags: 'g',
        replace: '<strong style="color:var(--cf-warning)">$<name></strong>\uff1a\u300c$<speech>\u300d',
        scope: 'output', enabled: true, priority: 22,
        description: '使用命名捕获组提取人物名并高亮显示，格式：名字：「对话」',
        example: { input: '苍月：「你是谁？」', output: '<strong ...>苍月</strong>：「你是谁？」' },
    },

    advanced_stat_highlight: {
        id: 'advanced_stat_highlight', name: '属性数值高亮',
        category: 'advanced', find: '\\[([^\\]]+): (\\d+)\\]', flags: 'g',
        replace: '<span style="background:rgba(123,104,238,0.2);border:1px solid var(--cf-primary);border-radius:3px;padding:1px 5px;font-size:0.9em">$1: $2</span>',
        scope: 'output', enabled: true, priority: 20,
        description: '将 [HP: 100] 格式的属性数值显示为紫色徽章',
        example: { input: '当前状态 [HP: 75] [MP: 30]', output: '当前状态 <span ...>HP: 75</span> ...' },
    },

    advanced_spoiler_tag: {
        id: 'advanced_spoiler_tag', name: '剧透遮挡（||文字|| 格式）',
        category: 'advanced', find: '\\|\\|(.+?)\\|\\|', flags: 'g',
        replace: '<span style="background:var(--cf-text);color:var(--cf-text);border-radius:2px;cursor:pointer" onclick="this.style.background=\'transparent\';this.style.color=\'inherit\'">$1</span>',
        scope: 'output', enabled: true, priority: 20,
        description: '将 ||文字|| 转换为点击后才显示的剧透遮挡块',
        example: { input: '凶手是 ||管家|| 。', output: '凶手是 <span ...>管家</span> 。' },
    },

    advanced_ruby_annotation: {
        id: 'advanced_ruby_annotation', name: '汉字注音（{字|音} 格式）',
        category: 'advanced', find: '\\{([^|]+)\\|([^}]+)\\}', flags: 'g',
        replace: '<ruby>$1<rt>$2</rt></ruby>',
        scope: 'output', enabled: true, priority: 20,
        description: '将 {汉字|读音} 格式转换为 HTML ruby 注音元素',
        example: { input: '{漪澜|yī lán}', output: '<ruby>漪澜<rt>yī lán</rt></ruby>' },
    },

    advanced_color_tag: {
        id: 'advanced_color_tag', name: '颜色标记（[color=red]文字[/color]）',
        category: 'advanced', find: '\\[color=([\\w#]+)\\](.*?)\\[\\/color\\]', flags: 'gis',
        replace: '<span style="color:$1">$2</span>',
        scope: 'output', enabled: true, priority: 20,
        description: '将 BBCode 风格的颜色标记转换为内联 CSS 颜色',
        example: { input: '她的[color=red]愤怒[/color]溢于言表。', output: '她的<span style="color:red">愤怒</span>溢于言表。' },
    },

    // ── RPG 专用类 ───────────────────────────

    rpg_damage_format: {
        id: 'rpg_damage_format', name: 'RPG 伤害数值红色高亮',
        category: 'rpg',
        find: '(-\\d+(?:\\.\\d+)?)\\s*(?:HP|生命|血量)', flags: 'gi',
        replace: '<span style="color:var(--cf-danger);font-weight:700">$1 HP</span>',
        scope: 'output', enabled: true, priority: 25,
        description: '将 -数字 HP 形式的伤害数值高亮为红色粗体',
        example: { input: '你受到了 -25 HP 的伤害。', output: '你受到了 <span ...>-25 HP</span> 的伤害。' },
    },

    rpg_heal_format: {
        id: 'rpg_heal_format', name: 'RPG 回复数值绿色高亮',
        category: 'rpg',
        find: '(\\+\\d+(?:\\.\\d+)?)\\s*(?:HP|生命|血量)', flags: 'gi',
        replace: '<span style="color:var(--cf-success);font-weight:700">$1 HP</span>',
        scope: 'output', enabled: true, priority: 25,
        description: '将 +数字 HP 形式的治疗数值高亮为绿色粗体',
        example: { input: '治疗效果：+30 HP。', output: '治疗效果：<span ...>+30 HP</span>。' },
    },

    rpg_dice_format: {
        id: 'rpg_dice_format', name: '骰子结果样式化',
        category: 'rpg',
        find: '\\b(\\d+)d(\\d+)(?:\\s*=\\s*(\\d+))?\\b', flags: 'gi',
        replace: '<span style="background:rgba(52,152,219,0.2);border:1px solid var(--cf-info);border-radius:3px;padding:1px 5px">🎲 $1d$2$3</span>',
        scope: 'output', enabled: true, priority: 22,
        description: '将骰子表达式（如 2d6=8）样式化为蓝色徽章',
        example: { input: '你掷出了 2d6=8 的结果。', output: '你掷出了 <span ...>🎲 2d6=8</span> 的结果。' },
    },

    rpg_level_up: {
        id: 'rpg_level_up', name: '升级提示高亮',
        category: 'rpg',
        find: '(等级提升|Level Up|升级)[!！]?', flags: 'gi',
        replace: '<strong style="color:var(--cf-warning);font-size:1.05em">⬆ $1！</strong>',
        scope: 'output', enabled: true, priority: 22,
        description: '将升级关键词高亮为金色粗体',
        example: { input: '恭喜！Level Up！', output: '恭喜！<strong ...>⬆ Level Up！</strong>' },
    },

    rpg_critical_hit: {
        id: 'rpg_critical_hit', name: '暴击提示样式化',
        category: 'rpg',
        find: '(暴击|Critical Hit|CRIT)[!！]?', flags: 'gi',
        replace: '<strong style="color:var(--cf-danger);font-size:1.1em;letter-spacing:1px">💥 $1！</strong>',
        scope: 'output', enabled: true, priority: 22,
        description: '将暴击关键词样式化为红色大字',
        example: { input: '暴击！造成了 200 伤害！', output: '<strong ...>💥 暴击！</strong>造成了 200 伤害！' },
    },

    rpg_status_effect: {
        id: 'rpg_status_effect', name: '状态异常标签样式化',
        category: 'rpg', find: '\\[状态：([^\\]]+)\\]', flags: 'g',
        replace: '<span style="background:rgba(231,76,60,0.2);border:1px solid var(--cf-danger);border-radius:3px;padding:1px 6px;font-size:0.85em">⚠ $1</span>',
        scope: 'output', enabled: true, priority: 23,
        description: '将 [状态：中毒] 格式显示为红色警告徽章',
        example: { input: '你当前 [状态：中毒]。', output: '你当前 <span ...>⚠ 中毒</span>。' },
    },
};

// ─────────────────────────────────────────────
// § 工具函数
// ─────────────────────────────────────────────

/**
 * 获取单条预设规则（深拷贝 + 补充 schema 字段）
 */
export function getPreset(id) {
    const preset = REGEX_PRESETS[id];
    if (!preset) return undefined;
    return {
        ...JSON.parse(JSON.stringify(REGEX_RULE_SCHEMA)),
        ...JSON.parse(JSON.stringify(preset)),
    };
}

/**
 * 获取指定分类下的所有预设（按 priority 降序）
 */
export function getPresetsByCategory(categoryId) {
    return Object.values(REGEX_PRESETS)
        .filter(p => p.category === categoryId)
        .sort((a, b) => (b.priority || 0) - (a.priority || 0))
        .map(p => getPreset(p.id));
}

/**
 * 获取所有预设（扁平数组，按 category + priority 排序）
 */
export function getAllPresets() {
    const order = Object.keys(PRESET_CATEGORIES);
    return Object.values(REGEX_PRESETS)
        .sort((a, b) => {
            const diff = order.indexOf(a.category) - order.indexOf(b.category);
            return diff !== 0 ? diff : (b.priority || 0) - (a.priority || 0);
        })
        .map(p => getPreset(p.id));
}

/**
 * 模糊搜索预设（优先 fuse.js，降级字符串匹配）
 */
export function searchPresets(query) {
    if (!query?.trim()) return getAllPresets();
    const q = query.trim().toLowerCase();

    try {
        const Fuse = window.Fuse;
        if (Fuse) {
            const fuse = new Fuse(Object.values(REGEX_PRESETS), {
                keys: ['name', 'description', 'category', 'find'],
                threshold: 0.4,
            });
            return fuse.search(q).map(r => getPreset(r.item.id));
        }
    } catch {}

    return Object.values(REGEX_PRESETS)
        .filter(p =>
            p.name.toLowerCase().includes(q) ||
            p.description.toLowerCase().includes(q) ||
            p.find.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q)
        )
        .map(p => getPreset(p.id));
}

/**
 * 获取所有分类信息（含每类预设数量）
 */
export function getCategoriesWithCount() {
    return Object.values(PRESET_CATEGORIES).map(cat => ({
        ...cat,
        count: Object.values(REGEX_PRESETS).filter(p => p.category === cat.id).length,
    }));
}

/**
 * 验证预设 ID 是否存在
 */
export function presetExists(id) {
    return id in REGEX_PRESETS;
}