/**
 * @file regex-forge.js
 * @description 正则锻造器主模块
 *              整合：AI 生成正则 / 预设库 / 测试沙盒 / 规则管理 / 导出
 *              实现 IModule 接口
 * @module RegexForge
 * @version 1.0.0
 */

import { EVENTS, REGEX_RULE_SCHEMA } from '../../contracts.js';
import {
    REGEX_PRESETS,
    PRESET_CATEGORIES,
    getPreset,
    getPresetsByCategory as getPresetsByCategoryFn,
    searchPresets as searchPresetsFn,
} from './preset-library.js';
import {
    RegexTester,
    validateRegexSyntax,
} from './regex-tester.js';

// ─────────────────────────────────────────────
// § 内部常量
// ─────────────────────────────────────────────

/** 规则 ID 前缀 */
const RULE_ID_PREFIX = 'rule_';

/** 持久化 IDB key */
const IDB_KEY_RULES    = 'regex_forge_rules';
const IDB_KEY_SETTINGS = 'regex_forge_settings';

/** 导出文件格式枚举 */
export const EXPORT_FORMATS = {
    ST_JSON:    'st_json',    // SillyTavern 可识别 JSON
    RAW_JSON:   'raw_json',   // 原始 JSON（含所有字段）
    MARKDOWN:   'markdown',   // Markdown 文档
};

// ─────────────────────────────────────────────
// § RegexForge 类
// ─────────────────────────────────────────────

/**
 * 正则锻造器主模块
 * @implements {IModule}
 */
export class RegexForge {

    /**
     * @param {import('../../core/ai-engine.js').AIEngine}              aiEngine
     * @param {import('../../core/event-bus.js').EventBus}             eventBus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     * @param {import('../../utils/indexeddb-store.js').IndexedDBStore|null}  dbStore  可选
     */
    constructor(aiEngine, eventBus, settings, dbStore = null) {
        this._ai       = aiEngine;
        this._eventBus = eventBus;
        this._settings = settings;
        this._dbStore  = dbStore;      // 允许为 null（无 IndexedDB 时降级）

        /**
         * 规则列表（有序，index 决定执行顺序）
         * @type {Object[]}
         */
        this._rules = [];

        /**
         * 规则 ID → 列表索引的快速查找 Map
         * @type {Map<string, number>}
         */
        this._ruleIndex = new Map();

        /** 测试沙盒实例 @type {RegexTester} */
        this._tester = new RegexTester();

        /** 是否已初始化 @type {boolean} */
        this._ready = false;

        /** 事件取消函数 @type {Function[]} */
        this._unsubscribers = [];

        /** ID 自增 @type {number} */
        this._idCounter = 0;
    }

    // ── IModule 接口 ─────────────────────────

    /**
     * 模块初始化
     * @returns {Promise<void>}
     */
    async init() {
        try {
            await this._loadRulesFromDB();
            this._ready = true;
            this._eventBus.emit(EVENTS.MODULE_READY, { module: 'RegexForge' });
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'RegexForge',
                method:  'init',
                error,
                context: {},
            });
            throw error;
        }
    }

    /**
     * 模块销毁
     */
    destroy() {
        this._unsubscribers.forEach(fn => fn());
        this._unsubscribers = [];
        this._rules         = [];
        this._ruleIndex.clear();
        this._ready         = false;
    }

    /**
     * 获取当前模块状态
     * @returns {Object}
     */
    getState() {
        return {
            ruleCount:    this._rules.length,
            enabledCount: this._rules.filter(r => r.enabled).length,
            isReady:      this._ready,
        };
    }

    /**
     * @returns {boolean}
     */
    isReady() {
        return this._ready;
    }

    // ── AI 生成 ──────────────────────────────

    /**
     * 根据自然语言描述生成正则规则
     * @param {string} description  用户描述，如「移除所有括号里的内容」
     * @returns {Promise<Object>}  生成的 REGEX_RULE_SCHEMA 对象
     */
    async generateFromDescription(description) {
        try {
            this._eventBus.emit(EVENTS.LOADING_START, { msg: '正在生成正则规则...' });
            this._eventBus.emit(EVENTS.FIELD_ENHANCE_STARTED, { field: 'regex' });

            const systemPrompt = [
                '你是一位精通正则表达式的专家，专门为 SillyTavern AI 对话系统设计正则规则。',
                '请根据用户的需求生成一条精确的正则规则，以 JSON 格式返回。',
                '',
                '返回格式（严格 JSON）：',
                '{',
                '  "name": "规则名称（10字以内）",',
                '  "description": "功能说明（30字以内）",',
                '  "find": "正则表达式字符串（不含斜杠和 flags）",',
                '  "flags": "正则 flags，如 gi",',
                '  "replace": "替换字符串（支持 $1 等捕获引用）",',
                '  "scope": "output 或 input 或 both",',
                '  "priority": 数字（0-100）',
                '}',
                '',
                '注意事项：',
                '- find 字段中的特殊字符需要正确转义（如 \\( 而非 (）',
                '- 优先使用具名捕获组 (?<name>...) 提高可读性',
                '- scope 默认为 output',
                '- 不要添加额外的文字说明，只返回 JSON',
            ].join('\n');

            const raw = await this._ai.generateCard(systemPrompt, `需求：${description}`);
            const parsed = this._parseRuleResponse(raw);

            const rule = this._createRule(parsed);

            this._eventBus.emit(EVENTS.LOADING_END, {});
            this._eventBus.emit(EVENTS.REGEX_TESTED, {
                ruleId: rule.id,
                source: 'ai_generated',
            });

            return rule;

        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'RegexForge',
                method:  'generateFromDescription',
                error,
                context: { description },
            });
            this._eventBus.emit(EVENTS.LOADING_END, {});
            throw error;
        }
    }

    /**
     * 根据使用场景生成预设化规则组
     * @param {string} useCase  使用场景 ID
     * @returns {Promise<Object[]>}  生成的规则数组
     */
    async generateForUseCase(useCase) {
        const useCasePrompts = {
            remove_ooc:       '移除对话中所有出戏注记，包括括号内的 OOC、作者注记、系统提示等',
            beautify_action:  '将星号包裹的动作描写美化为斜体，双星号内容加粗',
            format_thought:   '将下划线包裹的内心独白格式化为蓝色斜体',
            cn_typography:    '修正中文标点符号（逗号、句号、引号），添加中英文间距',
            rpg_stats:        '将 RPG 属性变化（+/-数字 HP/MP）高亮显示为红绿色',
            remove_markdown:  '移除不必要的 Markdown 语法标记，保留纯文本',
            highlight_speech: '高亮人物对话，将人名冒号后的内容用不同颜色显示',
        };

        const desc = useCasePrompts[useCase];
        if (!desc) {
            throw new Error(`未知的使用场景：${useCase}`);
        }

        // 优先用预设映射，精确且可控
        const presetMappings = {
            remove_ooc:      ['remove_ooc_bracket', 'remove_ooc_square', 'remove_author_note'],
            beautify_action: ['beautify_action_star', 'beautify_bold_double_star'],
            format_thought:  ['beautify_thought_italic'],
            cn_typography:   ['cn_comma_fix', 'cn_period_fix', 'cn_space_between',
                              'cn_space_between_reverse', 'cn_double_quote_convert'],
            rpg_stats:       ['rpg_damage_format', 'rpg_heal_format', 'rpg_dice_format'],
        };

        if (presetMappings[useCase]) {
            return presetMappings[useCase]
                .map(id => getPreset(id))
                .filter(Boolean)
                .map(p => this._createRule(p));
        }

        // 无内置预设则走 AI 生成
        const generated = await this.generateFromDescription(desc);
        return [generated];
    }

    // ── 规则 CRUD ────────────────────────────

    /**
     * 添加规则
     * @param {Partial<Object>} ruleData
     * @returns {Object}  完整规则对象（含生成的 id）
     */
    addRule(ruleData) {
        const rule = this._createRule(ruleData);
        this._rules.push(rule);
        this._rebuildIndex();
        this._persistRules().catch(() => {});

        this._eventBus.emit(EVENTS.REGEX_APPLIED, {
            action: 'add',
            ruleId: rule.id,
        });

        return rule;
    }

    /**
     * 更新规则
     * @param {string} id
     * @param {Partial<Object>} changes
     * @returns {boolean}
     */
    updateRule(id, changes) {
        const idx = this._ruleIndex.get(id);
        if (idx === undefined) return false;

        Object.assign(this._rules[idx], changes, { id });
        this._persistRules().catch(() => {});

        this._eventBus.emit(EVENTS.REGEX_APPLIED, {
            action: 'update',
            ruleId: id,
        });

        return true;
    }

    /**
     * 删除规则
     * @param {string} id
     * @returns {boolean}
     */
    deleteRule(id) {
        const idx = this._ruleIndex.get(id);
        if (idx === undefined) return false;

        this._rules.splice(idx, 1);
        this._rebuildIndex();
        this._persistRules().catch(() => {});

        this._eventBus.emit(EVENTS.REGEX_APPLIED, {
            action: 'delete',
            ruleId: id,
        });

        return true;
    }

    /**
     * 获取单条规则
     * @param {string} id
     * @returns {Object|undefined}
     */
    getRule(id) {
        const idx = this._ruleIndex.get(id);
        return idx !== undefined ? { ...this._rules[idx] } : undefined;
    }

    /**
     * 获取所有规则（返回深拷贝）
     * @returns {Object[]}
     */
    getRules() {
        return this._rules.map(r => ({ ...r }));
    }

    /**
     * 按 scope 过滤规则
     * @param {'input'|'output'|'both'} scope
     * @returns {Object[]}
     */
    getRulesByScope(scope) {
        return this._rules
            .filter(r => r.scope === scope || r.scope === 'both')
            .map(r => ({ ...r }));
    }

    /**
     * 启用/禁用规则
     * @param {string}  id
     * @param {boolean} enabled
     * @returns {boolean}
     */
    setRuleEnabled(id, enabled) {
        return this.updateRule(id, { enabled });
    }

    /**
     * 重排序规则（拖拽排序后调用）
     * @param {string[]} orderedIds  按新顺序排列的 ID 数组
     * @returns {boolean}
     */
    reorderRules(orderedIds) {
        const newRules = [];

        for (const id of orderedIds) {
            const idx = this._ruleIndex.get(id);
            if (idx !== undefined) {
                newRules.push(this._rules[idx]);
            }
        }

        // 把未在 orderedIds 中的规则追加到末尾
        for (const rule of this._rules) {
            if (!orderedIds.includes(rule.id)) {
                newRules.push(rule);
            }
        }

        this._rules = newRules;
        this._rebuildIndex();
        this._persistRules().catch(() => {});
        return true;
    }

    /**
     * 清空所有规则
     */
    clearRules() {
        this._rules = [];
        this._ruleIndex.clear();
        this._persistRules().catch(() => {});
    }

    // ── 预设库 ───────────────────────────────

    /**
     * 加载预设规则（自动去重：已存在同 id 的跳过）
     * @param {string} presetId
     * @returns {Object|null}  加载成功返回规则对象，已存在返回 null
     */
    loadPreset(presetId) {
        if (this._ruleIndex.has(presetId)) {
            return null; // 已存在
        }

        const preset = getPreset(presetId);
        if (!preset) return null;

        return this.addRule(preset);
    }

    /**
     * 批量加载分类下的所有预设
     * @param {string} categoryId
     * @returns {{ loaded: number, skipped: number }}
     */
    loadPresetCategory(categoryId) {
        const presets = getPresetsByCategoryFn(categoryId);
        let   loaded  = 0;
        let   skipped = 0;

        for (const preset of presets) {
            const result = this.loadPreset(preset.id);
            if (result) loaded++;
            else        skipped++;
        }

        return { loaded, skipped };
    }

    /**
     * 获取所有预设（供 UI 浏览选择）
     * @returns {Object[]}
     */
    getPresets() {
        return Object.values(REGEX_PRESETS);
    }

    /**
     * 获取指定分类预设
     * @param {string} categoryId
     * @returns {Object[]}
     */
    getPresetsByCategory(categoryId) {
        return getPresetsByCategoryFn(categoryId);
    }

    /**
     * 搜索预设
     * @param {string} query
     * @returns {Object[]}
     */
    searchPresets(query) {
        return searchPresetsFn(query);
    }

    /**
     * 获取预设分类列表
     * @returns {Object[]}
     */
    getPresetCategories() {
        return Object.values(PRESET_CATEGORIES);
    }

    // ── 测试沙盒 ─────────────────────────────

    /**
     * 测试单条规则
     * @param {Object|string} ruleOrId  规则对象或规则 ID
     * @param {string}        inputText
     * @returns {import('./regex-tester.js').TestResult}
     */
    testRule(ruleOrId, inputText) {
        const rule = typeof ruleOrId === 'string'
            ? this.getRule(ruleOrId)
            : ruleOrId;

        if (!rule) throw new Error(`规则 ${ruleOrId} 不存在`);

        const result = this._tester.testRule(rule, inputText);

        this._eventBus.emit(EVENTS.REGEX_TESTED, {
            ruleId:     rule.id,
            matchCount: result.matchCount,
            ok:         result.ok,
        });

        return result;
    }

    /**
     * 对所有启用规则进行链式测试
     * @param {string}  inputText
     * @param {string}  [scope='output']
     * @returns {import('./regex-tester.js').ChainResult}
     */
    testAllRules(inputText, scope = 'output') {
        return this._tester.testChain(this._rules, inputText, scope);
    }

    /**
     * 仅验证正则语法（不执行替换）
     * @param {string} pattern
     * @param {string} flags
     * @returns {{ valid: boolean, error?: string }}
     */
    validateRegex(pattern, flags) {
        return validateRegexSyntax(pattern, flags);
    }

    // ── 导出 ─────────────────────────────────

    /**
     * 导出为 SillyTavern 可识别的 JSON 格式
     * @param {string[]} [ids]  指定要导出的规则 ID，不传则导出全部
     * @returns {Object}  ST 正则规则 JSON
     */
    exportToSTFormat(ids) {
        const rules = ids
            ? ids.map(id => this.getRule(id)).filter(Boolean)
            : this.getRules();

        return {
            entries: rules.filter(r => r.enabled).map((r, idx) => ({
                id:              idx + 1,
                scriptName:      r.name,
                findRegex:       `/${r.find}/${r.flags}`,
                replaceString:   r.replace,
                trimStrings:     [],
                placement:       this._stPlacement(r.scope),
                disabled:        false,
                markdownOnly:    false,
                promptOnly:      false,
                runOnEdit:       false,
                substituteRegex: false,
                minDepth:        null,
                maxDepth:        null,
            })),
        };
    }

    /**
     * 导出全部规则为原始 JSON
     * @returns {string}  JSON 字符串
     */
    exportAllJSON() {
        return JSON.stringify({
            version:    '1.0.0',
            exportedAt: Date.now(),
            rules:      this.getRules(),
        }, null, 2);
    }

    /**
     * 导出为 Markdown 文档（便于分享）
     * @returns {string}
     */
    exportMarkdown() {
        const lines = [
            '# 正则规则集',
            '',
            `> 导出时间：${new Date().toLocaleString('zh-CN')}  `,
            `> 规则数量：${this._rules.length}`,
            '',
        ];

        const grouped = new Map();
        for (const rule of this._rules) {
            const cat = rule.category || 'custom';
            if (!grouped.has(cat)) grouped.set(cat, []);
            grouped.get(cat).push(rule);
        }

        for (const [cat, rules] of grouped.entries()) {
            const catInfo = PRESET_CATEGORIES[cat];
            lines.push(`## ${catInfo ? catInfo.label : `📂 ${cat}`}`);
            lines.push('');

            for (const rule of rules) {
                lines.push(`### ${rule.name} \`${rule.id}\``);
                lines.push('');
                lines.push(`**说明：** ${rule.description}`);
                lines.push('');
                lines.push('```regex');
                lines.push(`查找：/${rule.find}/${rule.flags}`);
                lines.push(`替换：${rule.replace}`);
                lines.push(`作用域：${rule.scope}`);
                lines.push('```');

                if (rule.example) {
                    lines.push('');
                    lines.push('**示例：**');
                    lines.push(`- 输入：\`${rule.example.input}\``);
                    lines.push(`- 输出：\`${rule.example.output}\``);
                }

                lines.push('');
            }
        }

        return lines.join('\n');
    }

    /**
     * 从 JSON 字符串导入规则
     * @param {string} jsonStr
     * @returns {{ imported: number, skipped: number, errors: string[] }}
     */
    importFromJSON(jsonStr) {
        const errors   = [];
        let   imported = 0;
        let   skipped  = 0;

        try {
            const data  = JSON.parse(jsonStr);
            const rules = data.rules || data.entries || [];

            for (const rule of rules) {
                try {
                    if (!rule.find) {
                        errors.push(`规则「${rule.name || '?'}」缺少 find 字段，已跳过`);
                        skipped++;
                        continue;
                    }

                    const syntax = validateRegexSyntax(rule.find, rule.flags || 'g');
                    if (!syntax.valid) {
                        errors.push(`规则「${rule.name}」正则语法错误：${syntax.error}`);
                        skipped++;
                        continue;
                    }

                    this.addRule(rule);
                    imported++;

                } catch (e) {
                    errors.push(`规则「${rule.name || '?'}」导入失败：${e.message}`);
                    skipped++;
                }
            }
        } catch (e) {
            errors.push(`JSON 解析失败：${e.message}`);
        }

        return { imported, skipped, errors };
    }

    // ── 私有方法 ─────────────────────────────

    /**
     * 创建标准规则对象
     * @param {Partial<Object>} data
     * @returns {Object}
     * @private
     */
    _createRule(data) {
        this._idCounter++;
        const id = data.id || `${RULE_ID_PREFIX}${Date.now()}_${this._idCounter}`;

        return {
            ...JSON.parse(JSON.stringify(REGEX_RULE_SCHEMA)),
            ...data,
            id,
            example: data.example || undefined,
        };
    }

    /**
     * 重建 ruleIndex Map
     * @private
     */
    _rebuildIndex() {
        this._ruleIndex.clear();
        this._rules.forEach((rule, idx) => {
            this._ruleIndex.set(rule.id, idx);
        });
    }

    /**
     * 将规则持久化到 IDB（无 dbStore 时静默跳过）
     * @returns {Promise<void>}
     * @private
     */
    async _persistRules() {
        if (!this._dbStore) return;
        try {
            await this._dbStore.set(IDB_KEY_RULES, {
                rules:   this._rules,
                savedAt: Date.now(),
            });
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'RegexForge',
                method:  '_persistRules',
                error,
                context: {},
            });
        }
    }

    /**
     * 从 IDB 加载规则（无 dbStore 时静默跳过）
     * @returns {Promise<void>}
     * @private
     */
    async _loadRulesFromDB() {
        if (!this._dbStore) return;
        try {
            const saved = await this._dbStore.get(IDB_KEY_RULES);
            if (saved && Array.isArray(saved.rules)) {
                this._rules = saved.rules;
                this._rebuildIndex();
            }
        } catch {
            // 首次启动或 IDB 不可用，忽略
        }
    }

    /**
     * 解析 AI 返回的规则 JSON
     * @param {string} raw
     * @returns {Object}
     * @private
     */
    _parseRuleResponse(raw) {
        const jsonMatch = raw.match(/\{[\s\S]*\}/);
        if (!jsonMatch) throw new Error('AI 未返回有效 JSON');

        const parsed = JSON.parse(jsonMatch[0]);

        return {
            name:        parsed.name        || 'AI 生成规则',
            description: parsed.description || '',
            find:        parsed.find        || parsed.findRegex || '',
            flags:       parsed.flags       || 'g',
            replace:     parsed.replace     || parsed.replaceString || '',
            scope:       parsed.scope       || 'output',
            priority:    Number(parsed.priority) || 50,
            enabled:     true,
            category:    'custom',
        };
    }

    /**
     * 将 scope 转换为 ST 的 placement 值
     * @param {string} scope
     * @returns {number[]}
     * @private
     */
    _stPlacement(scope) {
        // ST placement: 0=用户输入, 1=AI输出
        switch (scope) {
            case 'input':  return [0];
            case 'output': return [1];
            case 'both':   return [0, 1];
            default:       return [1];
        }
    }
}