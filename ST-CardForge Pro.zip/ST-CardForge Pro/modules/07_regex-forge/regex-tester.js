/**
 * @file regex-tester.js
 * @description 正则规则测试沙盒（修复版）
 *              提供：单规则测试 / 多规则链式测试 / 匹配高亮渲染 /
 *                    性能计时 / 安全超时保护
 * @module RegexTester
 * @version 1.0.1
 */

// ─────────────────────────────────────────────
// § 常量
// ─────────────────────────────────────────────

/** 单次正则测试超时时间（ms） */
const REGEX_TIMEOUT_MS = 3000;

/** 最大匹配数量（防止输出过大） */
const MAX_MATCHES = 200;

/** 正则缓存上限 */
const CACHE_LIMIT = 100;

// ─────────────────────────────────────────────
// § 类型定义（JSDoc）
// ─────────────────────────────────────────────

/**
 * @typedef {Object} TestResult
 * @property {string}   output          替换后的输出文本
 * @property {Match[]}  matches         所有匹配项列表
 * @property {string}   highlightedHTML 带匹配高亮的 HTML 字符串
 * @property {number}   matchCount      匹配数量
 * @property {number}   elapsedMs       执行耗时（毫秒）
 * @property {boolean}  ok              是否执行成功
 * @property {string}   [error]         错误信息
 */

/**
 * @typedef {Object} Match
 * @property {number}   index           匹配起始位置
 * @property {number}   length          匹配长度
 * @property {string}   matched         匹配的原始文本
 * @property {string[]} groups          捕获组数组
 * @property {Object}   namedGroups     命名捕获组
 */

/**
 * @typedef {Object} ChainResult
 * @property {string}       finalOutput    最终输出
 * @property {StepResult[]} steps          每步的执行结果
 * @property {number}       totalMatches   总匹配数
 * @property {number}       totalElapsedMs 总耗时
 * @property {boolean}      ok             全部成功为 true
 */

/**
 * @typedef {Object} StepResult
 * @property {string}     ruleId
 * @property {string}     ruleName
 * @property {TestResult} result
 */

// ─────────────────────────────────────────────
// § RegexTester 类
// ─────────────────────────────────────────────

/**
 * 正则规则测试沙盒
 */
export class RegexTester {

    constructor() {
        /**
         * 已编译的正则缓存
         * @type {Map<string, RegExp>}
         */
        this._compiled = new Map();
    }

    // ── 核心测试方法 ─────────────────────────

    /**
     * 测试单条规则
     * @param {Object} rule   规则对象
     * @param {string} input  待测试的输入文本
     * @returns {TestResult}
     */
    testRule(rule, input) {
        const startTime = _now();

        // 输入校验
        if (!rule || typeof rule.find !== 'string') {
            return this._errorResult('规则定义无效：缺少 find 字段', startTime);
        }

        if (typeof input !== 'string') {
            return this._errorResult('输入必须是字符串', startTime);
        }

        try {
            const regex = this._compileRegex(rule.find, rule.flags);

            // 复杂度检查（防止灾难性回溯）
            if (this._estimateComplexity(input, regex) > REGEX_TIMEOUT_MS * 10000) {
                return this._errorResult('输入文本与正则复杂度过高，已跳过执行', startTime);
            }

            // 收集所有匹配
            const matches = this._collectMatches(regex, input);

            // 执行替换（使用新实例避免 lastIndex 污染）
            const freshRegex = this._compileRegex(rule.find, rule.flags, true);
            const output     = input.replace(freshRegex, rule.replace || '');

            // 生成高亮 HTML
            const highlightedHTML = this._buildHighlightHTML(input, matches);

            return {
                output,
                matches,
                highlightedHTML,
                matchCount: matches.length,
                elapsedMs:  _round(_now() - startTime),
                ok:         true,
            };

        } catch (error) {
            return this._errorResult(error.message || String(error), startTime);
        }
    }

    /**
     * 链式测试多条规则
     * @param {Object[]} rules   规则数组
     * @param {string}   input   输入文本
     * @param {string}   [scope='output']  作用域过滤
     * @returns {ChainResult}
     */
    testChain(rules, input, scope = 'output') {
        const startAll = _now();

        // 输入校验
        if (!Array.isArray(rules)) {
            return {
                finalOutput:    input || '',
                steps:          [],
                totalMatches:   0,
                totalElapsedMs: 0,
                ok:             false,
            };
        }

        if (typeof input !== 'string') {
            input = String(input || '');
        }

        // 过滤启用状态和 scope
        const activeRules = rules
            .filter(r =>
                r &&
                r.enabled !== false &&
                (r.scope === scope || r.scope === 'both' || scope === 'both')
            )
            .sort((a, b) => (b.priority || 0) - (a.priority || 0));

        const steps        = [];
        let   current      = input;
        let   totalMatches = 0;
        let   allOk        = true;

        for (const rule of activeRules) {
            const result = this.testRule(rule, current);

            steps.push({
                ruleId:   rule.id || 'unknown',
                ruleName: rule.name || rule.id || 'unnamed',
                result,
            });

            if (result.ok) {
                current      = result.output;
                totalMatches += result.matchCount;
            } else {
                allOk = false;
                // 某条规则出错时，保留上一步输出继续执行
            }
        }

        return {
            finalOutput:    current,
            steps,
            totalMatches,
            totalElapsedMs: _round(_now() - startAll),
            ok:             allOk,
        };
    }

    /**
     * 仅校验正则表达式语法
     * @param {string} pattern
     * @param {string} [flags='']
     * @returns {{ valid: boolean, error?: string }}
     */
    validateSyntax(pattern, flags = '') {
        try {
            new RegExp(pattern, flags);
            return { valid: true };
        } catch (e) {
            return { valid: false, error: e.message || String(e) };
        }
    }

    /**
     * 提取匹配详情（不执行替换）
     * @param {string} pattern
     * @param {string} flags
     * @param {string} input
     * @returns {Match[]}
     */
    extractMatches(pattern, flags, input) {
        try {
            const regex = this._compileRegex(pattern, flags, true);
            return this._collectMatches(regex, input);
        } catch {
            return [];
        }
    }

    /**
     * 计算两段文本的差异摘要
     * @param {string} original
     * @param {string} modified
     * @returns {{ added: number, removed: number, unchanged: number, diffPercent: number }}
     */
    diffSummary(original, modified) {
        const origLen = (original || '').length;
        const modLen  = (modified || '').length;
        const shorter = Math.min(origLen, modLen);

        let unchanged = 0;
        for (let i = 0; i < shorter; i++) {
            if (original[i] === modified[i]) unchanged++;
        }

        const removed = origLen - unchanged;
        const added   = modLen  - unchanged;

        return {
            added,
            removed,
            unchanged,
            diffPercent: origLen > 0
                ? Math.round((Math.abs(origLen - modLen) / origLen) * 100)
                : 0,
        };
    }

    // ── UI 渲染辅助 ──────────────────────────

    /**
     * 将高亮 HTML 渲染到 DOM 元素
     * @param {HTMLElement} container
     * @param {string}      highlightedHTML
     */
    renderHighlight(container, highlightedHTML) {
        if (container && typeof container.innerHTML !== 'undefined') {
            container.innerHTML = highlightedHTML || '';
        }
    }

    /**
     * 生成人类可读的测试报告
     * @param {TestResult} result
     * @param {Object}     rule
     * @returns {string}
     */
    formatReport(result, rule) {
        if (!result.ok) {
            return `❌ 规则「${rule.name || 'unnamed'}」执行失败：${result.error}`;
        }

        const lines = [
            `✅ 规则：${rule.name || rule.id || 'unnamed'}`,
            `   匹配数：${result.matchCount}`,
            `   耗时：${result.elapsedMs} ms`,
        ];

        if (result.matchCount > 0) {
            lines.push('   匹配详情：');
            result.matches.slice(0, 5).forEach((m, i) => {
                lines.push(`     [${i + 1}] pos ${m.index}: "${this._truncate(m.matched, 40)}"`);
            });
            if (result.matchCount > 5) {
                lines.push(`     ... 还有 ${result.matchCount - 5} 处匹配`);
            }
        }

        return lines.join('\n');
    }

    /**
     * 生成链式测试的汇总报告
     * @param {ChainResult} chainResult
     * @returns {string}
     */
    formatChainReport(chainResult) {
        const lines = [
            `🔗 链式测试完成：共 ${chainResult.steps.length} 条规则`,
            `   总匹配：${chainResult.totalMatches} 处`,
            `   总耗时：${chainResult.totalElapsedMs} ms`,
            `   状态：${chainResult.ok ? '✅ 全部成功' : '⚠️ 部分规则出错'}`,
        ];

        if (!chainResult.ok) {
            const failed = chainResult.steps.filter(s => !s.result.ok);
            lines.push(`   失败规则（${failed.length} 条）：`);
            failed.forEach(s => {
                lines.push(`     - ${s.ruleName}：${s.result.error}`);
            });
        }

        return lines.join('\n');
    }

    // ── 私有方法 ─────────────────────────────

    /**
     * 编译并缓存正则表达式
     * @private
     */
    _compileRegex(pattern, flags = '', forceNew = false) {
        const key = `${pattern}|||${flags}`;

        if (!forceNew && this._compiled.has(key)) {
            return this._compiled.get(key);
        }

        // 规范化 flags（去重 + 排序）
        const normalizedFlags = [...new Set((flags || '').split(''))]
            .sort()
            .join('');

        const regex = new RegExp(pattern, normalizedFlags);

        if (!forceNew) {
            // 缓存上限控制
            if (this._compiled.size >= CACHE_LIMIT) {
                this._compiled.clear();
            }
            this._compiled.set(key, regex);
        }

        return regex;
    }

    /**
     * 收集所有匹配项
     * @private
     */
    _collectMatches(regex, input) {
        const matches  = [];
        const isGlobal = regex.global || regex.sticky;

        if (!isGlobal) {
            // 无全局 flag：只匹配一次
            const single = regex.exec(input);
            if (single) {
                matches.push(this._formatMatch(single));
            }
            return matches;
        }

        // 全局匹配
        regex.lastIndex = 0;
        let m;

        while ((m = regex.exec(input)) !== null && matches.length < MAX_MATCHES) {
            matches.push(this._formatMatch(m));

            // 防止零宽匹配导致死循环
            if (m[0].length === 0) {
                regex.lastIndex++;
            }

            // 额外保护：如果 lastIndex 没增长，强制退出
            if (regex.lastIndex === m.index) {
                regex.lastIndex++;
            }
        }

        regex.lastIndex = 0;
        return matches;
    }

    /**
     * 格式化匹配结果
     * @private
     */
    _formatMatch(m) {
        return {
            index:       m.index,
            length:      m[0].length,
            matched:     m[0],
            groups:      Array.from(m).slice(1),
            namedGroups: m.groups || {},
        };
    }

    /**
     * 生成带匹配高亮的 HTML
     * @private
     */
    _buildHighlightHTML(input, matches) {
        if (!matches || matches.length === 0) {
            return this._escapeHTML(input);
        }

        let result = '';
        let cursor = 0;

        // 合并重叠匹配（按起始位置排序）
        const sorted = [...matches].sort((a, b) => a.index - b.index);

        for (const match of sorted) {
            if (match.index < cursor) continue; // 跳过重叠区域

            // 匹配前的普通文本
            result += this._escapeHTML(input.slice(cursor, match.index));

            // 高亮匹配区域
            const matchedText = input.slice(match.index, match.index + match.length);
            const title = this._escapeHTML(match.matched).slice(0, 100);
            result += `<mark style="background:rgba(123,104,238,0.35);border-radius:2px;padding:0 2px" title="匹配: ${title}">${this._escapeHTML(matchedText)}</mark>`;

            cursor = match.index + match.length;
        }

        // 剩余普通文本
        result += this._escapeHTML(input.slice(cursor));

        return result;
    }

    /**
     * 估算正则复杂度
     * @private
     */
    _estimateComplexity(input, regex) {
        // 极简估算：输入长度 × 正则源码长度
        return (input || '').length * (regex.source || '').length;
    }

    /**
     * 生成错误结果对象
     * @private
     */
    _errorResult(message, startTime) {
        return {
            output:          '',
            matches:         [],
            highlightedHTML: '',
            matchCount:      0,
            elapsedMs:       _round(_now() - startTime),
            ok:              false,
            error:           message || '未知错误',
        };
    }

    /**
     * HTML 转义
     * @private
     */
    _escapeHTML(str) {
        return String(str || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    /**
     * 截断字符串
     * @private
     */
    _truncate(str, max) {
        const s = String(str || '');
        return s.length > max ? s.slice(0, max) + '…' : s;
    }
}

// ─────────────────────────────────────────────
// § 便捷函数（无需实例化）
// ─────────────────────────────────────────────

/** 全局共享 RegexTester 实例 */
const _sharedTester = new RegexTester();

/**
 * 快速测试单条规则
 * @param {Object} rule
 * @param {string} input
 * @returns {TestResult}
 */
export function testRule(rule, input) {
    return _sharedTester.testRule(rule, input);
}

/**
 * 快速链式测试
 * @param {Object[]} rules
 * @param {string}   input
 * @param {string}   [scope]
 * @returns {ChainResult}
 */
export function testChain(rules, input, scope) {
    return _sharedTester.testChain(rules, input, scope);
}

/**
 * 验证正则语法
 * @param {string} pattern
 * @param {string} [flags]
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateRegexSyntax(pattern, flags) {
    return _sharedTester.validateSyntax(pattern, flags);
}

// ─────────────────────────────────────────────
// § 内部工具函数
// ─────────────────────────────────────────────

/**
 * 获取当前时间戳（兼容性处理）
 * @returns {number}
 */
function _now() {
    if (typeof performance !== 'undefined' && performance.now) {
        return performance.now();
    }
    return Date.now();
}

/**
 * 四舍五入保留2位小数
 * @param {number} n
 * @returns {number}
 */
function _round(n) {
    return Math.round(n * 100) / 100;
}