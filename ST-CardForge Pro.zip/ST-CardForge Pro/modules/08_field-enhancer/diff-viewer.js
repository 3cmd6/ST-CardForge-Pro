/**
 * @file diff-viewer.js
 * @description 字段增强差异对比查看器
 *              基于 diff-match-patch 计算字符级 diff
 *              支持：行内模式 / 左右对比模式 / 统计摘要 / 差异导航
 * @module DiffViewer
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// § 常量
// ─────────────────────────────────────────────

/** diff 操作类型（与 diff-match-patch 一致） */
const DIFF_DELETE = -1;
const DIFF_INSERT =  1;
const DIFF_EQUAL  =  0;

/** CSS 颜色 */
const COLORS = {
    insert: {
        bg:   'rgba(46,204,113,0.20)',
        border: 'rgba(46,204,113,0.60)',
        text:   '#2ecc71',
    },
    delete: {
        bg:   'rgba(231,76,60,0.20)',
        border: 'rgba(231,76,60,0.60)',
        text:   '#e74c3c',
    },
    equal: {
        bg:   'transparent',
        text:  'inherit',
    },
};

// ─────────────────────────────────────────────
// § DiffViewer 类
// ─────────────────────────────────────────────

/**
 * 文本差异对比查看器
 */
export class DiffViewer {

    /**
     * @param {HTMLElement} container  承载查看器的 DOM 元素
     * @param {Object}      [options]
     * @param {string}      [options.mode='inline']     初始显示模式
     * @param {boolean}     [options.showStats=true]    是否显示统计
     * @param {boolean}     [options.showNavigation=true] 是否显示差异导航
     */
    constructor(container, options = {}) {
        /** @type {HTMLElement} */
        this._container = container;

        this._opts = {
            mode:           'inline',   // 'inline' | 'side-by-side'
            showStats:      true,
            showNavigation: true,
            ...options,
        };

        /** 当前 diff 数组（diff-match-patch 格式） @type {Array|null} */
        this._diffs = null;

        /** 原始文本 @type {string} */
        this._original = '';

        /** 修改后文本 @type {string} */
        this._modified = '';

        /** 差异块 DOM 索引（用于导航） @type {number} */
        this._currentDiffIdx = 0;

        /** 差异块 DOM 元素列表 @type {HTMLElement[]} */
        this._diffElements = [];

        /** diff-match-patch 实例 @type {Object|null} */
        this._dmp = null;

        this._initDMP();
        this._buildSkeleton();
    }

    // ── 初始化 ────────────────────────────────

    /**
     * 初始化 diff-match-patch 实例
     * @private
     */
    _initDMP() {
        try {
            // diff-match-patch 通过 window 全局或 import 获取
            if (typeof window !== 'undefined' && window.diff_match_patch) {
                this._dmp = new window.diff_match_patch();
            } else if (typeof diff_match_patch !== 'undefined') {
                // eslint-disable-next-line no-undef
                this._dmp = new diff_match_patch();
            }
        } catch {
            this._dmp = null;
        }
    }

    /**
     * 构建 DOM 骨架
     * @private
     */
    _buildSkeleton() {
        this._container.innerHTML = '';
        this._container.className = 'cf-diff-viewer';
        this._container.style.cssText = `
            display: flex;
            flex-direction: column;
            gap: 8px;
            font-size: 13px;
        `;

        // 工具栏
        this._toolbar = document.createElement('div');
        this._toolbar.className = 'cf-diff-toolbar';
        this._toolbar.style.cssText = `
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        `;
        this._container.appendChild(this._toolbar);

        // 统计条
        if (this._opts.showStats) {
            this._statsBar = document.createElement('div');
            this._statsBar.className = 'cf-diff-stats';
            this._statsBar.style.cssText = `
                display: flex;
                gap: 14px;
                padding: 6px 12px;
                background: var(--cf-bg-card, #1a1a2e);
                border: 1px solid var(--cf-border, #333);
                border-radius: 6px;
                font-size: 12px;
            `;
            this._container.appendChild(this._statsBar);
        }

        // 内容区
        this._content = document.createElement('div');
        this._content.className = 'cf-diff-content';
        this._container.appendChild(this._content);

        // 导航区
        if (this._opts.showNavigation) {
            this._navBar = document.createElement('div');
            this._navBar.className = 'cf-diff-nav';
            this._navBar.style.cssText = `
                display: none;
                align-items: center;
                gap: 8px;
                font-size: 12px;
                color: var(--cf-text-muted, #888);
            `;
            this._container.appendChild(this._navBar);
        }

        this._buildToolbar();
    }

    /**
     * 构建工具栏内容
     * @private
     */
    _buildToolbar() {
        this._toolbar.innerHTML = `
            <div style="display:flex;gap:4px">
                <button class="cf-diff-mode-btn ${this._opts.mode === 'inline' ? 'active' : ''}"
                        data-mode="inline"
                        style="padding:3px 10px;border-radius:4px;font-size:11px;cursor:pointer;
                               border:1px solid var(--cf-border,#333);
                               background:${this._opts.mode === 'inline' ? 'var(--cf-primary,#7b68ee)' : 'transparent'};
                               color:${this._opts.mode === 'inline' ? '#fff' : 'var(--cf-text-muted,#888)'}">
                    行内对比
                </button>
                <button class="cf-diff-mode-btn ${this._opts.mode === 'side-by-side' ? 'active' : ''}"
                        data-mode="side-by-side"
                        style="padding:3px 10px;border-radius:4px;font-size:11px;cursor:pointer;
                               border:1px solid var(--cf-border,#333);
                               background:${this._opts.mode === 'side-by-side' ? 'var(--cf-primary,#7b68ee)' : 'transparent'};
                               color:${this._opts.mode === 'side-by-side' ? '#fff' : 'var(--cf-text-muted,#888)'}">
                    左右对比
                </button>
            </div>
            <div style="margin-left:auto;display:flex;gap:6px">
                <button id="cf-diff-copy-orig"
                        style="padding:3px 8px;font-size:11px;cursor:pointer;
                               border:1px solid var(--cf-border,#333);border-radius:4px;
                               background:transparent;color:var(--cf-text-muted,#888)">
                    📋 复制原文
                </button>
                <button id="cf-diff-copy-new"
                        style="padding:3px 8px;font-size:11px;cursor:pointer;
                               border:1px solid var(--cf-success,#2ecc71);border-radius:4px;
                               background:transparent;color:var(--cf-success,#2ecc71)">
                    📋 复制增强版
                </button>
            </div>
        `;

        // 绑定模式切换
        this._toolbar.querySelectorAll('.cf-diff-mode-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const newMode = btn.dataset.mode;
                this.setMode(newMode);
            });
        });

        // 复制按钮
        this._toolbar.querySelector('#cf-diff-copy-orig')?.addEventListener('click', () => {
            this._copyToClipboard(this._original);
        });
        this._toolbar.querySelector('#cf-diff-copy-new')?.addEventListener('click', () => {
            this._copyToClipboard(this._modified);
        });
    }

    // ── 公共 API ──────────────────────────────

    /**
     * 渲染 diff（核心方法）
     * @param {string} original  原始文本
     * @param {string} modified  修改后文本
     */
    render(original, modified) {
        this._original = original || '';
        this._modified = modified || '';
        this._diffs    = this._computeDiff(this._original, this._modified);
        this._diffElements = [];
        this._currentDiffIdx = 0;

        this._renderStats();
        this._renderContent();
        this._renderNavigation();
    }

    /**
     * 清空视图
     */
    clear() {
        this._diffs     = null;
        this._original  = '';
        this._modified  = '';
        this._diffElements = [];

        if (this._statsBar) this._statsBar.innerHTML = '';
        this._content.innerHTML = '';
        if (this._navBar) this._navBar.style.display = 'none';
    }

    /**
     * 获取 diff 统计信息
     * @returns {{ added: number, removed: number, unchanged: number, addedChars: number, removedChars: number }}
     */
    getDiffStats() {
        if (!this._diffs) return { added: 0, removed: 0, unchanged: 0, addedChars: 0, removedChars: 0 };
        return this._calcStats(this._diffs);
    }

    /**
     * 设置显示模式
     * @param {'inline'|'side-by-side'} mode
     */
    setMode(mode) {
        this._opts.mode = mode;

        // 更新按钮状态
        this._toolbar.querySelectorAll('.cf-diff-mode-btn').forEach(btn => {
            const isActive = btn.dataset.mode === mode;
            btn.style.background = isActive ? 'var(--cf-primary,#7b68ee)' : 'transparent';
            btn.style.color      = isActive ? '#fff' : 'var(--cf-text-muted,#888)';
        });

        if (this._diffs) {
            this._renderContent();
        }
    }

    /**
     * 切换模式
     */
    toggleMode() {
        this.setMode(this._opts.mode === 'inline' ? 'side-by-side' : 'inline');
    }

    /**
     * 导航到下一处差异
     */
    nextDiff() {
        if (this._diffElements.length === 0) return;
        this._currentDiffIdx = (this._currentDiffIdx + 1) % this._diffElements.length;
        this._scrollToDiff(this._currentDiffIdx);
        this._updateNavLabel();
    }

    /**
     * 导航到上一处差异
     */
    prevDiff() {
        if (this._diffElements.length === 0) return;
        this._currentDiffIdx = (this._currentDiffIdx - 1 + this._diffElements.length) % this._diffElements.length;
        this._scrollToDiff(this._currentDiffIdx);
        this._updateNavLabel();
    }

    // ── 渲染方法 ─────────────────────────────

    /**
     * 渲染统计条
     * @private
     */
    _renderStats() {
        if (!this._statsBar || !this._diffs) return;

        const stats = this._calcStats(this._diffs);
        const delta = this._modified.length - this._original.length;
        const sign  = delta >= 0 ? '+' : '';

        this._statsBar.innerHTML = `
            <span style="color:${COLORS.insert.text}">
                ＋ ${stats.addedChars} 字符新增
            </span>
            <span style="color:${COLORS.delete.text}">
                － ${stats.removedChars} 字符删除
            </span>
            <span style="color:var(--cf-text-muted,#888)">
                ≈ ${stats.unchanged} 字符未变
            </span>
            <span style="color:var(--cf-text-muted,#888);margin-left:auto">
                字数变化：${sign}${delta}（${this._original.length} → ${this._modified.length}）
            </span>
        `;
    }

    /**
     * 根据当前模式渲染内容区
     * @private
     */
    _renderContent() {
        this._content.innerHTML = '';
        this._diffElements = [];

        if (!this._diffs) return;

        if (this._opts.mode === 'side-by-side') {
            this._renderSideBySide();
        } else {
            this._renderInline();
        }
    }

    /**
     * 行内模式渲染
     * @private
     */
    _renderInline() {
        const wrap = document.createElement('div');
        wrap.style.cssText = `
            background: var(--cf-bg-card, #1a1a2e);
            border: 1px solid var(--cf-border, #333);
            border-radius: 6px;
            padding: 12px 14px;
            line-height: 1.8;
            white-space: pre-wrap;
            word-break: break-word;
            font-size: 13px;
        `;

        for (const [op, text] of this._diffs) {
            const span = this._createDiffSpan(op, text);
            if (op !== DIFF_EQUAL) {
                this._diffElements.push(span);
            }
            wrap.appendChild(span);
        }

        this._content.appendChild(wrap);
    }

    /**
     * 左右对比模式渲染
     * @private
     */
    _renderSideBySide() {
        const container = document.createElement('div');
        container.style.cssText = `
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        `;

        const leftWrap  = this._buildSidePane('原文',  COLORS.delete.text);
        const rightWrap = this._buildSidePane('增强后', COLORS.insert.text);

        const leftContent  = leftWrap.querySelector('.cf-diff-side-content');
        const rightContent = rightWrap.querySelector('.cf-diff-side-content');

        for (const [op, text] of this._diffs) {
            if (op === DIFF_EQUAL) {
                leftContent.appendChild(this._createDiffSpan(DIFF_EQUAL, text));
                rightContent.appendChild(this._createDiffSpan(DIFF_EQUAL, text));
            } else if (op === DIFF_DELETE) {
                const span = this._createDiffSpan(DIFF_DELETE, text);
                this._diffElements.push(span);
                leftContent.appendChild(span);
            } else if (op === DIFF_INSERT) {
                const span = this._createDiffSpan(DIFF_INSERT, text);
                this._diffElements.push(span);
                rightContent.appendChild(span);
            }
        }

        container.appendChild(leftWrap);
        container.appendChild(rightWrap);
        this._content.appendChild(container);
    }

    /**
     * 构建左右对比的单个面板
     * @param {string} title
     * @param {string} accentColor
     * @returns {HTMLElement}
     * @private
     */
    _buildSidePane(title, accentColor) {
        const wrap = document.createElement('div');
        wrap.style.cssText = `
            background: var(--cf-bg-card, #1a1a2e);
            border: 1px solid var(--cf-border, #333);
            border-radius: 6px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        `;

        const header = document.createElement('div');
        header.style.cssText = `
            padding: 6px 12px;
            font-size: 11px;
            font-weight: 700;
            color: ${accentColor};
            border-bottom: 1px solid var(--cf-border, #333);
            background: rgba(255,255,255,0.03);
        `;
        header.textContent = title;

        const content = document.createElement('div');
        content.className = 'cf-diff-side-content';
        content.style.cssText = `
            padding: 12px 14px;
            line-height: 1.8;
            white-space: pre-wrap;
            word-break: break-word;
            font-size: 13px;
            flex: 1;
            overflow-y: auto;
            max-height: 400px;
        `;

        wrap.appendChild(header);
        wrap.appendChild(content);
        return wrap;
    }

    /**
     * 渲染差异导航
     * @private
     */
    _renderNavigation() {
        if (!this._navBar) return;

        if (this._diffElements.length === 0) {
            this._navBar.style.display = 'none';
            return;
        }

        this._navBar.style.display = 'flex';
        this._navBar.innerHTML = `
            <button id="cf-diff-prev"
                    style="padding:2px 8px;font-size:11px;cursor:pointer;
                           border:1px solid var(--cf-border,#333);border-radius:4px;
                           background:transparent;color:var(--cf-text,#ccc)">◀</button>
            <span id="cf-diff-nav-label" style="font-size:11px;color:var(--cf-text-muted,#888)">
                差异 1/${this._diffElements.length}
            </span>
            <button id="cf-diff-next"
                    style="padding:2px 8px;font-size:11px;cursor:pointer;
                           border:1px solid var(--cf-border,#333);border-radius:4px;
                           background:transparent;color:var(--cf-text,#ccc)">▶</button>
        `;

        this._navBar.querySelector('#cf-diff-prev')?.addEventListener('click', () => this.prevDiff());
        this._navBar.querySelector('#cf-diff-next')?.addEventListener('click', () => this.nextDiff());

        // 高亮第一处差异
        if (this._diffElements.length > 0) {
            this._highlightDiffElement(0);
        }
    }

    // ── 核心计算 ─────────────────────────────

    /**
     * 计算 diff
     * @param {string} original
     * @param {string} modified
     * @returns {Array}  diff-match-patch 格式的 diff 数组
     * @private
     */
    _computeDiff(original, modified) {
        if (this._dmp) {
            try {
                const diffs = this._dmp.diff_main(original, modified);
                this._dmp.diff_cleanupSemantic(diffs);
                return diffs;
            } catch {
                // 降级到简单 diff
            }
        }
        return this._simpleDiff(original, modified);
    }

    /**
     * 简单 diff 降级实现（无 diff-match-patch 时使用）
     * 基于行级 diff（性能更好，但精度较低）
     * @param {string} original
     * @param {string} modified
     * @returns {Array}
     * @private
     */
    _simpleDiff(original, modified) {
        const origLines = original.split('\n');
        const modLines  = modified.split('\n');
        const diffs     = [];

        const maxLen = Math.max(origLines.length, modLines.length);

        for (let i = 0; i < maxLen; i++) {
            const oLine = origLines[i];
            const mLine = modLines[i];

            if (oLine === undefined) {
                diffs.push([DIFF_INSERT, mLine + '\n']);
            } else if (mLine === undefined) {
                diffs.push([DIFF_DELETE, oLine + '\n']);
            } else if (oLine === mLine) {
                diffs.push([DIFF_EQUAL, oLine + '\n']);
            } else {
                diffs.push([DIFF_DELETE, oLine + '\n']);
                diffs.push([DIFF_INSERT, mLine + '\n']);
            }
        }

        return diffs;
    }

    /**
     * 计算 diff 统计
     * @param {Array} diffs
     * @returns {Object}
     * @private
     */
    _calcStats(diffs) {
        let added = 0, removed = 0, unchanged = 0;
        let addedChars = 0, removedChars = 0;

        for (const [op, text] of diffs) {
            const len = text.length;
            if (op === DIFF_INSERT) { added++;    addedChars   += len; }
            if (op === DIFF_DELETE) { removed++;  removedChars += len; }
            if (op === DIFF_EQUAL)  { unchanged += len; }
        }

        return { added, removed, unchanged, addedChars, removedChars };
    }

    // ── 工具方法 ─────────────────────────────

    /**
     * 根据 diff 操作类型创建 span 元素
     * @param {number} op
     * @param {string} text
     * @returns {HTMLSpanElement}
     * @private
     */
    _createDiffSpan(op, text) {
        const span = document.createElement('span');
        span.textContent = text;

        if (op === DIFF_INSERT) {
            span.style.cssText = `
                background: ${COLORS.insert.bg};
                color: ${COLORS.insert.text};
                border-bottom: 1px solid ${COLORS.insert.border};
                border-radius: 2px;
            `;
            span.dataset.diffType = 'insert';
        } else if (op === DIFF_DELETE) {
            span.style.cssText = `
                background: ${COLORS.delete.bg};
                color: ${COLORS.delete.text};
                border-bottom: 1px solid ${COLORS.delete.border};
                border-radius: 2px;
                text-decoration: line-through;
                text-decoration-color: ${COLORS.delete.border};
            `;
            span.dataset.diffType = 'delete';
        }

        return span;
    }

    /**
     * 高亮指定索引的差异元素
     * @param {number} idx
     * @private
     */
    _highlightDiffElement(idx) {
        // 移除旧的高亮
        this._diffElements.forEach(el => {
            el.style.outline = '';
        });

        if (idx >= 0 && idx < this._diffElements.length) {
            const el = this._diffElements[idx];
            el.style.outline = `2px solid var(--cf-primary, #7b68ee)`;
            el.style.outlineOffset = '1px';
        }
    }

    /**
     * 滚动到指定差异块
     * @param {number} idx
     * @private
     */
    _scrollToDiff(idx) {
        this._highlightDiffElement(idx);
        const el = this._diffElements[idx];
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    /**
     * 更新导航标签
     * @private
     */
    _updateNavLabel() {
        const label = this._navBar?.querySelector('#cf-diff-nav-label');
        if (label) {
            label.textContent = `差异 ${this._currentDiffIdx + 1}/${this._diffElements.length}`;
        }
    }

    /**
     * 复制文本到剪贴板
     * @param {string} text
     * @private
     */
    async _copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
        } catch {
            // 降级：创建临时 textarea
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.opacity  = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        }
    }
}

// ─────────────────────────────────────────────
// § 便捷函数
// ─────────────────────────────────────────────

/**
 * 快速在指定容器中渲染 diff
 * @param {HTMLElement} container
 * @param {string}      original
 * @param {string}      modified
 * @param {Object}      [options]
 * @returns {DiffViewer}
 */
export function renderDiff(container, original, modified, options = {}) {
    const viewer = new DiffViewer(container, options);
    viewer.render(original, modified);
    return viewer;
}

/**
 * 计算两段文本的差异统计（无需 DOM）
 * @param {string} original
 * @param {string} modified
 * @returns {{ addedChars: number, removedChars: number, unchanged: number, changeRate: number }}
 */
export function calcDiffStats(original, modified) {
    const tempViewer = new DiffViewer(document.createElement('div'));
    const diffs      = tempViewer._computeDiff(original, modified);
    const stats      = tempViewer._calcStats(diffs);
    const total      = original.length;

    return {
        ...stats,
        changeRate: total > 0
            ? Math.round(((stats.addedChars + stats.removedChars) / total) * 100)
            : 0,
    };
}