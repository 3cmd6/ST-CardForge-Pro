/**
 * @file enhance-prompts.js
 * @description 字段增强器 · Prompt 模板库
 *              为每种增强模式和字段类型提供精确的系统/用户 Prompt
 *              支持：文学化 / 详细化 / 精简化 / 诗意化 / 风格迁移
 * @module EnhancePrompts
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// § 增强模式定义
// ─────────────────────────────────────────────

/**
 * 增强模式枚举
 * @readonly
 * @enum {string}
 */
export const ENHANCE_MODES = {
    LITERARY:   'literary',   // 文学化：提升文字质感和描述力
    DETAILED:   'detailed',   // 详细化：扩展内容，增加细节
    CONCISE:    'concise',    // 精简化：压缩冗余，保留核心
    POETIC:     'poetic',     // 诗意化：偏文学诗意的表达
    DRAMATIC:   'dramatic',   // 戏剧化：强化情感张力
    MYSTICAL:   'mystical',   // 神秘化：增加神秘感和模糊感
};

/**
 * 增强模式 UI 描述
 */
export const ENHANCE_MODE_INFO = {
    [ENHANCE_MODES.LITERARY]:  { label: '📖 文学化',  desc: '提升文字质感，增强描述力与画面感' },
    [ENHANCE_MODES.DETAILED]:  { label: '🔍 详细化',  desc: '扩展内容，补充细节、背景与动机' },
    [ENHANCE_MODES.CONCISE]:   { label: '✂️ 精简化',  desc: '去除冗余，保留核心信息，更简洁有力' },
    [ENHANCE_MODES.POETIC]:    { label: '🌸 诗意化',  desc: '使用诗意意象和隐喻，风格偏文学' },
    [ENHANCE_MODES.DRAMATIC]:  { label: '🎭 戏剧化',  desc: '强化情感张力，增加冲突感与代入感' },
    [ENHANCE_MODES.MYSTICAL]:  { label: '🌙 神秘化',  desc: '增加神秘感、模糊性和留白空间' },
};

// ─────────────────────────────────────────────
// § 字段专属 Prompt 配置
// ─────────────────────────────────────────────

/**
 * 每个角色卡字段的专属增强指引
 * @type {Object.<string, Object>}
 */
export const FIELD_PROMPTS = {

    description: {
        label: '角色描述',
        role:  '你是一位擅长角色设计的作家，专注于塑造立体、真实的人物形象。',
        focus: '外貌特征、体态气质、标志性细节、给人的第一印象',
        avoid: '避免单纯罗列特征，要让描写有层次和情感温度',
        length: {
            min: 150,
            max: 500,
        },
    },

    personality: {
        label: '性格特点',
        role:  '你是一位心理学背景的角色设计师，擅长刻画人物的内在世界。',
        focus: '核心性格特质、行为习惯、内在矛盾、情感反应方式、人际相处模式',
        avoid: '避免贴标签式的描述（如"她很善良"），要体现在具体的行为和心理上',
        length: {
            min: 100,
            max: 400,
        },
    },

    scenario: {
        label: '场景背景',
        role:  '你是一位世界观构建专家，擅长营造沉浸式的叙事背景。',
        focus: '时间地点、社会背景、当前处境、与玩家的关系、即将发生的情节',
        avoid: '不要过度解释世界背景，要以角色视角呈现，突出与玩家的关联',
        length: {
            min: 100,
            max: 400,
        },
    },

    first_mes: {
        label: '开场白',
        role:  '你是一位互动小说作家，擅长写出引人入胜的开场对话。',
        focus: '角色的第一印象、场景氛围、钩子（引发玩家兴趣的元素）、对玩家的直接互动',
        avoid: '不要写成旁白，要让角色直接开口；不要过于平淡，要有记忆点',
        length: {
            min: 100,
            max: 600,
        },
    },

    mes_example: {
        label: '对话示例',
        role:  '你是一位角色扮演导演，擅长通过对话展现角色个性。',
        focus: '角色独特的说话方式、语气习惯、词汇偏好、对不同情境的反应',
        avoid: '每段示例要展现不同的情绪状态；话语要符合角色身份和背景',
        length: {
            min: 80,
            max: 300,
            perExample: true,
        },
    },

    system_prompt: {
        label: '系统提示',
        role:  '你是一位 AI 角色扮演系统设计师，擅长编写精确的行为指令。',
        focus: '角色扮演规则、行为边界、叙事风格、互动准则',
        avoid: '语言要简洁精确，不要模糊；优先使用祈使句和明确规则',
        length: {
            min: 60,
            max: 400,
        },
    },

    creator_notes: {
        label: '创作者注记',
        role:  '你是一位有经验的角色卡创作者，善于用简洁的语言传达角色精髓。',
        focus: '创作意图、使用建议、特别注意事项、推荐的交互方式',
        avoid: '用第三人称从创作者角度说话，不要混入角色视角',
        length: {
            min: 50,
            max: 300,
        },
    },

    // 通用字段（未在上面列出的字段使用此配置）
    _default: {
        label: '字段内容',
        role:  '你是一位专业的写作编辑，擅长改进各类文本的表达质量。',
        focus: '内容的清晰度、表达力、一致性',
        avoid: '保持原有的语义不变，只改善表达方式',
        length: {
            min: 50,
            max: 500,
        },
    },
};

// ─────────────────────────────────────────────
// § 增强模式 Prompt 修饰词
// ─────────────────────────────────────────────

/**
 * 各增强模式的 Prompt 追加指令
 * @type {Object.<string, Object>}
 */
const MODE_MODIFIERS = {

    [ENHANCE_MODES.LITERARY]: {
        instruction: [
            '以文学化的笔触重写以下内容。',
            '要求：',
            '- 使用具体可感的意象，而非抽象描述',
            '- 注重节奏感和语言的音乐性',
            '- 适当使用修辞（比喻、通感、白描）',
            '- 保持克制，避免过度堆砌形容词',
            '- 让文字有画面感和情感温度',
        ].join('\n'),
        intensity_low:  '轻度文学化：在原有基础上提升语言质感，保持信息完整',
        intensity_high: '深度文学化：大幅重构语言风格，追求文学美感，允许发挥创意',
    },

    [ENHANCE_MODES.DETAILED]: {
        instruction: [
            '在保留原有核心内容的基础上，大幅扩充和丰富以下内容。',
            '要求：',
            '- 补充具体细节、背景、动机和情感',
            '- 增加环境描写和感官细节（视觉、听觉、触觉）',
            '- 深化人物的内心世界和行为逻辑',
            '- 使内容更加立体、真实、可信',
            '- 扩充后的篇幅应为原文的 1.5~2.5 倍',
        ].join('\n'),
        intensity_low:  '轻度扩充：添加关键细节，小幅扩展',
        intensity_high: '深度扩充：全面丰富内容，大幅增加细节和深度',
    },

    [ENHANCE_MODES.CONCISE]: {
        instruction: [
            '对以下内容进行精简和凝练，去除冗余，保留核心。',
            '要求：',
            '- 删除重复信息和不必要的修饰',
            '- 用更精准的词汇替代繁复的描述',
            '- 保持信息密度，每句话都要有价值',
            '- 精简后的篇幅应为原文的 50%~70%',
            '- 不得删除关键信息或改变核心含义',
        ].join('\n'),
        intensity_low:  '轻度精简：去除明显冗余，保留大部分内容',
        intensity_high: '深度精简：极度压缩，只保留最核心的信息',
    },

    [ENHANCE_MODES.POETIC]: {
        instruction: [
            '以诗意的语言重写以下内容，营造意境和美感。',
            '要求：',
            '- 使用意象、隐喻和象征手法',
            '- 语言偏向古典或文学诗歌风格',
            '- 注重音韵和节奏的美感',
            '- 留有想象空间，不必把一切说尽',
            '- 情感要含蓄而有深度',
        ].join('\n'),
        intensity_low:  '轻度诗意：在写实基础上添加诗意色彩',
        intensity_high: '深度诗意：全面诗意化，追求意境之美，允许大幅重构',
    },

    [ENHANCE_MODES.DRAMATIC]: {
        instruction: [
            '强化以下内容的戏剧张力和情感冲击力。',
            '要求：',
            '- 强调冲突、矛盾和情感对立',
            '- 使用有力的动词和鲜明的对比',
            '- 增加悬念感和情感张力',
            '- 语气可以更加强烈和有冲击力',
            '- 让读者感受到情绪的起伏',
        ].join('\n'),
        intensity_low:  '轻度戏剧化：增强情感表达，保持基本克制',
        intensity_high: '深度戏剧化：全力渲染情感，强烈的戏剧效果',
    },

    [ENHANCE_MODES.MYSTICAL]: {
        instruction: [
            '为以下内容增添神秘感和模糊性，营造捉摸不定的氛围。',
            '要求：',
            '- 减少直白陈述，增加暗示和留白',
            '- 使用带有神秘色彩的意象（暗影、迷雾、回声等）',
            '- 让某些细节刻意保持模糊',
            '- 制造一种"真相若隐若现"的感觉',
            '- 语言要有一种难以言说的疏离感',
        ].join('\n'),
        intensity_low:  '轻度神秘化：添加神秘氛围，保持基本清晰度',
        intensity_high: '深度神秘化：大量留白和暗示，意义模糊多解',
    },
};

// ─────────────────────────────────────────────
// § 语言变体
// ─────────────────────────────────────────────

const LANGUAGE_SUFFIX = {
    'zh-CN': '请用中文输出，保持与原文相同的语言风格。',
    'en-US': 'Please output in English, maintaining the same language register as the original.',
};

// ─────────────────────────────────────────────
// § Prompt 构建函数
// ─────────────────────────────────────────────

/**
 * 构建单字段增强的完整 Prompt
 * @param {string} fieldName     字段名（如 'description'）
 * @param {string} content       待增强的原始内容
 * @param {string} mode          ENHANCE_MODES 中的值
 * @param {number} [intensity=0.5]   强度 0.0~1.0
 * @param {string} [language='zh-CN'] 输出语言
 * @returns {{ system: string, user: string }}
 */
export function buildEnhancePrompt(fieldName, content, mode, intensity = 0.5, language = 'zh-CN') {
    const fieldConfig  = FIELD_PROMPTS[fieldName] || FIELD_PROMPTS._default;
    const modeModifier = MODE_MODIFIERS[mode]      || MODE_MODIFIERS[ENHANCE_MODES.LITERARY];

    const intensityLabel = intensity <= 0.3
        ? modeModifier.intensity_low
        : intensity >= 0.7
        ? modeModifier.intensity_high
        : '适中强度：在保持原意的基础上有明显改善';

    // 构建系统 Prompt
    const systemParts = [
        fieldConfig.role,
        '',
        `你正在处理「${fieldConfig.label}」字段。`,
        `关注重点：${fieldConfig.focus}`,
        `注意事项：${fieldConfig.avoid}`,
        '',
        modeModifier.instruction,
        '',
        `增强强度：${intensityLabel}`,
        '',
        `字数参考：${fieldConfig.length.min}~${fieldConfig.length.max} 字`,
        '',
        LANGUAGE_SUFFIX[language] || LANGUAGE_SUFFIX['zh-CN'],
        '',
        '【重要】只输出增强后的内容本身，不要有任何前缀说明或解释文字。',
    ];

    // 构建用户 Prompt
    const userParts = [
        '请增强以下内容：',
        '',
        '---',
        content.trim(),
        '---',
    ];

    return {
        system: systemParts.join('\n'),
        user:   userParts.join('\n'),
    };
}

/**
 * 构建批量增强的 Prompt（多字段一次性处理）
 * @param {Object}   cardData   角色卡数据对象
 * @param {string[]} fields     要增强的字段名列表
 * @param {string}   mode
 * @param {number}   [intensity=0.5]
 * @returns {{ system: string, user: string }}
 */
export function buildBatchEnhancePrompt(cardData, fields, mode, intensity = 0.5) {
    const modeInfo     = ENHANCE_MODE_INFO[mode] || ENHANCE_MODE_INFO[ENHANCE_MODES.LITERARY];
    const modeModifier = MODE_MODIFIERS[mode]    || MODE_MODIFIERS[ENHANCE_MODES.LITERARY];

    const systemParts = [
        '你是一位专业的角色卡编辑，擅长同时优化多个字段的表达质量。',
        '',
        `增强模式：${modeInfo.label} — ${modeInfo.desc}`,
        '',
        modeModifier.instruction,
        '',
        '要求：',
        '- 每个字段独立增强，风格相互呼应但各有侧重',
        '- 各字段之间的内容要保持一致性（人物设定不矛盾）',
        '- 严格按照要求的 JSON 格式输出',
        '',
        '输出格式（严格 JSON）：',
        '{',
        ...fields.map(f => `  "${f}": "增强后的内容",`),
        '}',
    ];

    const fieldContents = fields.map(f => {
        const config  = FIELD_PROMPTS[f] || FIELD_PROMPTS._default;
        const content = cardData?.data?.[f] || cardData?.[f] || '';
        return [
            `【${config.label}】（${f}）：`,
            content.trim() || '（空）',
        ].join('\n');
    });

    const userParts = [
        '请增强以下角色卡的各字段：',
        '',
        ...fieldContents.map((fc, i) => `${i + 1}. ${fc}`),
        '',
        '返回 JSON 格式。',
    ];

    return {
        system: systemParts.join('\n'),
        user:   userParts.join('\n'),
    };
}

/**
 * 构建风格迁移 Prompt（参照参考文本的写作风格重写目标内容）
 * @param {string} content         待改写的原始内容
 * @param {string} referenceStyle  参考风格文本（1~3段）
 * @param {string} fieldName       字段名
 * @returns {{ system: string, user: string }}
 */
export function buildStyleTransferPrompt(content, referenceStyle, fieldName) {
    const fieldConfig = FIELD_PROMPTS[fieldName] || FIELD_PROMPTS._default;

    const system = [
        '你是一位风格迁移专家，能够精准模仿目标写作风格，同时保留原文的核心信息。',
        '',
        `任务：将「${fieldConfig.label}」字段按照参考风格重写。`,
        '',
        '分析步骤（内部分析，不需要输出）：',
        '1. 分析参考文本的词汇特点（口语/书面/古典/现代）',
        '2. 分析句式结构（长句/短句/省略/倒装）',
        '3. 分析修辞习惯（是否使用比喻、排比、反问等）',
        '4. 分析情感基调（克制/热烈/冷峻/温柔）',
        '',
        '然后按照该风格重写目标内容，只输出重写结果，不要解释。',
    ].join('\n');

    const user = [
        '【参考风格文本】：',
        '---',
        referenceStyle.trim(),
        '---',
        '',
        '【待改写内容】：',
        '---',
        content.trim(),
        '---',
        '',
        '请按照参考风格重写：',
    ].join('\n');

    return { system, user };
}

/**
 * 构建对比差异说明的 Prompt（让 AI 解释增强做了什么改动）
 * @param {string} original
 * @param {string} enhanced
 * @param {string} fieldName
 * @param {string} mode
 * @returns {{ system: string, user: string }}
 */
export function buildDiffExplanationPrompt(original, enhanced, fieldName, mode) {
    const modeInfo    = ENHANCE_MODE_INFO[mode] || { label: mode };
    const fieldConfig = FIELD_PROMPTS[fieldName] || FIELD_PROMPTS._default;

    const system = [
        '你是一位写作教练，擅长分析文本改动并给出简洁的改进说明。',
        '请分析原文和增强版本的差异，用 3~5 条要点说明做了哪些改动及理由。',
        '语言要简洁，每条不超过 40 字，使用「-」开头。',
    ].join('\n');

    const user = [
        `字段：${fieldConfig.label}`,
        `增强模式：${modeInfo.label}`,
        '',
        '【原文】：',
        original.trim().slice(0, 300),
        '',
        '【增强后】：',
        enhanced.trim().slice(0, 300),
        '',
        '请列出 3~5 条主要改动要点：',
    ].join('\n');

    return { system, user };
}

// ─────────────────────────────────────────────
// § 工具函数
// ─────────────────────────────────────────────

/**
 * 获取字段的增强配置信息
 * @param {string} fieldName
 * @returns {Object}
 */
export function getFieldConfig(fieldName) {
    return FIELD_PROMPTS[fieldName] || FIELD_PROMPTS._default;
}

/**
 * 获取所有增强模式列表
 * @returns {Array<{ value: string, label: string, desc: string }>}
 */
export function getEnhanceModes() {
    return Object.entries(ENHANCE_MODE_INFO).map(([value, info]) => ({
        value,
        label: info.label,
        desc:  info.desc,
    }));
}

/**
 * 获取可增强的字段名列表（有专属配置的字段）
 * @returns {string[]}
 */
export function getEnhancableFields() {
    return Object.keys(FIELD_PROMPTS).filter(k => k !== '_default');
}

/**
 * 将强度值（0~1）转换为描述文字
 * @param {number} intensity
 * @returns {string}
 */
export function intensityLabel(intensity) {
    if (intensity <= 0.2) return '极轻（基本保留原文）';
    if (intensity <= 0.4) return '轻度（小幅改善）';
    if (intensity <= 0.6) return '适中（明显改善）';
    if (intensity <= 0.8) return '深度（大幅重构）';
    return '极度（全面重写）';
}