/**
 * @file field-enhancer.js
 * @description 字段增强器主模块
 *              整合：AI 增强 / Prompt 模板 / Diff 对比 / 版本历史 / 批量操作
 *              实现 IModule 接口
 * @module FieldEnhancer
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import {
    buildEnhancePrompt,
    buildBatchEnhancePrompt,
    buildStyleTransferPrompt,
    buildDiffExplanationPrompt,
    ENHANCE_MODES,
    getEnhancableFields,
    getFieldConfig,
} from './enhance-prompts.js';
import { DiffViewer, calcDiffStats } from './diff-viewer.js';

// ─────────────────────────────────────────────
// § 常量
// ─────────────────────────────────────────────

/** IDB 持久化 key */
const IDB_KEY_HISTORY = 'field_enhancer_history';

/** 每个字段保留的最大历史版本数 */
const MAX_VERSIONS_PER_FIELD = 20;

/** 最大并发增强字段数（批量时） */
const MAX_CONCURRENT_ENHANCE = 3;

// ─────────────────────────────────────────────
// § FieldEnhancer 类
// ─────────────────────────────────────────────

/**
 * 字段增强器主模块
 * @implements {IModule}
 */
export class FieldEnhancer {

    /**
     * @param {import('../../core/ai-engine.js').AIEngine}              aiEngine
     * @param {import('../../core/event-bus.js').EventBus}               eventBus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     * @param {import('../../utils/undo-manager.js').UndoManager}        undoManager
     * @param {import('../../utils/indexeddb-store.js').IndexedDBStore}  dbStore
     */
    constructor(aiEngine, eventBus, settings, undoManager, dbStore) {
        this._ai          = aiEngine;
        this._eventBus    = eventBus;
        this._settings    = settings;
        this._undoManager = undoManager;
        this._dbStore     = dbStore;

        /**
         * 版本历史：fieldName → VersionRecord[]
         * @type {Map<string, VersionRecord[]>}
         */
        this._history = new Map();

        /**
         * 当前正在进行的增强任务 Map（fieldName → AbortController）
         * @type {Map<string, AbortController>}
         */
        this._activeJobs = new Map();

        /**
         * DiffViewer 实例缓存（容器 id → DiffViewer）
         * @type {Map<string, DiffViewer>}
         */
        this._diffViewers = new Map();

        /** 是否已初始化 @type {boolean} */
        this._ready = false;

        /** 事件取消函数 @type {Function[]} */
        this._unsubscribers = [];
    }

    // ── IModule 接口 ─────────────────────────

    /**
     * 初始化模块
     * @returns {Promise<void>}
     */
    async init() {
        try {
            await this._loadHistoryFromDB();
            this._ready = true;
            this._eventBus.emit(EVENTS.MODULE_READY, { module: 'FieldEnhancer' });
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module: 'FieldEnhancer',
                method: 'init',
                error,
                context: {},
            });
            throw error;
        }
    }

    /**
     * 销毁模块
     */
    destroy() {
        // 取消所有进行中的任务
        for (const ctrl of this._activeJobs.values()) {
            ctrl.abort();
        }
        this._activeJobs.clear();

        this._unsubscribers.forEach(fn => fn());
        this._unsubscribers = [];
        this._diffViewers.clear();
        this._ready = false;
    }

    /**
     * 获取当前模块状态
     * @returns {Object}
     */
    getState() {
        const totalVersions = Array.from(this._history.values())
            .reduce((sum, v) => sum + v.length, 0);

        return {
            isReady:       this._ready,
            activeJobs:    this._activeJobs.size,
            trackedFields: this._history.size,
            totalVersions,
        };
    }

    /**
     * @returns {boolean}
     */
    isReady() {
        return this._ready;
    }

    // ── 核心增强 API ─────────────────────────

    /**
     * 增强单个字段
     * @param {string} fieldName     字段名
     * @param {string} content       待增强的原始内容
     * @param {string} mode          ENHANCE_MODES 中的值
     * @param {number} [intensity=0.5]  增强强度 0.0~1.0
     * @returns {Promise<string>}    增强后的内容
     */
    async enhanceField(fieldName, content, mode = ENHANCE_MODES.LITERARY, intensity = 0.5) {
        if (!content?.trim()) {
            throw new Error(`字段「${fieldName}」内容为空，无法增强`);
        }

        // 取消同字段的上一次任务
        if (this._activeJobs.has(fieldName)) {
            this._activeJobs.get(fieldName).abort();
        }

        const ctrl = new AbortController();
        this._activeJobs.set(fieldName, ctrl);

        try {
            this._eventBus.emit(EVENTS.FIELD_ENHANCE_STARTED, { fieldName, mode, intensity });
            this._eventBus.emit(EVENTS.LOADING_START, {
                msg: `正在增强「${getFieldConfig(fieldName).label}」...`,
            });

            const { system, user } = buildEnhancePrompt(
                fieldName, content, mode, intensity,
                this._settings.get('defaultLanguage', 'zh-CN')
            );

            const enhanced = await this._ai.generateCard(system, user);

            if (!enhanced?.trim()) {
                throw new Error('AI 返回内容为空');
            }

            const result = enhanced.trim();

            // 保存版本历史
            await this._saveVersion(fieldName, content, result, mode, intensity);

            // 推入 undo 快照
            this._undoManager.push(
                { fieldName, original: content, enhanced: result },
                `增强字段：${fieldName}（${mode}）`
            );

            this._eventBus.emit(EVENTS.FIELD_ENHANCED, {
                fieldName,
                mode,
                intensity,
                originalLength: content.length,
                enhancedLength: result.length,
                stats: calcDiffStats(content, result),
            });

            return result;

        } catch (error) {
            if (error.name === 'AbortError') {
                return content; // 任务被取消，返回原内容
            }
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'FieldEnhancer',
                method:  'enhanceField',
                error,
                context: { fieldName, mode, intensity },
            });
            throw error;
        } finally {
            this._activeJobs.delete(fieldName);
            this._eventBus.emit(EVENTS.LOADING_END, {});
        }
    }

    /**
     * 批量增强多个字段（并发控制）
     * @param {Object}   cardData    角色卡数据
     * @param {string[]} fieldNames  要增强的字段列表
     * @param {string}   mode
     * @param {number}   [intensity=0.5]
     * @param {Function} [onProgress]   (fieldName, result) => void  进度回调
     * @returns {Promise<Object>}   { [fieldName]: string } 增强结果 Map
     */
    async enhanceAll(cardData, fieldNames, mode, intensity = 0.5, onProgress) {
        const results   = {};
        const fields    = fieldNames || getEnhancableFields();
        const batchSize = MAX_CONCURRENT_ENHANCE;

        try {
            this._eventBus.emit(EVENTS.LOADING_START, {
                msg: `正在批量增强 ${fields.length} 个字段...`,
            });

            // 分批并发执行
            for (let i = 0; i < fields.length; i += batchSize) {
                const batch = fields.slice(i, i + batchSize);

                const batchResults = await Promise.allSettled(
                    batch.map(async (fieldName) => {
                        const content = cardData?.data?.[fieldName] ?? cardData?.[fieldName] ?? '';
                        if (!content?.trim()) {
                            return { fieldName, result: content, skipped: true };
                        }

                        const enhanced = await this.enhanceField(
                            fieldName, content, mode, intensity
                        );

                        if (onProgress) onProgress(fieldName, enhanced);
                        return { fieldName, result: enhanced };
                    })
                );

                for (const settled of batchResults) {
                    if (settled.status === 'fulfilled') {
                        const { fieldName, result } = settled.value;
                        results[fieldName] = result;
                    }
                }
            }

            return results;

        } finally {
            this._eventBus.emit(EVENTS.LOADING_END, {});
        }
    }

    /**
     * 增强选定的字段（同 enhanceAll 但更精简的接口）
     * @param {string[]} fieldNames
     * @param {Object}   cardData
     * @param {string}   mode
     * @returns {Promise<Object>}
     */
    async enhanceSelected(fieldNames, cardData, mode) {
        return this.enhanceAll(cardData, fieldNames, mode);
    }

    /**
     * 取消指定字段的增强任务
     * @param {string} fieldName
     */
    cancelEnhance(fieldName) {
        const ctrl = this._activeJobs.get(fieldName);
        if (ctrl) {
            ctrl.abort();
            this._activeJobs.delete(fieldName);
        }
    }

    /**
     * 取消所有进行中的增强任务
     */
    cancelAll() {
        for (const [fieldName, ctrl] of this._activeJobs.entries()) {
            ctrl.abort();
        }
        this._activeJobs.clear();
    }

    // ── 风格迁移 ─────────────────────────────

    /**
     * 风格迁移：按参考文本的写作风格重写目标内容
     * @param {string} content         待改写内容
     * @param {string} referenceStyle  参考风格文本
     * @param {string} fieldName       字段名
     * @returns {Promise<string>}
     */
    async transferStyle(content, referenceStyle, fieldName) {
        if (!content?.trim())       throw new Error('待改写内容不能为空');
        if (!referenceStyle?.trim()) throw new Error('参考风格文本不能为空');

        try {
            this._eventBus.emit(EVENTS.LOADING_START, { msg: '正在进行风格迁移...' });

            const { system, user } = buildStyleTransferPrompt(content, referenceStyle, fieldName);
            const result = await this._ai.generateCard(system, user);

            if (!result?.trim()) throw new Error('AI 返回内容为空');

            const enhanced = result.trim();
            await this._saveVersion(fieldName, content, enhanced, 'style_transfer', 0.5);

            this._eventBus.emit(EVENTS.FIELD_ENHANCED, {
                fieldName,
                mode: 'style_transfer',
                stats: calcDiffStats(content, enhanced),
            });

            return enhanced;

        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'FieldEnhancer',
                method:  'transferStyle',
                error,
                context: { fieldName },
            });
            throw error;
        } finally {
            this._eventBus.emit(EVENTS.LOADING_END, {});
        }
    }

    /**
     * 获取 AI 对增强改动的说明
     * @param {string} original
     * @param {string} enhanced
     * @param {string} fieldName
     * @param {string} mode
     * @returns {Promise<string>}
     */
    async explainDiff(original, enhanced, fieldName, mode) {
        try {
            const { system, user } = buildDiffExplanationPrompt(
                original, enhanced, fieldName, mode
            );
            const result = await this._ai.generateCard(system, user);
            return result?.trim() || '（无说明）';
        } catch {
            return '（获取说明失败）';
        }
    }

    // ── Diff 对比视图 ─────────────────────────

    /**
     * 在指定容器中创建并渲染 Diff 视图
     * @param {HTMLElement} container
     * @param {string}      original
     * @param {string}      enhanced
     * @param {Object}      [options]
     * @returns {DiffViewer}
     */
    mountDiffViewer(container, original, enhanced, options = {}) {
        const viewerId = container.id || `diff_${Date.now()}`;

        // 销毁旧实例
        if (this._diffViewers.has(viewerId)) {
            this._diffViewers.get(viewerId).clear();
        }

        const viewer = new DiffViewer(container, options);
        viewer.render(original, enhanced);
        this._diffViewers.set(viewerId, viewer);

        return viewer;
    }

    /**
     * 更新已挂载的 Diff 视图
     * @param {string} viewerId  容器 id
     * @param {string} original
     * @param {string} enhanced
     */
    updateDiffViewer(viewerId, original, enhanced) {
        const viewer = this._diffViewers.get(viewerId);
        if (viewer) {
            viewer.render(original, enhanced);
        }
    }

    /**
     * 销毁指定 Diff 视图
     * @param {string} viewerId
     */
    destroyDiffViewer(viewerId) {
        const viewer = this._diffViewers.get(viewerId);
        if (viewer) {
            viewer.clear();
            this._diffViewers.delete(viewerId);
        }
    }

    /**
     * 计算两段文本的差异统计
     * @param {string} original
     * @param {string} enhanced
     * @returns {Object}
     */
    computeDiff(original, enhanced) {
        return calcDiffStats(original, enhanced);
    }

    // ── 版本历史 ─────────────────────────────

    /**
     * 获取字段的所有历史版本（最新优先）
     * @param {string} fieldName
     * @returns {VersionRecord[]}
     */
    getVersionHistory(fieldName) {
        const versions = this._history.get(fieldName) || [];
        return [...versions].reverse(); // 最新在前
    }

    /**
     * 恢复到指定版本
     * @param {string} fieldName
     * @param {string} versionId
     * @returns {VersionRecord|null}
     */
    revertToVersion(fieldName, versionId) {
        const versions = this._history.get(fieldName) || [];
        const version  = versions.find(v => v.id === versionId);
        if (!version) return null;

        // 将当前版本的 original 保存（便于再次撤回）
        this._undoManager.push(
            { fieldName, versionId },
            `恢复版本：${new Date(version.timestamp).toLocaleString('zh-CN')}`
        );

        this._eventBus.emit(EVENTS.FIELD_ENHANCED, {
            fieldName,
            mode:     'revert',
            versionId,
        });

        return version;
    }

    /**
     * 删除字段的单条历史版本
     * @param {string} fieldName
     * @param {string} versionId
     * @returns {boolean}
     */
    deleteVersion(fieldName, versionId) {
        const versions = this._history.get(fieldName);
        if (!versions) return false;

        const idx = versions.findIndex(v => v.id === versionId);
        if (idx === -1) return false;

        versions.splice(idx, 1);
        this._persistHistory();
        return true;
    }

    /**
     * 清除字段的所有历史
     * @param {string} fieldName
     */
    clearHistory(fieldName) {
        this._history.delete(fieldName);
        this._persistHistory();
    }

    /**
     * 清除所有字段历史
     */
    clearAllHistory() {
        this._history.clear();
        this._persistHistory();
    }

    /**
     * 获取历史统计
     * @returns {{ fieldCount: number, totalVersions: number, oldestTimestamp: number|null }}
     */
    getHistoryStats() {
        let totalVersions   = 0;
        let oldestTimestamp = null;

        for (const versions of this._history.values()) {
            totalVersions += versions.length;
            for (const v of versions) {
                if (!oldestTimestamp || v.timestamp < oldestTimestamp) {
                    oldestTimestamp = v.timestamp;
                }
            }
        }

        return {
            fieldCount:       this._history.size,
            totalVersions,
            oldestTimestamp,
        };
    }

    // ── 工具方法（公共） ─────────────────────

    /**
     * 获取可增强的字段列表（有专属 Prompt 配置的字段）
     * @returns {string[]}
     */
    getEnhancableFields() {
        return getEnhancableFields();
    }

    /**
     * 获取增强模式列表
     * @returns {Array<{value:string, label:string, desc:string}>}
     */
    getEnhanceModes() {
        return Object.entries(ENHANCE_MODES).map(([, value]) => {
            const info = {
                literary: { label: '📖 文学化',  desc: '提升文字质感和描述力' },
                detailed: { label: '🔍 详细化',  desc: '扩展内容，补充细节' },
                concise:  { label: '✂️ 精简化',  desc: '去除冗余，保留核心' },
                poetic:   { label: '🌸 诗意化',  desc: '使用诗意意象和隐喻' },
                dramatic: { label: '🎭 戏剧化',  desc: '强化情感张力' },
                mystical: { label: '🌙 神秘化',  desc: '增加神秘感和留白' },
            }[value] || { label: value, desc: '' };
            return { value, ...info };
        });
    }

    /**
     * 检查指定字段是否有进行中的增强任务
     * @param {string} fieldName
     * @returns {boolean}
     */
    isEnhancing(fieldName) {
        return this._activeJobs.has(fieldName);
    }

    // ── 私有方法 ─────────────────────────────

    /**
     * 保存版本到历史记录
     * @param {string} fieldName
     * @param {string} original
     * @param {string} enhanced
     * @param {string} mode
     * @param {number} intensity
     * @returns {Promise<void>}
     * @private
     */
    async _saveVersion(fieldName, original, enhanced, mode, intensity) {
        if (!this._history.has(fieldName)) {
            this._history.set(fieldName, []);
        }

        const versions = this._history.get(fieldName);

        /** @type {VersionRecord} */
        const record = {
            id:        `v_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            fieldName,
            original,
            enhanced,
            mode,
            intensity,
            timestamp: Date.now(),
            stats:     calcDiffStats(original, enhanced),
        };

        versions.push(record);

        // 超出上限时删除最旧的版本
        if (versions.length > MAX_VERSIONS_PER_FIELD) {
            versions.splice(0, versions.length - MAX_VERSIONS_PER_FIELD);
        }

        await this._persistHistory();
    }

    /**
     * 将历史记录持久化到 IDB
     * @returns {Promise<void>}
     * @private
     */
    async _persistHistory() {
        try {
            const serializable = {};
            for (const [field, versions] of this._history.entries()) {
                serializable[field] = versions;
            }
            await this._dbStore.set(IDB_KEY_HISTORY, {
                history: serializable,
                savedAt: Date.now(),
            });
        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module:  'FieldEnhancer',
                method:  '_persistHistory',
                error,
                context: {},
            });
        }
    }

    /**
     * 从 IDB 恢复历史记录
     * @returns {Promise<void>}
     * @private
     */
    async _loadHistoryFromDB() {
        try {
            const saved = await this._dbStore.get(IDB_KEY_HISTORY);
            if (saved?.history) {
                for (const [field, versions] of Object.entries(saved.history)) {
                    this._history.set(field, versions);
                }
            }
        } catch {
            // 首次启动，无历史数据
        }
    }
}

// ─────────────────────────────────────────────
// § 类型注解（JSDoc）
// ─────────────────────────────────────────────

/**
 * 版本历史记录
 * @typedef {Object} VersionRecord
 * @property {string} id            版本 ID
 * @property {string} fieldName     字段名
 * @property {string} original      增强前内容
 * @property {string} enhanced      增强后内容
 * @property {string} mode          增强模式
 * @property {number} intensity     增强强度
 * @property {number} timestamp     时间戳（ms）
 * @property {Object} stats         差异统计
 */