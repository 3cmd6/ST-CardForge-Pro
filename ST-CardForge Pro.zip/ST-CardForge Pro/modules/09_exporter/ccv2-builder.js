/**
 * @file ccv2-builder.js
 * @description CCv2（Chara Card v2）格式构建器
 *              将内部 CardData 结构序列化为标准 CCv2 JSON 对象
 *              同时提供字段校验、字段补全、兼容性修复
 * @module CCv2Builder
 * @version 1.0.0
 */

import { CARD_DATA_SCHEMA } from '../../contracts.js';

// ─────────────────────────────────────────────
// § CCv2 规范常量
// ─────────────────────────────────────────────

/** CCv2 规范版本 */
export const CCv2_SPEC         = 'chara_card_v2';
export const CCv2_SPEC_VERSION = '2.0';

/**
 * CCv2 必填字段
 * @readonly
 */
export const CCv2_REQUIRED_FIELDS = [
    'name',
];

/**
 * CCv2 推荐字段（缺失时添加警告）
 * @readonly
 */
export const CCv2_RECOMMENDED_FIELDS = [
    'description',
    'personality',
    'first_mes',
];

/**
 * CCv2 标准字段列表（白名单）
 * @readonly
 */
export const CCv2_STANDARD_FIELDS = [
    'name',
    'description',
    'personality',
    'scenario',
    'first_mes',
    'mes_example',
    'creator_notes',
    'system_prompt',
    'post_history_instructions',
    'alternate_greetings',
    'character_book',
    'tags',
    'creator',
    'character_version',
    'extensions',
];

// ─────────────────────────────────────────────
// § CCv2Builder 类
// ─────────────────────────────────────────────

/**
 * CCv2 格式构建器
 */
export class CCv2Builder {

    constructor() {
        /**
         * 构建过程中的警告信息
         * @type {string[]}
         */
        this._warnings = [];

        /**
         * 构建过程中的错误信息
         * @type {string[]}
         */
        this._errors = [];
    }

    // ── 主方法 ───────────────────────────────

    /**
     * 将 CardData 构建为标准 CCv2 JSON 对象
     * @param {Object} cardData  内部 CardData 格式
     * @returns {{ data: Object, warnings: string[], errors: string[] }}
     */
    build(cardData) {
        this._warnings = [];
        this._errors   = [];

        try {
            const source = this._normalizeSource(cardData);
            const v2     = this._buildV2Object(source);

            return {
                data:     v2,
                warnings: [...this._warnings],
                errors:   [...this._errors],
            };
        } catch (error) {
            this._errors.push(`构建失败：${error.message}`);
            return {
                data:     null,
                warnings: this._warnings,
                errors:   this._errors,
            };
        }
    }

    /**
     * 校验 CCv2 JSON 对象的合规性
     * @param {Object} v2Data  待校验的 CCv2 JSON
     * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
     */
    validate(v2Data) {
        const errors   = [];
        const warnings = [];

        if (!v2Data || typeof v2Data !== 'object') {
            errors.push('数据为空或格式不正确');
            return { valid: false, errors, warnings };
        }

        // 检查 spec 标识
        if (v2Data.spec !== CCv2_SPEC) {
            errors.push(`spec 字段不正确：期望 "${CCv2_SPEC}"，实际 "${v2Data.spec}"`);
        }

        if (!v2Data.data || typeof v2Data.data !== 'object') {
            errors.push('缺少 data 字段');
            return { valid: false, errors, warnings };
        }

        const data = v2Data.data;

        // 必填字段检查
        for (const field of CCv2_REQUIRED_FIELDS) {
            if (!data[field] || String(data[field]).trim() === '') {
                errors.push(`必填字段「${field}」不能为空`);
            }
        }

        // 推荐字段检查
        for (const field of CCv2_RECOMMENDED_FIELDS) {
            if (!data[field] || String(data[field]).trim() === '') {
                warnings.push(`推荐字段「${field}」为空，建议填写`);
            }
        }

        // 字段类型检查
        if (data.alternate_greetings && !Array.isArray(data.alternate_greetings)) {
            errors.push('alternate_greetings 必须是数组');
        }
        if (data.tags && !Array.isArray(data.tags)) {
            errors.push('tags 必须是数组');
        }

        // character_book 结构检查
        if (data.character_book) {
            const wbResult = this._validateCharacterBook(data.character_book);
            errors.push(...wbResult.errors);
            warnings.push(...wbResult.warnings);
        }

        return {
            valid:    errors.length === 0,
            errors,
            warnings,
        };
    }

    /**
     * 从 CCv2 JSON 解析为内部 CardData 格式
     * @param {Object} v2Data
     * @returns {Object}  CardData 格式对象
     */
    parse(v2Data) {
        if (!v2Data?.data) {
            throw new Error('无效的 CCv2 数据：缺少 data 字段');
        }

        const src  = v2Data.data;
        const card = JSON.parse(JSON.stringify(CARD_DATA_SCHEMA));

        // 映射标准字段
        for (const field of CCv2_STANDARD_FIELDS) {
            if (src[field] !== undefined) {
                card.data[field] = src[field];
            }
        }

        // 设置规范版本
        card.spec         = CCv2_SPEC;
        card.spec_version = CCv2_SPEC_VERSION;

        // 处理时间戳
        if (!card.data.extensions.cardforge.meta.created_at) {
            card.data.extensions.cardforge.meta.created_at = Date.now();
        }
        card.data.extensions.cardforge.meta.updated_at = Date.now();

        return card;
    }

    /**
     * 将 CCv2 升级为 CCv3 兼容格式（迁移辅助）
     * @param {Object} v2Data
     * @returns {Object}  CCv3 兼容的 data 字段
     */
    upgradeToV3Compatible(v2Data) {
        if (!v2Data?.data) throw new Error('无效的 CCv2 数据');

        const src = v2Data.data;

        return {
            // V2 字段直接映射
            name:                       src.name || '',
            description:                src.description || '',
            personality:                src.personality || '',
            scenario:                   src.scenario || '',
            first_mes:                  src.first_mes || '',
            mes_example:                src.mes_example || '',
            creator_notes:              src.creator_notes || '',
            system_prompt:              src.system_prompt || '',
            post_history_instructions:  src.post_history_instructions || '',
            alternate_greetings:        src.alternate_greetings || [],
            tags:                       src.tags || [],
            creator:                    src.creator || '',
            character_version:          src.character_version || '',

            // V3 新增字段（默认值）
            nickname:                   '',
            creator_notes_multilingual: {},
            source:                     [],
            group_only_greetings:       [],
            assets:                     [],

            // 迁移 character_book → extensions
            extensions: {
                cardforge: {
                    version: '1.0.0',
                    migrated_from: 'ccv2',
                    migrated_at: Date.now(),
                },
                ...(src.extensions || {}),
            },

            // 如果有 character_book，保留
            ...(src.character_book ? { character_book: src.character_book } : {}),
        };
    }

    // ── 私有构建方法 ─────────────────────────

    /**
     * 规范化输入数据源（兼容多种输入格式）
     * @param {Object} cardData
     * @returns {Object}  规范化后的 data 层对象
     * @private
     */
    _normalizeSource(cardData) {
        // 已是 CCv2 格式
        if (cardData?.spec === CCv2_SPEC && cardData?.data) {
            return cardData.data;
        }
        // 已是 CCv3 格式
        if (cardData?.spec === 'chara_card_v3' && cardData?.data) {
            return cardData.data;
        }
        // 内部 CardData 格式
        if (cardData?.data && typeof cardData.data === 'object') {
            return cardData.data;
        }
        // 裸对象（直接是 data 层）
        if (cardData?.name !== undefined) {
            return cardData;
        }
        throw new Error('无法识别的输入数据格式');
    }

    /**
     * 构建标准 CCv2 对象
     * @param {Object} source  规范化后的 data 层
     * @returns {Object}  完整 CCv2 JSON
     * @private
     */
    _buildV2Object(source) {
        // 必填字段校验
        if (!source.name?.trim()) {
            this._errors.push('name 字段不能为空');
        }

        // 推荐字段警告
        for (const field of CCv2_RECOMMENDED_FIELDS) {
            if (!source[field]?.trim?.()) {
                this._warnings.push(`推荐字段「${field}」为空`);
            }
        }

        const data = {
            // 核心叙事字段
            name:                       this._sanitizeString(source.name),
            description:                this._sanitizeString(source.description),
            personality:                this._sanitizeString(source.personality),
            scenario:                   this._sanitizeString(source.scenario),
            first_mes:                  this._sanitizeString(source.first_mes),
            mes_example:                this._sanitizeString(source.mes_example),

            // 提示词字段
            creator_notes:              this._sanitizeString(source.creator_notes),
            system_prompt:              this._sanitizeString(source.system_prompt),
            post_history_instructions:  this._sanitizeString(source.post_history_instructions),

            // 数组字段
            alternate_greetings:        this._sanitizeArray(source.alternate_greetings),
            tags:                       this._sanitizeTagArray(source.tags),

            // 元数据
            creator:                    this._sanitizeString(source.creator),
            character_version:          this._sanitizeString(source.character_version),

            // 扩展（保留 cardforge 命名空间，清理非标准数据）
            extensions:                 this._buildExtensions(source),
        };

        // character_book（世界书）
        if (source.character_book && typeof source.character_book === 'object') {
            data.character_book = this._buildCharacterBook(source.character_book);
        }

        return {
            spec:         CCv2_SPEC,
            spec_version: CCv2_SPEC_VERSION,
            data,
        };
    }

    /**
     * 构建 character_book（嵌入世界书）
     * @param {Object} worldBook
     * @returns {Object}
     * @private
     */
    _buildCharacterBook(worldBook) {
        const entries = (worldBook.entries || []).map((entry, idx) => ({
            keys:              this._sanitizeArray(entry.keys),
            secondary_keys:    this._sanitizeArray(entry.secondary_keys),
            content:           this._sanitizeString(entry.content),
            extensions:        entry.extensions || {},
            enabled:           entry.enabled !== false,
            insertion_order:   Number(entry.insertion_order) || 100,
            case_sensitive:    entry.case_sensitive || false,
            name:              entry.name || entry.keys?.[0] || `entry_${idx}`,
            priority:          Number(entry.priority) || 10,
            id:                entry.uid ?? entry.id ?? idx,
            comment:           entry.comment || '',
            selective:         entry.selective || false,
            secondary_key_logic: entry.secondary_key_logic || 'AND',
            constant:          entry.constant || false,
            position:          this._normalizeWBPosition(entry.position),
        }));

        return {
            name:               worldBook.name || '',
            description:        worldBook.description || '',
            scan_depth:         worldBook.scan_depth || 2,
            token_budget:       worldBook.token_budget || 512,
            recursive_scanning: worldBook.recursive_scanning || false,
            extensions:         worldBook.extensions || {},
            entries,
        };
    }

    /**
     * 构建 extensions 字段（保留白名单命名空间）
     * @param {Object} source
     * @returns {Object}
     * @private
     */
    _buildExtensions(source) {
        const ext = source.extensions || {};

        // 保留 cardforge 命名空间数据
        const cardforgeExt = ext.cardforge || {};

        return {
            cardforge: {
                version:    cardforgeExt.version    || '1.0.0',
                stats:      cardforgeExt.stats      || {},
                branches:   cardforgeExt.branches   || [],
                regex:      cardforgeExt.regex      || [],
                meta: {
                    created_at: cardforgeExt.meta?.created_at || Date.now(),
                    updated_at: Date.now(),
                    session_id: cardforgeExt.meta?.session_id || null,
                },
            },
        };
    }

    /**
     * 校验嵌入世界书结构
     * @param {Object} book
     * @returns {{ errors: string[], warnings: string[] }}
     * @private
     */
    _validateCharacterBook(book) {
        const errors   = [];
        const warnings = [];

        if (!Array.isArray(book.entries)) {
            errors.push('character_book.entries 必须是数组');
            return { errors, warnings };
        }

        book.entries.forEach((entry, i) => {
            if (!Array.isArray(entry.keys) || entry.keys.length === 0) {
                warnings.push(`世界书条目 #${i} 缺少关键词`);
            }
            if (!entry.content?.trim()) {
                warnings.push(`世界书条目 #${i} 内容为空`);
            }
        });

        return { errors, warnings };
    }

    // ── 工具方法 ─────────────────────────────

    /**
     * 规范化字符串（去除首尾空白，将 null/undefined 转为空字符串）
     * @param {*} val
     * @returns {string}
     * @private
     */
    _sanitizeString(val) {
        if (val === null || val === undefined) return '';
        return String(val).trim();
    }

    /**
     * 规范化数组（过滤空字符串）
     * @param {*} val
     * @returns {string[]}
     * @private
     */
    _sanitizeArray(val) {
        if (!Array.isArray(val)) return [];
        return val
            .filter(item => item !== null && item !== undefined)
            .map(item => String(item).trim())
            .filter(item => item !== '');
    }

    /**
     * 规范化标签数组（去重 + 去空 + 小写化）
     * @param {*} val
     * @returns {string[]}
     * @private
     */
    _sanitizeTagArray(val) {
        const arr = this._sanitizeArray(val);
        const seen = new Set();
        return arr
            .map(t => t.toLowerCase().trim())
            .filter(t => {
                if (seen.has(t)) return false;
                seen.add(t);
                return true;
            });
    }

    /**
     * 规范化世界书条目位置值
     * @param {string} position
     * @returns {string}
     * @private
     */
    _normalizeWBPosition(position) {
        const valid = ['before_char', 'after_char', 'before_example', 'after_example', 'at_depth'];
        return valid.includes(position) ? position : 'before_char';
    }
}

// ─────────────────────────────────────────────
// § 便捷函数
// ─────────────────────────────────────────────

/** 全局共享实例 */
const _builder = new CCv2Builder();

/**
 * 快速构建 CCv2 JSON 对象
 * @param {Object} cardData
 * @returns {{ data: Object, warnings: string[], errors: string[] }}
 */
export function buildCCv2(cardData) {
    return _builder.build(cardData);
}

/**
 * 快速校验 CCv2 对象
 * @param {Object} v2Data
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
export function validateCCv2(v2Data) {
    return _builder.validate(v2Data);
}

/**
 * 解析 CCv2 为内部 CardData
 * @param {Object} v2Data
 * @returns {Object}
 */
export function parseCCv2(v2Data) {
    return _builder.parse(v2Data);
}

/**
 * CCv2 升级为 CCv3 兼容格式
 * @param {Object} v2Data
 * @returns {Object}
 */
export function migrateCCv2ToCCv3(v2Data) {
    return _builder.upgradeToV3Compatible(v2Data);
}