/**
 * @file ccv3-builder.js
 * @description CCv3（Chara Card v3）格式构建器
 *              将内部 CardData 结构序列化为标准 CCv3 JSON 对象
 *              支持：多语言 creator_notes / 资产清单 / group_only_greetings /
 *                    lorebook（扩展世界书）/ 完整校验
 * @module CCv3Builder
 * @version 1.0.0
 */

import { CARD_DATA_SCHEMA, WB_ENTRY_SCHEMA } from '../../contracts.js';

// ─────────────────────────────────────────────
// § CCv3 规范常量
// ─────────────────────────────────────────────

export const CCv3_SPEC         = 'chara_card_v3';
export const CCv3_SPEC_VERSION = '3.0';

/**
 * CCv3 必填字段
 * @readonly
 */
export const CCv3_REQUIRED_FIELDS = [
    'name',
];

/**
 * CCv3 推荐字段
 * @readonly
 */
export const CCv3_RECOMMENDED_FIELDS = [
    'description',
    'personality',
    'first_mes',
    'tags',
];

/**
 * CCv3 所有标准字段
 * @readonly
 */
export const CCv3_STANDARD_FIELDS = [
    // 继承自 V2
    'name',
    'description',
    'personality',
    'scenario',
    'first_mes',
    'mes_example',
    'creator_notes',
    'system_prompt',
    'post_history_instructions',
    'alternate_greetings',
    'character_book',
    'tags',
    'creator',
    'character_version',
    'extensions',

    // V3 新增
    'nickname',
    'creator_notes_multilingual',
    'source',
    'group_only_greetings',
    'assets',
];

/**
 * CCv3 资产类型枚举
 * @readonly
 */
export const ASSET_TYPES = {
    ICON:       'icon',
    BACKGROUND: 'background',
    USER_ICON:  'user_icon',
    EMOTION:    'emotion',
    SOUND:      'sound',
    VIDEO:      'video',
    OTHER:      'other',
};

// ─────────────────────────────────────────────
// § CCv3Builder 类
// ─────────────────────────────────────────────

/**
 * CCv3 格式构建器
 */
export class CCv3Builder {

    constructor() {
        /** @type {string[]} */
        this._warnings = [];
        /** @type {string[]} */
        this._errors   = [];
    }

    // ── 主方法 ───────────────────────────────

    /**
     * 将 CardData 构建为标准 CCv3 JSON 对象
     * @param {Object} cardData
     * @returns {{ data: Object, warnings: string[], errors: string[] }}
     */
    build(cardData) {
        this._warnings = [];
        this._errors   = [];

        try {
            const source = this._normalizeSource(cardData);
            const v3     = this._buildV3Object(source);

            return {
                data:     v3,
                warnings: [...this._warnings],
                errors:   [...this._errors],
            };
        } catch (error) {
            this._errors.push(`构建失败：${error.message}`);
            return {
                data:     null,
                warnings: this._warnings,
                errors:   this._errors,
            };
        }
    }

    /**
     * 校验 CCv3 JSON 对象
     * @param {Object} v3Data
     * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
     */
    validate(v3Data) {
        const errors   = [];
        const warnings = [];

        if (!v3Data || typeof v3Data !== 'object') {
            return { valid: false, errors: ['数据为空或格式不正确'], warnings };
        }

        // spec 检查
        if (v3Data.spec !== CCv3_SPEC) {
            errors.push(`spec 不正确：期望 "${CCv3_SPEC}"，实际 "${v3Data.spec}"`);
        }
        if (v3Data.spec_version !== CCv3_SPEC_VERSION) {
            warnings.push(`spec_version 不是最新版本（${CCv3_SPEC_VERSION}）`);
        }

        if (!v3Data.data || typeof v3Data.data !== 'object') {
            errors.push('缺少 data 字段');
            return { valid: false, errors, warnings };
        }

        const data = v3Data.data;

        // 必填字段
        for (const field of CCv3_REQUIRED_FIELDS) {
            if (!data[field]?.trim?.()) {
                errors.push(`必填字段「${field}」不能为空`);
            }
        }

        // 推荐字段
        for (const field of CCv3_RECOMMENDED_FIELDS) {
            const val = data[field];
            const isEmpty = Array.isArray(val)
                ? val.length === 0
                : !val?.trim?.();
            if (isEmpty) {
                warnings.push(`推荐字段「${field}」为空`);
            }
        }

        // 类型检查
        const arrayFields = [
            'alternate_greetings', 'tags', 'source',
            'group_only_greetings', 'assets',
        ];
        for (const field of arrayFields) {
            if (data[field] !== undefined && !Array.isArray(data[field])) {
                errors.push(`字段「${field}」必须是数组`);
            }
        }

        // assets 结构检查
        if (Array.isArray(data.assets)) {
            data.assets.forEach((asset, i) => {
                if (!asset.type)   warnings.push(`assets[${i}] 缺少 type 字段`);
                if (!asset.name)   warnings.push(`assets[${i}] 缺少 name 字段`);
                if (!asset.uri)    errors.push(`assets[${i}] 缺少 uri 字段`);
            });
        }

        // creator_notes_multilingual 检查
        if (data.creator_notes_multilingual &&
            typeof data.creator_notes_multilingual !== 'object') {
            errors.push('creator_notes_multilingual 必须是对象');
        }

        // character_book 检查
        if (data.character_book) {
            const bookResult = this._validateLorebook(data.character_book);
            errors.push(...bookResult.errors);
            warnings.push(...bookResult.warnings);
        }

        return {
            valid: errors.length === 0,
            errors,
            warnings,
        };
    }

    /**
     * 从 CCv3 JSON 解析为内部 CardData 格式
     * @param {Object} v3Data
     * @returns {Object}  CardData 格式
     */
    parse(v3Data) {
        if (!v3Data?.data) {
            throw new Error('无效的 CCv3 数据：缺少 data 字段');
        }

        const src  = v3Data.data;
        const card = JSON.parse(JSON.stringify(CARD_DATA_SCHEMA));

        // 映射所有标准字段
        for (const field of CCv3_STANDARD_FIELDS) {
            if (src[field] !== undefined) {
                card.data[field] = src[field];
            }
        }

        // 规范版本
        card.spec         = CCv3_SPEC;
        card.spec_version = CCv3_SPEC_VERSION;

        // 合并 extensions.cardforge
        if (src.extensions?.cardforge) {
            Object.assign(
                card.data.extensions.cardforge,
                src.extensions.cardforge
            );
        }

        card.data.extensions.cardforge.meta.updated_at = Date.now();
        if (!card.data.extensions.cardforge.meta.created_at) {
            card.data.extensions.cardforge.meta.created_at = Date.now();
        }

        return card;
    }

    /**
     * 清理并规范化 CCv3 对象（移除非法字段、修复类型错误）
     * @param {Object} v3Data
     * @returns {Object}  清理后的 CCv3 JSON
     */
    sanitize(v3Data) {
        if (!v3Data?.data) return v3Data;

        const cleaned = JSON.parse(JSON.stringify(v3Data));
        const data    = cleaned.data;

        // 确保数组字段是数组
        const arrayFields = [
            'alternate_greetings', 'tags', 'source',
            'group_only_greetings', 'assets',
        ];
        for (const field of arrayFields) {
            if (!Array.isArray(data[field])) {
                data[field] = data[field] ? [data[field]] : [];
            }
        }

        // 确保字符串字段是字符串
        const stringFields = [
            'name', 'description', 'personality', 'scenario',
            'first_mes', 'mes_example', 'creator_notes',
            'system_prompt', 'post_history_instructions',
            'nickname', 'creator', 'character_version',
        ];
        for (const field of stringFields) {
            if (data[field] !== undefined && typeof data[field] !== 'string') {
                data[field] = String(data[field] ?? '');
            }
        }

        // 确保 extensions 是对象
        if (!data.extensions || typeof data.extensions !== 'object') {
            data.extensions = {};
        }

        // 确保 creator_notes_multilingual 是对象
        if (!data.creator_notes_multilingual ||
            typeof data.creator_notes_multilingual !== 'object') {
            data.creator_notes_multilingual = {};
        }

        return cleaned;
    }

    // ── 私有构建方法 ─────────────────────────

    /**
     * 规范化输入数据源
     * @param {Object} cardData
     * @returns {Object}
     * @private
     */
    _normalizeSource(cardData) {
        if (cardData?.spec === CCv3_SPEC && cardData?.data) {
            return cardData.data;
        }
        if (cardData?.spec === 'chara_card_v2' && cardData?.data) {
            this._warnings.push('输入为 CCv2 格式，将自动升级字段');
            return cardData.data;
        }
        if (cardData?.data && typeof cardData.data === 'object') {
            return cardData.data;
        }
        if (cardData?.name !== undefined) {
            return cardData;
        }
        throw new Error('无法识别的输入数据格式');
    }

    /**
     * 构建完整 CCv3 对象
     * @param {Object} source
     * @returns {Object}
     * @private
     */
    _buildV3Object(source) {
        // 必填字段检查
        if (!source.name?.trim()) {
            this._errors.push('name 字段不能为空');
        }

        // 推荐字段警告
        for (const field of CCv3_RECOMMENDED_FIELDS) {
            const val = source[field];
            const isEmpty = Array.isArray(val) ? val.length === 0 : !val?.trim?.();
            if (isEmpty) {
                this._warnings.push(`推荐字段「${field}」为空`);
            }
        }

        const data = {
            // ── 继承自 CCv2 的核心字段 ──
            name:                       this._str(source.name),
            description:                this._str(source.description),
            personality:                this._str(source.personality),
            scenario:                   this._str(source.scenario),
            first_mes:                  this._str(source.first_mes),
            mes_example:                this._str(source.mes_example),
            creator_notes:              this._str(source.creator_notes),
            system_prompt:              this._str(source.system_prompt),
            post_history_instructions:  this._str(source.post_history_instructions),
            alternate_greetings:        this._arr(source.alternate_greetings),
            tags:                       this._tags(source.tags),
            creator:                    this._str(source.creator),
            character_version:          this._str(source.character_version),

            // ── CCv3 新增字段 ──
            nickname:                   this._str(source.nickname),
            creator_notes_multilingual: this._buildMultilingualNotes(source),
            source:                     this._arr(source.source),
            group_only_greetings:       this._arr(source.group_only_greetings),
            assets:                     this._buildAssets(source.assets),

            // ── extensions ──
            extensions:                 this._buildExtensionsV3(source),
        };

        // character_book（嵌入世界书）
        if (source.character_book && typeof source.character_book === 'object') {
            data.character_book = this._buildLorebook(source.character_book);
        }

        return {
            spec:         CCv3_SPEC,
            spec_version: CCv3_SPEC_VERSION,
            data,
        };
    }

    /**
     * 构建多语言 creator_notes 对象
     * @param {Object} source
     * @returns {Object}
     * @private
     */
    _buildMultilingualNotes(source) {
        const multilingual = source.creator_notes_multilingual || {};

        // 如果有中文 notes 但没有 zh-CN 键，自动填充
        if (source.creator_notes && !multilingual['zh-CN']) {
            multilingual['zh-CN'] = source.creator_notes;
        }

        // 仅保留字符串值
        const cleaned = {};
        for (const [lang, note] of Object.entries(multilingual)) {
            if (typeof note === 'string' && note.trim()) {
                cleaned[lang] = note.trim();
            }
        }

        return cleaned;
    }

    /**
     * 构建资产清单
     * @param {Array|undefined} assets
     * @returns {Object[]}
     * @private
     */
    _buildAssets(assets) {
        if (!Array.isArray(assets)) return [];

        return assets
            .filter(asset => asset && typeof asset === 'object')
            .map(asset => ({
                type:  asset.type  || ASSET_TYPES.OTHER,
                name:  this._str(asset.name),
                uri:   this._str(asset.uri),
                ext:   this._str(asset.ext  || this._extractExt(asset.uri)),
            }))
            .filter(asset => asset.uri); // 必须有 URI
    }

    /**
     * 构建 CCv3 版的 lorebook（扩展世界书格式）
     * @param {Object} worldBook
     * @returns {Object}
     * @private
     */
    _buildLorebook(worldBook) {
        const entries = (worldBook.entries || []).map((entry, idx) => {
            // 构建符合 CCv3 lorebook entry 规范的对象
            const built = {
                keys:                this._arr(entry.keys),
                secondary_keys:      this._arr(entry.secondary_keys),
                content:             this._str(entry.content),
                extensions:          entry.extensions || {},
                enabled:             entry.enabled !== false,
                insertion_order:     Number(entry.insertion_order) || 100,
                case_sensitive:      entry.case_sensitive || false,
                name:                this._str(entry.name || entry.keys?.[0] || `entry_${idx}`),
                priority:            Number(entry.priority) || 10,
                id:                  entry.uid ?? entry.id ?? idx,
                comment:             this._str(entry.comment),
                selective:           entry.selective || false,
                secondary_key_logic: entry.secondary_key_logic || 'AND',
                constant:            entry.constant || false,
                position:            this._normalizePosition(entry.position),
            };

            // CCv3 新增：depth 位置（at_depth 时有效）
            if (entry.position === 'at_depth') {
                built.depth = Number(entry.depth) || 4;
                built.role  = entry.role || 0; // 0=system, 1=user, 2=assistant
            }

            return built;
        });

        return {
            name:               this._str(worldBook.name),
            description:        this._str(worldBook.description),
            scan_depth:         Number(worldBook.scan_depth) || 2,
            token_budget:       Number(worldBook.token_budget) || 512,
            recursive_scanning: worldBook.recursive_scanning || false,
            extensions:         worldBook.extensions || {},
            entries,
        };
    }

    /**
     * 构建 CCv3 extensions 字段
     * @param {Object} source
     * @returns {Object}
     * @private
     */
    _buildExtensionsV3(source) {
        const ext = source.extensions || {};
        const cardforgeExt = ext.cardforge || {};

        return {
            cardforge: {
                version:    cardforgeExt.version    || '1.0.0',
                stats:      cardforgeExt.stats      || {},
                branches:   cardforgeExt.branches   || [],
                worldbook:  cardforgeExt.worldbook  || null,
                regex:      cardforgeExt.regex      || [],
                meta: {
                    created_at: cardforgeExt.meta?.created_at || Date.now(),
                    updated_at: Date.now(),
                    session_id: cardforgeExt.meta?.session_id || null,
                },
            },
        };
    }

    /**
     * 校验 Lorebook 结构
     * @param {Object} book
     * @returns {{ errors: string[], warnings: string[] }}
     * @private
     */
    _validateLorebook(book) {
        const errors   = [];
        const warnings = [];

        if (!Array.isArray(book.entries)) {
            errors.push('character_book.entries 必须是数组');
            return { errors, warnings };
        }

        book.entries.forEach((entry, i) => {
            if (!Array.isArray(entry.keys) || entry.keys.length === 0) {
                warnings.push(`lorebook 条目 #${i}「${entry.name || '?'}」没有关键词`);
            }
            if (!entry.content?.trim()) {
                warnings.push(`lorebook 条目 #${i}「${entry.name || '?'}」内容为空`);
            }
        });

        if (book.token_budget && (book.token_budget < 0 || book.token_budget > 4096)) {
            warnings.push('character_book.token_budget 建议在 0~4096 之间');
        }

        return { errors, warnings };
    }

    // ── 工具方法 ─────────────────────────────

    /**
     * 安全字符串化
     * @param {*} val
     * @returns {string}
     * @private
     */
    _str(val) {
        if (val === null || val === undefined) return '';
        return String(val).trim();
    }

    /**
     * 规范化数组
     * @param {*} val
     * @returns {any[]}
     * @private
     */
    _arr(val) {
        if (!Array.isArray(val)) return [];
        return val.filter(item => item !== null && item !== undefined);
    }

    /**
     * 规范化标签数组（去重去空小写）
     * @param {*} val
     * @returns {string[]}
     * @private
     */
    _tags(val) {
        if (!Array.isArray(val)) return [];
        const seen = new Set();
        return val
            .filter(t => t != null)
            .map(t => String(t).toLowerCase().trim())
            .filter(t => {
                if (!t || seen.has(t)) return false;
                seen.add(t);
                return true;
            });
    }

    /**
     * 规范化 lorebook 条目位置值
     * @param {string} pos
     * @returns {string}
     * @private
     */
    _normalizePosition(pos) {
        const valid = [
            'before_char', 'after_char',
            'before_example', 'after_example',
            'at_depth',
        ];
        return valid.includes(pos) ? pos : 'before_char';
    }

    /**
     * 从 URI 提取扩展名
     * @param {string} uri
     * @returns {string}
     * @private
     */
    _extractExt(uri) {
        if (!uri) return '';
        const match = uri.match(/\.([a-zA-Z0-9]+)(?:\?|#|$)/);
        return match ? match[1].toLowerCase() : '';
    }
}

// ─────────────────────────────────────────────
// § 便捷函数
// ─────────────────────────────────────────────

const _builder = new CCv3Builder();

/**
 * 快速构建 CCv3 JSON 对象
 * @param {Object} cardData
 * @returns {{ data: Object, warnings: string[], errors: string[] }}
 */
export function buildCCv3(cardData) {
    return _builder.build(cardData);
}

/**
 * 快速校验 CCv3 对象
 * @param {Object} v3Data
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
export function validateCCv3(v3Data) {
    return _builder.validate(v3Data);
}

/**
 * 解析 CCv3 为内部 CardData
 * @param {Object} v3Data
 * @returns {Object}
 */
export function parseCCv3(v3Data) {
    return _builder.parse(v3Data);
}

/**
 * 清理规范化 CCv3 对象
 * @param {Object} v3Data
 * @returns {Object}
 */
export function sanitizeCCv3(v3Data) {
    return _builder.sanitize(v3Data);
}