/**
 * @file exporter.js
 * @description 导出器主模块
 *              整合：CCv2Builder / CCv3Builder / PNGEmbedder
 *              提供：单卡导出 / 批量导出 / 封面处理 / 预检查 / 导入解析
 *              实现 IModule 接口
 * @module Exporter
 * @version 1.0.0
 */

import { EVENTS } from '../../contracts.js';
import { CCv2Builder, validateCCv2, parseCCv2, migrateCCv2ToCCv3 } from './ccv2-builder.js';
import { CCv3Builder, validateCCv3, parseCCv3, sanitizeCCv3 }       from './ccv3-builder.js';
import { PNGEmbedder, readCardFromPNG, embedCardInPNG }              from './png-embedder.js';

// ─────────────────────────────────────────────
// § 常量
// ─────────────────────────────────────────────

/** 封面图建议尺寸 */
const COVER_WIDTH  = 400;
const COVER_HEIGHT = 600;

/** 封面图最大文件大小（字节）：2 MB */
const COVER_MAX_BYTES = 2 * 1024 * 1024;

/** 导出格式枚举 */
export const EXPORT_FORMATS = {
    CCv2_JSON:  'ccv2_json',    // CCv2 JSON 文件
    CCv3_JSON:  'ccv3_json',    // CCv3 JSON 文件
    CCv2_PNG:   'ccv2_png',     // CCv2 嵌入 PNG
    CCv3_PNG:   'ccv3_png',     // CCv3 嵌入 PNG
    BOTH_PNG:   'both_png',     // CCv2+CCv3 双规范嵌入 PNG（推荐）
};

/** 默认导出格式 */
const DEFAULT_FORMAT = EXPORT_FORMATS.BOTH_PNG;

// ─────────────────────────────────────────────
// § Exporter 类
// ─────────────────────────────────────────────

/**
 * 导出器主模块
 * @implements {IModule}
 */
export class Exporter {

    /**
     * @param {import('../../core/event-bus.js').EventBus}               eventBus
     * @param {import('../../core/settings-manager.js').SettingsManager} settings
     */
    constructor(eventBus, settings) {
        this._eventBus = eventBus;
        this._settings = settings;

        /** @type {CCv2Builder} */
        this._v2Builder = new CCv2Builder();

        /** @type {CCv3Builder} */
        this._v3Builder = new CCv3Builder();

        /** @type {PNGEmbedder} */
        this._embedder  = new PNGEmbedder();

        /** 是否已初始化 @type {boolean} */
        this._ready = false;

        /** 事件取消函数 @type {Function[]} */
        this._unsubscribers = [];
    }

    // ── IModule 接口 ─────────────────────────

    /** @returns {Promise<void>} */
    async init() {
        this._ready = true;
        this._eventBus.emit(EVENTS.MODULE_READY, { module: 'Exporter' });
    }

    destroy() {
        this._unsubscribers.forEach(fn => fn());
        this._unsubscribers = [];
        this._ready = false;
    }

    getState() {
        return { isReady: this._ready };
    }

    isReady() {
        return this._ready;
    }

    // ── 预检查 ───────────────────────────────

    /**
     * 导出前预检查
     * @param {Object} cardData   内部 CardData 格式
     * @param {string} [format]   导出格式
     * @returns {{ ok: boolean, errors: string[], warnings: string[] }}
     */
    preflightCheck(cardData, format = DEFAULT_FORMAT) {
        const errors   = [];
        const warnings = [];

        if (!cardData) {
            errors.push('角色卡数据为空');
            return { ok: false, errors, warnings };
        }

        const data = cardData?.data || cardData;

        // 必填字段
        if (!data.name?.trim()) {
            errors.push('角色名称（name）不能为空');
        }

        // 推荐字段
        if (!data.description?.trim()) {
            warnings.push('角色描述（description）为空，建议填写');
        }
        if (!data.first_mes?.trim()) {
            warnings.push('开场白（first_mes）为空，建议填写');
        }
        if (!data.personality?.trim()) {
            warnings.push('性格特点（personality）为空，建议填写');
        }

        // 标签检查
        if (!data.tags || data.tags.length === 0) {
            warnings.push('未设置标签（tags），建议至少添加一个');
        }

        // PNG 格式需要封面图
        const needsImage = [
            EXPORT_FORMATS.CCv2_PNG,
            EXPORT_FORMATS.CCv3_PNG,
            EXPORT_FORMATS.BOTH_PNG,
        ].includes(format);

        if (needsImage) {
            warnings.push('PNG 导出需要选择封面图，未选择时将使用默认占位图');
        }

        // CCv3 额外校验
        if (format === EXPORT_FORMATS.CCv3_JSON || format === EXPORT_FORMATS.CCv3_PNG ||
            format === EXPORT_FORMATS.BOTH_PNG) {
            const v3Result = validateCCv3(this._v3Builder.build(cardData).data);
            errors.push(...v3Result.errors);
            warnings.push(...v3Result.warnings);
        }

        return {
            ok: errors.length === 0,
            errors,
            warnings,
        };
    }

    // ── 单卡导出 ─────────────────────────────

    /**
     * 导出为 JSON 文件（CCv2 或 CCv3）
     * @param {Object} cardData
     * @param {'v2'|'v3'} [spec='v3']
     * @returns {Promise<{ blob: Blob, filename: string, warnings: string[], errors: string[] }>}
     */
    async exportJSON(cardData, spec = 'v3') {
        try {
            this._eventBus.emit(EVENTS.EXPORT_STARTED, { format: `${spec}_json` });

            let buildResult;
            if (spec === 'v2') {
                buildResult = this._v2Builder.build(cardData);
            } else {
                buildResult = this._v3Builder.build(cardData);
            }

            if (!buildResult.data) {
                throw new Error(`构建失败：${buildResult.errors.join('；')}`);
            }

            const json     = JSON.stringify(buildResult.data, null, 2);
            const blob     = new Blob([json], { type: 'application/json;charset=utf-8' });
            const filename = this._generateFilename(cardData, `ccv${spec === 'v2' ? '2' : '3'}.json`);

            this._eventBus.emit(EVENTS.EXPORT_READY, { format: `${spec}_json`, filename });

            return {
                blob,
                filename,
                warnings: buildResult.warnings,
                errors:   buildResult.errors,
            };
        } catch (error) {
            this._eventBus.emit(EVENTS.EXPORT_FAILED, { error: error.message });
            this._eventBus.emit(EVENTS.ERROR, {
                module: 'Exporter', method: 'exportJSON', error, context: { spec },
            });
            throw error;
        }
    }

    /**
     * 导出为 PNG 文件（角色卡嵌入封面图）
     * @param {Object}          cardData
     * @param {File|ArrayBuffer|null} imageFile   封面图（null 则使用占位图）
     * @param {'v2'|'v3'|'both'} [spec='both']
     * @returns {Promise<{ blob: Blob, filename: string, warnings: string[], errors: string[] }>}
     */
    async exportPNG(cardData, imageFile = null, spec = 'both') {
        try {
            this._eventBus.emit(EVENTS.EXPORT_STARTED, { format: `${spec}_png` });

            const allWarnings = [];
            const allErrors   = [];

            // 获取图像 ArrayBuffer
            let imageBuffer;
            if (!imageFile) {
                imageBuffer = await this._getDefaultCoverPNG();
                allWarnings.push('未选择封面图，已使用默认占位图');
            } else {
                imageBuffer = await this._fileToArrayBuffer(imageFile);
            }

            // 验证图像是否为 PNG
            try {
                this._embedder._validatePNGSignature(imageBuffer);
            } catch {
                // 尝试将图片转换为 PNG
                imageBuffer = await this._convertToPNG(imageBuffer);
                allWarnings.push('封面图已自动转换为 PNG 格式');
            }

            // 裁剪/缩放封面
            imageBuffer = await this._resizeCover(imageBuffer);

            // 构建卡片数据
            const v3Build = this._v3Builder.build(cardData);
            allWarnings.push(...v3Build.warnings);
            allErrors.push(...v3Build.errors);

            if (!v3Build.data) {
                throw new Error(`卡片数据构建失败：${allErrors.join('；')}`);
            }

            // 嵌入元数据
            const embedSpec = spec === 'v2' ? 'v2' : spec === 'v3' ? 'v3' : 'both';
            const pngBytes  = await embedCardInPNG(imageBuffer, v3Build.data, embedSpec);

            const blob     = new Blob([pngBytes], { type: 'image/png' });
            const filename = this._generateFilename(cardData, 'png');

            this._eventBus.emit(EVENTS.EXPORT_READY, { format: `${spec}_png`, filename });

            return {
                blob,
                filename,
                warnings: allWarnings,
                errors:   allErrors,
            };
        } catch (error) {
            this._eventBus.emit(EVENTS.EXPORT_FAILED, { error: error.message });
            this._eventBus.emit(EVENTS.ERROR, {
                module: 'Exporter', method: 'exportPNG', error, context: { spec },
            });
            throw error;
        }
    }

    /**
     * 触发浏览器文件下载
     * @param {Blob}   blob
     * @param {string} filename
     */
    triggerDownload(blob, filename) {
        const url  = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href     = url;
        link.download = filename;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 10000);
    }

    // ── 批量导出 ─────────────────────────────

    /**
     * 批量导出多张角色卡（打包为 ZIP）
     * 注意：ZIP 打包需要 JSZip 库，若不可用则降级为逐个下载
     * @param {Object[]} cards    CardData 数组
     * @param {string}   format   EXPORT_FORMATS 中的值
     * @returns {Promise<{ blob: Blob|null, filename: string, count: number, errors: string[] }>}
     */
    async batchExport(cards, format = DEFAULT_FORMAT) {
        const errors = [];
        let   count  = 0;

        this._eventBus.emit(EVENTS.LOADING_START, {
            msg: `正在批量导出 ${cards.length} 张角色卡...`,
        });

        try {
            const files = [];

            for (const card of cards) {
                try {
                    let result;

                    if (format === EXPORT_FORMATS.CCv2_JSON) {
                        result = await this.exportJSON(card, 'v2');
                    } else if (format === EXPORT_FORMATS.CCv3_JSON) {
                        result = await this.exportJSON(card, 'v3');
                    } else {
                        result = await this.exportPNG(card, null, 'both');
                    }

                    files.push({ filename: result.filename, blob: result.blob });
                    count++;
                } catch (e) {
                    const name = card?.data?.name || card?.name || '未知角色';
                    errors.push(`「${name}」导出失败：${e.message}`);
                }
            }

            // 尝试使用 JSZip 打包
            const zipBlob = await this._tryZipFiles(files);

            if (zipBlob) {
                const zipFilename = `CardForge_Export_${this._dateStamp()}.zip`;
                return { blob: zipBlob, filename: zipFilename, count, errors };
            }

            // 降级：逐个下载
            for (const file of files) {
                this.triggerDownload(file.blob, file.filename);
                await this._sleep(300); // 避免浏览器阻止多次下载
            }

            return { blob: null, filename: '', count, errors };

        } finally {
            this._eventBus.emit(EVENTS.LOADING_END, {});
        }
    }

    // ── 导入 ─────────────────────────────────

    /**
     * 从 JSON 文件导入角色卡
     * @param {File} file
     * @returns {Promise<{ cardData: Object, spec: string, warnings: string[] }>}
     */
    async importFromJSON(file) {
        try {
            const text = await this._fileToText(file);
            const json = JSON.parse(text);

            let cardData;
            let spec;
            const warnings = [];

            if (json.spec === 'chara_card_v3') {
                // CCv3 格式
                const validation = validateCCv3(json);
                warnings.push(...validation.warnings);
                cardData = parseCCv3(json);
                spec     = 'v3';
            } else if (json.spec === 'chara_card_v2') {
                // CCv2 格式：自动升级
                const validation = validateCCv2(json);
                warnings.push(...validation.warnings);
                cardData = parseCCv2(json);
                spec     = 'v2';
                warnings.push('已从 CCv2 格式导入，建议重新导出为 CCv3 以使用完整功能');
            } else if (json.name) {
                // 旧版 TavernAI 格式（无 spec 字段）
                cardData = parseCCv2({ spec: 'chara_card_v2', spec_version: '2.0', data: json });
                spec     = 'legacy';
                warnings.push('检测到旧版 TavernAI 格式，已自动转换');
            } else {
                throw new Error('无法识别的角色卡 JSON 格式');
            }

            return { cardData, spec, warnings };

        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module: 'Exporter', method: 'importFromJSON', error, context: {},
            });
            throw error;
        }
    }

    /**
     * 从 PNG 文件导入角色卡
     * @param {File} file
     * @returns {Promise<{ cardData: Object, spec: string, warnings: string[], coverBlob: Blob }>}
     */
    async importFromPNG(file) {
        try {
            const buffer  = await this._fileToArrayBuffer(file);
            const { v2, v3, raw } = await readCardFromPNG(buffer);

            const warnings = [];
            let   cardData;
            let   spec;

            if (v3) {
                // 优先使用 CCv3 数据
                cardData = parseCCv3(v3);
                spec     = 'v3';
            } else if (v2) {
                cardData = parseCCv2(v2);
                spec     = 'v2';
                warnings.push('PNG 中只包含 CCv2 数据，已自动转换');
            } else {
                throw new Error('PNG 文件中未找到有效的角色卡数据');
            }

            // 提取封面图（移除 tEXt chunk 后的纯图像）
            const strippedBytes = await this._embedder.stripCardData(buffer);
            const coverBlob     = new Blob([strippedBytes], { type: 'image/png' });

            return { cardData, spec, warnings, coverBlob };

        } catch (error) {
            this._eventBus.emit(EVENTS.ERROR, {
                module: 'Exporter', method: 'importFromPNG', error, context: {},
            });
            throw error;
        }
    }

    // ── 封面处理 ─────────────────────────────

    /**
     * 缩放并裁剪封面图到建议尺寸
     * @param {ArrayBuffer} imageBuffer   原始图像 ArrayBuffer（PNG 格式）
     * @returns {Promise<ArrayBuffer>}    处理后的 PNG ArrayBuffer
     */
    async resizeCover(imageBuffer) {
        return this._resizeCover(imageBuffer);
    }

    /**
     * 检查图片文件是否符合封面规范
     * @param {File} file
     * @returns {Promise<{ ok: boolean, warnings: string[], width: number, height: number, size: number }>}
     */
    async checkCoverImage(file) {
        const warnings = [];
        const buffer   = await this._fileToArrayBuffer(file);
        const size     = buffer.byteLength;

        if (size > COVER_MAX_BYTES) {
            warnings.push(`封面图过大（${(size / 1024 / 1024).toFixed(1)} MB），建议压缩到 2 MB 以内`);
        }

        const { width, height } = await this._getImageDimensions(buffer);

        if (width !== COVER_WIDTH || height !== COVER_HEIGHT) {
            warnings.push(
                `封面图尺寸 ${width}×${height}，建议使用 ${COVER_WIDTH}×${COVER_HEIGHT}（竖向 2:3 比例）`
            );
        }

        return {
            ok: warnings.length === 0,
            warnings,
            width,
            height,
            size,
        };
    }

    // ── 私有辅助方法 ─────────────────────────

    /**
     * 生成导出文件名
     * @param {Object} cardData
     * @param {string} ext
     * @returns {string}
     * @private
     */
    _generateFilename(cardData, ext) {
        const name = (cardData?.data?.name || cardData?.name || 'character')
            .replace(/[\\/:*?"<>|]/g, '_')  // 移除非法文件名字符
            .replace(/\s+/g, '_')
            .slice(0, 50);

        return `${name}_${this._dateStamp()}.${ext}`;
    }

    /**
     * 生成日期时间戳字符串
     * @returns {string}  如 20240115_143022
     * @private
     */
    _dateStamp() {
        const now = new Date();
        const pad = (n) => String(n).padStart(2, '0');
        return [
            now.getFullYear(),
            pad(now.getMonth() + 1),
            pad(now.getDate()),
            '_',
            pad(now.getHours()),
            pad(now.getMinutes()),
            pad(now.getSeconds()),
        ].join('');
    }

    /**
     * File 对象转 ArrayBuffer
     * @param {File|ArrayBuffer} file
     * @returns {Promise<ArrayBuffer>}
     * @private
     */
    async _fileToArrayBuffer(file) {
        if (file instanceof ArrayBuffer) return file;
        if (file instanceof Uint8Array)  return file.buffer;
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload  = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('文件读取失败'));
            reader.readAsArrayBuffer(file);
        });
    }

    /**
     * File 对象读取为文本
     * @param {File} file
     * @returns {Promise<string>}
     * @private
     */
    async _fileToText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload  = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('文件读取失败'));
            reader.readAsText(file, 'utf-8');
        });
    }

    /**
     * 使用 Canvas 将任意图片格式转换为 PNG ArrayBuffer
     * @param {ArrayBuffer} buffer
     * @returns {Promise<ArrayBuffer>}
     * @private
     */
    async _convertToPNG(buffer) {
        return new Promise((resolve, reject) => {
            const blob  = new Blob([buffer]);
            const url   = URL.createObjectURL(blob);
            const img   = new Image();

            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width  = img.naturalWidth;
                canvas.height = img.naturalHeight;
                canvas.getContext('2d').drawImage(img, 0, 0);
                URL.revokeObjectURL(url);

                canvas.toBlob((pngBlob) => {
                    pngBlob.arrayBuffer().then(resolve).catch(reject);
                }, 'image/png');
            };

            img.onerror = () => {
                URL.revokeObjectURL(url);
                reject(new Error('图片加载失败，无法转换为 PNG'));
            };

            img.src = url;
        });
    }

    /**
     * 缩放封面图到建议尺寸（Canvas 实现）
     * @param {ArrayBuffer} buffer
     * @returns {Promise<ArrayBuffer>}
     * @private
     */
    async _resizeCover(buffer) {
        return new Promise((resolve, reject) => {
            const blob = new Blob([buffer], { type: 'image/png' });
            const url  = URL.createObjectURL(blob);
            const img  = new Image();

            img.onload = () => {
                URL.revokeObjectURL(url);

                const srcW = img.naturalWidth;
                const srcH = img.naturalHeight;

                // 已是目标尺寸，跳过处理
                if (srcW === COVER_WIDTH && srcH === COVER_HEIGHT) {
                    resolve(buffer);
                    return;
                }

                // 计算居中裁剪区域（保持宽高比，裁剪到 2:3）
                const targetRatio = COVER_WIDTH / COVER_HEIGHT;
                const srcRatio    = srcW / srcH;

                let cropX = 0, cropY = 0, cropW = srcW, cropH = srcH;

                if (srcRatio > targetRatio) {
                    // 图片过宽：裁剪左右
                    cropW = Math.round(srcH * targetRatio);
                    cropX = Math.round((srcW - cropW) / 2);
                } else if (srcRatio < targetRatio) {
                    // 图片过高：裁剪上下
                    cropH = Math.round(srcW / targetRatio);
                    cropY = Math.round((srcH - cropH) / 2);
                }

                const canvas = document.createElement('canvas');
                canvas.width  = COVER_WIDTH;
                canvas.height = COVER_HEIGHT;

                canvas.getContext('2d').drawImage(
                    img,
                    cropX, cropY, cropW, cropH,   // 源区域
                    0, 0, COVER_WIDTH, COVER_HEIGHT // 目标区域
                );

                canvas.toBlob((pngBlob) => {
                    pngBlob.arrayBuffer().then(resolve).catch(reject);
                }, 'image/png');
            };

            img.onerror = () => {
                URL.revokeObjectURL(url);
                resolve(buffer); // 处理失败则返回原始数据
            };

            img.src = url;
        });
    }

    /**
     * 获取默认封面 PNG（纯色占位图）
     * @returns {Promise<ArrayBuffer>}
     * @private
     */
    async _getDefaultCoverPNG() {
        return new Promise((resolve) => {
            const canvas = document.createElement('canvas');
            canvas.width  = COVER_WIDTH;
            canvas.height = COVER_HEIGHT;

            const ctx = canvas.getContext('2d');

            // 渐变背景
            const gradient = ctx.createLinearGradient(0, 0, COVER_WIDTH, COVER_HEIGHT);
            gradient.addColorStop(0,   '#1a1a2e');
            gradient.addColorStop(0.5, '#16213e');
            gradient.addColorStop(1,   '#0f3460');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, COVER_WIDTH, COVER_HEIGHT);

            // 中央图标
            ctx.fillStyle = 'rgba(123,104,238,0.6)';
            ctx.font      = '80px serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🃏', COVER_WIDTH / 2, COVER_HEIGHT / 2 - 30);

            // 底部文字
            ctx.fillStyle = 'rgba(255,255,255,0.4)';
            ctx.font      = '18px sans-serif';
            ctx.fillText('ST-CardForge Pro', COVER_WIDTH / 2, COVER_HEIGHT / 2 + 60);

            canvas.toBlob((blob) => {
                blob.arrayBuffer().then(resolve);
            }, 'image/png');
        });
    }

    /**
     * 获取图片尺寸
     * @param {ArrayBuffer} buffer
     * @returns {Promise<{ width: number, height: number }>}
     * @private
     */
    async _getImageDimensions(buffer) {
        return new Promise((resolve) => {
            const blob = new Blob([buffer]);
            const url  = URL.createObjectURL(blob);
            const img  = new Image();
            img.onload = () => {
                URL.revokeObjectURL(url);
                resolve({ width: img.naturalWidth, height: img.naturalHeight });
            };
            img.onerror = () => {
                URL.revokeObjectURL(url);
                resolve({ width: 0, height: 0 });
            };
            img.src = url;
        });
    }

    /**
     * 尝试使用 JSZip 打包文件
     * @param {Array<{ filename: string, blob: Blob }>} files
     * @returns {Promise<Blob|null>}
     * @private
     */
    async _tryZipFiles(files) {
        try {
            // 动态检测 JSZip
            const JSZip = window.JSZip;
            if (!JSZip) return null;

            const zip = new JSZip();
            for (const file of files) {
                const buffer = await file.blob.arrayBuffer();
                zip.file(file.filename, buffer);
            }

            return await zip.generateAsync({
                type:               'blob',
                compression:        'DEFLATE',
                compressionOptions: { level: 6 },
            });
        } catch {
            return null;
        }
    }

    /**
     * 延迟工具
     * @param {number} ms
     * @returns {Promise<void>}
     * @private
     */
    _sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}