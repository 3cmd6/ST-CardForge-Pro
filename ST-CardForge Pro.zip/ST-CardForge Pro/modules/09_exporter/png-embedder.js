/**
 * @file png-embedder.js
 * @description PNG 元数据嵌入器
 *              实现在 PNG 文件的 tEXt chunk 中读写角色卡数据
 *              完全兼容 SillyTavern / TavernAI 的 PNG 嵌入规范
 *              使用纯 JS 解析 PNG 结构，无需 pngjs 依赖（可选增强）
 * @module PNGEmbedder
 * @version 1.0.0
 */

// ─────────────────────────────────────────────
// § PNG 格式常量
// ─────────────────────────────────────────────

/** PNG 文件魔数（8 字节） */
const PNG_SIGNATURE = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]);

/** tEXt chunk 关键字（角色卡规范） */
const CHARA_KEYWORD_V2 = 'chara';        // CCv2 / TavernAI 兼容关键字
const CHARA_KEYWORD_V3 = 'ccv3';         // CCv3 专用关键字

/** CRC 查表（IEEE 802.3） */
const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
        let c = i;
        for (let j = 0; j < 8; j++) {
            c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        table[i] = c;
    }
    return table;
})();

// ─────────────────────────────────────────────
// § PNGEmbedder 类
// ─────────────────────────────────────────────

/**
 * PNG 元数据嵌入器
 * 负责在 PNG 的 tEXt chunk 中读取/写入角色卡 Base64 数据
 */
export class PNGEmbedder {

    // ── 读取方法 ─────────────────────────────

    /**
     * 从 PNG ArrayBuffer 读取所有角色卡数据
     * @param {ArrayBuffer} buffer  PNG 文件的 ArrayBuffer
     * @returns {{ v2: Object|null, v3: Object|null, raw: Object }}
     *   v2: CCv2 格式的解析对象（或 null）
     *   v3: CCv3 格式的解析对象（或 null）
     *   raw: 所有 tEXt chunk 的原始 key-value 对
     */
    async readCardFromPNG(buffer) {
        this._validatePNGSignature(buffer);

        const chunks    = this._parseChunks(buffer);
        const textChunks = chunks.filter(c => c.type === 'tEXt');

        const raw = {};
        for (const chunk of textChunks) {
            const { keyword, text } = this._parseTextChunk(chunk.data);
            raw[keyword] = text;
        }

        let v2 = null;
        let v3 = null;

        // 读取 CCv2/TavernAI 格式（关键字 = 'chara'）
        if (raw[CHARA_KEYWORD_V2]) {
            try {
                const decoded = this._decodeBase64UTF8(raw[CHARA_KEYWORD_V2]);
                v2 = JSON.parse(decoded);
            } catch {
                // 解析失败：可能是旧版格式或数据损坏
                v2 = null;
            }
        }

        // 读取 CCv3 格式（关键字 = 'ccv3'）
        if (raw[CHARA_KEYWORD_V3]) {
            try {
                const decoded = this._decodeBase64UTF8(raw[CHARA_KEYWORD_V3]);
                v3 = JSON.parse(decoded);
            } catch {
                v3 = null;
            }
        }

        return { v2, v3, raw };
    }

    /**
     * 从 PNG ArrayBuffer 读取指定关键字的 tEXt chunk
     * @param {ArrayBuffer} buffer
     * @param {string}      keyword
     * @returns {string|null}  Base64 字符串，或 null
     */
    async readTextChunk(buffer, keyword) {
        this._validatePNGSignature(buffer);
        const chunks     = this._parseChunks(buffer);
        const textChunks = chunks.filter(c => c.type === 'tEXt');

        for (const chunk of textChunks) {
            const parsed = this._parseTextChunk(chunk.data);
            if (parsed.keyword === keyword) {
                return parsed.text;
            }
        }
        return null;
    }

    // ── 写入方法 ─────────────────────────────

    /**
     * 将角色卡数据嵌入 PNG
     * @param {ArrayBuffer} imageBuffer  原始 PNG 文件的 ArrayBuffer
     * @param {Object}      cardData     角色卡数据（内部 CardData 格式）
     * @param {'v2'|'v3'|'both'} spec   嵌入规范版本
     * @returns {Uint8Array}  嵌入后的 PNG 文件二进制数据
     */
    async embedCardInPNG(imageBuffer, cardData, spec = 'both') {
        this._validatePNGSignature(imageBuffer);

        // 移除旧的角色卡 chunk（chara / ccv3）
        let chunks = this._parseChunks(imageBuffer);
        chunks     = chunks.filter(c => {
            if (c.type !== 'tEXt') return true;
            const { keyword } = this._parseTextChunk(c.data);
            return keyword !== CHARA_KEYWORD_V2 && keyword !== CHARA_KEYWORD_V3;
        });

        // 构建新的 tEXt chunk
        const newChunks = [];

        if (spec === 'v2' || spec === 'both') {
            // CCv2 格式嵌入（向后兼容 SillyTavern / TavernAI）
            const v2Json  = this._toV2JSON(cardData);
            const v2B64   = this._encodeBase64UTF8(JSON.stringify(v2Json));
            newChunks.push(this._buildTextChunk(CHARA_KEYWORD_V2, v2B64));
        }

        if (spec === 'v3' || spec === 'both') {
            // CCv3 格式嵌入
            const v3Json  = this._toV3JSON(cardData);
            const v3B64   = this._encodeBase64UTF8(JSON.stringify(v3Json));
            newChunks.push(this._buildTextChunk(CHARA_KEYWORD_V3, v3B64));
        }

        // 将新 chunk 插入到 IHDR chunk 之后（PNG 规范要求）
        const ihdrIdx = chunks.findIndex(c => c.type === 'IHDR');
        const insertAt = ihdrIdx >= 0 ? ihdrIdx + 1 : 0;

        const finalChunks = [
            ...chunks.slice(0, insertAt),
            ...newChunks,
            ...chunks.slice(insertAt),
        ];

        return this._assembleChunks(finalChunks);
    }

    /**
     * 写入任意关键字的 tEXt chunk
     * @param {ArrayBuffer} buffer
     * @param {string}      keyword   tEXt chunk 关键字
     * @param {string}      value     值（字符串）
     * @returns {Uint8Array}
     */
    async writeTextChunk(buffer, keyword, value) {
        this._validatePNGSignature(buffer);

        // 移除同关键字的旧 chunk
        let chunks = this._parseChunks(buffer);
        chunks     = chunks.filter(c => {
            if (c.type !== 'tEXt') return true;
            const { keyword: k } = this._parseTextChunk(c.data);
            return k !== keyword;
        });

        // 插入新 chunk
        const newChunk = this._buildTextChunk(keyword, value);
        const ihdrIdx  = chunks.findIndex(c => c.type === 'IHDR');
        const insertAt = ihdrIdx >= 0 ? ihdrIdx + 1 : 0;

        chunks.splice(insertAt, 0, newChunk);
        return this._assembleChunks(chunks);
    }

    /**
     * 移除 PNG 中所有角色卡相关 tEXt chunk
     * @param {ArrayBuffer} buffer
     * @returns {Uint8Array}
     */
    async stripCardData(buffer) {
        this._validatePNGSignature(buffer);
        const chunks = this._parseChunks(buffer).filter(c => {
            if (c.type !== 'tEXt') return true;
            const { keyword } = this._parseTextChunk(c.data);
            return keyword !== CHARA_KEYWORD_V2 && keyword !== CHARA_KEYWORD_V3;
        });
        return this._assembleChunks(chunks);
    }

    // ── PNG 解析核心 ─────────────────────────

    /**
     * 验证 PNG 文件签名
     * @param {ArrayBuffer} buffer
     * @throws {Error} 不是有效 PNG 时抛出
     * @private
     */
    _validatePNGSignature(buffer) {
        const view = new Uint8Array(buffer, 0, 8);
        for (let i = 0; i < 8; i++) {
            if (view[i] !== PNG_SIGNATURE[i]) {
                throw new Error('不是有效的 PNG 文件（签名不匹配）');
            }
        }
    }

    /**
     * 解析 PNG 文件的所有 chunk
     * @param {ArrayBuffer} buffer
     * @returns {Array<{ type: string, data: Uint8Array, length: number, crc: number }>}
     * @private
     */
    _parseChunks(buffer) {
        const view   = new DataView(buffer);
        const bytes  = new Uint8Array(buffer);
        const chunks = [];

        let offset = 8; // 跳过 PNG 签名

        while (offset < buffer.byteLength) {
            if (offset + 12 > buffer.byteLength) break; // 防止越界

            const length    = view.getUint32(offset, false);         // 大端序
            const typeBytes = bytes.slice(offset + 4, offset + 8);
            const type      = String.fromCharCode(...typeBytes);
            const data      = bytes.slice(offset + 8, offset + 8 + length);
            const crc       = view.getUint32(offset + 8 + length, false);

            chunks.push({ type, data, length, crc, offset });

            offset += 4 + 4 + length + 4; // length + type + data + crc

            if (type === 'IEND') break;
        }

        return chunks;
    }

    /**
     * 解析 tEXt chunk 的 data 部分
     * tEXt chunk 格式：keyword\0text（null 分隔）
     * @param {Uint8Array} data
     * @returns {{ keyword: string, text: string }}
     * @private
     */
    _parseTextChunk(data) {
        // 找到 null 分隔符的位置
        let nullPos = -1;
        for (let i = 0; i < data.length; i++) {
            if (data[i] === 0) {
                nullPos = i;
                break;
            }
        }

        if (nullPos === -1) {
            // 无 null 分隔符，整个 data 作为 keyword
            return {
                keyword: new TextDecoder('latin1').decode(data),
                text:    '',
            };
        }

        const keyword = new TextDecoder('latin1').decode(data.slice(0, nullPos));
        const text    = new TextDecoder('latin1').decode(data.slice(nullPos + 1));

        return { keyword, text };
    }

    /**
     * 构建 tEXt chunk
     * @param {string} keyword
     * @param {string} text
     * @returns {{ type: string, data: Uint8Array }}
     * @private
     */
    _buildTextChunk(keyword, text) {
        const encoder = new TextEncoder();

        // 关键字用 latin1 编码（PNG 规范），text 同样用 latin1
        const keyBytes  = this._stringToLatin1(keyword);
        const textBytes = this._stringToLatin1(text);

        // data = keyword + 0x00 + text
        const data = new Uint8Array(keyBytes.length + 1 + textBytes.length);
        data.set(keyBytes, 0);
        data[keyBytes.length] = 0;
        data.set(textBytes, keyBytes.length + 1);

        return { type: 'tEXt', data };
    }

    /**
     * 将所有 chunk 重新组装为完整 PNG 二进制
     * @param {Array} chunks
     * @returns {Uint8Array}
     * @private
     */
    _assembleChunks(chunks) {
        // 计算总长度
        const sigLen    = PNG_SIGNATURE.length;
        const chunksSz  = chunks.reduce((sum, c) => sum + 4 + 4 + c.data.length + 4, 0);
        const totalLen  = sigLen + chunksSz;

        const output = new Uint8Array(totalLen);
        const view   = new DataView(output.buffer);
        let   offset = 0;

        // 写入 PNG 签名
        output.set(PNG_SIGNATURE, 0);
        offset = sigLen;

        // 写入每个 chunk
        for (const chunk of chunks) {
            const dataLen = chunk.data.length;

            // length（4 字节，大端）
            view.setUint32(offset, dataLen, false);
            offset += 4;

            // type（4 字节 ASCII）
            for (let i = 0; i < 4; i++) {
                output[offset + i] = chunk.type.charCodeAt(i);
            }
            offset += 4;

            // data
            output.set(chunk.data, offset);
            offset += dataLen;

            // CRC（4 字节，大端）：对 type + data 计算
            const crcInput = new Uint8Array(4 + dataLen);
            for (let i = 0; i < 4; i++) {
                crcInput[i] = chunk.type.charCodeAt(i);
            }
            crcInput.set(chunk.data, 4);
            const crc = this._crc32(crcInput);
            view.setUint32(offset, crc, false);
            offset += 4;
        }

        return output;
    }

    // ── CRC 计算 ─────────────────────────────

    /**
     * 计算 CRC32（IEEE 802.3 标准）
     * @param {Uint8Array} data
     * @returns {number}
     * @private
     */
    _crc32(data) {
        let crc = 0xFFFFFFFF;
        for (let i = 0; i < data.length; i++) {
            crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ data[i]) & 0xFF];
        }
        return (crc ^ 0xFFFFFFFF) >>> 0;
    }

    // ── Base64 编解码 ─────────────────────────

    /**
     * 将字符串编码为 Base64（兼容 UTF-8 和中文）
     * PNG tEXt chunk 使用 latin1，Base64 结果只含 ASCII，完全兼容
     * @param {string} str
     * @returns {string}  Base64 字符串
     */
    _encodeBase64UTF8(str) {
        // 方案：先 UTF-8 编码，再 Base64
        try {
            // 现代浏览器环境
            const utf8Bytes = new TextEncoder().encode(str);
            let binary = '';
            for (const byte of utf8Bytes) {
                binary += String.fromCharCode(byte);
            }
            return btoa(binary);
        } catch {
            // 降级：使用 encodeURIComponent
            return btoa(unescape(encodeURIComponent(str)));
        }
    }

    /**
     * 将 Base64 字符串解码为 UTF-8 字符串
     * @param {string} b64
     * @returns {string}
     */
    _decodeBase64UTF8(b64) {
        try {
            const binary   = atob(b64);
            const bytes    = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
                bytes[i] = binary.charCodeAt(i);
            }
            return new TextDecoder('utf-8').decode(bytes);
        } catch {
            // 降级
            return decodeURIComponent(escape(atob(b64)));
        }
    }

    // ── 格式转换辅助 ─────────────────────────

    /**
     * 将 CardData 转换为 CCv2 JSON 对象（用于嵌入）
     * @param {Object} cardData
     * @returns {Object}
     * @private
     */
    _toV2JSON(cardData) {
        const data = cardData?.data || cardData;
        return {
            spec:         'chara_card_v2',
            spec_version: '2.0',
            data: {
                name:                       data.name                      || '',
                description:                data.description               || '',
                personality:                data.personality               || '',
                scenario:                   data.scenario                  || '',
                first_mes:                  data.first_mes                 || '',
                mes_example:                data.mes_example               || '',
                creator_notes:              data.creator_notes             || '',
                system_prompt:              data.system_prompt             || '',
                post_history_instructions:  data.post_history_instructions || '',
                alternate_greetings:        data.alternate_greetings       || [],
                tags:                       data.tags                      || [],
                creator:                    data.creator                   || '',
                character_version:          data.character_version         || '',
                extensions:                 data.extensions                || {},
                ...(data.character_book ? { character_book: data.character_book } : {}),
            },
        };
    }

    /**
     * 将 CardData 转换为 CCv3 JSON 对象（用于嵌入）
     * @param {Object} cardData
     * @returns {Object}
     * @private
     */
    _toV3JSON(cardData) {
        const data = cardData?.data || cardData;
        const spec = cardData?.spec || 'chara_card_v3';

        if (spec === 'chara_card_v3') {
            return cardData; // 已是 V3 格式，直接返回
        }

        return {
            spec:         'chara_card_v3',
            spec_version: '3.0',
            data: {
                name:                       data.name                      || '',
                description:                data.description               || '',
                personality:                data.personality               || '',
                scenario:                   data.scenario                  || '',
                first_mes:                  data.first_mes                 || '',
                mes_example:                data.mes_example               || '',
                creator_notes:              data.creator_notes             || '',
                system_prompt:              data.system_prompt             || '',
                post_history_instructions:  data.post_history_instructions || '',
                alternate_greetings:        data.alternate_greetings       || [],
                tags:                       data.tags                      || [],
                creator:                    data.creator                   || '',
                character_version:          data.character_version         || '',
                nickname:                   data.nickname                  || '',
                creator_notes_multilingual: data.creator_notes_multilingual || {},
                source:                     data.source                    || [],
                group_only_greetings:       data.group_only_greetings      || [],
                assets:                     data.assets                    || [],
                extensions:                 data.extensions                || {},
                ...(data.character_book ? { character_book: data.character_book } : {}),
            },
        };
    }

    /**
     * 将字符串转换为 latin1 字节数组
     * （PNG tEXt chunk 使用 latin1 编码，Base64 内容符合此约束）
     * @param {string} str
     * @returns {Uint8Array}
     * @private
     */
    _stringToLatin1(str) {
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) {
            bytes[i] = str.charCodeAt(i) & 0xFF;
        }
        return bytes;
    }
}

// ─────────────────────────────────────────────
// § 便捷函数（对外导出）
// ─────────────────────────────────────────────

/** 全局共享实例 */
const _embedder = new PNGEmbedder();

/**
 * 从 PNG 文件读取角色卡数据
 * @param {ArrayBuffer} buffer
 * @returns {Promise<{ v2: Object|null, v3: Object|null, raw: Object }>}
 */
export async function readCardFromPNG(buffer) {
    return _embedder.readCardFromPNG(buffer);
}

/**
 * 将角色卡数据嵌入 PNG
 * @param {ArrayBuffer} imageBuffer
 * @param {Object}      cardData
 * @param {'v2'|'v3'|'both'} [spec='both']
 * @returns {Promise<Uint8Array>}
 */
export async function embedCardInPNG(imageBuffer, cardData, spec = 'both') {
    return _embedder.embedCardInPNG(imageBuffer, cardData, spec);
}

/**
 * 读取任意 tEXt chunk
 * @param {ArrayBuffer} buffer
 * @param {string}      keyword
 * @returns {Promise<string|null>}
 */
export async function readTextChunk(buffer, keyword) {
    return _embedder.readTextChunk(buffer, keyword);
}

/**
 * 写入任意 tEXt chunk
 * @param {ArrayBuffer} buffer
 * @param {string}      keyword
 * @param {string}      value
 * @returns {Promise<Uint8Array>}
 */
export async function writeTextChunk(buffer, keyword, value) {
    return _embedder.writeTextChunk(buffer, keyword, value);
}

/**
 * Base64 编码（兼容 UTF-8 + 中文）
 * @param {string} str
 * @returns {string}
 */
export function encodeBase64UTF8(str) {
    return _embedder._encodeBase64UTF8(str);
}

/**
 * Base64 解码
 * @param {string} b64
 * @returns {string}
 */
export function decodeBase64UTF8(b64) {
    return _embedder._decodeBase64UTF8(b64);
}

/**
 * 移除 PNG 中的角色卡数据（用于隐私处理）
 * @param {ArrayBuffer} buffer
 * @returns {Promise<Uint8Array>}
 */
export async function stripCardData(buffer) {
    return _embedder.stripCardData(buffer);
}