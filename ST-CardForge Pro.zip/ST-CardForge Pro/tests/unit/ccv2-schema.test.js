/**
 * @file tests/unit/ccv2-schema.test.js
 * @description ccv2-schema.js 完整单元测试
 * @framework Vitest
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
    validateCCv2,
    buildCCv2,
    sanitizeCCv2,
    migrateCCv2ToCCv3,
    createEmptyCCv2,
    CCv2_REQUIRED_FIELDS,
    CCv2_RECOMMENDED_FIELDS,
    CCv2_ALL_FIELDS,
} from '../../utils/ccv2-schema.js';

// ─── 测试夹具 ───────────────────────────────────

/** 合法的最小 CCv2 数据（仅含必填字段）*/
function makeMinimalV2() {
    return {
        spec:         'chara_card_v2',
        spec_version: '2.0',
        data: {
            name: '测试角色',
        },
    };
}

/** 合法的完整 CCv2 数据 */
function makeFullV2() {
    return {
        spec:         'chara_card_v2',
        spec_version: '2.0',
        data: {
            name:                       '完整测试角色',
            description:                '这是角色描述',
            personality:                '活泼开朗',
            scenario:                   '在咖啡馆初次相遇',
            first_mes:                  '你好，我是测试角色。',
            mes_example:                '<START>\n{{user}}: 你好\n{{char}}: 你好！',
            creator_notes:              '这是创作者备注',
            system_prompt:              '请扮演测试角色',
            post_history_instructions:  '对话后补充说明',
            alternate_greetings:        ['备用开场白一', '备用开场白二'],
            tags:                       ['测试', '示例', 'CCv2'],
            creator:                    'TestCreator',
            character_version:          '1.0.0',
            extensions:                 { custom_field: 'value' },
        },
    };
}

// ═══════════════════════════════════════════════
// § 1  createEmptyCCv2
// ═══════════════════════════════════════════════

describe('createEmptyCCv2', () => {

    it('返回对象顶层包含 spec 和 spec_version', () => {
        const result = createEmptyCCv2();
        expect(result.spec).toBe('chara_card_v2');
        expect(result.spec_version).toBe('2.0');
    });

    it('返回对象包含 data 子对象', () => {
        const result = createEmptyCCv2();
        expect(result.data).toBeDefined();
        expect(typeof result.data).toBe('object');
    });

    it('data 中所有文本字段默认为空字符串', () => {
        const result = createEmptyCCv2();
        const textFields = [
            'name', 'description', 'personality', 'scenario',
            'first_mes', 'mes_example', 'creator_notes',
            'system_prompt', 'post_history_instructions',
            'creator', 'character_version',
        ];
        for (const f of textFields) {
            expect(result.data[f]).toBe('');
        }
    });

    it('data.alternate_greetings 默认为空数组', () => {
        const result = createEmptyCCv2();
        expect(Array.isArray(result.data.alternate_greetings)).toBe(true);
        expect(result.data.alternate_greetings).toHaveLength(0);
    });

    it('data.tags 默认为空数组', () => {
        const result = createEmptyCCv2();
        expect(Array.isArray(result.data.tags)).toBe(true);
        expect(result.data.tags).toHaveLength(0);
    });

    it('data.extensions 默认为空对象', () => {
        const result = createEmptyCCv2();
        expect(result.data.extensions).toEqual({});
    });

    it('每次调用返回独立的新对象（无引用共享）', () => {
        const a = createEmptyCCv2();
        const b = createEmptyCCv2();
        a.data.name = '修改A';
        expect(b.data.name).toBe('');
    });
});

// ═══════════════════════════════════════════════
// § 2  validateCCv2
// ═══════════════════════════════════════════════

describe('validateCCv2 — 合法输入', () => {

    it('最小合法数据校验通过', () => {
        const { valid, errors } = validateCCv2(makeMinimalV2());
        expect(valid).toBe(true);
        expect(errors).toHaveLength(0);
    });

    it('完整合法数据校验通过', () => {
        const { valid, errors } = validateCCv2(makeFullV2());
        expect(valid).toBe(true);
        expect(errors).toHaveLength(0);
    });

    it('完整数据没有必填字段错误', () => {
        const { errors } = validateCCv2(makeFullV2());
        const requiredErrors = errors.filter(e => e.includes('必填'));
        expect(requiredErrors).toHaveLength(0);
    });

    it('合法数据返回的 warnings 是数组', () => {
        const { warnings } = validateCCv2(makeMinimalV2());
        expect(Array.isArray(warnings)).toBe(true);
    });

    it('最小数据（只有 name）会产生推荐字段警告', () => {
        const { warnings } = validateCCv2(makeMinimalV2());
        // description, personality 等推荐字段缺失应有警告
        expect(warnings.length).toBeGreaterThan(0);
    });

    it('完整数据无推荐字段警告', () => {
        const { warnings } = validateCCv2(makeFullV2());
        const recommendedWarnings = warnings.filter(w => w.includes('推荐'));
        expect(recommendedWarnings).toHaveLength(0);
    });
});

describe('validateCCv2 — 非法输入', () => {

    it('null 输入返回 valid=false', () => {
        const { valid } = validateCCv2(null);
        expect(valid).toBe(false);
    });

    it('undefined 输入返回 valid=false', () => {
        const { valid } = validateCCv2(undefined);
        expect(valid).toBe(false);
    });

    it('空对象返回 valid=false', () => {
        const { valid } = validateCCv2({});
        expect(valid).toBe(false);
    });

    it('spec 字段错误产生 error', () => {
        const data = makeMinimalV2();
        data.spec = 'wrong_spec';
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('spec'))).toBe(true);
    });

    it('缺少 data 对象产生 error', () => {
        const { valid, errors } = validateCCv2({
            spec:         'chara_card_v2',
            spec_version: '2.0',
        });
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('data'))).toBe(true);
    });

    it('name 为空字符串产生 error', () => {
        const data = makeMinimalV2();
        data.data.name = '';
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('name'))).toBe(true);
    });

    it('name 仅含空格产生 error', () => {
        const data = makeMinimalV2();
        data.data.name = '   ';
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
    });

    it('alternate_greetings 不是数组产生 error', () => {
        const data = makeFullV2();
        data.data.alternate_greetings = '不是数组';
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('alternate_greetings'))).toBe(true);
    });

    it('tags 不是数组产生 error', () => {
        const data = makeFullV2();
        data.data.tags = 123;
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('tags'))).toBe(true);
    });

    it('extensions 不是对象产生 error', () => {
        const data = makeFullV2();
        data.data.extensions = '不是对象';
        const { valid, errors } = validateCCv2(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('extensions'))).toBe(true);
    });

    it('name 超过 100 字符产生 warning', () => {
        const data = makeFullV2();
        data.data.name = 'A'.repeat(101);
        const { valid, warnings } = validateCCv2(data);
        expect(valid).toBe(true); // 不是 error，只是 warning
        expect(warnings.some(w => w.includes('name'))).toBe(true);
    });
});

describe('validateCCv2 — 返回结构完整性', () => {

    it('始终返回 { valid, errors, warnings } 结构', () => {
        const cases = [null, {}, makeMinimalV2(), makeFullV2()];
        for (const c of cases) {
            const result = validateCCv2(c);
            expect(result).toHaveProperty('valid');
            expect(result).toHaveProperty('errors');
            expect(result).toHaveProperty('warnings');
            expect(typeof result.valid).toBe('boolean');
            expect(Array.isArray(result.errors)).toBe(true);
            expect(Array.isArray(result.warnings)).toBe(true);
        }
    });
});

// ═══════════════════════════════════════════════
// § 3  buildCCv2
// ═══════════════════════════════════════════════

describe('buildCCv2', () => {

    it('从完整 CardData 构建出合法的 CCv2 对象', () => {
        const cardData = makeFullV2();
        const result   = buildCCv2(cardData);
        const { valid } = validateCCv2(result);
        expect(valid).toBe(true);
    });

    it('spec 固定为 chara_card_v2', () => {
        const result = buildCCv2(makeFullV2());
        expect(result.spec).toBe('chara_card_v2');
    });

    it('spec_version 固定为 2.0', () => {
        const result = buildCCv2(makeFullV2());
        expect(result.spec_version).toBe('2.0');
    });

    it('文本字段正确映射', () => {
        const cardData = makeFullV2();
        const result   = buildCCv2(cardData);
        expect(result.data.name).toBe('完整测试角色');
        expect(result.data.description).toBe('这是角色描述');
        expect(result.data.personality).toBe('活泼开朗');
    });

    it('alternate_greetings 数组正确映射', () => {
        const cardData = makeFullV2();
        const result   = buildCCv2(cardData);
        expect(result.data.alternate_greetings).toEqual(['备用开场白一', '备用开场白二']);
    });

    it('tags 数组正确映射', () => {
        const cardData = makeFullV2();
        const result   = buildCCv2(cardData);
        expect(result.data.tags).toContain('测试');
        expect(result.data.tags).toContain('CCv2');
    });

    it('支持不带 data 包装的扁平输入', () => {
        const flatData = makeFullV2().data;
        const result   = buildCCv2(flatData);
        expect(result.data.name).toBe('完整测试角色');
    });

    it('空输入返回结构完整的空对象', () => {
        const result = buildCCv2({});
        expect(result.spec).toBe('chara_card_v2');
        expect(result.data.name).toBe('');
        expect(Array.isArray(result.data.alternate_greetings)).toBe(true);
    });

    it('非字符串字段值被强制转为字符串', () => {
        const cardData = {
            data: {
                name:    123,
                creator: null,
            }
        };
        const result = buildCCv2(cardData);
        expect(typeof result.data.name).toBe('string');
        expect(result.data.name).toBe('123');
    });

    it('extensions 中的 cardforge 扩展被保留', () => {
        const cardData = makeFullV2();
        cardData.data.extensions.cardforge = { version: '1.0.0' };
        const result = buildCCv2(cardData);
        expect(result.data.extensions.cardforge).toBeDefined();
    });
});

// ═══════════════════════════════════════════════
// § 4  sanitizeCCv2
// ═══════════════════════════════════════════════

describe('sanitizeCCv2', () => {

    it('合法输入原样通过', () => {
        const data   = makeFullV2();
        const result = sanitizeCCv2(data);
        expect(result.data.name).toBe(data.data.name);
        expect(result.data.description).toBe(data.data.description);
    });

    it('非字符串文本字段被修正为空字符串', () => {
        const data = makeMinimalV2();
        data.data.description = 42;
        data.data.personality = null;
        data.data.scenario    = undefined;
        const result = sanitizeCCv2(data);
        expect(result.data.description).toBe('');
        expect(result.data.personality).toBe('');
        expect(result.data.scenario).toBe('');
    });

    it('非数组的 alternate_greetings 被修正为空数组', () => {
        const data = makeMinimalV2();
        data.data.alternate_greetings = '错误类型';
        const result = sanitizeCCv2(data);
        expect(Array.isArray(result.data.alternate_greetings)).toBe(true);
        expect(result.data.alternate_greetings).toHaveLength(0);
    });

    it('数组中的非字符串条目被过滤', () => {
        const data = makeMinimalV2();
        data.data.alternate_greetings = ['合法', 123, null, '也合法', undefined];
        const result = sanitizeCCv2(data);
        expect(result.data.alternate_greetings).toEqual(['合法', '也合法']);
    });

    it('非数组的 tags 被修正为空数组', () => {
        const data = makeMinimalV2();
        data.data.tags = { wrong: 'type' };
        const result = sanitizeCCv2(data);
        expect(Array.isArray(result.data.tags)).toBe(true);
    });

    it('非对象的 extensions 被修正为空对象', () => {
        const data = makeMinimalV2();
        data.data.extensions = '非对象';
        const result = sanitizeCCv2(data);
        expect(typeof result.data.extensions).toBe('object');
        expect(result.data.extensions).toEqual({});
    });

    it('null 输入返回空结构', () => {
        const result = sanitizeCCv2(null);
        expect(result.spec).toBe('chara_card_v2');
        expect(result.data.name).toBe('');
    });

    it('缺少 data 字段的输入返回空结构', () => {
        const result = sanitizeCCv2({ spec: 'chara_card_v2' });
        expect(result.data.name).toBe('');
    });

    it('净化后的数据可通过 validateCCv2（假设 name 有值）', () => {
        const messy = {
            spec:         'chara_card_v2',
            spec_version: '2.0',
            data: {
                name:                 '合法名称',
                description:          123,
                alternate_greetings:  'wrong',
                tags:                 null,
                extensions:           'wrong',
            }
        };
        const cleaned = sanitizeCCv2(messy);
        const { valid } = validateCCv2(cleaned);
        expect(valid).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 5  migrateCCv2ToCCv3
// ═══════════════════════════════════════════════

describe('migrateCCv2ToCCv3', () => {

    it('输出 spec 为 chara_card_v3', () => {
        const result = migrateCCv2ToCCv3(makeFullV2());
        expect(result.spec).toBe('chara_card_v3');
    });

    it('输出 spec_version 为 3.0', () => {
        const result = migrateCCv2ToCCv3(makeFullV2());
        expect(result.spec_version).toBe('3.0');
    });

    it('原始文本字段被保留', () => {
        const v2     = makeFullV2();
        const result = migrateCCv2ToCCv3(v2);
        expect(result.data.name).toBe(v2.data.name);
        expect(result.data.description).toBe(v2.data.description);
        expect(result.data.first_mes).toBe(v2.data.first_mes);
    });

    it('alternate_greetings 被保留', () => {
        const v2     = makeFullV2();
        const result = migrateCCv2ToCCv3(v2);
        expect(result.data.alternate_greetings).toEqual(v2.data.alternate_greetings);
    });

    it('tags 被保留', () => {
        const v2     = makeFullV2();
        const result = migrateCCv2ToCCv3(v2);
        expect(result.data.tags).toEqual(v2.data.tags);
    });

    it('输出包含 CCv3 新增的 group_only_greetings 字段', () => {
        const result = migrateCCv2ToCCv3(makeFullV2());
        expect(Array.isArray(result.data.group_only_greetings)).toBe(true);
    });

    it('不修改原始输入对象', () => {
        const v2         = makeFullV2();
        const origName   = v2.data.name;
        migrateCCv2ToCCv3(v2);
        expect(v2.data.name).toBe(origName);
        expect(v2.spec).toBe('chara_card_v2');
    });
});

// ═══════════════════════════════════════════════
// § 6  常量校验
// ═══════════════════════════════════════════════

describe('CCv2 常量', () => {

    it('CCv2_REQUIRED_FIELDS 包含 name', () => {
        expect(CCv2_REQUIRED_FIELDS).toContain('name');
    });

    it('CCv2_RECOMMENDED_FIELDS 包含核心叙事字段', () => {
        expect(CCv2_RECOMMENDED_FIELDS).toContain('description');
        expect(CCv2_RECOMMENDED_FIELDS).toContain('first_mes');
    });

    it('CCv2_ALL_FIELDS 包含所有必填和推荐字段', () => {
        for (const f of CCv2_REQUIRED_FIELDS) {
            expect(CCv2_ALL_FIELDS).toContain(f);
        }
        for (const f of CCv2_RECOMMENDED_FIELDS) {
            expect(CCv2_ALL_FIELDS).toContain(f);
        }
    });

    it('必填字段不超过推荐字段范围', () => {
        for (const f of CCv2_REQUIRED_FIELDS) {
            expect(CCv2_RECOMMENDED_FIELDS.includes(f) || CCv2_ALL_FIELDS.includes(f)).toBe(true);
        }
    });
});