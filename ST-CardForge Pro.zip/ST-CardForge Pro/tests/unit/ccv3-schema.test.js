/**
 * @file tests/unit/ccv3-schema.test.js
 * @description ccv3-schema.js 完整单元测试
 * @framework Vitest
 */

import { describe, it, expect } from 'vitest';
import {
    validateCCv3,
    buildCCv3,
    sanitizeCCv3,
    createEmptyCCv3,
    CCv3_REQUIRED_FIELDS,
    CCv3_RECOMMENDED_FIELDS,
    CCv3_ALL_FIELDS,
    VALID_ASSET_TYPES,
    VALID_ENTRY_POSITIONS,
} from '../../utils/ccv3-schema.js';

// ─── 测试夹具 ───────────────────────────────────

function makeMinimalV3() {
    return {
        spec:         'chara_card_v3',
        spec_version: '3.0',
        data: {
            name: 'CCv3测试角色',
        },
    };
}

function makeFullV3() {
    return {
        spec:         'chara_card_v3',
        spec_version: '3.0',
        data: {
            name:                       'CCv3完整角色',
            description:                '这是完整的角色描述',
            personality:                '沉稳冷静',
            scenario:                   '在星界学院初次相遇',
            first_mes:                  '你好，欢迎来到星界学院。',
            mes_example:                '<START>\n{{user}}: 你好\n{{char}}: 你好。',
            creator_notes:              'CCv3专属备注',
            system_prompt:              '请严格遵守角色设定',
            post_history_instructions:  '补充历史后指令',
            alternate_greetings:        ['备用开场A', '备用开场B'],
            group_only_greetings:       ['群聊专用开场'],
            tags:                       ['CCv3', '测试', '奇幻'],
            creator:                    'TestCreator',
            character_version:          '2.0.0',
            assets: [
                { type: 'icon', uri: 'ccdefault:', name: '默认头像', ext: 'png' }
            ],
            character_book: {
                name:               '测试世界书',
                description:        '配套世界书',
                scan_depth:         2,
                token_budget:       512,
                recursive_scanning: false,
                extensions:         {},
                entries: [
                    {
                        id:               1,
                        keys:             ['关键词A', '关键词B'],
                        secondary_keys:   [],
                        content:          '这是条目内容',
                        enabled:          true,
                        insertion_order:  100,
                        case_sensitive:   false,
                        name:             '测试条目',
                        priority:         10,
                        comment:          '注释',
                        selective:        false,
                        constant:         false,
                        position:         'before_char',
                        extensions:       {},
                    }
                ],
            },
            extensions: {
                cardforge: { version: '1.0.0' }
            },
        },
    };
}

// ═══════════════════════════════════════════════
// § 1  createEmptyCCv3
// ═══════════════════════════════════════════════

describe('createEmptyCCv3', () => {

    it('顶层 spec 为 chara_card_v3', () => {
        expect(createEmptyCCv3().spec).toBe('chara_card_v3');
    });

    it('顶层 spec_version 为 3.0', () => {
        expect(createEmptyCCv3().spec_version).toBe('3.0');
    });

    it('包含 CCv3 专有字段 group_only_greetings', () => {
        const result = createEmptyCCv3();
        expect(Array.isArray(result.data.group_only_greetings)).toBe(true);
    });

    it('包含 CCv3 专有字段 assets', () => {
        const result = createEmptyCCv3();
        expect(Array.isArray(result.data.assets)).toBe(true);
    });

    it('character_book 默认为 undefined', () => {
        const result = createEmptyCCv3();
        expect(result.data.character_book).toBeUndefined();
    });

    it('每次调用返回独立的新对象', () => {
        const a = createEmptyCCv3();
        const b = createEmptyCCv3();
        a.data.name = '修改A';
        expect(b.data.name).toBe('');
    });

    it('所有文本字段默认为空字符串', () => {
        const result = createEmptyCCv3();
        const textFields = [
            'name', 'description', 'personality', 'scenario',
            'first_mes', 'mes_example', 'creator_notes',
            'system_prompt', 'post_history_instructions',
            'creator', 'character_version',
        ];
        for (const f of textFields) {
            expect(result.data[f]).toBe('');
        }
    });
});

// ═══════════════════════════════════════════════
// § 2  validateCCv3 — 合法输入
// ═══════════════════════════════════════════════

describe('validateCCv3 — 合法输入', () => {

    it('最小合法数据校验通过', () => {
        const { valid, errors } = validateCCv3(makeMinimalV3());
        expect(valid).toBe(true);
        expect(errors).toHaveLength(0);
    });

    it('完整合法数据校验通过', () => {
        const { valid, errors } = validateCCv3(makeFullV3());
        expect(valid).toBe(true);
        expect(errors).toHaveLength(0);
    });

    it('完整数据无必填字段错误', () => {
        const { errors } = validateCCv3(makeFullV3());
        const required = errors.filter(e => e.includes('必填'));
        expect(required).toHaveLength(0);
    });

    it('合法 assets 类型不产生 error', () => {
        const data = makeMinimalV3();
        data.data.assets = VALID_ASSET_TYPES.map(type => ({
            type, uri: 'test://uri', name: type, ext: 'png'
        }));
        const { errors } = validateCCv3(data);
        const assetErrors = errors.filter(e => e.includes('asset'));
        expect(assetErrors).toHaveLength(0);
    });

    it('合法 character_book 不产生 error', () => {
        const { valid, errors } = validateCCv3(makeFullV3());
        expect(valid).toBe(true);
        const bookErrors = errors.filter(e => e.includes('character_book'));
        expect(bookErrors).toHaveLength(0);
    });

    it('character_book 为 undefined 时不报错', () => {
        const data = makeMinimalV3();
        data.data.character_book = undefined;
        const { valid } = validateCCv3(data);
        expect(valid).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 3  validateCCv3 — 非法输入
// ═══════════════════════════════════════════════

describe('validateCCv3 — 非法输入', () => {

    it('null 输入返回 valid=false', () => {
        expect(validateCCv3(null).valid).toBe(false);
    });

    it('spec 错误返回 valid=false', () => {
        const data = makeMinimalV3();
        data.spec  = 'chara_card_v2'; // 故意填 v2
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('spec'))).toBe(true);
    });

    it('缺少 data 返回 valid=false', () => {
        const { valid } = validateCCv3({ spec: 'chara_card_v3' });
        expect(valid).toBe(false);
    });

    it('name 为空返回 valid=false', () => {
        const data = makeMinimalV3();
        data.data.name = '';
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('name'))).toBe(true);
    });

    it('assets 不是数组产生 error', () => {
        const data = makeMinimalV3();
        data.data.assets = '非数组';
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('assets'))).toBe(true);
    });

    it('assets 中缺少 type 字段产生 error', () => {
        const data = makeMinimalV3();
        data.data.assets = [{ uri: 'test://uri' }]; // 缺少 type
        const { errors } = validateCCv3(data);
        expect(errors.some(e => e.includes('type'))).toBe(true);
    });

    it('assets 中未知 type 产生 warning 而非 error', () => {
        const data = makeMinimalV3();
        data.data.assets = [{ type: 'unknown_type', uri: 'test://uri' }];
        const { valid, warnings } = validateCCv3(data);
        expect(valid).toBe(true); // 只是 warning
        expect(warnings.some(w => w.includes('unknown_type'))).toBe(true);
    });

    it('character_book 不是对象时产生 error', () => {
        const data = makeMinimalV3();
        data.data.character_book = '非对象';
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('character_book'))).toBe(true);
    });

    it('character_book.entries 不是数组时产生 error', () => {
        const data = makeMinimalV3();
        data.data.character_book = {
            name:    '测试',
            entries: '不是数组',
        };
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
    });

    it('character_book 条目缺少 keys 产生 warning', () => {
        const data = makeFullV3();
        data.data.character_book.entries[0].keys = [];
        const { warnings } = validateCCv3(data);
        expect(warnings.some(w => w.includes('keys'))).toBe(true);
    });

    it('character_book 条目 content 为空产生 warning', () => {
        const data = makeFullV3();
        data.data.character_book.entries[0].content = '';
        const { warnings } = validateCCv3(data);
        expect(warnings.some(w => w.includes('content'))).toBe(true);
    });

    it('group_only_greetings 不是数组产生 error', () => {
        const data = makeMinimalV3();
        data.data.group_only_greetings = 'wrong';
        const { valid, errors } = validateCCv3(data);
        expect(valid).toBe(false);
        expect(errors.some(e => e.includes('group_only_greetings'))).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 4  buildCCv3
// ═══════════════════════════════════════════════

describe('buildCCv3', () => {

    it('构建后通过 validateCCv3', () => {
        const result = buildCCv3(makeFullV3());
        const { valid } = validateCCv3(result);
        expect(valid).toBe(true);
    });

    it('spec 固定为 chara_card_v3', () => {
        expect(buildCCv3(makeFullV3()).spec).toBe('chara_card_v3');
    });

    it('spec_version 固定为 3.0', () => {
        expect(buildCCv3(makeFullV3()).spec_version).toBe('3.0');
    });

    it('文本字段正确映射', () => {
        const result = buildCCv3(makeFullV3());
        expect(result.data.name).toBe('CCv3完整角色');
        expect(result.data.description).toBe('这是完整的角色描述');
        expect(result.data.scenario).toBe('在星界学院初次相遇');
    });

    it('group_only_greetings 正确映射', () => {
        const result = buildCCv3(makeFullV3());
        expect(result.data.group_only_greetings).toEqual(['群聊专用开场']);
    });

    it('assets 正确映射', () => {
        const result = buildCCv3(makeFullV3());
        expect(result.data.assets).toHaveLength(1);
        expect(result.data.assets[0].type).toBe('icon');
    });

    it('character_book 存在时被正确构建', () => {
        const result = buildCCv3(makeFullV3());
        expect(result.data.character_book).toBeDefined();
        expect(result.data.character_book.entries).toHaveLength(1);
    });

    it('character_book 不存在时 data.character_book 为 undefined', () => {
        const data = makeMinimalV3();
        data.data.name = '仅有名称';
        const result = buildCCv3(data);
        expect(result.data.character_book).toBeUndefined();
    });

    it('extensions.cardforge 被注入 meta.updated_at', () => {
        const result = buildCCv3(makeFullV3());
        expect(result.data.extensions.cardforge.meta.updated_at).toBeDefined();
    });

    it('character_book 条目的 position 非法值被修正为 before_char', () => {
        const data = makeFullV3();
        data.data.character_book.entries[0].position = 'invalid_position';
        const result = buildCCv3(data);
        expect(result.data.character_book.entries[0].position).toBe('before_char');
    });

    it('空输入返回结构完整的空对象', () => {
        const result = buildCCv3({});
        expect(result.spec).toBe('chara_card_v3');
        expect(result.data.name).toBe('');
        expect(Array.isArray(result.data.group_only_greetings)).toBe(true);
        expect(Array.isArray(result.data.assets)).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 5  sanitizeCCv3
// ═══════════════════════════════════════════════

describe('sanitizeCCv3', () => {

    it('合法输入原样通过', () => {
        const data   = makeFullV3();
        const result = sanitizeCCv3(data);
        expect(result.data.name).toBe(data.data.name);
    });

    it('非字符串文本字段被修正为空字符串', () => {
        const data = makeMinimalV3();
        data.data.description = 999;
        const result = sanitizeCCv3(data);
        expect(result.data.description).toBe('');
    });

    it('非数组 group_only_greetings 被修正为空数组', () => {
        const data = makeMinimalV3();
        data.data.group_only_greetings = 'wrong';
        const result = sanitizeCCv3(data);
        expect(Array.isArray(result.data.group_only_greetings)).toBe(true);
        expect(result.data.group_only_greetings).toHaveLength(0);
    });

    it('非数组 assets 被修正为空数组', () => {
        const data = makeMinimalV3();
        data.data.assets = { type: 'icon' };
        const result = sanitizeCCv3(data);
        expect(Array.isArray(result.data.assets)).toBe(true);
    });

    it('null 输入返回空结构', () => {
        const result = sanitizeCCv3(null);
        expect(result.spec).toBe('chara_card_v3');
        expect(result.data.name).toBe('');
    });

    it('净化后数据（name有值时）可通过 validateCCv3', () => {
        const messy = {
            spec:         'chara_card_v3',
            spec_version: '3.0',
            data: {
                name:                 '净化测试角色',
                description:          123,
                group_only_greetings: 'wrong',
                assets:               null,
                extensions:           'wrong',
            }
        };
        const result = sanitizeCCv3(messy);
        const { valid } = validateCCv3(result);
        expect(valid).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 6  常量完整性
// ═══════════════════════════════════════════════

describe('CCv3 常量', () => {

    it('VALID_ASSET_TYPES 包含核心资源类型', () => {
        expect(VALID_ASSET_TYPES).toContain('icon');
        expect(VALID_ASSET_TYPES).toContain('background');
    });

    it('VALID_ENTRY_POSITIONS 包含核心位置', () => {
        expect(VALID_ENTRY_POSITIONS).toContain('before_char');
        expect(VALID_ENTRY_POSITIONS).toContain('after_char');
    });

    it('CCv3_ALL_FIELDS 包含 CCv3 专有字段', () => {
        expect(CCv3_ALL_FIELDS).toContain('group_only_greetings');
        expect(CCv3_ALL_FIELDS).toContain('assets');
        expect(CCv3_ALL_FIELDS).toContain('character_book');
    });

    it('CCv3_REQUIRED_FIELDS 所有字段都在 CCv3_ALL_FIELDS 中', () => {
        for (const f of CCv3_REQUIRED_FIELDS) {
            expect(CCv3_ALL_FIELDS).toContain(f);
        }
    });

    it('CCv3_RECOMMENDED_FIELDS 所有字段都在 CCv3_ALL_FIELDS 中', () => {
        for (const f of CCv3_RECOMMENDED_FIELDS) {
            expect(CCv3_ALL_FIELDS).toContain(f);
        }
    });
});