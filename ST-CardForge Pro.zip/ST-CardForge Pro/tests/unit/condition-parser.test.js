/**
 * @file tests/unit/condition-parser.test.js
 * @description condition-parser.js 完整单元测试
 * @framework Vitest
 */

import { describe, it, expect } from 'vitest';
import {
    parseCondition,
    compileToSTScript,
    evaluateCondition,
    OPERATORS,
} from '../../modules/06_plot-branch/condition-parser.js';

// ═══════════════════════════════════════════════
// § 1  parseCondition
// ═══════════════════════════════════════════════

describe('parseCondition — 对象格式输入', () => {

    it('合法对象直接返回（深拷贝）', () => {
        const cond   = { variable: 'hp', operator: 'gt', value: 0 };
        const result = parseCondition(cond);
        expect(result.variable).toBe('hp');
        expect(result.operator).toBe('gt');
        expect(result.value).toBe(0);
    });

    it('默认 negate 为 false', () => {
        const result = parseCondition({ variable: 'hp', operator: 'gt', value: 0 });
        expect(result.negate).toBe(false);
    });

    it('negate=true 被保留', () => {
        const result = parseCondition({
            variable: 'hp', operator: 'gt', value: 0, negate: true
        });
        expect(result.negate).toBe(true);
    });

    it('所有合法 operator 均可解析', () => {
        const operators = Object.keys(OPERATORS);
        for (const op of operators) {
            expect(() => parseCondition({
                variable: 'x', operator: op, value: 0
            })).not.toThrow();
        }
    });

    it('返回对象与输入对象不共享引用', () => {
        const cond   = { variable: 'hp', operator: 'gt', value: 50 };
        const result = parseCondition(cond);
        result.variable = '修改后';
        expect(cond.variable).toBe('hp');
    });
});

describe('parseCondition — 字符串格式输入', () => {

    it('解析 "hp > 0" 格式', () => {
        const result = parseCondition('hp > 0');
        expect(result.variable).toBe('hp');
        expect(result.operator).toBe('gt');
        expect(result.value).toBe(0);
    });

    it('解析 "hp >= 100" 格式', () => {
        const result = parseCondition('hp >= 100');
        expect(result.operator).toBe('gte');
        expect(result.value).toBe(100);
    });

    it('解析 "hp < 50" 格式', () => {
        const result = parseCondition('hp < 50');
        expect(result.operator).toBe('lt');
        expect(result.value).toBe(50);
    });

    it('解析 "hp <= 50" 格式', () => {
        const result = parseCondition('hp <= 50');
        expect(result.operator).toBe('lte');
    });

    it('解析 "hp == 100" 或 "hp = 100" 格式', () => {
        const result = parseCondition('hp == 100');
        expect(result.operator).toBe('eq');
        expect(result.value).toBe(100);
    });

    it('解析 "hp != 0" 格式', () => {
        const result = parseCondition('hp != 0');
        expect(result.operator).toBe('neq');
    });

    it('解析含空格的变量名 "  hp  >  0  "', () => {
        const result = parseCondition('  hp  >  0  ');
        expect(result.variable).toBe('hp');
        expect(result.value).toBe(0);
    });

    it('解析字符串值 "status == alive"', () => {
        const result = parseCondition('status == alive');
        expect(result.variable).toBe('status');
        expect(result.value).toBe('alive');
    });

    it('解析带引号的字符串值 "name == \"勇者\""', () => {
        const result = parseCondition('name == "勇者"');
        expect(result.value).toBe('勇者');
    });

    it('中文变量名可正确解析', () => {
        const result = parseCondition('生命值 > 0');
        expect(result.variable).toBe('生命值');
    });
});

describe('parseCondition — 异常输入', () => {

    it('null 输入不抛出错误', () => {
        expect(() => parseCondition(null)).not.toThrow();
    });

    it('undefined 输入不抛出错误', () => {
        expect(() => parseCondition(undefined)).not.toThrow();
    });

    it('空字符串输入不抛出错误', () => {
        expect(() => parseCondition('')).not.toThrow();
    });

    it('无效字符串返回的对象包含合理默认值', () => {
        const result = parseCondition('这不是条件表达式!!!');
        expect(typeof result).toBe('object');
        expect(result).not.toBeNull();
    });
});

// ═══════════════════════════════════════════════
// § 2  compileToSTScript
// ═══════════════════════════════════════════════

describe('compileToSTScript', () => {

    it('gt 操作符生成正确的 if 语句', () => {
        const cond   = { variable: 'hp', operator: 'gt', value: 0 };
        const result = compileToSTScript(cond);
        expect(typeof result).toBe('string');
        expect(result).toContain('hp');
        expect(result).toContain('0');
    });

    it('eq 操作符生成包含等号判断', () => {
        const cond   = { variable: 'flag', operator: 'eq', value: 1 };
        const result = compileToSTScript(cond);
        expect(result).toContain('flag');
        expect(result).toContain('1');
    });

    it('negate=true 生成取反逻辑', () => {
        const cond   = { variable: 'hp', operator: 'gt', value: 0, negate: true };
        const result = compileToSTScript(cond);
        expect(typeof result).toBe('string');
        // 取反后应包含某种否定标记
        expect(result.length).toBeGreaterThan(0);
    });

    it('生成的脚本包含 /if 或 if 关键字', () => {
        const cond   = { variable: 'hp', operator: 'gt', value: 0 };
        const result = compileToSTScript(cond);
        expect(result.toLowerCase()).toMatch(/if/i);
    });

    it('contains 操作符生成包含检测语句', () => {
        const cond   = { variable: 'inventory', operator: 'contains', value: '剑' };
        const result = compileToSTScript(cond);
        expect(result).toContain('inventory');
        expect(result).toContain('剑');
    });

    it('字符串值被正确引用', () => {
        const cond   = { variable: 'status', operator: 'eq', value: 'active' };
        const result = compileToSTScript(cond);
        expect(result).toContain('active');
    });

    it('所有支持的操作符均可编译', () => {
        for (const op of Object.keys(OPERATORS)) {
            expect(() => compileToSTScript({
                variable: 'x', operator: op, value: 0
            })).not.toThrow();
        }
    });

    it('null 输入不崩溃', () => {
        expect(() => compileToSTScript(null)).not.toThrow();
    });
});

// ═══════════════════════════════════════════════
// § 3  evaluateCondition
// ═══════════════════════════════════════════════

describe('evaluateCondition — 数值比较', () => {

    const vars = { hp: 50, mp: 100, level: 5, gold: 0 };

    it('gt：50 > 30 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'gt', value: 30 }, vars
        )).toBe(true);
    });

    it('gt：50 > 50 = false', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'gt', value: 50 }, vars
        )).toBe(false);
    });

    it('gte：50 >= 50 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'gte', value: 50 }, vars
        )).toBe(true);
    });

    it('lt：50 < 100 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'lt', value: 100 }, vars
        )).toBe(true);
    });

    it('lte：50 <= 50 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'lte', value: 50 }, vars
        )).toBe(true);
    });

    it('eq：50 == 50 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'eq', value: 50 }, vars
        )).toBe(true);
    });

    it('eq：50 == 51 = false', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'eq', value: 51 }, vars
        )).toBe(false);
    });

    it('neq：50 != 30 = true', () => {
        expect(evaluateCondition(
            { variable: 'hp', operator: 'neq', value: 30 }, vars
        )).toBe(true);
    });

    it('gold == 0 = true', () => {
        expect(evaluateCondition(
            { variable: 'gold', operator: 'eq', value: 0 }, vars
        )).toBe(true);
    });
});

describe('evaluateCondition — 字符串比较', () => {

    const vars = { status: 'active', name: '勇者艾伦', class: 'warrior' };

    it('eq：字符串精确匹配', () => {
        expect(evaluateCondition(
            { variable: 'status', operator: 'eq', value: 'active' }, vars
        )).toBe(true);
    });

    it('neq：字符串不匹配', () => {
        expect(evaluateCondition(
            { variable: 'status', operator: 'neq', value: 'inactive' }, vars
        )).toBe(true);
    });

    it('contains：name 包含 "艾伦"', () => {
        expect(evaluateCondition(
            { variable: 'name', operator: 'contains', value: '艾伦' }, vars
        )).toBe(true);
    });

    it('contains：name 不包含 "龙"', () => {
        expect(evaluateCondition(
            { variable: 'name', operator: 'contains', value: '龙' }, vars
        )).toBe(false);
    });

    it('matches：正则匹配', () => {
        expect(evaluateCondition(
            { variable: 'class', operator: 'matches', value: '^war' }, vars
        )).toBe(true);
    });

    it('matches：正则不匹配', () => {
        expect(evaluateCondition(
            { variable: 'class', operator: 'matches', value: '^mage' }, vars
        )).toBe(false);
    });
});

describe('evaluateCondition — negate 取反', () => {

    const vars = { hp: 50 };

    it('negate=true 时结果取反', () => {
        const plain   = evaluateCondition({ variable: 'hp', operator: 'gt', value: 30 }, vars);
        const negated = evaluateCondition({ variable: 'hp', operator: 'gt', value: 30, negate: true }, vars);
        expect(plain).toBe(true);
        expect(negated).toBe(false);
    });

    it('negate=false 时结果不变', () => {
        const plain    = evaluateCondition({ variable: 'hp', operator: 'gt', value: 30 }, vars);
        const explicit = evaluateCondition({ variable: 'hp', operator: 'gt', value: 30, negate: false }, vars);
        expect(plain).toBe(explicit);
    });
});

describe('evaluateCondition — 边界与异常', () => {

    it('变量不存在时返回 false（不抛出）', () => {
        expect(() => evaluateCondition(
            { variable: 'nonexistent', operator: 'gt', value: 0 }, {}
        )).not.toThrow();

        const result = evaluateCondition(
            { variable: 'nonexistent', operator: 'gt', value: 0 }, {}
        );
        expect(typeof result).toBe('boolean');
    });

    it('null condition 不抛出', () => {
        expect(() => evaluateCondition(null, {})).not.toThrow();
    });

    it('null variables 不抛出', () => {
        expect(() => evaluateCondition(
            { variable: 'hp', operator: 'gt', value: 0 }, null
        )).not.toThrow();
    });

    it('数值与字符串的混合比较不崩溃', () => {
        expect(() => evaluateCondition(
            { variable: 'hp', operator: 'gt', value: '50' }, { hp: 100 }
        )).not.toThrow();
    });

    it('返回值始终为 boolean 类型', () => {
        const cases = [
            { variable: 'hp', operator: 'gt',       value: 0   },
            { variable: 'hp', operator: 'lt',       value: 0   },
            { variable: 'hp', operator: 'eq',       value: 100 },
            { variable: 'hp', operator: 'contains', value: 'x' },
        ];
        for (const cond of cases) {
            const result = evaluateCondition(cond, { hp: 50 });
            expect(typeof result).toBe('boolean');
        }
    });
});

// ═══════════════════════════════════════════════
// § 4  OPERATORS 常量
// ═══════════════════════════════════════════════

describe('OPERATORS 常量', () => {

    it('包含所有必要的操作符', () => {
        const required = ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'contains', 'matches'];
        for (const op of required) {
            expect(OPERATORS).toHaveProperty(op);
        }
    });

    it('每个操作符有对应的中文描述', () => {
        for (const [key, label] of Object.entries(OPERATORS)) {
            expect(typeof label).toBe('string');
            expect(label.length).toBeGreaterThan(0);
        }
    });
});