/**
 * @file tests/unit/entry-builder.test.js
 * @description entry-builder.js 完整单元测试
 * @framework Vitest
 */

import { describe, it, expect } from 'vitest';
import {
    buildEntry,
    createPlaceEntry,
    createCharacterEntry,
    createOrganizationEntry,
    createItemEntry,
    createHistoryEntry,
    createRuleEntry,
    mergeEntries,
    sortEntries,
} from '../../modules/02_world-book/entry-builder.js';
import { WB_ENTRY_SCHEMA } from '../../contracts.js';

// ─── 工具函数 ───────────────────────────────────

/**
 * 检查一个对象是否符合 WB_ENTRY_SCHEMA 的结构（字段存在性）
 */
function hasAllSchemaFields(entry) {
    return Object.keys(WB_ENTRY_SCHEMA).every(key => key in entry);
}

// ═══════════════════════════════════════════════
// § 1  buildEntry
// ═══════════════════════════════════════════════

describe('buildEntry', () => {

    it('返回对象包含 WB_ENTRY_SCHEMA 所有字段', () => {
        const entry = buildEntry({
            keys:    ['关键词'],
            content: '条目内容',
        });
        expect(hasAllSchemaFields(entry)).toBe(true);
    });

    it('指定的 keys 被正确设置', () => {
        const entry = buildEntry({ keys: ['词A', '词B'], content: '内容' });
        expect(entry.keys).toContain('词A');
        expect(entry.keys).toContain('词B');
    });

    it('指定的 content 被正确设置', () => {
        const entry = buildEntry({ keys: [], content: '这是内容' });
        expect(entry.content).toBe('这是内容');
    });

    it('enabled 默认为 true', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.enabled).toBe(true);
    });

    it('可以覆盖默认的 enabled', () => {
        const entry = buildEntry({ keys: [], content: '', enabled: false });
        expect(entry.enabled).toBe(false);
    });

    it('insertion_order 默认为 100', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.insertion_order).toBe(100);
    });

    it('priority 默认为 10', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.priority).toBe(10);
    });

    it('position 默认为 before_char', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.position).toBe('before_char');
    });

    it('selective 默认为 false', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.selective).toBe(false);
    });

    it('constant 默认为 false', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.constant).toBe(false);
    });

    it('secondary_keys 默认为空数组', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(Array.isArray(entry.secondary_keys)).toBe(true);
        expect(entry.secondary_keys).toHaveLength(0);
    });

    it('extensions 默认为空对象', () => {
        const entry = buildEntry({ keys: [], content: '' });
        expect(entry.extensions).toEqual({});
    });

    it('可以自定义 category', () => {
        const entry = buildEntry({ keys: [], content: '', category: '地名' });
        expect(entry.category).toBe('地名');
    });

    it('可以自定义所有字段', () => {
        const custom = {
            uid:              42,
            keys:             ['主键'],
            secondary_keys:   ['副键'],
            content:          '自定义内容',
            enabled:          false,
            insertion_order:  200,
            priority:         5,
            position:         'after_char',
            depth:            8,
            selective:        true,
            constant:         true,
            category:         '规则',
            extensions:       { extra: 'data' },
        };
        const entry = buildEntry(custom);
        for (const [key, value] of Object.entries(custom)) {
            expect(entry[key]).toEqual(value);
        }
    });

    it('空输入不抛出错误', () => {
        expect(() => buildEntry({})).not.toThrow();
    });

    it('null 输入不抛出错误', () => {
        expect(() => buildEntry(null)).not.toThrow();
    });

    it('每次调用返回独立对象', () => {
        const a = buildEntry({ keys: ['A'], content: '' });
        const b = buildEntry({ keys: ['B'], content: '' });
        a.keys.push('修改A');
        expect(b.keys).not.toContain('修改A');
    });
});

// ═══════════════════════════════════════════════
// § 2  工厂函数
// ═══════════════════════════════════════════════

describe('createPlaceEntry', () => {

    it('返回 category 为 地名', () => {
        const entry = createPlaceEntry('星界学院', '学院描述', ['学院', '星界']);
        expect(entry.category).toBe('地名');
    });

    it('name 被设置为传入的地名', () => {
        const entry = createPlaceEntry('星界学院', '学院描述', ['学院']);
        expect(entry.name ?? entry.keys[0]).toContain('星界学院');
    });

    it('content 被正确设置', () => {
        const entry = createPlaceEntry('城市', '一座繁华的城市', ['城市']);
        expect(entry.content).toBe('一座繁华的城市');
    });

    it('keys 被正确设置', () => {
        const entry = createPlaceEntry('城市', '描述', ['城市', '都市', '王都']);
        expect(entry.keys).toContain('城市');
        expect(entry.keys).toContain('王都');
    });

    it('返回对象包含 WB_ENTRY_SCHEMA 所有字段', () => {
        const entry = createPlaceEntry('地点', '描述', ['地点']);
        expect(hasAllSchemaFields(entry)).toBe(true);
    });
});

describe('createCharacterEntry', () => {

    it('返回 category 为 人物', () => {
        const entry = createCharacterEntry('艾拉', '银发魔法师', ['艾拉']);
        expect(entry.category).toBe('人物');
    });

    it('content 被正确设置', () => {
        const entry = createCharacterEntry('艾拉', '银发魔法师', ['艾拉']);
        expect(entry.content).toBe('银发魔法师');
    });

    it('人物条目默认为 selective=true（避免污染无关场景）', () => {
        const entry = createCharacterEntry('角色名', '描述', ['关键词']);
        // selective 为 true 是人物条目的推荐设置
        expect(typeof entry.selective).toBe('boolean');
    });
});

describe('createOrganizationEntry', () => {

    it('返回 category 为 组织', () => {
        const entry = createOrganizationEntry('行会', '锻造师行会描述', ['行会']);
        expect(entry.category).toBe('组织');
    });

    it('keys 被正确设置', () => {
        const entry = createOrganizationEntry('行会', '描述', ['行会', '公会', '锻造师行会']);
        expect(entry.keys).toContain('行会');
        expect(entry.keys).toContain('公会');
    });
});

describe('createItemEntry', () => {

    it('返回 category 为 物品', () => {
        const entry = createItemEntry('星纹印记', '神秘的星界契约印记', ['印记', '星纹']);
        expect(entry.category).toBe('物品');
    });

    it('content 被正确设置', () => {
        const entry = createItemEntry('陨铁', '稀有的星铁材料', ['陨铁']);
        expect(entry.content).toBe('稀有的星铁材料');
    });
});

describe('createHistoryEntry', () => {

    it('返回 category 为 历史', () => {
        const entry = createHistoryEntry('碎星纪元起源', '三百年前的星坠事件', ['碎星纪元']);
        expect(entry.category).toBe('历史');
    });

    it('content 被正确设置', () => {
        const entry = createHistoryEntry('古战役', '一场古老的战役', ['古战役']);
        expect(entry.content).toBe('一场古老的战役');
    });
});

describe('createRuleEntry', () => {

    it('返回 category 为 规则', () => {
        const entry = createRuleEntry('魔法消耗规则', '【系统规则】魔力使用规范', ['魔法规则']);
        expect(entry.category).toBe('规则');
    });

    it('规则条目的 position 为 after_char', () => {
        const entry = createRuleEntry('规则', '内容', ['规则']);
        expect(entry.position).toBe('after_char');
    });

    it('规则条目 constant 为 false（按需激活）', () => {
        const entry = createRuleEntry('规则', '内容', ['规则']);
        expect(entry.constant).toBe(false);
    });
});

// ═══════════════════════════════════════════════
// § 3  mergeEntries
// ═══════════════════════════════════════════════

describe('mergeEntries', () => {

    const baseEntries = [
        buildEntry({ uid: 1, keys: ['地点A'], content: '原始内容A', category: '地名' }),
        buildEntry({ uid: 2, keys: ['人物B'], content: '原始内容B', category: '人物' }),
    ];

    it('新条目被合并到结果中', () => {
        const incoming = [
            buildEntry({ uid: 3, keys: ['物品C'], content: '新条目C', category: '物品' }),
        ];
        const result = mergeEntries(baseEntries, incoming);
        const uids   = result.map(e => e.uid);
        expect(uids).toContain(3);
    });

    it('existing 条目被保留', () => {
        const incoming = [
            buildEntry({ uid: 3, keys: ['物品C'], content: '新C', category: '物品' }),
        ];
        const result = mergeEntries(baseEntries, incoming);
        const uids   = result.map(e => e.uid);
        expect(uids).toContain(1);
        expect(uids).toContain(2);
    });

    it('uid 冲突时 incoming 覆盖 existing', () => {
        const incoming = [
            buildEntry({ uid: 1, keys: ['地点A'], content: '更新后的内容A', category: '地名' }),
        ];
        const result  = mergeEntries(baseEntries, incoming);
        const entry1  = result.find(e => e.uid === 1);
        expect(entry1.content).toBe('更新后的内容A');
    });

    it('uid 冲突时不产生重复条目', () => {
        const incoming = [
            buildEntry({ uid: 1, keys: ['地点A'], content: '覆盖内容', category: '地名' }),
        ];
        const result = mergeEntries(baseEntries, incoming);
        const uid1s  = result.filter(e => e.uid === 1);
        expect(uid1s).toHaveLength(1);
    });

    it('空 incoming 返回 existing 的副本', () => {
        const result = mergeEntries(baseEntries, []);
        expect(result).toHaveLength(baseEntries.length);
    });

    it('空 existing 返回 incoming 的副本', () => {
        const incoming = [
            buildEntry({ uid: 10, keys: ['X'], content: 'X 内容', category: '物品' }),
        ];
        const result = mergeEntries([], incoming);
        expect(result).toHaveLength(1);
        expect(result[0].uid).toBe(10);
    });

    it('两者都为空返回空数组', () => {
        const result = mergeEntries([], []);
        expect(result).toHaveLength(0);
        expect(Array.isArray(result)).toBe(true);
    });

    it('不修改原始数组', () => {
        const incoming = [
            buildEntry({ uid: 99, keys: ['新'], content: '新内容', category: '物品' }),
        ];
        const origLen = baseEntries.length;
        mergeEntries(baseEntries, incoming);
        expect(baseEntries).toHaveLength(origLen);
    });
});

// ═══════════════════════════════════════════════
// § 4  sortEntries
// ═══════════════════════════════════════════════

describe('sortEntries', () => {

    const unsorted = [
        buildEntry({ uid: 1, keys: ['A'], content: '', priority: 5,  insertion_order: 300, category: '规则' }),
        buildEntry({ uid: 2, keys: ['B'], content: '', priority: 10, insertion_order: 100, category: '地名' }),
        buildEntry({ uid: 3, keys: ['C'], content: '', priority: 1,  insertion_order: 200, category: '人物' }),
        buildEntry({ uid: 4, keys: ['D'], content: '', priority: 8,  insertion_order: 50,  category: '地名' }),
    ];

    it('按 priority 降序排序', () => {
        const result = sortEntries(unsorted, 'priority');
        expect(result[0].priority).toBeGreaterThanOrEqual(result[1].priority);
        expect(result[1].priority).toBeGreaterThanOrEqual(result[2].priority);
        expect(result[2].priority).toBeGreaterThanOrEqual(result[3].priority);
    });

    it('按 insertion_order 升序排序', () => {
        const result = sortEntries(unsorted, 'insertion_order');
        expect(result[0].insertion_order).toBeLessThanOrEqual(result[1].insertion_order);
        expect(result[1].insertion_order).toBeLessThanOrEqual(result[2].insertion_order);
        expect(result[2].insertion_order).toBeLessThanOrEqual(result[3].insertion_order);
    });

    it('按 category 分组排序', () => {
        const result   = sortEntries(unsorted, 'category');
        const cats     = result.map(e => e.category);
        // 相同 category 的条目应相邻
        const geNames  = result.filter(e => e.category === '地名');
        const firstIdx = result.findIndex(e => e.category === '地名');
        const lastIdx  = result.map(e => e.category).lastIndexOf('地名');
        expect(lastIdx - firstIdx).toBe(geNames.length - 1);
    });

    it('排序不修改原始数组', () => {
        const copy     = [...unsorted];
        const origUids = copy.map(e => e.uid);
        sortEntries(unsorted, 'priority');
        expect(unsorted.map(e => e.uid)).toEqual(origUids);
    });

    it('返回新数组，不是原数组的引用', () => {
        const result = sortEntries(unsorted, 'priority');
        expect(result).not.toBe(unsorted);
    });

    it('空数组输入返回空数组', () => {
        expect(sortEntries([], 'priority')).toEqual([]);
    });

    it('单元素数组输入原样返回', () => {
        const single = [buildEntry({ uid: 1, keys: [], content: '', priority: 5 })];
        const result = sortEntries(single, 'priority');
        expect(result).toHaveLength(1);
        expect(result[0].uid).toBe(1);
    });

    it('未知排序字段不抛出错误', () => {
        expect(() => sortEntries(unsorted, 'unknown_field')).not.toThrow();
    });
});

// ═══════════════════════════════════════════════
// § 5  WB_ENTRY_SCHEMA 结构校验
// ═══════════════════════════════════════════════

describe('WB_ENTRY_SCHEMA 字段覆盖性', () => {

    it('所有工厂函数的输出均包含 schema 全部字段', () => {
        const factories = [
            () => createPlaceEntry('地点', '描述', ['地点']),
            () => createCharacterEntry('人物', '描述', ['人物']),
            () => createOrganizationEntry('组织', '描述', ['组织']),
            () => createItemEntry('物品', '描述', ['物品']),
            () => createHistoryEntry('历史', '描述', ['历史']),
            () => createRuleEntry('规则', '描述', ['规则']),
        ];

        for (const factory of factories) {
            const entry = factory();
            expect(hasAllSchemaFields(entry)).toBe(true);
        }
    });

    it('buildEntry 的输出符合 schema 字段类型约定', () => {
        const entry = buildEntry({
            uid:             1,
            keys:            ['测试'],
            secondary_keys:  [],
            content:         '内容',
            enabled:         true,
            insertion_order: 100,
            priority:        10,
            position:        'before_char',
            selective:       false,
            constant:        false,
            category:        '地名',
            extensions:      {},
        });

        expect(typeof entry.uid).toBe('number');
        expect(Array.isArray(entry.keys)).toBe(true);
        expect(Array.isArray(entry.secondary_keys)).toBe(true);
        expect(typeof entry.content).toBe('string');
        expect(typeof entry.enabled).toBe('boolean');
        expect(typeof entry.insertion_order).toBe('number');
        expect(typeof entry.priority).toBe('number');
        expect(typeof entry.position).toBe('string');
        expect(typeof entry.selective).toBe('boolean');
        expect(typeof entry.constant).toBe('boolean');
        expect(typeof entry.category).toBe('string');
        expect(typeof entry.extensions).toBe('object');
    });
});