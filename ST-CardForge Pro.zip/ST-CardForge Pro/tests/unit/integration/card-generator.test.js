/**
 * @file tests/integration/card-generator.test.js
 * @description CardGenerator 集成测试
 *              测试 CardGenerator ↔ AIEngine ↔ EventBus ↔ UndoManager ↔ IndexedDBStore
 *              全部外部依赖使用 vi.fn() Mock，验证模块间协作
 * @framework Vitest
 */

import {
    describe, it, expect, beforeEach, afterEach,
    vi, type MockedFunction,
} from 'vitest';
import { CardGenerator }  from '../../modules/01_card-generator/card-generator.js';
import { EventBus }       from '../../core/event-bus.js';
import { UndoManager }    from '../../utils/undo-manager.js';
import { EVENTS }         from '../../contracts.js';

// ─── Mock：AIEngine ──────────────────────────────

function makeMockAIEngine() {
    return {
        generateCard:    vi.fn(),
        enhanceField:    vi.fn(),
        estimateTokens:  vi.fn().mockReturnValue(100),
        generateStream:  vi.fn(),
    };
}

// ─── Mock：IndexedDBStore ────────────────────────

function makeMockDBStore() {
    const store = new Map();
    return {
        open:        vi.fn().mockResolvedValue(undefined),
        saveDraft:   vi.fn().mockImplementation(async (id, data) => {
            store.set(`draft_${id}`, data);
        }),
        loadDraft:   vi.fn().mockImplementation(async (id) => {
            return store.get(`draft_${id}`) ?? null;
        }),
        listDrafts:  vi.fn().mockResolvedValue([]),
        deleteDraft: vi.fn().mockResolvedValue(undefined),
        _store:      store,
    };
}

// ─── Mock：SettingsManager ───────────────────────

function makeMockSettings() {
    const data = {
        autoSaveDraft:   true,
        defaultLanguage: 'zh-CN',
    };
    return {
        get: vi.fn().mockImplementation((key, def) => data[key] ?? def),
        set: vi.fn(),
    };
}

// ─── 标准 AI 生成响应夹具 ────────────────────────

const MOCK_GENERATED_CARD = {
    name:        '夜幕骑士·卡尔',
    description: '一位来自北方的落魄贵族骑士，专注于寻找失踪的家族宝剑。',
    personality: '沉默寡言，行事谨慎，内心深处藏着难以释怀的愧疚。',
    scenario:    '卡尔在一家昏暗的酒馆中与{{user}}初次相遇，两人都在追查同一个线索。',
    first_mes:   '「……你也是来找雷文特家族宝剑的？」低沉的声音从阴影中传出。',
    mes_example: '<START>\n{{user}}: 你为什么要找这把剑？\n{{char}}: 「那是我对亡父的承诺。」',
    system_prompt:              '请扮演卡尔，保持低沉、谨慎的语调。',
    post_history_instructions:  '若涉及战斗，请细致描写骑士战斗风格。',
    tags:                       ['骑士', '悬疑', '北方', '奇幻'],
};

// ═══════════════════════════════════════════════
// § 0  测试环境准备
// ═══════════════════════════════════════════════

let generator;
let mockAI;
let mockDB;
let mockSettings;
let eventBus;
let undoManager;
let emittedEvents;

beforeEach(async () => {
    mockAI       = makeMockAIEngine();
    mockDB       = makeMockDBStore();
    mockSettings = makeMockSettings();
    eventBus     = new EventBus();
    undoManager  = new UndoManager(20);
    emittedEvents = [];

    // 监听所有事件，记录到 emittedEvents
    Object.values(EVENTS).forEach(eventName => {
        eventBus.on(eventName, (data) => {
            emittedEvents.push({ event: eventName, data });
        });
    });

    generator = new CardGenerator(mockAI, eventBus, mockSettings, undoManager, mockDB);
    await generator.init();
});

afterEach(() => {
    generator.destroy();
    vi.clearAllMocks();
    emittedEvents = [];
});

// ═══════════════════════════════════════════════
// § 1  初始化与生命周期
// ═══════════════════════════════════════════════

describe('CardGenerator · 初始化与生命周期', () => {

    it('init() 后 isReady() 返回 true', async () => {
        expect(generator.isReady()).toBe(true);
    });

    it('destroy() 后模块状态被清理', () => {
        generator.destroy();
        // destroy 后调用 isReady 不应抛出
        expect(() => generator.isReady()).not.toThrow();
    });

    it('getState() 返回合法的状态对象', () => {
        const state = generator.getState();
        expect(state).toBeDefined();
        expect(typeof state).toBe('object');
    });

    it('初始 getCardData() 返回空白 CardData 结构', () => {
        const card = generator.getCardData();
        expect(card).toBeDefined();
        expect(card.data ?? card).toBeDefined();
    });
});

// ═══════════════════════════════════════════════
// § 2  generateAll — 一键全生成
// ═══════════════════════════════════════════════

describe('CardGenerator · generateAll', () => {

    beforeEach(() => {
        // 配置 AI Mock 返回标准 JSON
        mockAI.generateCard.mockResolvedValue(
            JSON.stringify(MOCK_GENERATED_CARD)
        );
    });

    it('调用后 AI generateCard 被触发一次', async () => {
        await generator.generateAll('一位寻找家族宝剑的骑士', {});
        expect(mockAI.generateCard).toHaveBeenCalledTimes(1);
    });

    it('正确传递 userInput 给 AI', async () => {
        const desc = '一位寻找家族宝剑的骑士';
        await generator.generateAll(desc, {});
        const callArgs = mockAI.generateCard.mock.calls[0];
        // userInput 应包含用户描述
        const hasDesc = callArgs.some(arg =>
            typeof arg === 'string' && arg.includes(desc)
        );
        expect(hasDesc).toBe(true);
    });

    it('生成后 getField("name") 返回 AI 返回的名称', async () => {
        await generator.generateAll('骑士描述', {});
        expect(generator.getField('name')).toBe('夜幕骑士·卡尔');
    });

    it('生成后 description 字段被正确填充', async () => {
        await generator.generateAll('骑士描述', {});
        expect(generator.getField('description')).toBe(MOCK_GENERATED_CARD.description);
    });

    it('生成后 tags 字段被正确填充', async () => {
        await generator.generateAll('骑士描述', {});
        const tags = generator.getField('tags');
        expect(Array.isArray(tags)).toBe(true);
        expect(tags).toContain('骑士');
    });

    it('生成完成后发布 CARD_UPDATED 事件', async () => {
        await generator.generateAll('骑士描述', {});
        const cardUpdated = emittedEvents.filter(e => e.event === EVENTS.CARD_UPDATED);
        expect(cardUpdated.length).toBeGreaterThan(0);
    });

    it('生成过程中发布 LOADING_START，完成后发布 LOADING_END', async () => {
        await generator.generateAll('骑士描述', {});
        const starts = emittedEvents.filter(e => e.event === EVENTS.LOADING_START);
        const ends   = emittedEvents.filter(e => e.event === EVENTS.LOADING_END);
        expect(starts.length).toBeGreaterThan(0);
        expect(ends.length).toBeGreaterThan(0);
    });

    it('AI 返回非 JSON 时不抛出错误（鲁棒性）', async () => {
        mockAI.generateCard.mockResolvedValue('这不是 JSON 格式的回复，但程序不应崩溃。');
        await expect(generator.generateAll('任意描述', {})).resolves.not.toThrow();
    });

    it('AI 抛出错误时发布 ERROR 事件', async () => {
        mockAI.generateCard.mockRejectedValue(new Error('AI 服务不可用'));
        try {
            await generator.generateAll('骑士描述', {});
        } catch { /* 预期抛出 */ }
        const errors = emittedEvents.filter(e => e.event === EVENTS.ERROR);
        expect(errors.length).toBeGreaterThan(0);
    });

    it('AI 抛出错误时错误事件包含 module 信息', async () => {
        mockAI.generateCard.mockRejectedValue(new Error('超时'));
        try {
            await generator.generateAll('骑士描述', {});
        } catch { /* 预期 */ }
        const errorEvent = emittedEvents.find(e => e.event === EVENTS.ERROR);
        if (errorEvent) {
            expect(errorEvent.data).toHaveProperty('module');
        }
    });

    it('生成成功后 undoManager 有历史记录', async () => {
        await generator.generateAll('骑士描述', {});
        expect(undoManager.canUndo()).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 3  generateField — 单字段生成
// ═══════════════════════════════════════════════

describe('CardGenerator · generateField', () => {

    beforeEach(() => {
        mockAI.generateCard.mockResolvedValue(
            JSON.stringify({ description: '重新生成的角色描述内容，更加详细和生动。' })
        );
    });

    it('单字段生成后对应字段被更新', async () => {
        await generator.generateField('description', {});
        expect(generator.getField('description')).toBeTruthy();
    });

    it('单字段生成不影响其他字段', async () => {
        generator.setField('name', '原始角色名');
        await generator.generateField('description', {});
        expect(generator.getField('name')).toBe('原始角色名');
    });

    it('单字段生成后发布 CARD_FIELD_CHANGED 事件', async () => {
        await generator.generateField('description', {});
        const fieldChanged = emittedEvents.filter(e => e.event === EVENTS.CARD_FIELD_CHANGED);
        expect(fieldChanged.length).toBeGreaterThan(0);
    });

    it('CARD_FIELD_CHANGED 事件包含字段名', async () => {
        await generator.generateField('description', {});
        const event = emittedEvents.find(e => e.event === EVENTS.CARD_FIELD_CHANGED);
        if (event) {
            expect(JSON.stringify(event.data)).toContain('description');
        }
    });
});

// ═══════════════════════════════════════════════
// § 4  setField / getField — 字段编辑
// ═══════════════════════════════════════════════

describe('CardGenerator · setField / getField', () => {

    it('setField 后 getField 返回相同值', () => {
        generator.setField('name', '测试角色');
        expect(generator.getField('name')).toBe('测试角色');
    });

    it('setField 中文内容正确存储', () => {
        const cn = '这是一段包含中文、标点，以及换行\n的角色描述。';
        generator.setField('description', cn);
        expect(generator.getField('description')).toBe(cn);
    });

    it('setField 后发布 CARD_FIELD_CHANGED 事件', () => {
        generator.setField('personality', '内敛沉稳');
        const events = emittedEvents.filter(e => e.event === EVENTS.CARD_FIELD_CHANGED);
        expect(events.length).toBeGreaterThan(0);
    });

    it('setField 后 undoManager 记录快照', () => {
        generator.setField('name', '第一次修改');
        generator.setField('name', '第二次修改');
        expect(undoManager.canUndo()).toBe(true);
    });

    it('多次 setField 可以依次 undo', () => {
        generator.setField('name', '版本一');
        generator.setField('name', '版本二');
        generator.setField('name', '版本三');

        undoManager.undo();
        undoManager.undo();

        // undo 两次后应回到版本一
        // （具体行为取决于实现，验证不崩溃且 canUndo 状态正确）
        expect(typeof generator.getField('name')).toBe('string');
    });

    it('getField 获取不存在的字段返回 undefined 或 null 或空字符串', () => {
        const val = generator.getField('nonexistent_field');
        expect([undefined, null, '']).toContain(val);
    });

    it('setField 空字符串可以正常存储', () => {
        generator.setField('description', '先设置一个值');
        generator.setField('description', '');
        expect(generator.getField('description')).toBe('');
    });

    it('连续快速 setField 不丢失最后一次值', () => {
        for (let i = 0; i < 10; i++) {
            generator.setField('name', `角色名${i}`);
        }
        expect(generator.getField('name')).toBe('角色名9');
    });
});

// ═══════════════════════════════════════════════
// § 5  resetCard
// ═══════════════════════════════════════════════

describe('CardGenerator · resetCard', () => {

    it('resetCard 后所有字段恢复为默认值', () => {
        generator.setField('name', '有名字的角色');
        generator.setField('description', '有描述的角色');
        generator.resetCard();
        expect(generator.getField('name')).toBeFalsy();
        expect(generator.getField('description')).toBeFalsy();
    });

    it('resetCard 后发布 CARD_RESET 事件', () => {
        generator.resetCard();
        const resets = emittedEvents.filter(e => e.event === EVENTS.CARD_RESET);
        expect(resets.length).toBeGreaterThan(0);
    });

    it('resetCard 后仍可正常 setField', () => {
        generator.resetCard();
        expect(() => generator.setField('name', '重置后重新设置')).not.toThrow();
        expect(generator.getField('name')).toBe('重置后重新设置');
    });
});

// ═══════════════════════════════════════════════
// § 6  草稿管理
// ═══════════════════════════════════════════════

describe('CardGenerator · 草稿管理', () => {

    it('saveDraft 调用 dbStore.saveDraft', async () => {
        generator.setField('name', '需要保存的角色');
        await generator.saveDraft();
        expect(mockDB.saveDraft).toHaveBeenCalled();
    });

    it('saveDraft 传入的 cardData 包含当前字段值', async () => {
        generator.setField('name', '草稿角色名');
        await generator.saveDraft();

        const callArgs = mockDB.saveDraft.mock.calls[0];
        const savedData = callArgs[1];
        const dataStr = JSON.stringify(savedData);
        expect(dataStr).toContain('草稿角色名');
    });

    it('saveDraft 后发布 CARD_DRAFT_SAVED 事件', async () => {
        await generator.saveDraft();
        const draftSaved = emittedEvents.filter(e => e.event === EVENTS.CARD_DRAFT_SAVED);
        expect(draftSaved.length).toBeGreaterThan(0);
    });

    it('loadDraft 成功后字段值被还原', async () => {
        const draftData = { name: '从草稿恢复的角色', description: '草稿描述' };
        mockDB.loadDraft.mockResolvedValue({
            id:      'test-draft-id',
            cardData: { data: draftData },
            savedAt: new Date().toISOString(),
            name:    '从草稿恢复的角色',
        });

        await generator.loadDraft('test-draft-id');
        expect(generator.getField('name')).toBe('从草稿恢复的角色');
    });

    it('loadDraft 不存在的草稿不抛出错误', async () => {
        mockDB.loadDraft.mockResolvedValue(null);
        await expect(generator.loadDraft('nonexistent')).resolves.not.toThrow();
    });

    it('listDrafts 调用 dbStore.listDrafts', async () => {
        await generator.listDrafts();
        expect(mockDB.listDrafts).toHaveBeenCalled();
    });
});

// ═══════════════════════════════════════════════
// § 7  validate — 字段校验
// ═══════════════════════════════════════════════

describe('CardGenerator · validate', () => {

    it('空白卡片 validate 返回 errors 包含 name 错误', () => {
        const { errors } = generator.validate();
        expect(errors.some(e => e.toLowerCase().includes('name')
            || e.includes('名称') || e.includes('必填'))).toBe(true);
    });

    it('只填 name 时 validate 通过（无 error）', () => {
        generator.setField('name', '最小合法角色');
        const { errors } = generator.validate();
        expect(errors).toHaveLength(0);
    });

    it('validate 返回 { errors, warnings } 结构', () => {
        const result = generator.validate();
        expect(result).toHaveProperty('errors');
        expect(result).toHaveProperty('warnings');
        expect(Array.isArray(result.errors)).toBe(true);
        expect(Array.isArray(result.warnings)).toBe(true);
    });

    it('完整填写后 warnings 比空白时更少', () => {
        const emptyWarnings = generator.validate().warnings.length;

        generator.setField('name',        '完整角色');
        generator.setField('description', '完整描述文字');
        generator.setField('personality', '完整性格');
        generator.setField('first_mes',   '完整开场白');

        const fullWarnings = generator.validate().warnings.length;
        expect(fullWarnings).toBeLessThanOrEqual(emptyWarnings);
    });
});

// ═══════════════════════════════════════════════
// § 8  getState — 状态序列化
// ═══════════════════════════════════════════════

describe('CardGenerator · getState', () => {

    it('getState 包含当前字段值', () => {
        generator.setField('name', '状态测试角色');
        const state = generator.getState();
        expect(JSON.stringify(state)).toContain('状态测试角色');
    });

    it('getState 可被 JSON 序列化', () => {
        generator.setField('name', '序列化测试');
        expect(() => JSON.stringify(generator.getState())).not.toThrow();
    });

    it('连续调用 getState 结果一致（无副作用）', () => {
        generator.setField('name', '一致性测试');
        const s1 = JSON.stringify(generator.getState());
        const s2 = JSON.stringify(generator.getState());
        expect(s1).toBe(s2);
    });
});