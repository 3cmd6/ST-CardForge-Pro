/**
 * @file tests/integration/exporter.test.js
 * @description Exporter 集成测试
 *              验证导出器在 JSON / PNG / 批量导出 / 导入 / 预检等场景下的行为
 * @framework Vitest
 */

import {
    describe, it, expect, beforeEach, afterEach, vi,
} from 'vitest';
import { Exporter }  from '../../modules/09_exporter/exporter.js';
import { EventBus }  from '../../core/event-bus.js';
import { EVENTS }    from '../../contracts.js';

// ─── Mock 工厂 ───────────────────────────────────

function makeMockSettings() {
    return {
        get: vi.fn().mockImplementation((key, def) => {
            const overrides = {
                defaultExportFormat: 'ccv3_png',
                creator:             'TestCreator',
            };
            return overrides[key] ?? def;
        }),
        set: vi.fn(),
    };
}

// ─── 合法的 CardData 夹具 ────────────────────────

function makeCardData(overrides = {}) {
    return {
        spec:         'chara_card_v3',
        spec_version: '3.0',
        data: {
            name:                       '导出测试角色',
            description:                '这是一个用于测试导出功能的角色。',
            personality:                '沉静',
            scenario:                   '测试场景',
            first_mes:                  '这是开场白。',
            mes_example:                '<START>\n{{user}}: 你好\n{{char}}: 你好。',
            creator_notes:              '导出测试备注',
            system_prompt:              '请扮演测试角色',
            post_history_instructions:  '',
            alternate_greetings:        ['备用开场'],
            group_only_greetings:       [],
            tags:                       ['测试', '导出'],
            creator:                    'TestCreator',
            character_version:          '1.0.0',
            assets:                     [],
            extensions: {
                cardforge: { version: '1.0.0' }
            },
            ...overrides,
        }
    };
}

/** 生成一个最小 PNG 文件的 ArrayBuffer（1×1 像素透明 PNG）*/
function makeMinimalPNG() {
    const PNG_1x1 = new Uint8Array([
        137,80,78,71,13,10,26,10,   // 签名
        0,0,0,13,73,72,68,82,       // IHDR chunk 长度 + 类型
        0,0,0,1,0,0,0,1,            // 宽=1, 高=1
        8,2,0,0,0,144,119,83,222,   // 位深度8,色彩类型2,其他,CRC
        0,0,0,12,73,68,65,84,       // IDAT chunk
        8,215,99,248,207,192,0,0,0,2,0,1,
        226,33,188,51,              // IDAT CRC
        0,0,0,0,73,69,78,68,        // IEND chunk
        174,66,96,130               // IEND CRC
    ]);
    return PNG_1x1.buffer;
}

// ─── 测试环境变量 ────────────────────────────────

let exporter;
let mockSettings;
let eventBus;
let emittedEvents;

beforeEach(async () => {
    mockSettings  = makeMockSettings();
    eventBus      = new EventBus();
    emittedEvents = [];

    Object.values(EVENTS).forEach(name => {
        eventBus.on(name, data => emittedEvents.push({ event: name, data }));
    });

    // Mock URL.createObjectURL / revokeObjectURL（JSDOM 中不存在）
    global.URL.createObjectURL = vi.fn().mockReturnValue('blob:mock-url');
    global.URL.revokeObjectURL = vi.fn();

    // Mock document.createElement('a').click（下载触发）
    const mockAnchor = { href: '', download: '', click: vi.fn(), style: {} };
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
        if (tag === 'a') return mockAnchor;
        return document.createElement.wrappedMethod?.(tag) ?? {};
    });

    exporter = new Exporter(eventBus, mockSettings);
    await exporter.init();
});

afterEach(() => {
    exporter.destroy();
    vi.clearAllMocks();
    vi.restoreAllMocks();
    emittedEvents = [];
});

// ═══════════════════════════════════════════════
// § 1  初始化与生命周期
// ═══════════════════════════════════════════════

describe('Exporter · 初始化', () => {

    it('init 后 isReady() 返回 true', () => {
        expect(exporter.isReady()).toBe(true);
    });

    it('getState() 返回合法对象', () => {
        const state = exporter.getState();
        expect(state).toBeDefined();
        expect(typeof state).toBe('object');
    });

    it('destroy 不抛出错误', () => {
        expect(() => exporter.destroy()).not.toThrow();
    });
});

// ═══════════════════════════════════════════════
// § 2  preflightCheck — 导出前预检
// ═══════════════════════════════════════════════

describe('Exporter · preflightCheck', () => {

    it('完整 CardData 预检通过', () => {
        const { ok, errors } = exporter.preflightCheck(makeCardData());
        expect(ok).toBe(true);
        expect(errors).toHaveLength(0);
    });

    it('缺少 name 字段预检失败', () => {
        const card = makeCardData({ name: '' });
        const { ok, errors } = exporter.preflightCheck(card);
        expect(ok).toBe(false);
        expect(errors.some(e => e.includes('name') || e.includes('名称') || e.includes('必填'))).toBe(true);
    });

    it('null 输入预检失败', () => {
        const { ok } = exporter.preflightCheck(null);
        expect(ok).toBe(false);
    });

    it('预检返回 { ok, errors, warnings } 结构', () => {
        const result = exporter.preflightCheck(makeCardData());
        expect(result).toHaveProperty('ok');
        expect(result).toHaveProperty('errors');
        expect(result).toHaveProperty('warnings');
        expect(typeof result.ok).toBe('boolean');
        expect(Array.isArray(result.errors)).toBe(true);
        expect(Array.isArray(result.warnings)).toBe(true);
    });

    it('缺少推荐字段产生 warnings 不产生 errors', () => {
        const card = makeCardData({
            description: '',
            personality: '',
            first_mes:   '',
        });
        const { ok, errors, warnings } = exporter.preflightCheck(card);
        expect(ok).toBe(true);       // 不影响导出
        expect(errors).toHaveLength(0);
        expect(warnings.length).toBeGreaterThan(0);
    });

    it('tags 超过合理数量产生 warning', () => {
        const card = makeCardData({
            tags: Array.from({ length: 30 }, (_, i) => `标签${i}`)
        });
        const { warnings } = exporter.preflightCheck(card);
        // 超多 tag 应有警告
        expect(typeof warnings).toBe('object');
    });
});

// ═══════════════════════════════════════════════
// § 3  exportJSON — JSON 导出
// ═══════════════════════════════════════════════

describe('Exporter · exportJSON', () => {

    it('exportJSON(v2) 不抛出错误', async () => {
        await expect(exporter.exportJSON(makeCardData(), 'v2')).resolves.not.toThrow();
    });

    it('exportJSON(v3) 不抛出错误', async () => {
        await expect(exporter.exportJSON(makeCardData(), 'v3')).resolves.not.toThrow();
    });

    it('exportJSON 后发布 EXPORT_STARTED 事件', async () => {
        await exporter.exportJSON(makeCardData(), 'v3');
        const started = emittedEvents.filter(e => e.event === EVENTS.EXPORT_STARTED);
        expect(started.length).toBeGreaterThan(0);
    });

    it('exportJSON 成功后发布 EXPORT_READY 事件', async () => {
        await exporter.exportJSON(makeCardData(), 'v3');
        const ready = emittedEvents.filter(e => e.event === EVENTS.EXPORT_READY);
        expect(ready.length).toBeGreaterThan(0);
    });

    it('EXPORT_READY 事件不包含 EXPORT_FAILED', async () => {
        await exporter.exportJSON(makeCardData(), 'v3');
        const failed = emittedEvents.filter(e => e.event === EVENTS.EXPORT_FAILED);
        expect(failed).toHaveLength(0);
    });

    it('exportJSON(v2) 导出的数据包含 spec: chara_card_v2', async () => {
        let exportedData = null;
        eventBus.on(EVENTS.EXPORT_READY, (data) => { exportedData = data; });
        await exporter.exportJSON(makeCardData(), 'v2');
        if (exportedData) {
            const dataStr = JSON.stringify(exportedData);
            expect(dataStr).toContain('chara_card_v2');
        }
    });

    it('exportJSON(v3) 导出的数据包含 spec: chara_card_v3', async () => {
        let exportedData = null;
        eventBus.on(EVENTS.EXPORT_READY, (data) => { exportedData = data; });
        await exporter.exportJSON(makeCardData(), 'v3');
        if (exportedData) {
            const dataStr = JSON.stringify(exportedData);
            expect(dataStr).toContain('chara_card_v3');
        }
    });

    it('exportJSON null cardData 发布 EXPORT_FAILED 或抛出错误', async () => {
        try {
            await exporter.exportJSON(null, 'v3');
        } catch { /* 可以抛出 */ }
        const failed = emittedEvents.filter(e => e.event === EVENTS.EXPORT_FAILED);
        const errors = emittedEvents.filter(e => e.event === EVENTS.ERROR);
        expect(failed.length + errors.length).toBeGreaterThan(0);
    });

    it('导出文件名包含角色名称', async () => {
        const mockAnchor = { href: '', download: '', click: vi.fn(), style: {} };
        let capturedFilename = '';
        Object.defineProperty(mockAnchor, 'download', {
            set: (val) => { capturedFilename = val; },
            get: () => capturedFilename,
        });
        document.createElement.mockReturnValue(mockAnchor);

        await exporter.exportJSON(makeCardData(), 'v3');

        if (capturedFilename) {
            expect(capturedFilename).toContain('导出测试角色');
        }
    });
});

// ═══════════════════════════════════════════════
// § 4  exportPNG — PNG 导出
// ═══════════════════════════════════════════════

describe('Exporter · exportPNG', () => {

    it('exportPNG(v3) 不抛出错误', async () => {
        const pngBuffer = makeMinimalPNG();
        const mockFile  = new File([pngBuffer], 'test.png', { type: 'image/png' });
        await expect(
            exporter.exportPNG(makeCardData(), mockFile, 'v3')
        ).resolves.not.toThrow();
    });

    it('exportPNG(both) 不抛出错误', async () => {
        const pngBuffer = makeMinimalPNG();
        const mockFile  = new File([pngBuffer], 'test.png', { type: 'image/png' });
        await expect(
            exporter.exportPNG(makeCardData(), mockFile, 'both')
        ).resolves.not.toThrow();
    });

    it('exportPNG 后发布 EXPORT_READY 事件', async () => {
        const pngBuffer = makeMinimalPNG();
        const mockFile  = new File([pngBuffer], 'test.png', { type: 'image/png' });
        await exporter.exportPNG(makeCardData(), mockFile, 'v3');
        const ready = emittedEvents.filter(e => e.event === EVENTS.EXPORT_READY);
        expect(ready.length).toBeGreaterThan(0);
    });

    it('exportPNG 无图像文件时不崩溃', async () => {
        try {
            await exporter.exportPNG(makeCardData(), null, 'v3');
        } catch { /* 预期可能报错 */ }
        // 核心：不崩溃，不无响应
        expect(true).toBe(true);
    });

    it('exportPNG 非 PNG 文件不崩溃', async () => {
        const textFile = new File(['not a png'], 'test.txt', { type: 'text/plain' });
        try {
            await exporter.exportPNG(makeCardData(), textFile, 'v3');
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 5  importFromJSON — JSON 导入
// ═══════════════════════════════════════════════

describe('Exporter · importFromJSON', () => {

    it('导入合法 CCv2 JSON 文件不抛出错误', async () => {
        const content = JSON.stringify({
            spec: 'chara_card_v2', spec_version: '2.0',
            data: { name: '导入角色V2', description: '描述' }
        });
        const file = new File([content], 'card.json', { type: 'application/json' });
        await expect(exporter.importFromJSON(file)).resolves.not.toThrow();
    });

    it('导入合法 CCv3 JSON 文件不抛出错误', async () => {
        const content = JSON.stringify(makeCardData());
        const file    = new File([content], 'card.json', { type: 'application/json' });
        await expect(exporter.importFromJSON(file)).resolves.not.toThrow();
    });

    it('importFromJSON 返回包含 cardData 的对象', async () => {
        const content = JSON.stringify(makeCardData());
        const file    = new File([content], 'card.json', { type: 'application/json' });
        const result  = await exporter.importFromJSON(file);
        expect(result).toBeDefined();
    });

    it('importFromJSON 返回的 cardData 包含正确 name', async () => {
        const content = JSON.stringify(makeCardData({ name: '精确匹配角色' }));
        const file    = new File([content], 'card.json', { type: 'application/json' });
        const result  = await exporter.importFromJSON(file);
        if (result?.data?.name ?? result?.name) {
            const name = result?.data?.name ?? result?.name;
            expect(name).toBe('精确匹配角色');
        }
    });

    it('导入非法 JSON 内容发布 ERROR 事件或抛出错误', async () => {
        const file = new File(['这不是JSON'], 'bad.json', { type: 'application/json' });
        try {
            await exporter.importFromJSON(file);
        } catch { /* 预期 */ }
        const errors = emittedEvents.filter(
            e => e.event === EVENTS.ERROR || e.event === EVENTS.EXPORT_FAILED
        );
        expect(errors.length).toBeGreaterThan(0);
    });

    it('导入 null 不崩溃', async () => {
        try {
            await exporter.importFromJSON(null);
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 6  importFromPNG — PNG 导入
// ═══════════════════════════════════════════════

describe('Exporter · importFromPNG', () => {

    it('importFromPNG 处理无元数据的 PNG 不崩溃', async () => {
        const pngBuffer = makeMinimalPNG();
        const file      = new File([pngBuffer], 'no-meta.png', { type: 'image/png' });
        try {
            await exporter.importFromPNG(file);
        } catch { /* 可能返回 null 或抛出 */ }
        expect(true).toBe(true);
    });

    it('importFromPNG 非 PNG 文件不崩溃', async () => {
        const file = new File(['random data'], 'fake.png', { type: 'image/png' });
        try {
            await exporter.importFromPNG(file);
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });

    it('importFromPNG null 不崩溃', async () => {
        try {
            await exporter.importFromPNG(null);
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 7  resizeCover — 封面处理
// ═══════════════════════════════════════════════

describe('Exporter · resizeCover', () => {

    it('resizeCover 处理合法图片文件不崩溃', async () => {
        const pngBuffer = makeMinimalPNG();
        const file      = new File([pngBuffer], 'cover.png', { type: 'image/png' });

        // Mock HTMLCanvasElement（JSDOM 不支持 canvas）
        const mockCanvas = {
            width:      0,
            height:     0,
            getContext: vi.fn().mockReturnValue({
                drawImage: vi.fn(),
            }),
            toBlob: vi.fn().mockImplementation((cb) => {
                cb(new Blob(['fake image'], { type: 'image/png' }));
            }),
        };
        vi.spyOn(document, 'createElement').mockImplementation((tag) => {
            if (tag === 'canvas') return mockCanvas;
            if (tag === 'img')    return { src: '', onload: null, onerror: null };
            if (tag === 'a')      return { href: '', download: '', click: vi.fn() };
            return {};
        });

        try {
            await exporter.resizeCover(file);
        } catch { /* JSDOM 环境限制可能失败 */ }
        expect(true).toBe(true);
    });

    it('resizeCover null 不崩溃', async () => {
        try {
            await exporter.resizeCover(null);
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 8  事件完整性校验
// ═══════════════════════════════════════════════

describe('Exporter · 事件协议', () => {

    it('成功导出时 EXPORT_STARTED 早于 EXPORT_READY', async () => {
        const sequence = [];
        eventBus.on(EVENTS.EXPORT_STARTED, () => sequence.push('START'));
        eventBus.on(EVENTS.EXPORT_READY,   () => sequence.push('READY'));

        await exporter.exportJSON(makeCardData(), 'v3');

        if (sequence.includes('START') && sequence.includes('READY')) {
            expect(sequence.indexOf('START')).toBeLessThan(sequence.indexOf('READY'));
        }
    });

    it('失败导出时 EXPORT_STARTED 早于 EXPORT_FAILED', async () => {
        const sequence = [];
        eventBus.on(EVENTS.EXPORT_STARTED, () => sequence.push('START'));
        eventBus.on(EVENTS.EXPORT_FAILED,  () => sequence.push('FAILED'));

        try {
            await exporter.exportJSON(null, 'v3');
        } catch { /* 预期 */ }

        if (sequence.includes('START') && sequence.includes('FAILED')) {
            expect(sequence.indexOf('START')).toBeLessThan(sequence.indexOf('FAILED'));
        }
    });

    it('导出期间不同时发布 EXPORT_READY 和 EXPORT_FAILED', async () => {
        await exporter.exportJSON(makeCardData(), 'v3');
        const hasReady  = emittedEvents.some(e => e.event === EVENTS.EXPORT_READY);
        const hasFailed = emittedEvents.some(e => e.event === EVENTS.EXPORT_FAILED);
        // 成功和失败事件不应同时出现
        expect(hasReady && hasFailed).toBe(false);
    });
});

// ═══════════════════════════════════════════════
// § 9  batchExport — 批量导出
// ═══════════════════════════════════════════════

describe('Exporter · batchExport', () => {

    const cards = [
        makeCardData({ name: '角色甲' }),
        makeCardData({ name: '角色乙' }),
        makeCardData({ name: '角色丙' }),
    ];

    it('batchExport 不抛出错误', async () => {
        await expect(exporter.batchExport(cards, 'json_v3')).resolves.not.toThrow();
    });

    it('batchExport 后发布 EXPORT_READY 事件', async () => {
        await exporter.batchExport(cards, 'json_v3');
        const ready = emittedEvents.filter(e => e.event === EVENTS.EXPORT_READY);
        expect(ready.length).toBeGreaterThan(0);
    });

    it('batchExport 空数组不崩溃', async () => {
        await expect(exporter.batchExport([], 'json_v3')).resolves.not.toThrow();
    });

    it('batchExport null 不崩溃', async () => {
        try {
            await exporter.batchExport(null, 'json_v3');
        } catch { /* 预期 */ }
        expect(true).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 10  _generateFilename — 文件名生成
// ═══════════════════════════════════════════════

describe('Exporter · 文件名生成', () => {

    it('生成的文件名包含角色名', () => {
        const card     = makeCardData({ name: '星空猎人' });
        // 通过反射或公开 API 测试（若已暴露）
        if (typeof exporter._generateFilename === 'function') {
            const name = exporter._generateFilename(card, 'json_v3');
            expect(name).toContain('星空猎人');
        }
    });

    it('生成的文件名包含正确扩展名', () => {
        if (typeof exporter._generateFilename === 'function') {
            const jsonName = exporter._generateFilename(makeCardData(), 'json_v3');
            const pngName  = exporter._generateFilename(makeCardData(), 'ccv3_png');
            expect(jsonName.endsWith('.json')).toBe(true);
            expect(pngName.endsWith('.png')).toBe(true);
        }
    });

    it('角色名含特殊字符时文件名可安全使用', () => {
        if (typeof exporter._generateFilename === 'function') {
            const card = makeCardData({ name: '角色/名称:特殊*字符?' });
            const name = exporter._generateFilename(card, 'json_v3');
            // 文件名不应包含 / : * ? 等非法字符
            expect(name).not.toMatch(/[\/\\:*?"<>|]/);
        }
    });
});