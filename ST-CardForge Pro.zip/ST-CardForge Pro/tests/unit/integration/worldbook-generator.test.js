/**
 * @file tests/integration/worldbook-generator.test.js
 * @description WorldBookGenerator 集成测试
 *              验证世界书生成、条目管理、关键词处理、序列化的模块间协作
 * @framework Vitest
 */

import {
    describe, it, expect, beforeEach, afterEach, vi,
} from 'vitest';
import { WorldBookGenerator } from '../../modules/02_world-book/worldbook-generator.js';
import { EventBus }           from '../../core/event-bus.js';
import { EVENTS, WB_ENTRY_SCHEMA } from '../../contracts.js';

// ─── Mock 工厂 ───────────────────────────────────

function makeMockAIEngine() {
    return {
        generateWorldBook: vi.fn(),
        generateCard:      vi.fn(),
        estimateTokens:    vi.fn().mockReturnValue(50),
    };
}

function makeMockSettings() {
    return {
        get: vi.fn().mockImplementation((key, def) => def),
        set: vi.fn(),
    };
}

// ─── AI 返回的条目夹具 ───────────────────────────

function makeMockEntry(overrides = {}) {
    return {
        keys:            ['测试关键词'],
        secondary_keys:  [],
        content:         '这是 AI 生成的条目内容，描述了世界观中的某个元素。',
        enabled:         true,
        insertion_order: 100,
        priority:        10,
        position:        'before_char',
        category:        '地名',
        ...overrides,
    };
}

// ─── 测试环境变量 ────────────────────────────────

let generator;
let mockAI;
let mockSettings;
let eventBus;
let emittedEvents;

beforeEach(async () => {
    mockAI        = makeMockAIEngine();
    mockSettings  = makeMockSettings();
    eventBus      = new EventBus();
    emittedEvents = [];

    Object.values(EVENTS).forEach(name => {
        eventBus.on(name, data => emittedEvents.push({ event: name, data }));
    });

    generator = new WorldBookGenerator(mockAI, eventBus, mockSettings);
    await generator.init();
});

afterEach(() => {
    generator.destroy();
    vi.clearAllMocks();
    emittedEvents = [];
});

// ═══════════════════════════════════════════════
// § 1  初始化与生命周期
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · 初始化', () => {

    it('init 后 isReady() 返回 true', () => {
        expect(generator.isReady()).toBe(true);
    });

    it('初始状态 getEntries() 返回空数组', () => {
        expect(generator.getEntries()).toHaveLength(0);
    });

    it('getState() 返回合法对象', () => {
        const state = generator.getState();
        expect(state).toBeDefined();
        expect(typeof state).toBe('object');
    });

    it('destroy 后不抛出错误', () => {
        expect(() => generator.destroy()).not.toThrow();
    });
});

// ═══════════════════════════════════════════════
// § 2  generateFromCard — 基于角色卡生成
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · generateFromCard', () => {

    const mockCardData = {
        data: {
            name:        '艾拉·星辰',
            description: '来自星界学院的魔法师，与星界学院、熔岩山、碎星城都有关联。',
            scenario:    '在星界学院的图书馆中',
        }
    };

    beforeEach(() => {
        mockAI.generateWorldBook.mockResolvedValue(
            JSON.stringify({
                entries: [
                    makeMockEntry({ keys: ['星界学院'], content: '星界学院描述', category: '地名' }),
                    makeMockEntry({ keys: ['艾拉'], content: '人物背景', category: '人物' }),
                    makeMockEntry({ keys: ['魔法规则'], content: '魔法系统规则', category: '规则' }),
                ]
            })
        );
    });

    it('调用后 AI generateWorldBook 被触发', async () => {
        await generator.generateFromCard(mockCardData, ['地名', '人物', '规则']);
        expect(mockAI.generateWorldBook).toHaveBeenCalled();
    });

    it('传递的分类列表被包含在调用参数中', async () => {
        const categories = ['地名', '人物'];
        await generator.generateFromCard(mockCardData, categories);
        const callArgs = mockAI.generateWorldBook.mock.calls[0];
        const argsStr  = JSON.stringify(callArgs);
        expect(argsStr).toContain('地名');
        expect(argsStr).toContain('人物');
    });

    it('生成后条目被添加到 getEntries()', async () => {
        await generator.generateFromCard(mockCardData, ['地名', '人物', '规则']);
        expect(generator.getEntries().length).toBeGreaterThan(0);
    });

    it('生成完成后发布 WB_UPDATED 事件', async () => {
        await generator.generateFromCard(mockCardData, ['地名']);
        const updates = emittedEvents.filter(e => e.event === EVENTS.WB_UPDATED);
        expect(updates.length).toBeGreaterThan(0);
    });

    it('生成过程发布 LOADING_START 和 LOADING_END', async () => {
        await generator.generateFromCard(mockCardData, ['地名']);
        const starts = emittedEvents.filter(e => e.event === EVENTS.LOADING_START);
        const ends   = emittedEvents.filter(e => e.event === EVENTS.LOADING_END);
        expect(starts.length).toBeGreaterThan(0);
        expect(ends.length).toBeGreaterThan(0);
    });

    it('AI 返回非法 JSON 时不崩溃', async () => {
        mockAI.generateWorldBook.mockResolvedValue('这是纯文本，不是JSON');
        await expect(
            generator.generateFromCard(mockCardData, ['地名'])
        ).resolves.not.toThrow();
    });

    it('AI 抛出错误时发布 ERROR 事件', async () => {
        mockAI.generateWorldBook.mockRejectedValue(new Error('AI 超时'));
        try {
            await generator.generateFromCard(mockCardData, ['地名']);
        } catch { /* 预期 */ }
        const errors = emittedEvents.filter(e => e.event === EVENTS.ERROR);
        expect(errors.length).toBeGreaterThan(0);
    });

    it('空分类列表时不调用 AI（或仅调用 0 次）', async () => {
        await generator.generateFromCard(mockCardData, []);
        // 空分类无需生成
        expect(mockAI.generateWorldBook.mock.calls.length).toBe(0);
    });
});

// ═══════════════════════════════════════════════
// § 3  addEntry / updateEntry / removeEntry
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · CRUD 操作', () => {

    it('addEntry 返回 uid', () => {
        const uid = generator.addEntry(makeMockEntry());
        expect(typeof uid).toBe('number');
        expect(uid).toBeGreaterThanOrEqual(0);
    });

    it('addEntry 后 getEntries() 包含该条目', () => {
        generator.addEntry(makeMockEntry({ keys: ['新条目关键词'] }));
        const entries = generator.getEntries();
        expect(entries.some(e => e.keys.includes('新条目关键词'))).toBe(true);
    });

    it('addEntry 后发布 WB_ENTRY_ADDED 事件', () => {
        generator.addEntry(makeMockEntry());
        const added = emittedEvents.filter(e => e.event === EVENTS.WB_ENTRY_ADDED);
        expect(added.length).toBeGreaterThan(0);
    });

    it('连续 addEntry 各自拥有唯一 uid', () => {
        const uid1 = generator.addEntry(makeMockEntry({ keys: ['A'] }));
        const uid2 = generator.addEntry(makeMockEntry({ keys: ['B'] }));
        const uid3 = generator.addEntry(makeMockEntry({ keys: ['C'] }));
        expect(new Set([uid1, uid2, uid3]).size).toBe(3);
    });

    it('updateEntry 更新指定 uid 的字段', () => {
        const uid = generator.addEntry(makeMockEntry({ content: '原始内容' }));
        generator.updateEntry(uid, { content: '更新后内容' });
        const entry = generator.getEntries().find(e => e.uid === uid);
        expect(entry.content).toBe('更新后内容');
    });

    it('updateEntry 不影响其他字段', () => {
        const uid = generator.addEntry(
            makeMockEntry({ keys: ['原关键词'], content: '原内容' })
        );
        generator.updateEntry(uid, { content: '新内容' });
        const entry = generator.getEntries().find(e => e.uid === uid);
        expect(entry.keys).toContain('原关键词');
    });

    it('updateEntry 不存在的 uid 不抛出错误', () => {
        expect(() => generator.updateEntry(99999, { content: '不存在的 uid' })).not.toThrow();
    });

    it('removeEntry 后条目从 getEntries() 中消失', () => {
        const uid = generator.addEntry(makeMockEntry());
        generator.removeEntry(uid);
        const remaining = generator.getEntries().filter(e => e.uid === uid);
        expect(remaining).toHaveLength(0);
    });

    it('removeEntry 后发布 WB_ENTRY_REMOVED 事件', () => {
        const uid = generator.addEntry(makeMockEntry());
        emittedEvents = [];
        generator.removeEntry(uid);
        const removed = emittedEvents.filter(e => e.event === EVENTS.WB_ENTRY_REMOVED);
        expect(removed.length).toBeGreaterThan(0);
    });

    it('removeEntry 不存在的 uid 不抛出错误', () => {
        expect(() => generator.removeEntry(99999)).not.toThrow();
    });
});

// ═══════════════════════════════════════════════
// § 4  getEntriesByCategory
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · getEntriesByCategory', () => {

    beforeEach(() => {
        generator.addEntry(makeMockEntry({ keys: ['地点A'], category: '地名' }));
        generator.addEntry(makeMockEntry({ keys: ['地点B'], category: '地名' }));
        generator.addEntry(makeMockEntry({ keys: ['人物A'], category: '人物' }));
        generator.addEntry(makeMockEntry({ keys: ['规则A'], category: '规则' }));
    });

    it('返回指定分类的所有条目', () => {
        const places = generator.getEntriesByCategory('地名');
        expect(places).toHaveLength(2);
        expect(places.every(e => e.category === '地名')).toBe(true);
    });

    it('不返回其他分类的条目', () => {
        const places = generator.getEntriesByCategory('地名');
        expect(places.some(e => e.category === '人物')).toBe(false);
    });

    it('不存在的分类返回空数组', () => {
        const result = generator.getEntriesByCategory('不存在的分类');
        expect(result).toHaveLength(0);
        expect(Array.isArray(result)).toBe(true);
    });
});

// ═══════════════════════════════════════════════
// § 5  clearEntries
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · clearEntries', () => {

    it('clearEntries 后 getEntries() 返回空数组', () => {
        generator.addEntry(makeMockEntry({ keys: ['A'] }));
        generator.addEntry(makeMockEntry({ keys: ['B'] }));
        generator.clearEntries();
        expect(generator.getEntries()).toHaveLength(0);
    });

    it('clearEntries 后可以重新添加条目', () => {
        generator.addEntry(makeMockEntry());
        generator.clearEntries();
        const uid = generator.addEntry(makeMockEntry({ keys: ['清空后重加'] }));
        expect(typeof uid).toBe('number');
        expect(generator.getEntries()).toHaveLength(1);
    });
});

// ═══════════════════════════════════════════════
// § 6  toJSON / fromJSON — 序列化
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · toJSON / fromJSON', () => {

    beforeEach(() => {
        generator.addEntry(makeMockEntry({ keys: ['条目A'], category: '地名', content: 'A内容' }));
        generator.addEntry(makeMockEntry({ keys: ['条目B'], category: '人物', content: 'B内容' }));
    });

    it('toJSON 返回对象包含 entries 数组', () => {
        const json = generator.toJSON();
        expect(json).toHaveProperty('entries');
        expect(Array.isArray(json.entries)).toBe(true);
    });

    it('toJSON 导出的条目数与内部一致', () => {
        const json    = generator.toJSON();
        const entries = generator.getEntries();
        expect(json.entries).toHaveLength(entries.length);
    });

    it('toJSON 可被 JSON.stringify 序列化', () => {
        expect(() => JSON.stringify(generator.toJSON())).not.toThrow();
    });

    it('fromJSON 导入后条目正确恢复', () => {
        const json = generator.toJSON();
        generator.clearEntries();
        generator.fromJSON(json);
        expect(generator.getEntries().length).toBeGreaterThan(0);
    });

    it('fromJSON 后条目内容与导出前一致', () => {
        const json = generator.toJSON();
        generator.clearEntries();
        generator.fromJSON(json);
        const entries   = generator.getEntries();
        const entryKeys = entries.flatMap(e => e.keys);
        expect(entryKeys).toContain('条目A');
        expect(entryKeys).toContain('条目B');
    });

    it('fromJSON 空对象不抛出错误', () => {
        expect(() => generator.fromJSON({})).not.toThrow();
    });

    it('fromJSON null 不抛出错误', () => {
        expect(() => generator.fromJSON(null)).not.toThrow();
    });

    it('fromJSON 后发布 WB_UPDATED 事件', () => {
        const json = generator.toJSON();
        generator.clearEntries();
        emittedEvents = [];
        generator.fromJSON(json);
        const updates = emittedEvents.filter(e => e.event === EVENTS.WB_UPDATED);
        expect(updates.length).toBeGreaterThan(0);
    });

    it('序列化 → 反序列化后 uid 保持唯一', () => {
        const json = generator.toJSON();
        generator.clearEntries();
        generator.fromJSON(json);
        const uids    = generator.getEntries().map(e => e.uid);
        const unique  = new Set(uids);
        expect(unique.size).toBe(uids.length);
    });
});

// ═══════════════════════════════════════════════
// § 7  bulkImport
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · bulkImport', () => {

    const importJson = {
        name:    '导入的世界书',
        entries: [
            makeMockEntry({ uid: 101, keys: ['导入A'], content: '导入内容A' }),
            makeMockEntry({ uid: 102, keys: ['导入B'], content: '导入内容B' }),
            makeMockEntry({ uid: 103, keys: ['导入C'], content: '导入内容C' }),
        ]
    };

    it('bulkImport 后条目被加载', async () => {
        await generator.bulkImport(importJson);
        expect(generator.getEntries().length).toBeGreaterThanOrEqual(3);
    });

    it('bulkImport 后可以通过关键词找到导入的条目', async () => {
        await generator.bulkImport(importJson);
        const entries = generator.getEntries();
        const keys    = entries.flatMap(e => e.keys);
        expect(keys).toContain('导入A');
    });

    it('bulkImport 不合法格式不崩溃', async () => {
        await expect(generator.bulkImport(null)).resolves.not.toThrow();
        await expect(generator.bulkImport('非对象')).resolves.not.toThrow();
        await expect(generator.bulkImport({ entries: 'wrong' })).resolves.not.toThrow();
    });

    it('bulkImport 后发布 WB_UPDATED 事件', async () => {
        emittedEvents = [];
        await generator.bulkImport(importJson);
        const updates = emittedEvents.filter(e => e.event === EVENTS.WB_UPDATED);
        expect(updates.length).toBeGreaterThan(0);
    });
});

// ═══════════════════════════════════════════════
// § 8  条目结构完整性校验
// ═══════════════════════════════════════════════

describe('WorldBookGenerator · 条目结构完整性', () => {

    it('addEntry 后的条目包含 WB_ENTRY_SCHEMA 所有字段', () => {
        generator.addEntry(makeMockEntry());
        const entry = generator.getEntries()[0];
        for (const key of Object.keys(WB_ENTRY_SCHEMA)) {
            expect(entry).toHaveProperty(key);
        }
    });

    it('uid 自动分配为数字类型', () => {
        const uid = generator.addEntry(makeMockEntry());
        expect(typeof uid).toBe('number');
    });

    it('多次 addEntry 后每个条目的 uid 字段类型均为 number', () => {
        generator.addEntry(makeMockEntry({ keys: ['X'] }));
        generator.addEntry(makeMockEntry({ keys: ['Y'] }));
        generator.addEntry(makeMockEntry({ keys: ['Z'] }));
        for (const entry of generator.getEntries()) {
            expect(typeof entry.uid).toBe('number');
        }
    });
});