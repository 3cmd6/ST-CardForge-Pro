/**
 * @file tests/unit/token-counter.test.js
 * @description token-counter.js 单元测试
 * @framework Vitest
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
    estimateTokens,
    estimateCardTokens,
    checkBudget,
    checkFieldBudget,
    truncateToLimit,
    formatTokenCount,
    getTokenLevelColor,
    TOKEN_LIMITS,
    FIELD_TOKEN_LIMITS,
} from '../../utils/token-counter.js';

// ═══════════════════════════════════════════════
// § 1  estimateTokens
// ═══════════════════════════════════════════════

describe('estimateTokens', () => {

    it('空字符串返回 0', () => {
        expect(estimateTokens('')).toBe(0);
    });

    it('null/undefined 返回 0', () => {
        expect(estimateTokens(null)).toBe(0);
        expect(estimateTokens(undefined)).toBe(0);
    });

    it('纯英文文本估算', () => {
        // "Hello world" ≈ 2 tokens
        const result = estimateTokens('Hello world');
        expect(result).toBeGreaterThan(0);
        expect(result).toBeLessThan(10);
    });

    it('纯中文文本估算', () => {
        // "你好世界" 4个中文字符 → 约 3 tokens (4/1.5 ≈ 2.67)
        const result = estimateTokens('你好世界');
        expect(result).toBeGreaterThan(0);
        expect(result).toBeLessThanOrEqual(5);
    });

    it('中英混合文本估算', () => {
        const result = estimateTokens('Hello 你好 World 世界');
        expect(result).toBeGreaterThan(2);
        expect(result).toBeLessThan(20);
    });

    it('长中文文本 Token 数随长度增长', () => {
        const short  = estimateTokens('这是一段短文本。');
        const medium = estimateTokens('这是一段较长的中文文本，包含了更多的汉字和标点符号。');
        const long   = estimateTokens('这是一段非常长的中文文本，'.repeat(10));
        expect(short).toBeLessThan(medium);
        expect(medium).toBeLessThan(long);
    });

    it('长英文文本 Token 数随长度增长', () => {
        const short  = estimateTokens('Short text');
        const medium = estimateTokens('This is a medium length English sentence with some words.');
        const long   = estimateTokens('This is a very long English text. '.repeat(10));
        expect(short).toBeLessThan(medium);
        expect(medium).toBeLessThan(long);
    });

    it('不同模型参数不影响核心结果（启发式兜底）', () => {
        const r1 = estimateTokens('Hello world', 'auto');
        const r2 = estimateTokens('Hello world', 'gpt-4');
        const r3 = estimateTokens('Hello world', 'claude-3');
        expect(r1).toBe(r2);
        expect(r2).toBe(r3);
    });

    it('纯标点符号文本', () => {
        const result = estimateTokens('，。！？；：""''【】');
        expect(result).toBeGreaterThan(0);
    });

    it('纯空白字符', () => {
        const result = estimateTokens('   \n\t  ');
        expect(result).toBeGreaterThanOrEqual(0);
    });

    it('带换行的多行文本', () => {
        const multiline = '第一行\n第二行\n第三行\n第四行';
        const result = estimateTokens(multiline);
        expect(result).toBeGreaterThan(0);
    });

    it('返回值始终为正整数', () => {
        const texts = ['a', '中', 'abc', '一二三', 'mixed混合text'];
        for (const t of texts) {
            const r = estimateTokens(t);
            expect(r).toBeGreaterThan(0);
            expect(Number.isInteger(r)).toBe(true);
        }
    });

    it('Emoji 文本不崩溃', () => {
        expect(() => estimateTokens('Hello 😀 World 🌟')).not.toThrow();
    });

    it('超长文本（100KB）性能不崩溃', () => {
        const longText = '这是一段测试文本，包含各种中文字符。'.repeat(1000);
        const start = Date.now();
        const result = estimateTokens(longText);
        const elapsed = Date.now() - start;

        expect(result).toBeGreaterThan(0);
        expect(elapsed).toBeLessThan(1000); // 应在 1 秒内完成
    });
});

// ═══════════════════════════════════════════════
// § 2  estimateCardTokens
// ═══════════════════════════════════════════════

describe('estimateCardTokens', () => {

    it('空对象返回 total 为 0 的结构', () => {
        const result = estimateCardTokens({});
        expect(result).toHaveProperty('total');
        expect(result).toHaveProperty('fields');
        expect(result.total).toBeGreaterThanOrEqual(0);
    });

    it('带 data 包装的 CCv3 格式', () => {
        const cardData = {
            data: {
                name:        '测试角色',
                description: '这是一段描述文字，用于测试 Token 计算。',
                personality: '活泼开朗',
            }
        };
        const result = estimateCardTokens(cardData);
        expect(result.total).toBeGreaterThan(0);
        expect(result.fields.name).toBeGreaterThan(0);
        expect(result.fields.description).toBeGreaterThan(result.fields.personality);
    });

    it('不带 data 包装的扁平格式', () => {
        const cardData = {
            name:        '扁平格式测试',
            description: '直接传入 data 字段内容',
        };
        const result = estimateCardTokens(cardData);
        expect(result.total).toBeGreaterThan(0);
        expect(result.fields.name).toBeGreaterThan(0);
    });

    it('total 等于所有字段之和', () => {
        const cardData = {
            data: {
                name:        '角色名',
                description: '描述文字' ,
                personality: '性格描述',
                scenario:    '场景描述',
            }
        };
        const result = estimateCardTokens(cardData);
        const sum    = Object.values(result.fields).reduce((a, b) => a + b, 0);
        expect(result.total).toBe(sum);
    });

    it('alternate_greetings 数组统计正确', () => {
        const cardData = {
            data: {
                name: '角色',
                alternate_greetings: ['第一个备用开场白', '第二个备用开场白内容更长一些']
            }
        };
        const result = estimateCardTokens(cardData);
        expect(result.fields.alternate_greetings).toBeGreaterThan(0);
    });

    it('tags 数组统计正确', () => {
        const cardData = {
            data: {
                name: '角色',
                tags: ['标签一', '标签二', '标签三']
            }
        };
        const result = estimateCardTokens(cardData);
        expect(result.fields.tags).toBeGreaterThan(0);
    });

    it('空字段返回 0 Token', () => {
        const cardData = {
            data: {
                name:        '角色',
                description: '',
                personality: '',
            }
        };
        const result = estimateCardTokens(cardData);
        expect(result.fields.description).toBe(0);
        expect(result.fields.personality).toBe(0);
    });
});

// ═══════════════════════════════════════════════
// § 3  checkBudget
// ═══════════════════════════════════════════════

describe('checkBudget', () => {

    it('空文本的预算检查', () => {
        const result = checkBudget('', 1000);
        expect(result.ok).toBe(true);
        expect(result.used).toBe(0);
        expect(result.remaining).toBe(1000);
        expect(result.percentage).toBe(0);
    });

    it('未超限时 ok 为 true', () => {
        const result = checkBudget('短文本', 1000);
        expect(result.ok).toBe(true);
        expect(result.remaining).toBeGreaterThan(0);
    });

    it('超限时 ok 为 false', () => {
        const longText = '这是超限文本'.repeat(500);
        const result   = checkBudget(longText, 10);
        expect(result.ok).toBe(false);
        expect(result.remaining).toBe(0);
    });

    it('percentage 在 0-100 范围内', () => {
        const result1 = checkBudget('', 1000);
        const result2 = checkBudget('一段文本', 5);
        const result3 = checkBudget('中等长度的文本内容', 100);

        expect(result1.percentage).toBeGreaterThanOrEqual(0);
        expect(result1.percentage).toBeLessThanOrEqual(100);
        expect(result2.percentage).toBe(100); // 超限时 clamp 到 100
        expect(result3.percentage).toBeGreaterThanOrEqual(0);
        expect(result3.percentage).toBeLessThanOrEqual(100);
    });

    it('remaining 不为负数', () => {
        const longText = '测试文本'.repeat(1000);
        const result   = checkBudget(longText, 1);
        expect(result.remaining).toBeGreaterThanOrEqual(0);
    });

    it('used 与 estimateTokens 结果一致', () => {
        const text   = '这是一段测试文本，用于验证 checkBudget 的 used 字段。';
        const limit  = 5000;
        const budget = checkBudget(text, limit);
        const direct = estimateTokens(text);
        expect(budget.used).toBe(direct);
    });
});

// ═══════════════════════════════════════════════
// § 4  checkFieldBudget
// ═══════════════════════════════════════════════

describe('checkFieldBudget', () => {

    it('未知字段名返回 ok 等级', () => {
        const result = checkFieldBudget('unknown_field', '任意文本');
        expect(result.level).toBe('ok');
        expect(result.limit).toBe(Infinity);
    });

    it('空文本返回 ok 等级', () => {
        const result = checkFieldBudget('description', '');
        expect(result.level).toBe('ok');
        expect(result.used).toBe(0);
    });

    it('短文本在 description 字段返回 ok', () => {
        const result = checkFieldBudget('description', '这是一段很短的描述。');
        expect(result.level).toBe('ok');
    });

    it('超过 warn 阈值返回 warn', () => {
        // description warn = 1500 tokens，约需 2250 个中文字符
        const warnText = '描述'.repeat(1200); // ~1600 tokens
        const result   = checkFieldBudget('description', warnText);
        expect(['warn', 'hard']).toContain(result.level);
    });

    it('超过 hard 阈值返回 hard', () => {
        // description hard = 3000 tokens，约需 4500 个中文字符
        const hardText = '描述内容'.repeat(1500); // ~4000 tokens
        const result   = checkFieldBudget('description', hardText);
        expect(result.level).toBe('hard');
    });

    it('所有已知字段名均可处理', () => {
        const fields = Object.keys(FIELD_TOKEN_LIMITS);
        for (const field of fields) {
            expect(() => checkFieldBudget(field, '测试文本')).not.toThrow();
        }
    });
});

// ═══════════════════════════════════════════════
// § 5  truncateToLimit
// ═══════════════════════════════════════════════

describe('truncateToLimit', () => {

    it('空字符串原样返回', () => {
        expect(truncateToLimit('', 100)).toBe('');
    });

    it('未超限的文本原样返回', () => {
        const text   = '这是短文本';
        const result = truncateToLimit(text, 1000);
        expect(result).toBe(text);
    });

    it('end 策略：截断后 Token 数不超过 limit', () => {
        const longText = '这是一段需要被截断的很长文本。'.repeat(200);
        const limit    = 50;
        const result   = truncateToLimit(longText, limit, 'end');
        expect(estimateTokens(result)).toBeLessThanOrEqual(limit + 5); // 允许少量偏差
        expect(result.length).toBeLessThan(longText.length);
    });

    it('middle 策略：结果包含省略标记', () => {
        const longText = '开头内容'.repeat(50) + '中间内容'.repeat(50) + '结尾内容'.repeat(50);
        const result   = truncateToLimit(longText, 30, 'middle');
        // middle 策略应包含省略号或省略标记
        expect(result.length).toBeLessThan(longText.length);
    });

    it('smart 策略：截断后不超过 limit', () => {
        const longText = '这是第一句话，包含完整的句号。这是第二句话，也有标点。'.repeat(50);
        const limit    = 40;
        const result   = truncateToLimit(longText, limit, 'smart');
        expect(estimateTokens(result)).toBeLessThanOrEqual(limit + 10);
        expect(result.length).toBeLessThan(longText.length);
    });

    it('默认策略为 end', () => {
        const longText = '默认截断策略测试文本。'.repeat(100);
        const limit    = 20;
        const result1  = truncateToLimit(longText, limit);
        const result2  = truncateToLimit(longText, limit, 'end');
        expect(result1).toBe(result2);
    });

    it('limit 为 0 时返回空字符串或省略号', () => {
        const result = truncateToLimit('任意文本', 0, 'end');
        expect(typeof result).toBe('string');
    });
});

// ═══════════════════════════════════════════════
// § 6  格式化函数
// ═══════════════════════════════════════════════

describe('formatTokenCount', () => {

    it('返回字符串', () => {
        expect(typeof formatTokenCount(100)).toBe('string');
    });

    it('包含数字', () => {
        const result = formatTokenCount(1234);
        expect(result).toContain('1');
        expect(result).toContain('234');
    });

    it('包含 tokens 单位', () => {
        const result = formatTokenCount(100);
        expect(result.toLowerCase()).toContain('token');
    });
});

describe('getTokenLevelColor', () => {

    it('低使用率返回 success', () => {
        expect(getTokenLevelColor(0)).toBe('success');
        expect(getTokenLevelColor(50)).toBe('success');
        expect(getTokenLevelColor(69)).toBe('success');
    });

    it('中使用率返回 warning', () => {
        expect(getTokenLevelColor(70)).toBe('warning');
        expect(getTokenLevelColor(80)).toBe('warning');
        expect(getTokenLevelColor(89)).toBe('warning');
    });

    it('高使用率返回 danger', () => {
        expect(getTokenLevelColor(90)).toBe('danger');
        expect(getTokenLevelColor(100)).toBe('danger');
        expect(getTokenLevelColor(150)).toBe('danger');
    });
});

// ═══════════════════════════════════════════════
// § 7  常量完整性校验
// ═══════════════════════════════════════════════

describe('TOKEN_LIMITS 常量', () => {

    it('所有必要的限制常量存在', () => {
        expect(TOKEN_LIMITS.DESCRIPTION_WARN).toBeGreaterThan(0);
        expect(TOKEN_LIMITS.DESCRIPTION_HARD).toBeGreaterThan(TOKEN_LIMITS.DESCRIPTION_WARN);
        expect(TOKEN_LIMITS.TOTAL_CARD_WARN).toBeGreaterThan(0);
        expect(TOKEN_LIMITS.TOTAL_CARD_HARD).toBeGreaterThan(TOKEN_LIMITS.TOTAL_CARD_WARN);
        expect(TOKEN_LIMITS.WB_ENTRY_WARN).toBeGreaterThan(0);
    });
});

describe('FIELD_TOKEN_LIMITS 常量', () => {

    it('每个字段的 warn < hard', () => {
        for (const [field, limits] of Object.entries(FIELD_TOKEN_LIMITS)) {
            expect(limits.warn).toBeLessThan(limits.hard);
        }
    });

    it('包含核心字段', () => {
        expect(FIELD_TOKEN_LIMITS).toHaveProperty('description');
        expect(FIELD_TOKEN_LIMITS).toHaveProperty('personality');
        expect(FIELD_TOKEN_LIMITS).toHaveProperty('first_mes');
        expect(FIELD_TOKEN_LIMITS).toHaveProperty('system_prompt');
    });
});