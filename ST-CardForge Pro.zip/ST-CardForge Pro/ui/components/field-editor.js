/**
 * @file ui/components/field-editor.js
 * @description 单字段编辑器组件
 *              支持单行/多行、Markdown 预览、Token 计数、AI 增强按钮
 * @version 1.0.0
 */

import { eventBus }       from '../../core/event-bus.js';
import { EVENTS }         from '../../contracts.js';
import { estimateTokens, TOKEN_LIMITS } from '../../utils/token-counter.js';

export class FieldEditor {
    /**
     * @param {HTMLElement} containerElement
     * @param {object}      options
     * @param {string}      options.fieldName          字段名（用于事件）
     * @param {boolean}     [options.multiline=true]   多行
     * @param {boolean}     [options.markdown=false]   显示 Markdown 预览按钮
     * @param {Function}    [options.onChange]         (value: string) => void
     * @param {string}      [options.placeholder]
     * @param {number}      [options.minRows=3]
     * @param {number}      [options.maxRows=20]
     * @param {boolean}     [options.showTokenCount=true]
     * @param {boolean}     [options.showEnhanceBtn=false]  显示 AI 增强按钮
     * @param {boolean}     [options.readonly=false]
     */
    constructor(containerElement, options = {}) {
        this._container = containerElement;
        this._opts = {
            fieldName:      'unknown',
            multiline:      true,
            markdown:       false,
            onChange:       null,
            placeholder:    '',
            minRows:        3,
            maxRows:        20,
            showTokenCount: true,
            showEnhanceBtn: false,
            readonly:       false,
            ...options,
        };

        this._value    = '';
        this._inputEl  = null;
        this._tokenEl  = null;
        this._previewEl = null;
        this._previewMode = false;

        this._render();
    }

    // ═══════════════════════════════════════════
    // 公共方法
    // ═══════════════════════════════════════════

    /** @returns {string} */
    getValue() { return this._value; }

    /**
     * @param {string} text
     */
    setValue(text) {
        this._value = text ?? '';
        if (this._inputEl) this._inputEl.value = this._value;
        this._updateTokenDisplay();
        this._autoResize();
    }

    /**
     * @param {boolean} readonly
     */
    setReadOnly(readonly) {
        this._opts.readonly = readonly;
        if (this._inputEl) this._inputEl.readOnly = readonly;
    }

    focus() { this._inputEl?.focus(); }

    /** @returns {number} 估算 Token 数 */
    getTokenCount() {
        return estimateTokens(this._value);
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _render() {
        this._container.innerHTML = '';
        this._container.style.position = 'relative';

        // 工具栏（Markdown 预览 + 增强按钮）
        if (this._opts.markdown || this._opts.showEnhanceBtn || this._opts.showTokenCount) {
            const toolbar = this._buildToolbar();
            this._container.appendChild(toolbar);
        }

        // 编辑区
        if (this._opts.multiline) {
            const ta = document.createElement('textarea');
            ta.className   = 'cardforge-textarea';
            ta.placeholder = this._opts.placeholder;
            ta.readOnly    = this._opts.readonly;
            ta.rows        = this._opts.minRows;
            ta.value       = this._value;
            ta.style.width = '100%';

            ta.addEventListener('input', () => this._onInput());
            ta.addEventListener('keydown', e => {
                // Tab 键插入空格（不失焦）
                if (e.key === 'Tab') {
                    e.preventDefault();
                    const start = ta.selectionStart;
                    const end   = ta.selectionEnd;
                    ta.value = ta.value.slice(0, start) + '    ' + ta.value.slice(end);
                    ta.selectionStart = ta.selectionEnd = start + 4;
                }
            });

            this._inputEl = ta;
            this._container.appendChild(ta);

            // Markdown 预览区
            if (this._opts.markdown) {
                const preview = document.createElement('div');
                preview.className = 'cardforge-md-preview';
                preview.style.cssText = `
                    display:none; padding:8px 10px; min-height:80px;
                    background:var(--cf-bg-input); border:1px solid var(--cf-border);
                    border-radius:var(--cf-radius-sm); font-size:13px;
                    line-height:1.7; word-break:break-word;
                `;
                this._previewEl = preview;
                this._container.appendChild(preview);
            }
        } else {
            const input = document.createElement('input');
            input.type        = 'text';
            input.className   = 'cardforge-input';
            input.placeholder = this._opts.placeholder;
            input.readOnly    = this._opts.readonly;
            input.value       = this._value;
            input.style.width = '100%';
            input.addEventListener('input', () => this._onInput());
            this._inputEl = input;
            this._container.appendChild(input);
        }

        this._updateTokenDisplay();
    }

    _buildToolbar() {
        const bar = document.createElement('div');
        bar.style.cssText = `
            display:flex; align-items:center; gap:6px;
            margin-bottom:4px; flex-wrap:wrap;
        `;

        // Markdown 预览切换
        if (this._opts.markdown) {
            const mdBtn = document.createElement('button');
            mdBtn.className   = 'cardforge-btn cardforge-btn-ghost cardforge-btn-sm';
            mdBtn.textContent = '👁 预览';
            mdBtn.type        = 'button';
            mdBtn.addEventListener('click', () => this._togglePreview());
            bar.appendChild(mdBtn);
        }

        // AI 增强按钮
        if (this._opts.showEnhanceBtn) {
            const enhBtn = document.createElement('button');
            enhBtn.className   = 'cardforge-btn cardforge-btn-ghost cardforge-btn-sm';
            enhBtn.textContent = '✨ AI 增强';
            enhBtn.type        = 'button';
            enhBtn.addEventListener('click', () => {
                eventBus.emit(EVENTS.FIELD_ENHANCE_STARTED, {
                    fieldName: this._opts.fieldName,
                    content:   this._value,
                });
            });
            bar.appendChild(enhBtn);
        }

        // Token 计数（右侧）
        if (this._opts.showTokenCount) {
            const tokenSpan = document.createElement('span');
            tokenSpan.style.cssText = `
                margin-left:auto; font-size:11px;
                color:var(--cf-text-muted); font-weight:600;
            `;
            tokenSpan.title    = 'Token 估算值（仅供参考）';
            this._tokenEl      = tokenSpan;
            bar.appendChild(tokenSpan);
        }

        return bar;
    }

    _onInput() {
        this._value = this._inputEl?.value ?? '';
        this._updateTokenDisplay();
        this._autoResize();
        if (this._previewMode) this._renderPreview();
        this._opts.onChange?.(this._value);
        eventBus.emit(EVENTS.CARD_FIELD_CHANGED, {
            fieldName: this._opts.fieldName,
            value:     this._value,
        });
    }

    _updateTokenDisplay() {
        if (!this._tokenEl) return;
        const count = this.getTokenCount();
        const warn  = TOKEN_LIMITS?.DESCRIPTION_WARN ?? 2000;
        const hard  = TOKEN_LIMITS?.DESCRIPTION_HARD ?? 3000;

        let cls = '';
        if (count >= hard)    cls = 'danger';
        else if (count >= warn) cls = 'warn';

        this._tokenEl.textContent = `${count} tokens`;
        this._tokenEl.style.color = cls === 'danger'
            ? 'var(--cf-danger)'
            : cls === 'warn'
                ? 'var(--cf-warning)'
                : 'var(--cf-text-muted)';
    }

    _autoResize() {
        const ta = this._inputEl;
        if (!ta || ta.tagName !== 'TEXTAREA') return;
        ta.style.height = 'auto';
        const lineH    = parseInt(getComputedStyle(ta).lineHeight) || 22;
        const minH     = this._opts.minRows * lineH;
        const maxH     = this._opts.maxRows * lineH;
        ta.style.height = `${Math.min(maxH, Math.max(minH, ta.scrollHeight))}px`;
    }

    _togglePreview() {
        this._previewMode = !this._previewMode;
        if (!this._previewEl || !this._inputEl) return;

        if (this._previewMode) {
            this._renderPreview();
            this._inputEl.style.display   = 'none';
            this._previewEl.style.display = 'block';
        } else {
            this._inputEl.style.display   = '';
            this._previewEl.style.display = 'none';
        }
    }

    _renderPreview() {
        if (!this._previewEl) return;
        // 简单 Markdown → HTML（无需引入库，仅处理常见格式）
        const html = this._value
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.+?)\*/g,     '<em>$1</em>')
            .replace(/`(.+?)`/g,       '<code>$1</code>')
            .replace(/\n/g,            '<br>');
        this._previewEl.innerHTML = html;
    }
}