/**
 * @file ui/components/loading-overlay.js
 * @description Loading 遮罩组件，支持进度条和消息更新
 * @version 1.0.0
 */

export class LoadingOverlay {
    /**
     * @param {HTMLElement} containerElement  遮罩的父容器（需 position:relative）
     */
    constructor(containerElement) {
        this._container = containerElement;
        this._el        = null;
        this._msgEl     = null;
        this._fillEl    = null;
        this._visible   = false;
    }

    // ═══════════════════════════════════════════
    // 公共方法
    // ═══════════════════════════════════════════

    /**
     * 显示遮罩
     * @param {string} [message='加载中…']
     * @param {number|null} [progress]  0~100，null 表示不显示进度条
     */
    show(message = '加载中…', progress = null) {
        if (this._visible) {
            this.updateProgress(progress, message);
            return;
        }

        // 确保父容器有相对定位
        const pos = getComputedStyle(this._container).position;
        if (pos === 'static') this._container.style.position = 'relative';

        this._el = this._buildDOM(message, progress);
        this._container.appendChild(this._el);

        // 取引用（便于 updateProgress 更新）
        this._msgEl  = this._el.querySelector('.cardforge-loading-msg');
        this._fillEl = this._el.querySelector('.cardforge-progress-fill');
        const barEl  = this._el.querySelector('.cardforge-progress-bar');
        if (barEl) barEl.style.display = progress !== null ? 'block' : 'none';

        this._visible = true;
    }

    /**
     * 更新进度和消息（遮罩显示中）
     * @param {number|null} progress
     * @param {string} [message]
     */
    updateProgress(progress, message) {
        if (!this._visible) return;
        if (message && this._msgEl) {
            this._msgEl.textContent = message;
        }
        if (this._fillEl) {
            if (progress !== null && progress !== undefined) {
                const pct = Math.min(100, Math.max(0, progress));
                this._fillEl.style.width = `${pct}%`;
                this._fillEl.closest('.cardforge-progress-bar').style.display = 'block';
            }
        }
    }

    /**
     * 隐藏遮罩
     */
    hide() {
        if (!this._visible || !this._el) return;
        // 淡出
        this._el.style.opacity = '0';
        this._el.style.transition = 'opacity 0.2s ease';
        setTimeout(() => {
            this._el?.remove();
            this._el    = null;
            this._msgEl = null;
            this._fillEl = null;
            this._visible = false;
        }, 200);
    }

    /** @returns {boolean} */
    isVisible() { return this._visible; }

    // ─────────────────────────────────────────
    // 私有方法
    // ─────────────────────────────────────────

    _buildDOM(message, progress) {
        const el = document.createElement('div');
        el.className = 'cardforge-loading-overlay';

        const showBar = progress !== null && progress !== undefined;
        el.innerHTML = `
            <div class="cardforge-loading-spinner"></div>
            <div class="cardforge-loading-msg">${_escapeHTML(message)}</div>
            ${showBar ? `
            <div class="cardforge-progress-bar">
                <div class="cardforge-progress-fill" style="width:${progress}%"></div>
            </div>` : ''}
        `;
        return el;
    }
}

function _escapeHTML(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// ─────────────────────────────────────────────
// 全局 Loading（挂在 body 上的全屏遮罩，单例）
// ─────────────────────────────────────────────
let _globalOverlay = null;

export const GlobalLoading = {
    show(message, progress) {
        if (!_globalOverlay) {
            _globalOverlay = new LoadingOverlay(document.body);
        }
        _globalOverlay.show(message, progress);
    },
    update(progress, message) {
        _globalOverlay?.updateProgress(progress, message);
    },
    hide() {
        _globalOverlay?.hide();
    },
};