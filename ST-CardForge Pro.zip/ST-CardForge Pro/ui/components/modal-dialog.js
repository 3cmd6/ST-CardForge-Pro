/**
 * @file ui/components/modal-dialog.js
 * @description 通用模态对话框组件
 *              提供 confirm / alert / prompt / custom 四种静态方法
 * @version 1.0.0
 */

const ICONS = {
    info:    'ℹ️',
    success: '✅',
    warning: '⚠️',
    error:   '❌',
    question:'❓',
};

// ─────────────────────────────────────────────
// ModalDialog 类
// ─────────────────────────────────────────────
export class ModalDialog {

    // ═══════════════════════════════════════════
    // 静态快捷方法
    // ═══════════════════════════════════════════

    /**
     * 确认对话框
     * @param {string} message
     * @param {string} [title='确认']
     * @param {'info'|'warning'|'error'} [type='info']
     * @returns {Promise<boolean>}
     */
    static confirm(message, title = '确认', type = 'info') {
        return new Promise(resolve => {
            const dialog = new ModalDialog({
                title,
                icon:    ICONS[type],
                content: `<p style="margin:0;line-height:1.6">${_escapeHTML(message)}</p>`,
                buttons: [
                    {
                        label:    '取消',
                        variant:  'secondary',
                        onClick:  () => { dialog.close(); resolve(false); },
                    },
                    {
                        label:    '确认',
                        variant:  type === 'error' ? 'danger' : 'primary',
                        autofocus: true,
                        onClick:  () => { dialog.close(); resolve(true); },
                    },
                ],
                onClose: () => resolve(false),
            });
            dialog.open();
        });
    }

    /**
     * 提示对话框（仅 OK）
     * @param {string} message
     * @param {string} [title='提示']
     * @param {'info'|'success'|'warning'|'error'} [type='info']
     * @returns {Promise<void>}
     */
    static alert(message, title = '提示', type = 'info') {
        return new Promise(resolve => {
            const dialog = new ModalDialog({
                title,
                icon:    ICONS[type],
                content: `<p style="margin:0;line-height:1.6">${_escapeHTML(message)}</p>`,
                buttons: [
                    {
                        label:    '确定',
                        variant:  'primary',
                        autofocus: true,
                        onClick:  () => { dialog.close(); resolve(); },
                    },
                ],
                onClose: () => resolve(),
            });
            dialog.open();
        });
    }

    /**
     * 输入对话框
     * @param {string} message
     * @param {string} [defaultValue='']
     * @param {string} [title='输入']
     * @returns {Promise<string|null>}  用户取消时返回 null
     */
    static prompt(message, defaultValue = '', title = '输入') {
        return new Promise(resolve => {
            const inputId = `cf-prompt-input-${Date.now()}`;
            const dialog  = new ModalDialog({
                title,
                icon:    ICONS.question,
                content: `
                    <p style="margin:0 0 10px;line-height:1.6">${_escapeHTML(message)}</p>
                    <input
                        id="${inputId}"
                        class="cardforge-input"
                        type="text"
                        value="${_escapeAttr(defaultValue)}"
                        style="width:100%;box-sizing:border-box"
                    />
                `,
                buttons: [
                    {
                        label:   '取消',
                        variant: 'secondary',
                        onClick: () => { dialog.close(); resolve(null); },
                    },
                    {
                        label:    '确定',
                        variant:  'primary',
                        autofocus: false,
                        onClick:  () => {
                            const val = document.getElementById(inputId)?.value ?? '';
                            dialog.close();
                            resolve(val);
                        },
                    },
                ],
                onOpen:  () => {
                    const el = document.getElementById(inputId);
                    if (el) {
                        el.focus();
                        el.select();
                        // 按 Enter 确认
                        el.addEventListener('keydown', e => {
                            if (e.key === 'Enter') {
                                dialog.close();
                                resolve(el.value);
                            }
                        });
                    }
                },
                onClose: () => resolve(null),
            });
            dialog.open();
        });
    }

    /**
     * 自定义内容对话框
     * @param {object} options
     * @param {string}   options.title
     * @param {string}   [options.icon]
     * @param {string}   options.content     HTML 字符串
     * @param {Array}    options.buttons
     * @param {Function} [options.onClose]
     * @param {Function} [options.onOpen]
     * @param {string}   [options.width]     如 '600px'
     * @returns {Promise<void>}
     */
    static custom(options) {
        return new Promise(resolve => {
            const wrapped = {
                ...options,
                onClose: () => {
                    options.onClose?.();
                    resolve();
                },
            };
            const dialog = new ModalDialog(wrapped);
            dialog.open();
        });
    }

    // ═══════════════════════════════════════════
    // 实例方法
    // ═══════════════════════════════════════════

    /**
     * @param {object} options
     */
    constructor(options) {
        this._options  = options;
        this._backdrop = null;
        this._modal    = null;
    }

    open() {
        this._backdrop = this._buildBackdrop();
        document.body.appendChild(this._backdrop);
        this._options.onOpen?.();

        // 自动聚焦
        const autofocusBtn = this._modal.querySelector('[data-autofocus]');
        autofocusBtn?.focus();

        // ESC 关闭
        this._handleKeyDown = e => {
            if (e.key === 'Escape') this.close();
        };
        document.addEventListener('keydown', this._handleKeyDown);
    }

    close() {
        if (!this._backdrop) return;
        document.removeEventListener('keydown', this._handleKeyDown);
        this._backdrop.remove();
        this._backdrop = null;
        this._modal    = null;
    }

    // ─────────────────────────────────────────
    // 私有构建方法
    // ─────────────────────────────────────────

    _buildBackdrop() {
        const { title, icon, content, buttons = [], onClose, width } = this._options;

        // 遮罩
        const backdrop = document.createElement('div');
        backdrop.className = 'cardforge-modal-backdrop';
        backdrop.addEventListener('click', e => {
            if (e.target === backdrop) {
                this.close();
                onClose?.();
            }
        });

        // 模态框
        const modal = document.createElement('div');
        modal.className = 'cardforge-modal';
        if (width) modal.style.width = width;
        this._modal = modal;

        // 标题栏
        const header = document.createElement('div');
        header.className = 'cardforge-modal-header';
        header.innerHTML = `
            ${icon ? `<span style="font-size:18px">${icon}</span>` : ''}
            <span class="cardforge-modal-title">${_escapeHTML(title)}</span>
            <span class="cardforge-modal-close" title="关闭">✕</span>
        `;
        header.querySelector('.cardforge-modal-close').addEventListener('click', () => {
            this.close();
            onClose?.();
        });

        // 内容区
        const body = document.createElement('div');
        body.className = 'cardforge-modal-body';
        body.innerHTML  = content;

        // 按钮区
        const footer = document.createElement('div');
        footer.className = 'cardforge-modal-footer';
        for (const btn of buttons) {
            const el = document.createElement('button');
            el.className = `cardforge-btn cardforge-btn-${btn.variant ?? 'secondary'}`;
            el.textContent = btn.label;
            if (btn.autofocus) el.setAttribute('data-autofocus', '');
            el.addEventListener('click', () => btn.onClick?.());
            footer.appendChild(el);
        }

        modal.append(header, body, footer);
        backdrop.appendChild(modal);
        return backdrop;
    }
}

// ─────────────────────────────────────────────
// 工具函数
// ─────────────────────────────────────────────
function _escapeHTML(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function _escapeAttr(str) {
    return String(str).replace(/"/g, '&quot;');
}