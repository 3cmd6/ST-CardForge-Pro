/**
 * @file ui/components/tag-input.js
 * @description 标签输入组件
 *              支持自由输入、预设建议、最大标签数、删除、回车/逗号分隔
 * @version 1.0.0
 */

export class TagInput {
    /**
     * @param {HTMLElement} containerElement
     * @param {object}      [options]
     * @param {boolean}     [options.allowCreate=true]     允许用户创建新标签
     * @param {string[]}    [options.suggestions=[]]       建议标签列表
     * @param {number}      [options.maxTags=Infinity]     最大标签数
     * @param {Function}    [options.onChange]             值变化回调 (tags: string[]) => void
     * @param {string[]}    [options.value=[]]             初始值
     * @param {string}      [options.placeholder='输入标签…']
     * @param {boolean}     [options.readonly=false]
     * @param {string}      [options.tagCategory]          标签颜色分类 CSS class
     */
    constructor(containerElement, options = {}) {
        this._container = containerElement;
        this._opts = {
            allowCreate:    true,
            suggestions:    [],
            maxTags:        Infinity,
            onChange:       null,
            value:          [],
            placeholder:    '输入标签，按 Enter 或逗号确认',
            readonly:       false,
            tagCategory:    '',
            ...options,
        };

        this._tags       = [...this._opts.value];
        this._wrapper    = null;
        this._realInput  = null;
        this._suggestBox = null;

        this._render();
    }

    // ═══════════════════════════════════════════
    // 公共方法
    // ═══════════════════════════════════════════

    /** @returns {string[]} */
    getValue() { return [...this._tags]; }

    /**
     * @param {string[]} tags
     */
    setValue(tags) {
        this._tags = [...tags];
        this._syncTagDOM();
        this._opts.onChange?.(this.getValue());
    }

    /**
     * @param {string} tag
     */
    addTag(tag) {
        const t = tag.trim();
        if (!t || this._tags.includes(t)) return;
        if (this._tags.length >= this._opts.maxTags) return;
        this._tags.push(t);
        this._appendTagDOM(t);
        this._opts.onChange?.(this.getValue());
    }

    /**
     * @param {string} tag
     */
    removeTag(tag) {
        this._tags = this._tags.filter(t => t !== tag);
        this._syncTagDOM();
        this._opts.onChange?.(this.getValue());
    }

    clear() {
        this._tags = [];
        this._syncTagDOM();
        this._opts.onChange?.([]);
    }

    /**
     * 更新建议列表
     * @param {string[]} suggestions
     */
    setSuggestions(suggestions) {
        this._opts.suggestions = suggestions;
    }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _render() {
        // 清空容器
        this._container.innerHTML = '';

        // 外层 wrapper
        const wrapper = document.createElement('div');
        wrapper.className = 'cardforge-tag-input-wrapper';
        if (this._opts.readonly) {
            wrapper.style.opacity  = '0.7';
            wrapper.style.cursor   = 'default';
        }
        this._wrapper = wrapper;

        // 初始标签 DOM
        this._tags.forEach(t => this._appendTagDOM(t, false));

        // 真实输入框
        if (!this._opts.readonly) {
            const input = document.createElement('input');
            input.className   = 'cardforge-tag-real-input';
            input.type        = 'text';
            input.placeholder = this._tags.length === 0 ? this._opts.placeholder : '';
            this._realInput   = input;

            input.addEventListener('keydown', e => this._onKeyDown(e));
            input.addEventListener('input',   () => this._onInput());
            input.addEventListener('blur',    () => {
                // 失焦时提交当前输入
                this._commitInput();
                setTimeout(() => this._hideSuggestions(), 150);
            });

            wrapper.appendChild(input);
        }

        // 建议下拉框
        const suggest = document.createElement('div');
        suggest.className = 'cardforge-tag-suggestions';
        suggest.style.cssText = `
            display:none; position:absolute; background:var(--cf-bg-card);
            border:1px solid var(--cf-border); border-radius:var(--cf-radius-sm);
            z-index:100; max-height:180px; overflow-y:auto;
            box-shadow:var(--cf-shadow); min-width:160px; margin-top:2px;
        `;
        this._suggestBox = suggest;

        // 相对定位容器
        const rel = document.createElement('div');
        rel.style.position = 'relative';
        rel.appendChild(wrapper);
        rel.appendChild(suggest);

        this._container.appendChild(rel);

        // 点击 wrapper 聚焦 input
        wrapper.addEventListener('click', () => this._realInput?.focus());
    }

    _appendTagDOM(tag, update = true) {
        const input = this._realInput;
        const tagEl = this._buildTagEl(tag);

        if (input) {
            this._wrapper.insertBefore(tagEl, input);
        } else {
            this._wrapper.appendChild(tagEl);
        }

        if (update && this._realInput) {
            this._realInput.placeholder = '';
        }
    }

    _buildTagEl(tag) {
        const el = document.createElement('span');
        el.className = [
            'cardforge-tag',
            this._opts.tagCategory ? `category-${this._opts.tagCategory}` : '',
        ].filter(Boolean).join(' ');
        el.dataset.tag = tag;
        el.innerHTML = `
            <span class="cardforge-tag-text">${_escapeHTML(tag)}</span>
            ${!this._opts.readonly ? '<span class="cardforge-tag-remove" title="删除">✕</span>' : ''}
        `;
        el.querySelector('.cardforge-tag-remove')?.addEventListener('click', e => {
            e.stopPropagation();
            this.removeTag(tag);
        });
        return el;
    }

    _syncTagDOM() {
        // 移除所有标签 DOM（保留 input）
        this._wrapper.querySelectorAll('.cardforge-tag').forEach(el => el.remove());
        // 重新插入
        this._tags.forEach(t => this._appendTagDOM(t, false));
        // 更新 placeholder
        if (this._realInput) {
            this._realInput.placeholder = this._tags.length === 0
                ? this._opts.placeholder
                : '';
        }
    }

    _onKeyDown(e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            this._commitInput();
        } else if (e.key === 'Backspace' && this._realInput.value === '' && this._tags.length > 0) {
            this.removeTag(this._tags[this._tags.length - 1]);
        } else if (e.key === 'ArrowDown') {
            this._focusSuggestion(0);
        }
    }

    _onInput() {
        const query = this._realInput.value.trim();
        if (query.includes(',')) {
            // 批量添加
            const parts = this._realInput.value.split(',');
            parts.slice(0, -1).forEach(p => this.addTag(p));
            this._realInput.value = parts[parts.length - 1];
            return;
        }
        this._showSuggestions(query);
    }

    _commitInput() {
        const val = this._realInput?.value ?? '';
        if (val.trim()) {
            this.addTag(val);
            this._realInput.value = '';
        }
        this._hideSuggestions();
    }

    _showSuggestions(query) {
        if (!query || !this._opts.suggestions.length) {
            this._hideSuggestions();
            return;
        }
        const lower    = query.toLowerCase();
        const filtered = this._opts.suggestions
            .filter(s => s.toLowerCase().includes(lower) && !this._tags.includes(s))
            .slice(0, 8);

        if (!filtered.length) { this._hideSuggestions(); return; }

        this._suggestBox.innerHTML = '';
        filtered.forEach((s, idx) => {
            const item = document.createElement('div');
            item.style.cssText = 'padding:6px 10px;cursor:pointer;font-size:13px;';
            item.textContent   = s;
            item.dataset.idx   = idx;
            item.addEventListener('mousedown', () => {
                this.addTag(s);
                this._realInput.value = '';
                this._hideSuggestions();
            });
            item.addEventListener('mouseenter', () => {
                item.style.background = 'rgba(123,104,238,0.15)';
            });
            item.addEventListener('mouseleave', () => {
                item.style.background = '';
            });
            this._suggestBox.appendChild(item);
        });
        this._suggestBox.style.display = 'block';
    }

    _hideSuggestions() {
        if (this._suggestBox) this._suggestBox.style.display = 'none';
    }

    _focusSuggestion(idx) {
        const items = this._suggestBox.querySelectorAll('div');
        items[idx]?.focus();
    }
}

function _escapeHTML(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}