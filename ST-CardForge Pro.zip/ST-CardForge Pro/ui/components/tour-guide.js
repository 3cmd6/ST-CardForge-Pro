/**
 * @file ui/components/tour-guide.js
 * @description 新手导览组件（Step-by-step 气泡导览）
 * @version 1.0.0
 */

export class TourGuide {
    /**
     * @param {Array<object>} steps  导览步骤
     * @param {string}   steps[].selector   目标元素 CSS 选择器
     * @param {string}   steps[].title      气泡标题
     * @param {string}   steps[].content    气泡内容（支持 HTML）
     * @param {'top'|'bottom'|'left'|'right'} [steps[].position='bottom'] 气泡方向
     * @param {Function} [steps[].onEnter]  进入该步骤回调
     * @param {Function} [steps[].onLeave]  离开该步骤回调
     */
    constructor(steps = []) {
        this._steps        = steps;
        this._current      = -1;
        this._overlay      = null;
        this._bubble       = null;
        this._highlightEl  = null;
        this._active       = false;
        this._onDone       = null;   // 完成回调
    }

    // ═══════════════════════════════════════════
    // 公共方法
    // ═══════════════════════════════════════════

    /**
     * 开始导览
     * @param {number}   [startStep=0]
     * @param {Function} [onDone]  完成或跳过时回调
     */
    start(startStep = 0, onDone = null) {
        if (this._active) return;
        if (!this._steps.length) return;

        this._active  = true;
        this._onDone  = onDone;
        this._buildOverlay();
        this.goToStep(startStep);
    }

    next() {
        if (this._current < this._steps.length - 1) {
            this.goToStep(this._current + 1);
        } else {
            this.stop(true);
        }
    }

    prev() {
        if (this._current > 0) {
            this.goToStep(this._current - 1);
        }
    }

    /**
     * @param {number} step
     */
    goToStep(step) {
        if (step < 0 || step >= this._steps.length) return;

        // 离开回调
        if (this._current >= 0) {
            this._steps[this._current]?.onLeave?.();
        }

        this._current = step;
        const s = this._steps[step];

        // 进入回调
        s.onEnter?.();

        // 找目标元素
        const target = s.selector ? document.querySelector(s.selector) : null;

        this._renderHighlight(target);
        this._renderBubble(s, target);
    }

    stop(completed = false) {
        if (!this._active) return;
        this._active = false;

        this._overlay?.remove();
        this._bubble?.remove();
        this._overlay    = null;
        this._bubble     = null;
        this._highlightEl = null;
        this._current    = -1;

        if (completed) this._onDone?.();
    }

    /** @returns {boolean} */
    isActive() { return this._active; }

    // ═══════════════════════════════════════════
    // 私有方法
    // ═══════════════════════════════════════════

    _buildOverlay() {
        const overlay = document.createElement('div');
        overlay.className = 'cardforge-tour-overlay';
        document.body.appendChild(overlay);
        this._overlay = overlay;
    }

    _renderHighlight(target) {
        // 移除旧 highlight
        this._overlay.querySelectorAll('.cardforge-tour-highlight').forEach(e => e.remove());

        if (!target) return;

        const rect = target.getBoundingClientRect();
        const hl   = document.createElement('div');
        hl.className = 'cardforge-tour-highlight';
        hl.style.cssText = `
            position:fixed;
            top:${rect.top - 4}px;
            left:${rect.left - 4}px;
            width:${rect.width + 8}px;
            height:${rect.height + 8}px;
            pointer-events:none;
            z-index:calc(var(--cf-z-tour) - 1);
        `;
        this._overlay.appendChild(hl);
        this._highlightEl = hl;
    }

    _renderBubble(step, target) {
        // 移除旧气泡
        this._bubble?.remove();

        const bubble = document.createElement('div');
        bubble.className = 'cardforge-tour-bubble';
        bubble.style.zIndex = 'var(--cf-z-tour)';

        const isFirst = this._current === 0;
        const isLast  = this._current === this._steps.length - 1;

        bubble.innerHTML = `
            <div class="cardforge-tour-title">${_escapeHTML(step.title || '')}</div>
            <div class="cardforge-tour-content">${step.content || ''}</div>
            <div class="cardforge-tour-footer">
                <span class="cardforge-tour-step">${this._current + 1} / ${this._steps.length}</span>
                <div class="cardforge-tour-dots">
                    ${this._steps.map((_, i) => `
                        <span class="cardforge-tour-dot ${i === this._current ? 'active' : ''}"></span>
                    `).join('')}
                </div>
                <div class="cardforge-btn-group">
                    <button class="cardforge-btn cardforge-btn-ghost cardforge-btn-sm cf-tour-skip">跳过</button>
                    ${!isFirst ? '<button class="cardforge-btn cardforge-btn-secondary cardforge-btn-sm cf-tour-prev">◀ 上一步</button>' : ''}
                    <button class="cardforge-btn cardforge-btn-primary cardforge-btn-sm cf-tour-next">
                        ${isLast ? '完成 ✓' : '下一步 ▶'}
                    </button>
                </div>
            </div>
        `;

        bubble.querySelector('.cf-tour-next').addEventListener('click',  () => this.next());
        bubble.querySelector('.cf-tour-prev')?.addEventListener('click', () => this.prev());
        bubble.querySelector('.cf-tour-skip').addEventListener('click',  () => this.stop(false));

        document.body.appendChild(bubble);
        this._bubble = bubble;

        // 定位气泡
        this._positionBubble(bubble, target, step.position ?? 'bottom');
    }

    _positionBubble(bubble, target, position) {
        if (!target) {
            // 居中显示
            bubble.style.cssText += `
                top:50%; left:50%;
                transform:translate(-50%,-50%);
                position:fixed;
            `;
            return;
        }

        const rect  = target.getBoundingClientRect();
        const bw    = bubble.offsetWidth  || 300;
        const bh    = bubble.offsetHeight || 160;
        const GAP   = 12;

        let top, left;
        bubble.style.position = 'fixed';

        switch (position) {
            case 'top':
                top  = rect.top  - bh - GAP;
                left = rect.left + rect.width / 2 - bw / 2;
                break;
            case 'left':
                top  = rect.top  + rect.height / 2 - bh / 2;
                left = rect.left - bw - GAP;
                break;
            case 'right':
                top  = rect.top  + rect.height / 2 - bh / 2;
                left = rect.right + GAP;
                break;
            case 'bottom':
            default:
                top  = rect.bottom + GAP;
                left = rect.left   + rect.width / 2 - bw / 2;
                break;
        }

        // 边界修正
        const vw = window.innerWidth, vh = window.innerHeight;
        left = Math.max(8, Math.min(left, vw - bw - 8));
        top  = Math.max(8, Math.min(top,  vh - bh - 8));

        bubble.style.top  = `${top}px`;
        bubble.style.left = `${left}px`;
    }
}

function _escapeHTML(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}