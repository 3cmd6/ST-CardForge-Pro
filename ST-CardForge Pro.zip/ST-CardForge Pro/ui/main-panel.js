/**
 * @file ui/main-panel.js
 * @description ST-CardForge Pro 主面板
 * @version 1.0.2
 */

// 派生扩展根目录 URL（main-panel.js 位于 ui/ 子目录，所以 '..' 即为扩展根）
const _EXTENSION_BASE_URL = (() => {
    try {
        return new URL('..', import.meta.url).href;
    } catch(e) {
        const scripts = Array.from(document.querySelectorAll('script[src]'));
        for (const s of scripts) {
            const m = s.src.match(/^(.+\/(?:ST-CardForge[^/]*))\//i);
            if (m) return m[1] + '/';
        }
        return '/extensions/ST-CardForge Pro/';
    }
})();

// HTML文件路径映射（moduleKey → 相对于扩展根的路径）
const _HTML_FILE_MAP = {
    cardGenerator: 'modules/01_card-generator/ui-card-editor.html',
    wbGenerator:   'modules/02_world-book/ui-worldbook-editor.html',
    greetingGen:   'modules/03_greeting/ui-greeting-editor.html',
    scriptForge:   'modules/04_stscript-forge/ui-script-builder.html',
    rpgTracker:    'modules/05_rpg-tracker/ui-stat-designer.html',
    branchEngine:  'modules/06_plot-branch/ui-branch-designer.html',
    regexForge:    'modules/07_regex-forge/ui-regex-editor.html',
    fieldEnhancer: 'modules/08_field-enhancer/ui-enhancer-panel.html',
    exporter:      'modules/09_exporter/ui-export-panel.html',
};

export class MainPanel {
    constructor(eventBus, i18n, settings, modules = {}) {
        this._bus = eventBus;
        this._i18n = i18n;
        this._settings = settings;
        this._modules = modules;

        this._rootEl = null;
        this._visible = false;
        this._currentModule = 'card-generator';
        this._boundEscHandler = null;
    }

    async init() {
        this._buildPanel();
        this._bindEvents();
        await this._mountModulePanels();
        this.switchModule('card-generator');
        this.hide();

        console.log('[CardForge] MainPanel 初始化完成');
    }

    destroy() {
        if (this._boundEscHandler) {
            document.removeEventListener('keydown', this._boundEscHandler);
            this._boundEscHandler = null;
        }

        this._rootEl?.remove();
        this._rootEl = null;
        this._visible = false;
    }

    show() {
        if (!this._rootEl) return;
        this._rootEl.style.display = 'flex';
        if (this._backdropEl) this._backdropEl.style.display = 'block';
        this._visible = true;
        // 防止背景页面滚动
        document.body.style.overflow = 'hidden';
    }

    hide() {
        if (!this._rootEl) return;
        this._rootEl.style.display = 'none';
        if (this._backdropEl) this._backdropEl.style.display = 'none';
        this._visible = false;
        document.body.style.overflow = '';
    }

    toggle() {
        this._visible ? this.hide() : this.show();
    }

    switchModule(moduleId) {
        this._currentModule = moduleId;

        // 1. 更新左侧导航高亮
        this._rootEl?.querySelectorAll('.cardforge-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.module === moduleId);
        });

        // 2. 切换右侧 panel 显示
        const panelMap = {
            'card-generator': 'cf-panel-card-generator',
            'worldbook': 'cf-panel-worldbook',
            'greeting': 'cf-panel-greeting',
            'stscript-forge': 'cf-panel-stscript-forge',
            'rpg-tracker': 'cf-panel-rpg-tracker',
            'plot-branch': 'cf-panel-plot-branch',
            'regex-forge': 'cf-panel-regex-forge',
            'field-enhancer': 'cf-panel-field-enhancer',
            'exporter': 'cf-panel-exporter',
            'preview': 'cf-panel-preview',
            'settings': 'cf-panel-settings',
        };

        this._rootEl?.querySelectorAll('.cardforge-module-panel').forEach(panel => {
            panel.classList.remove('active');
            panel.style.display = 'none';
        });

        const activePanelId = panelMap[moduleId];
        const activePanel = activePanelId
            ? this._rootEl?.querySelector(`#${activePanelId}`)
            : null;

        if (activePanel) {
            activePanel.classList.add('active');
            activePanel.style.display = 'block';
        }
    }

    updateTokenCounter(stats) {
        if (!this._rootEl || !stats) return;

        const setText = (id, val) => {
            const el = this._rootEl.querySelector(id);
            if (el) el.textContent = val ?? '—';
        };

        setText('#cf-token-desc',        stats.description ?? '—');
        setText('#cf-token-personality', stats.personality ?? '—');
        setText('#cf-token-first-mes',   stats.first_mes ?? '—');
        setText('#cf-token-total',       stats.total ?? '—');

        const progress = this._rootEl.querySelector('#cf-token-progress');
        if (progress) {
            const pct = Math.max(0, Math.min(100, stats.percentage ?? 0));
            progress.style.width = `${pct}%`;
        }
    }

    setLoadingState(loading, msg = '加载中...') {
        // 你后面如果要接 loading-overlay，可在这里扩展
        console.debug('[CardForge][MainPanel] loading:', loading, msg);
    }

    // ─────────────────────────────────────────
    // 内部：构建面板
    // ─────────────────────────────────────────

    _buildPanel() {
        if (document.getElementById('cardforge-main-panel')) {
            this._rootEl = document.getElementById('cardforge-main-panel');
            this._backdropEl = document.getElementById('cardforge-backdrop');
            return;
        }

        // 创建背景遮罩
        const backdrop = document.createElement('div');
        backdrop.id = 'cardforge-backdrop';
        backdrop.style.cssText = `
            display:none;
            position:fixed;
            inset:0;
            background:rgba(0,0,0,0.65);
            z-index:9999;
        `;
        backdrop.addEventListener('click', () => this.hide());
        document.body.appendChild(backdrop);
        this._backdropEl = backdrop;

        const wrapper = document.createElement('div');
        wrapper.innerHTML = this._getHTML();
        document.body.appendChild(wrapper.firstElementChild);
        this._rootEl = document.getElementById('cardforge-main-panel');

        this._injectStyles();
    }

    _getHTML() {
        return `
<div id="cardforge-main-panel" style="
    display:none;
    position:fixed;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    width:min(1100px, 96vw);
    max-width:96vw;
    height:min(780px, calc(100vh - 60px));
    max-height:calc(100vh - 60px);
    z-index:10000;
    background:var(--cf-bg-panel,#1a1a2e);
    border:1px solid var(--cf-border,#444);
    border-radius:12px;
    box-shadow:0 12px 40px rgba(0,0,0,0.45);
    overflow:hidden;
    flex-direction:column;
    color:var(--cf-text,#eee);
">
    <div class="cardforge-header">
        <span class="cardforge-header-logo">🎴</span>
        <span class="cardforge-header-title">ST-CardForge Pro</span>

        <div style="display:flex;align-items:center;gap:8px;margin-left:auto">
            <button class="cardforge-btn cardforge-btn-ghost cardforge-btn-sm" id="cf-btn-wizard" title="启动新手向导">🧙 向导</button>
            <button class="cardforge-btn cardforge-btn-ghost cardforge-btn-sm" id="cf-btn-settings" title="拓展设置">⚙️</button>
            <button class="cardforge-btn cardforge-btn-ghost cardforge-btn-sm" id="cf-btn-help" title="帮助 / 导览">❓</button>
            <button class="cardforge-btn cardforge-btn-ghost cardforge-btn-sm" id="cf-btn-close" title="关闭面板" style="color:var(--cf-danger,#e74c3c)">✕</button>
        </div>
        <span class="cardforge-header-version">v1.0.0</span>
    </div>

    <div class="cardforge-body">
        <nav class="cardforge-sidebar" id="cf-sidebar">
            <div class="cardforge-nav-section-label">✨ 内容创作</div>

            <div class="cardforge-nav-item active" data-module="card-generator">
                <span class="cardforge-nav-icon">🎴</span>
                <span class="cardforge-nav-label">角色卡生成器</span>
            </div>

            <div class="cardforge-nav-item" data-module="worldbook">
                <span class="cardforge-nav-icon">🌍</span>
                <span class="cardforge-nav-label">世界书生成器</span>
            </div>

            <div class="cardforge-nav-item" data-module="greeting">
                <span class="cardforge-nav-icon">💬</span>
                <span class="cardforge-nav-label">开场白工坊</span>
            </div>

            <div class="cardforge-nav-separator"></div>
            <div class="cardforge-nav-section-label">🛠️ 脚本与系统</div>

            <div class="cardforge-nav-item" data-module="stscript-forge">
                <span class="cardforge-nav-icon">⚡</span>
                <span class="cardforge-nav-label">STscript 锻造器</span>
                <span class="cardforge-nav-badge">NEW</span>
            </div>

            <div class="cardforge-nav-item" data-module="rpg-tracker">
                <span class="cardforge-nav-icon">📊</span>
                <span class="cardforge-nav-label">RPG 属性追踪</span>
            </div>

            <div class="cardforge-nav-item" data-module="plot-branch">
                <span class="cardforge-nav-icon">🌿</span>
                <span class="cardforge-nav-label">剧情分支</span>
            </div>

            <div class="cardforge-nav-separator"></div>
            <div class="cardforge-nav-section-label">🔧 工具</div>

            <div class="cardforge-nav-item" data-module="regex-forge">
                <span class="cardforge-nav-icon">🔍</span>
                <span class="cardforge-nav-label">正则锻造器</span>
            </div>

            <div class="cardforge-nav-item" data-module="field-enhancer">
                <span class="cardforge-nav-icon">✨</span>
                <span class="cardforge-nav-label">字段增强器</span>
            </div>

            <div class="cardforge-nav-separator"></div>

            <div class="cardforge-nav-item" data-module="exporter">
                <span class="cardforge-nav-icon">📦</span>
                <span class="cardforge-nav-label">导出 / 导入</span>
            </div>

            <div class="cardforge-nav-item" data-module="preview">
                <span class="cardforge-nav-icon">👁</span>
                <span class="cardforge-nav-label">角色卡预览</span>
            </div>
        </nav>

        <main class="cardforge-content" id="cf-content">
            <div id="cf-panel-card-generator" class="cardforge-module-panel active"></div>
            <div id="cf-panel-worldbook" class="cardforge-module-panel"></div>
            <div id="cf-panel-greeting" class="cardforge-module-panel"></div>
            <div id="cf-panel-stscript-forge" class="cardforge-module-panel"></div>
            <div id="cf-panel-rpg-tracker" class="cardforge-module-panel"></div>
            <div id="cf-panel-plot-branch" class="cardforge-module-panel"></div>
            <div id="cf-panel-regex-forge" class="cardforge-module-panel"></div>
            <div id="cf-panel-field-enhancer" class="cardforge-module-panel"></div>
            <div id="cf-panel-exporter" class="cardforge-module-panel"></div>
            <div id="cf-panel-preview" class="cardforge-module-panel"></div>
            <div id="cf-panel-settings" class="cardforge-module-panel"></div>
        </main>
    </div>

    <div class="cardforge-token-bar" id="cf-token-bar">
        <div class="cardforge-token-item"><span class="label">📝 描述</span><span class="value" id="cf-token-desc">—</span></div>
        <div class="cardforge-token-item"><span class="label">💎 性格</span><span class="value" id="cf-token-personality">—</span></div>
        <div class="cardforge-token-item"><span class="label">💬 首条消息</span><span class="value" id="cf-token-first-mes">—</span></div>
        <div class="cardforge-token-progress">
            <div class="cardforge-token-progress-fill" id="cf-token-progress" style="width:0%"></div>
        </div>
        <div class="cardforge-token-item"><span class="label">🔢 总计</span><span class="value" id="cf-token-total">—</span></div>
    </div>

    <div id="cardforge-toast-container"></div>
</div>`;
    }

    _injectStyles() {
        if (document.getElementById('cardforge-main-panel-styles')) return;

        const style = document.createElement('style');
        style.id = 'cardforge-main-panel-styles';
        style.textContent = `
.cardforge-header {
    display:flex;
    align-items:center;
    gap:10px;
    padding:12px 16px;
    background:linear-gradient(135deg,var(--cf-primary,#7b68ee),var(--cf-primary-dark,#5a4fcf));
    border-bottom:1px solid var(--cf-border,#444);
}
.cardforge-header-logo { font-size:22px; }
.cardforge-header-title { font-size:16px; font-weight:800; color:#fff; }
.cardforge-header-version {
    margin-left:8px;
    font-size:10px;
    padding:2px 8px;
    border-radius:999px;
    background:rgba(255,255,255,0.18);
    color:#fff;
}
.cardforge-body {
    display:flex;
    flex:1;
    min-height:0;
}
.cardforge-sidebar {
    width:220px;
    flex-shrink:0;
    background:var(--cf-bg-card,#16213e);
    border-right:1px solid var(--cf-border,#444);
    overflow-y:auto;
    padding:10px 0;
}
.cardforge-nav-section-label {
    padding:8px 16px;
    font-size:11px;
    font-weight:700;
    color:var(--cf-text-muted,#aaa);
    text-transform:uppercase;
    letter-spacing:0.4px;
}
.cardforge-nav-item {
    display:flex;
    align-items:center;
    gap:8px;
    padding:10px 16px;
    cursor:pointer;
    transition:all 0.15s ease;
    border-left:3px solid transparent;
    color:var(--cf-text,#eee);
}
.cardforge-nav-item:hover {
    background:rgba(123,104,238,0.10);
}
.cardforge-nav-item.active {
    background:rgba(123,104,238,0.18);
    border-left-color:var(--cf-primary,#7b68ee);
    color:var(--cf-primary,#7b68ee);
}
.cardforge-nav-badge {
    margin-left:auto;
    font-size:10px;
    padding:1px 6px;
    border-radius:999px;
    background:var(--cf-primary,#7b68ee);
    color:#fff;
}
.cardforge-nav-separator {
    height:1px;
    background:var(--cf-border,#444);
    margin:10px 0;
}
.cardforge-content {
    flex:1;
    min-width:0;
    min-height:0;
    overflow:hidden;
    position:relative;
    background:var(--cf-bg-panel,#1a1a2e);
}
.cardforge-module-panel {
    display:none;
    height:100%;
    overflow:auto;
    padding:16px;
    box-sizing:border-box;
}
.cardforge-module-panel.active {
    display:block;
}
.cardforge-btn {
    padding:8px 14px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    transition:all 0.15s ease;
}
.cardforge-btn-sm {
    padding:6px 10px;
    font-size:12px;
}
.cardforge-btn-ghost {
    background:rgba(255,255,255,0.08);
    color:#fff;
}
.cardforge-btn-ghost:hover {
    background:rgba(255,255,255,0.16);
}
.cardforge-token-bar {
    display:flex;
    align-items:center;
    gap:12px;
    padding:10px 14px;
    border-top:1px solid var(--cf-border,#444);
    background:var(--cf-bg-card,#16213e);
}
.cardforge-token-item {
    display:flex;
    gap:6px;
    font-size:12px;
    color:var(--cf-text-muted,#aaa);
}
.cardforge-token-item .value {
    color:var(--cf-text,#eee);
    font-weight:700;
}
.cardforge-token-progress {
    flex:1;
    height:8px;
    border-radius:999px;
    overflow:hidden;
    background:rgba(255,255,255,0.08);
}
.cardforge-token-progress-fill {
    height:100%;
    background:linear-gradient(90deg,var(--cf-primary,#7b68ee),var(--cf-success,#2ecc71));
    transition:width 0.2s ease;
}
.cardforge-panel-card {
    background:var(--cf-bg-card,#16213e);
    border:1px solid var(--cf-border,#444);
    border-radius:10px;
    padding:16px;
}
.cardforge-panel-title {
    font-size:16px;
    font-weight:800;
    margin-bottom:10px;
    color:var(--cf-primary,#7b68ee);
}
.cardforge-muted {
    color:var(--cf-text-muted,#aaa);
    font-size:12px;
    line-height:1.7;
}
@media (max-width: 600px) {
    #cardforge-main-panel {
        width: 98vw !important;
        max-width: 98vw !important;
        border-radius: 10px !important;
    }
    .cardforge-sidebar {
        width: 50px !important;
    }
    .cardforge-nav-label,
    .cardforge-nav-section-label,
    .cardforge-nav-badge {
        display: none !important;
    }
    .cardforge-nav-item {
        justify-content: center;
        padding: 12px 0 !important;
    }
    .cardforge-nav-icon {
        font-size: 18px;
    }
    .cardforge-header-version {
        display: none;
    }
    .cardforge-token-bar {
        flex-wrap: wrap;
        gap: 6px;
        font-size: 11px;
    }
}
`;
        document.head.appendChild(style);
    }

    // ─────────────────────────────────────────
    // 内部：绑定事件
    // ─────────────────────────────────────────

    _bindEvents() {
        const q = (sel) => this._rootEl?.querySelector(sel);

        q('#cf-btn-close')?.addEventListener('click', () => this.hide());

        q('#cf-btn-wizard')?.addEventListener('click', () => {
            if (this._modules.wizard?.show) {
                this._modules.wizard.show();
            } else {
                alert('向导模块尚未初始化');
            }
        });

        q('#cf-btn-settings')?.addEventListener('click', () => {
            this.switchModule('settings');
        });

        q('#cf-btn-help')?.addEventListener('click', () => {
            alert('帮助/导览功能尚未接入。');
        });

        this._rootEl?.querySelectorAll('.cardforge-nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const moduleId = item.dataset.module;
                if (moduleId) this.switchModule(moduleId);
            });
        });

        this._boundEscHandler = (e) => {
            if (e.key === 'Escape' && this._visible) {
                this.hide();
            }
        };
        document.addEventListener('keydown', this._boundEscHandler);
    }

    // ─────────────────────────────────────────
    // 内部：挂载各模块面板
    // ─────────────────────────────────────────

    async _mountModulePanels() {
        const mountMap = [
            ['cardGenerator', '#cf-panel-card-generator', '角色卡生成器'],
            ['wbGenerator', '#cf-panel-worldbook', '世界书生成器'],
            ['greetingGen', '#cf-panel-greeting', '开场白工坊'],
            ['scriptForge', '#cf-panel-stscript-forge', 'STscript 锻造器'],
            ['rpgTracker', '#cf-panel-rpg-tracker', 'RPG 属性追踪'],
            ['branchEngine', '#cf-panel-plot-branch', '剧情分支'],
            ['regexForge', '#cf-panel-regex-forge', '正则锻造器'],
            ['fieldEnhancer', '#cf-panel-field-enhancer', '字段增强器'],
            ['exporter', '#cf-panel-exporter', '导出 / 导入'],
        ];

        for (const [moduleKey, selector, title] of mountMap) {
            const panel = this._rootEl?.querySelector(selector);
            const moduleInstance = this._modules[moduleKey];

            if (!panel) continue;

            if (moduleInstance?.mountUI) {
                try {
                    await moduleInstance.mountUI(panel);
                    console.log(`[MainPanel] ✅ ${title} mountUI 成功`);
                } catch (error) {
                    console.error(`[MainPanel] ${title} mountUI 失败:`, error);
                    await this._loadHTMLIntoPanel(panel, moduleKey, title);
                }
            } else {
                // 无论模块是否加载，都尝试加载 HTML 模板
                await this._loadHTMLIntoPanel(panel, moduleKey, title);
            }
        }

        this._renderPreviewPanel();
        this._renderSettingsPanel();
    }

    _renderPreviewPanel() {
        const panel = this._rootEl?.querySelector('#cf-panel-preview');
        if (!panel) return;

        panel.innerHTML = `
            <div class="cardforge-panel-card">
                <div class="cardforge-panel-title">👁 角色卡预览</div>
                <div class="cardforge-muted">
                    预览面板已预留，但尚未接入 preview-panel.js / preview-panel.html 的实际内容。
                </div>
            </div>
        `;
    }

    _renderSettingsPanel() {
        const panel = this._rootEl?.querySelector('#cf-panel-settings');
        if (!panel) return;

        panel.innerHTML = `
            <div class="cardforge-panel-card">
                <div class="cardforge-panel-title">⚙️ 拓展设置</div>
                <div class="cardforge-muted" style="margin-bottom:12px;">
                    当前先显示简化版设置面板。后续可把你原始 settings HTML 全量迁入。
                </div>

                <div style="display:grid;gap:12px;">
                    <label>
                        <div style="margin-bottom:4px;font-size:12px;">AI 模型偏好</div>
                        <select id="cf-setting-ai-model" style="width:100%;padding:8px;border-radius:6px;background:var(--cf-bg-panel,#1a1a2e);color:var(--cf-text,#eee);border:1px solid var(--cf-border,#444);">
                            <option value="current">使用当前选中模型</option>
                            <option value="gpt-4o">GPT-4o</option>
                            <option value="claude-3-5-sonnet">Claude 3.5 Sonnet</option>
                            <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
                        </select>
                    </label>

                    <label style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" id="cf-setting-auto-save" checked>
                        <span>自动保存草稿</span>
                    </label>

                    <div>
                        <button id="cf-save-settings-btn" class="cardforge-btn" style="background:var(--cf-primary,#7b68ee);color:#fff;">
                            💾 保存设置
                        </button>
                    </div>
                </div>
            </div>
        `;

        panel.querySelector('#cf-save-settings-btn')?.addEventListener('click', () => {
            const model = panel.querySelector('#cf-setting-ai-model')?.value ?? 'current';
            const autoSave = !!panel.querySelector('#cf-setting-auto-save')?.checked;

            try {
                this._settings?.set?.('aiModelPreference', model);
                this._settings?.set?.('autoSaveDraft', autoSave);
                this._settings?.save?.();
                alert('设置已保存');
            } catch (e) {
                console.error('[MainPanel] 保存设置失败:', e);
                alert('保存设置失败');
            }
        });
    }

    async _loadHTMLIntoPanel(panel, moduleKey, title) {
        const htmlFile = _HTML_FILE_MAP[moduleKey];
        if (!htmlFile) {
            panel.innerHTML = this._buildFallbackPanel(title, '模块尚未加载，且无对应的 UI 模板。');
            return;
        }

        try {
            const htmlUrl = new URL(htmlFile, _EXTENSION_BASE_URL).href;
            const resp = await fetch(htmlUrl);
            if (resp.ok) {
                panel.innerHTML = await resp.text();
                console.log(`[MainPanel] ✅ ${title} HTML 模板已加载`);
            } else {
                console.warn(`[MainPanel] ⚠️ 无法获取 ${title} HTML (HTTP ${resp.status}): ${htmlUrl}`);
                panel.innerHTML = this._buildFallbackPanel(
                    title,
                    `UI 文件加载失败 (HTTP ${resp.status})。模块逻辑${this._modules[moduleKey] ? '已' : '未'}加载。`
                );
            }
        } catch(e) {
            console.error(`[MainPanel] 加载 ${title} HTML 出错:`, e);
            panel.innerHTML = this._buildFallbackPanel(
                title,
                `UI 文件加载出错：${e.message}`
            );
        }
    }

    _buildFallbackPanel(title, message) {
        return `
            <div class="cardforge-panel-card">
                <div class="cardforge-panel-title">${title}</div>
                <div class="cardforge-muted">${message}</div>
            </div>
        `;
    }
}