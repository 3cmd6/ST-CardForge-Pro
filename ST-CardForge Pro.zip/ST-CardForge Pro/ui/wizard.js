/**
 * @file ui/wizard.js
 * @description ST-CardForge Pro 新手创作向导（完整版）
 *              共 6 步：基础信息 → 外貌性格 → 背景故事 → 对话风格 → 高级选项 → 确认生成
 * @version 1.0.0
 */

import { EVENTS } from '../contracts.js';

// ── 静态数据 ──────────────────────────────────────────────────────

const GENRES = [
    { value: 'fantasy',    icon: '🏰', label: '奇幻' },
    { value: 'modern',     icon: '🏙️', label: '现代' },
    { value: 'scifi',      icon: '🚀', label: '科幻' },
    { value: 'eastern',    icon: '☯️', label: '东方' },
    { value: 'horror',     icon: '🌙', label: '恐怖' },
    { value: 'romance',    icon: '💕', label: '浪漫' },
    { value: 'cyberpunk',  icon: '🤖', label: '赛博朋克' },
    { value: 'mythology',  icon: '⚡', label: '神话' },
    { value: 'historical', icon: '📜', label: '历史' },
    { value: 'postapoc',   icon: '☢️', label: '末世' },
];

const TRAITS = [
    '温柔体贴', '冷静理智', '活泼开朗', '神秘莫测', '正直勇敢',
    '腹黑狡猾', '天真烂漫', '傲娇', '毒舌', '话少稳重',
    '热情似火', '悲天悯人', '执着偏执', '洒脱不羁', '善解人意',
    '外冷内热', '刀子嘴豆腐心', '高冷禁欲', '平静如水', '霸道强势',
];

const SPEECH_STYLES = [
    { value: 'literary',   icon: '📖', label: '文学化',   desc: '辞藻优美，意境深远' },
    { value: 'casual',     icon: '💬', label: '轻松日常', desc: '随意自然，贴近生活' },
    { value: 'dramatic',   icon: '🎭', label: '戏剧性',   desc: '情绪饱满，张力十足' },
    { value: 'mysterious', icon: '🌙', label: '神秘感',   desc: '言辞隐晦，耐人寻味' },
    { value: 'poetic',     icon: '🌸', label: '诗意',     desc: '意象丰富，如诗如画' },
    { value: 'action',     icon: '⚔️', label: '动作派',   desc: '简洁有力，利落干脆' },
    { value: 'slice_life', icon: '☕', label: '日常感',   desc: '温馨细腻，娓娓道来' },
    { value: 'formal',     icon: '📜', label: '正式文体', desc: '端庄严肃，措辞考究' },
];

const CARD_FIELDS = [
    { key: 'description',              label: '📝 描述（description）',      checked: true },
    { key: 'personality',              label: '💎 性格（personality）',      checked: true },
    { key: 'scenario',                 label: '🌍 场景（scenario）',         checked: true },
    { key: 'first_mes',                label: '💬 开场白（first_mes）',      checked: true },
    { key: 'mes_example',              label: '🗨️ 对话示例（mes_example）', checked: true },
    { key: 'system_prompt',            label: '⚙️ 系统提示（system_prompt）',checked: false },
    { key: 'post_history_instructions',label: '📋 后置指令（post_history）', checked: false },
    { key: 'creator_notes',            label: '📌 创作者注记',               checked: false },
];

const STEPS_META = [
    { num: 1, icon: '👤', label: '基础信息' },
    { num: 2, icon: '💎', label: '外貌性格' },
    { num: 3, icon: '🌍', label: '背景故事' },
    { num: 4, icon: '💬', label: '对话风格' },
    { num: 5, icon: '⚙️', label: '高级选项' },
    { num: 6, icon: '🚀', label: '确认生成' },
];

// ── Wizard 主类 ───────────────────────────────────────────────────

export class Wizard {
    /**
     * @param {object} cardGenerator - CardGenerator 实例
     * @param {object} eventBus      - EventBus 实例
     * @param {object} i18n          - I18n 实例（可选）
     */
    constructor(cardGenerator, eventBus, i18n) {
        this._cardGen  = cardGenerator;
        this._bus      = eventBus;
        this._i18n     = i18n;

        /** 当前步骤（1-based） */
        this._step     = 1;
        this._total    = STEPS_META.length;

        /** 收集到的表单数据 */
        this._data     = {};

        /** 是否正在生成中 */
        this._generating = false;

        /** 根 DOM */
        this._rootEl   = null;

        /** 事件取消列表 */
        this._unsubs   = [];
    }

    // ── 生命周期 ──────────────────────────────────────────────────

    async init() {
        this._injectStyles();
        console.log('[Wizard] 初始化完成');
    }

    show() {
        if (this._rootEl) {
            this._rootEl.style.display = 'flex';
        } else {
            this._buildDOM();
            this._renderDynamicContent();
            this._bindEvents();
        }
        this._goToStep(1);
    }

    hide() {
        if (this._rootEl) {
            this._rootEl.style.display = 'none';
        }
    }

    destroy() {
        this._unsubs.forEach(fn => fn());
        this._unsubs   = [];
        this._rootEl?.remove();
        this._rootEl   = null;
        this._data     = {};
        this._step     = 1;
        this._generating = false;
    }

    // ── DOM 构建 ──────────────────────────────────────────────────

    _buildDOM() {
        const wrap = document.createElement('div');
        wrap.innerHTML = this._getHTML();
        document.body.appendChild(wrap.firstElementChild);
        this._rootEl = document.getElementById('cardforge-wizard-backdrop');
    }

    /** 完整 HTML 模板 */
    _getHTML() {
        return `
<div id="cardforge-wizard-backdrop" style="
    position:fixed;inset:0;
    background:rgba(0,0,0,0.65);
    z-index:10500;
    display:flex;align-items:center;justify-content:center;
    backdrop-filter:blur(3px);
    animation:cf-backdrop-in 0.2s ease;
">
<div id="cardforge-wizard" style="
    background:var(--cf-bg-panel,#1a1a2e);
    border:1px solid var(--cf-border,#444);
    border-radius:12px;
    box-shadow:0 16px 48px rgba(0,0,0,0.6);
    width:min(680px,94vw);
    max-height:90vh;
    display:flex;flex-direction:column;
    overflow:hidden;
    animation:cf-modal-in 0.25s ease;
">

    <!-- ══ 顶部进度导航 ══ -->
    <div id="cf-wiz-header" style="
        background:linear-gradient(135deg,var(--cf-primary-dark,#5a4fcf),var(--cf-primary,#7b68ee));
        padding:16px 24px 0;
        flex-shrink:0;
    ">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <span style="font-size:22px">🧙</span>
            <div>
                <div style="font-size:16px;font-weight:800;color:#fff">角色创作向导</div>
                <div style="font-size:11px;color:rgba(255,255,255,0.65);margin-top:1px">
                    按步骤填写，AI 将为您生成完整角色卡
                </div>
            </div>
            <button id="cf-wiz-close" style="
                margin-left:auto;background:none;border:none;
                color:rgba(255,255,255,0.7);cursor:pointer;
                font-size:18px;padding:4px 6px;border-radius:4px;
                transition:color 0.15s;
            " title="关闭向导">✕</button>
        </div>
        <!-- 步骤标签由 JS 渲染 -->
        <div id="cf-wiz-steps" style="
            display:flex;gap:0;overflow-x:auto;
            padding-bottom:0;white-space:nowrap;
            scrollbar-width:none;
        "></div>
    </div>

    <!-- ══ 步骤内容区 ══ -->
    <div id="cf-wiz-body" style="
        flex:1;overflow-y:auto;
        padding:24px;
        display:flex;flex-direction:column;
    ">

        <!-- Step 1：基础信息 -->
        <div class="cf-wiz-step-panel" data-step="1">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">👤</span>
                <div>
                    <div class="cf-wiz-step-name">基础信息</div>
                    <div class="cf-wiz-step-desc">给角色一个名字和简短的核心概念</div>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">角色名称 <span class="cf-required">*</span></label>
                <input type="text" class="cf-input cf-wiz-field" data-field="name"
                    placeholder="如：叶千夜 / Yuki Sato / Luna Evershade" maxlength="100"/>
                <div class="cf-hint">角色的正式名字，将显示在角色卡标题处</div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">核心概念 / 一句话简介 <span class="cf-required">*</span></label>
                <input type="text" class="cf-input cf-wiz-field" data-field="concept"
                    placeholder="如：落魄的皇室密探、善良的末世医者、孤独的星际猎人"/>
                <div class="cf-hint">这是最重要的输入——AI 将以此为核心展开创作</div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">世界观 / 设定类型</label>
                <div id="cf-wiz-genre-grid" style="
                    display:grid;
                    grid-template-columns:repeat(auto-fill,minmax(130px,1fr));
                    gap:8px;margin-top:4px;
                "></div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">角色性别</label>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <label class="cf-wiz-radio-btn" data-field="gender" data-value="female">
                        <input type="radio" name="cf-gender" value="female" style="display:none"> 👩 女性
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="gender" data-value="male">
                        <input type="radio" name="cf-gender" value="male" style="display:none"> 👨 男性
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="gender" data-value="nonbinary">
                        <input type="radio" name="cf-gender" value="nonbinary" style="display:none"> ⚧ 非二元
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="gender" data-value="unknown">
                        <input type="radio" name="cf-gender" value="unknown" style="display:none"> ❓ 不设定
                    </label>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">输出语言</label>
                <select class="cf-select cf-wiz-field" data-field="outputLanguage">
                    <option value="zh-CN">中文（简体）</option>
                    <option value="zh-TW">中文（繁體）</option>
                    <option value="en-US">English</option>
                    <option value="ja-JP">日本語</option>
                    <option value="ko-KR">한국어</option>
                </select>
            </div>
        </div>

        <!-- Step 2：外貌与性格 -->
        <div class="cf-wiz-step-panel" data-step="2" style="display:none">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">💎</span>
                <div>
                    <div class="cf-wiz-step-name">外貌与性格</div>
                    <div class="cf-wiz-step-desc">描述角色的外形特征和性格特质（可跳过让 AI 自由发挥）</div>
                </div>
            </div>
            <div style="
                background:rgba(123,104,238,0.1);
                border:1px dashed rgba(123,104,238,0.4);
                border-radius:8px;padding:10px 14px;
                display:flex;align-items:center;gap:10px;margin-bottom:16px;
            ">
                <span style="font-size:18px">✨</span>
                <div style="flex:1;font-size:12px;color:var(--cf-text-muted,#aaa);line-height:1.5">
                    不知道怎么填？点击让 AI 根据你的角色概念自动建议外貌和性格
                </div>
                <button class="cf-btn cf-btn-primary cf-btn-sm" id="cf-wiz-ai-suggest-step2">
                    ✨ AI 建议
                </button>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">外貌描述</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="appearance" rows="3"
                    placeholder="身高、发色、眼睛、服装风格、标志性特征等（留空则 AI 自由创作）"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">性格特质（多选）</label>
                <div id="cf-wiz-traits-grid" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px"></div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">性格补充描述</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="personalityNote" rows="2"
                    placeholder="除上方标签外，有什么特别的性格细节？（留空 AI 自动补全）"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">年龄设定</label>
                <div style="display:flex;gap:8px;align-items:center">
                    <input type="number" class="cf-input cf-wiz-field" data-field="age"
                        placeholder="如：23" min="1" max="9999"
                        style="width:100px;flex-shrink:0">
                    <span style="font-size:12px;color:var(--cf-text-muted,#aaa)">岁（留空则 AI 决定）</span>
                </div>
            </div>
        </div>

        <!-- Step 3：背景故事 -->
        <div class="cf-wiz-step-panel" data-step="3" style="display:none">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">🌍</span>
                <div>
                    <div class="cf-wiz-step-name">背景故事</div>
                    <div class="cf-wiz-step-desc">角色生活的世界和她/他的过去</div>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">世界背景简述</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="worldBackground" rows="3"
                    placeholder="这个世界的时代、环境、特殊设定等（留空则 AI 根据风格类型创作）"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">角色的过去 / 经历</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="backstory" rows="4"
                    placeholder="角色的���长经历、重要事件、目前处境等关键背景信息"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">角色的目标 / 动机</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="motivation" rows="2"
                    placeholder="角色想要什么？在追求什么？有什么恐惧或执念？"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">与玩家的初始关系</label>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="stranger">
                        <input type="radio" name="cf-rel" value="stranger" style="display:none"> 🔹 陌生人
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="acquaintance">
                        <input type="radio" name="cf-rel" value="acquaintance" style="display:none"> 🤝 相识
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="friend">
                        <input type="radio" name="cf-rel" value="friend" style="display:none"> 👫 朋友
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="rival">
                        <input type="radio" name="cf-rel" value="rival" style="display:none"> ⚔️ 对手
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="lover">
                        <input type="radio" name="cf-rel" value="lover" style="display:none"> 💗 恋人
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="relationship" data-value="custom">
                        <input type="radio" name="cf-rel" value="custom" style="display:none"> ✏️ 自定义
                    </label>
                </div>
                <input type="text" class="cf-input cf-wiz-field" data-field="relationshipCustom"
                    placeholder="自定义关系描述…"
                    id="cf-wiz-rel-custom"
                    style="margin-top:6px;display:none">
            </div>
        </div>

        <!-- Step 4：对话风格与开场白 -->
        <div class="cf-wiz-step-panel" data-step="4" style="display:none">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">💬</span>
                <div>
                    <div class="cf-wiz-step-name">对话风格与开场白</div>
                    <div class="cf-wiz-step-desc">角色如何说话？第一句话是什么？</div>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">对话风格</label>
                <div id="cf-wiz-style-grid" style="
                    display:grid;
                    grid-template-columns:repeat(auto-fill,minmax(150px,1fr));
                    gap:8px;margin-top:4px;
                "></div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">语言习惯 / 口头禅</label>
                <input type="text" class="cf-input cf-wiz-field" data-field="speechHabits"
                    placeholder="如：总是用敬语、喜欢引用古诗、经常说「不过如此」">
            </div>
            <div class="cf-form-group">
                <label class="cf-label">开场白情景</label>
                <select class="cf-select cf-wiz-field" data-field="greetingScenario" id="cf-wiz-scenario-select">
                    <option value="first_meeting">✨ 初次相遇</option>
                    <option value="reunion">🔄 久别重逢</option>
                    <option value="crisis">🚨 危机时刻</option>
                    <option value="daily">☀️ 日常相处</option>
                    <option value="conflict">⚡ 正面冲突</option>
                    <option value="custom">✏️ 自定义情景</option>
                </select>
            </div>
            <div class="cf-form-group" id="cf-wiz-scenario-custom-wrap" style="display:none">
                <label class="cf-label">自定义开场情景描述</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="greetingScenarioCustom" rows="2"
                    placeholder="描述角色与玩家相遇时的具体场景…"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">开场白字数参考</label>
                <div style="display:flex;align-items:center;gap:12px">
                    <input type="range" class="cf-range cf-wiz-field" data-field="greetingWordCount"
                        id="cf-wiz-wc-range"
                        min="100" max="600" step="50" value="200" style="flex:1">
                    <span id="cf-wiz-wc-label"
                        style="width:60px;text-align:right;font-size:12px;
                               color:var(--cf-text-muted,#aaa);font-weight:600">约 200 字</span>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">开场白视角</label>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <label class="cf-wiz-radio-btn" data-field="pov" data-value="first">
                        <input type="radio" name="cf-pov" value="first" style="display:none"> 我（第一人称）
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="pov" data-value="second">
                        <input type="radio" name="cf-pov" value="second" style="display:none"> 你（第二人称）
                    </label>
                    <label class="cf-wiz-radio-btn" data-field="pov" data-value="third">
                        <input type="radio" name="cf-pov" value="third" style="display:none"> 他/她（第三人称）
                    </label>
                </div>
            </div>
        </div>

        <!-- Step 5：高级选项 -->
        <div class="cf-wiz-step-panel" data-step="5" style="display:none">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">⚙️</span>
                <div>
                    <div class="cf-wiz-step-name">高级选项（可选）</div>
                    <div class="cf-wiz-step-desc">生成策略与附加功能，可全部跳过</div>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">需要生成哪些字段？</label>
                <div id="cf-wiz-fields-checklist" style="
                    display:grid;grid-template-columns:1fr 1fr;
                    gap:6px;margin-top:4px;
                "></div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">额外要求 / 特殊设定</label>
                <textarea class="cf-textarea cf-wiz-field" data-field="extraRequirements" rows="3"
                    placeholder="任何没有在前面填写的特殊要求、禁止内容、或需要强调的细节"></textarea>
            </div>
            <div class="cf-form-group">
                <label class="cf-label">附加生成选项</label>
                <div style="display:flex;flex-direction:column;gap:6px">
                    <label class="cf-checkbox-group">
                        <input type="checkbox" id="cf-wiz-gen-wb">
                        <span>是，角色生成后自动创建配套世界书条目</span>
                    </label>
                    <label class="cf-checkbox-group">
                        <input type="checkbox" id="cf-wiz-gen-alt-greetings" checked>
                        <span>生成 3 条备用开场白（Alternate Greetings）</span>
                    </label>
                    <label class="cf-checkbox-group">
                        <input type="checkbox" id="cf-wiz-gen-mes-example" checked>
                        <span>生成对话示例（mes_example）</span>
                    </label>
                </div>
            </div>
            <div class="cf-form-group">
                <label class="cf-label" style="display:flex;align-items:center">
                    AI 创意程度（Temperature 提示）
                    <span id="cf-wiz-temp-label"
                        style="margin-left:auto;font-weight:400;font-size:11px;
                               color:var(--cf-primary,#7b68ee)">平衡</span>
                </label>
                <input type="range" class="cf-range cf-wiz-field" data-field="creativity"
                    id="cf-wiz-creativity-range"
                    min="0" max="2" step="1" value="1" style="margin-top:4px">
                <div style="display:flex;justify-content:space-between;
                    font-size:10px;color:var(--cf-text-muted,#aaa);
                    margin-top:4px;padding:0 2px">
                    <span>🎯 精确严谨</span>
                    <span>⚖️ 平衡</span>
                    <span>🎨 天马行空</span>
                </div>
            </div>
        </div>

        <!-- Step 6：确认生成 -->
        <div class="cf-wiz-step-panel" data-step="6" style="display:none">
            <div class="cf-wiz-step-title">
                <span class="cf-wiz-step-icon">🚀</span>
                <div>
                    <div class="cf-wiz-step-name">确认生成</div>
                    <div class="cf-wiz-step-desc">检查信息摘要，确认无误后开始生成</div>
                </div>
            </div>
            <!-- 摘要卡 -->
            <div style="
                background:rgba(123,104,238,0.08);
                border:1px solid rgba(123,104,238,0.3);
                border-radius:8px;padding:16px;margin-bottom:16px;
            ">
                <div style="font-size:13px;font-weight:700;margin-bottom:10px">📋 创作摘要</div>
                <div id="cf-wiz-summary-content"
                    style="font-size:13px;line-height:2;color:var(--cf-text,#eee)"></div>
            </div>
            <!-- 预计用时 -->
            <div style="
                display:flex;align-items:center;gap:8px;
                padding:10px 12px;
                background:rgba(52,152,219,0.1);
                border:1px solid rgba(52,152,219,0.25);
                border-radius:8px;
                font-size:12px;color:var(--cf-info,#3498db);
                margin-bottom:16px;
            ">
                <span style="font-size:16px">⏱</span>
                <span>预计生成时间：<strong>约 30~60 秒</strong>（取决于 AI 响应速度）</span>
            </div>
            <!-- 生成进度（生成中显示） -->
            <div id="cf-wiz-progress-area" style="display:none;margin-bottom:16px">
                <div style="
                    background:var(--cf-bg-card,#16213e);
                    border:1px solid var(--cf-border,#444);
                    border-radius:8px;padding:16px;
                    display:flex;flex-direction:column;gap:10px;
                ">
                    <div id="cf-wiz-progress-label"
                        style="font-size:13px;color:var(--cf-text-muted,#aaa);text-align:center">
                        正在初始化…
                    </div>
                    <div style="width:100%;height:6px;background:rgba(255,255,255,0.08);border-radius:3px;overflow:hidden">
                        <div id="cf-wiz-progress-fill"
                            style="height:100%;width:0%;
                                   background:linear-gradient(90deg,var(--cf-primary,#7b68ee),var(--cf-success,#2ecc71));
                                   border-radius:3px;transition:width 0.4s ease"></div>
                    </div>
                    <div id="cf-wiz-progress-fields"
                        style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;font-size:11px"></div>
                </div>
            </div>
            <div style="font-size:11px;color:var(--cf-text-muted,#aaa);line-height:1.7">
                💡 生成完成后，所有内容将自动填入角色卡编辑器，您可以随时手动修改或重新生成单个字段。
            </div>
        </div>

    </div>

    <!-- ══ 底部导航按钮 ══ -->
    <div id="cf-wiz-footer" style="
        display:flex;align-items:center;justify-content:space-between;
        padding:14px 24px;
        border-top:1px solid var(--cf-border,#444);
        background:var(--cf-bg-card,#16213e);
        flex-shrink:0;gap:10px;
    ">
        <button class="cf-btn cf-btn-ghost cf-btn-sm" id="cf-wiz-save-draft" title="保存草稿">
            💾 保存草稿
        </button>
        <span id="cf-wiz-step-label"
            style="font-size:12px;color:var(--cf-text-muted,#aaa);
                   font-weight:600;white-space:nowrap">
            第 1 步 / 共 6 步
        </span>
        <div style="display:flex;gap:8px">
            <button class="cf-btn cf-btn-secondary" id="cf-wiz-prev" disabled>◀ 上一步</button>
            <button class="cf-btn cf-btn-primary" id="cf-wiz-next">下一步 ▶</button>
            <button class="cf-btn cf-btn-primary" id="cf-wiz-generate" style="
                display:none;
                background:linear-gradient(135deg,#7b68ee,#2ecc71);
                border:none;
            ">✨ 开始生成</button>
        </div>
    </div>

</div>
</div>`;
    }

    // ── 注入 CSS ──────────────────────────────────────────────────

    _injectStyles() {
        if (document.getElementById('cf-wizard-styles')) return;
        const style = document.createElement('style');
        style.id = 'cf-wizard-styles';
        style.textContent = `
/* 入场动画 */
@keyframes cf-backdrop-in { from { opacity:0 } to { opacity:1 } }
@keyframes cf-modal-in    { from { opacity:0;transform:scale(0.96) } to { opacity:1;transform:scale(1) } }

/* 步骤标签 */
.cf-wiz-step-tab {
    display:inline-flex; align-items:center; gap:6px;
    padding:8px 14px; font-size:12px; font-weight:600;
    color:rgba(255,255,255,0.55); cursor:pointer;
    border-bottom:3px solid transparent;
    transition:color 0.15s,border-color 0.15s;
    white-space:nowrap; user-select:none; flex-shrink:0;
}
.cf-wiz-step-tab.active { color:#fff; border-bottom-color:rgba(255,255,255,0.9); }
.cf-wiz-step-tab.done   { color:rgba(46,204,113,0.9); }
.cf-wiz-tab-num {
    display:inline-flex; align-items:center; justify-content:center;
    width:18px; height:18px; border-radius:50%;
    background:rgba(255,255,255,0.2); font-size:10px; flex-shrink:0;
}
.cf-wiz-step-tab.active .cf-wiz-tab-num { background:rgba(255,255,255,0.9); color:var(--cf-primary-dark,#5a4fcf); }
.cf-wiz-step-tab.done   .cf-wiz-tab-num { background:rgba(46,204,113,0.35); color:#2ecc71; }

/* 步骤面板标题 */
.cf-wiz-step-title {
    display:flex; align-items:flex-start; gap:12px;
    margin-bottom:20px; padding-bottom:16px;
    border-bottom:1px solid var(--cf-border,#444);
}
.cf-wiz-step-icon { font-size:28px; flex-shrink:0; margin-top:2px; }
.cf-wiz-step-name { font-size:17px; font-weight:800; color:var(--cf-text,#eee); }
.cf-wiz-step-desc { font-size:12px; color:var(--cf-text-muted,#aaa); margin-top:3px; }

/* 通用表单 */
.cf-form-group { margin-bottom:16px; }
.cf-label {
    display:flex; align-items:center;
    font-size:13px; font-weight:600;
    color:var(--cf-text,#eee); margin-bottom:6px;
}
.cf-required { color:var(--cf-danger,#e74c3c); margin-left:3px; }
.cf-hint { font-size:11px; color:var(--cf-text-muted,#aaa); margin-top:3px; line-height:1.5; }

.cf-input, .cf-textarea, .cf-select {
    width:100%; padding:9px 12px;
    background:var(--cf-bg-card,#16213e);
    border:1px solid var(--cf-border,#444);
    border-radius:6px;
    color:var(--cf-text,#eee);
    font-size:13px;
    transition:border-color 0.15s;
    box-sizing:border-box;
}
.cf-input:focus, .cf-textarea:focus, .cf-select:focus {
    outline:none; border-color:var(--cf-primary,#7b68ee);
}
.cf-textarea { resize:vertical; min-height:60px; }
.cf-range { width:100%; accent-color:var(--cf-primary,#7b68ee); }

/* 按钮 */
.cf-btn {
    padding:8px 16px; border:none; border-radius:6px;
    cursor:pointer; font-size:13px; font-weight:600;
    transition:all 0.2s; user-select:none;
}
.cf-btn-primary {
    background:var(--cf-primary,#7b68ee); color:#fff;
}
.cf-btn-primary:hover { background:var(--cf-primary-dark,#5a4fcf); transform:translateY(-1px); }
.cf-btn-secondary {
    background:var(--cf-bg-card,#16213e);
    border:1px solid var(--cf-border,#444);
    color:var(--cf-text,#eee);
}
.cf-btn-secondary:hover { border-color:var(--cf-primary,#7b68ee); }
.cf-btn-secondary:disabled { opacity:0.4; cursor:not-allowed; transform:none; }
.cf-btn-ghost {
    background:transparent;
    border:1px solid var(--cf-border,#444);
    color:var(--cf-text-muted,#aaa);
}
.cf-btn-ghost:hover { border-color:var(--cf-primary,#7b68ee); color:var(--cf-text,#eee); }
.cf-btn-sm { padding:6px 12px; font-size:12px; }

/* 单选/多选按钮 */
.cf-wiz-radio-btn {
    display:inline-flex; align-items:center; gap:5px;
    padding:6px 12px;
    border:1px solid var(--cf-border,#444);
    border-radius:6px; cursor:pointer;
    font-size:12px; font-weight:600;
    color:var(--cf-text-muted,#aaa);
    background:var(--cf-bg-card,#16213e);
    transition:all 0.15s; user-select:none;
}
.cf-wiz-radio-btn:hover { border-color:var(--cf-primary,#7b68ee); color:var(--cf-text,#eee); }
.cf-wiz-radio-btn.selected {
    border-color:var(--cf-primary,#7b68ee);
    background:rgba(123,104,238,0.18);
    color:var(--cf-primary,#7b68ee);
}

/* 风格/类型按钮 */
.cf-wiz-genre-btn, .cf-wiz-style-btn {
    display:flex; align-items:center; gap:6px;
    padding:8px 10px;
    border:1px solid var(--cf-border,#444);
    border-radius:6px; cursor:pointer;
    font-size:12px; font-weight:600;
    color:var(--cf-text-muted,#aaa);
    background:var(--cf-bg-card,#16213e);
    transition:all 0.15s; user-select:none;
}
.cf-wiz-genre-btn:hover, .cf-wiz-style-btn:hover {
    border-color:var(--cf-primary,#7b68ee); color:var(--cf-text,#eee);
}
.cf-wiz-genre-btn.selected, .cf-wiz-style-btn.selected {
    border-color:var(--cf-primary,#7b68ee);
    background:rgba(123,104,238,0.18);
    color:var(--cf-primary,#7b68ee);
}

/* 性格特质标签 */
.cf-wiz-trait-tag {
    display:inline-flex; align-items:center; gap:4px;
    padding:4px 10px; border-radius:12px;
    border:1px solid var(--cf-border,#444);
    cursor:pointer; font-size:12px;
    color:var(--cf-text-muted,#aaa);
    background:var(--cf-bg-card,#16213e);
    transition:all 0.15s; user-select:none;
}
.cf-wiz-trait-tag:hover { border-color:var(--cf-primary,#7b68ee); color:var(--cf-text,#eee); }
.cf-wiz-trait-tag.selected {
    border-color:var(--cf-primary,#7b68ee);
    background:rgba(123,104,238,0.18);
    color:var(--cf-primary,#7b68ee);
}

/* 字段勾选 */
.cf-wiz-field-check {
    display:flex; align-items:center; gap:7px;
    padding:6px 8px; border-radius:6px;
    background:var(--cf-bg-card,#16213e);
    font-size:12px; cursor:pointer;
    transition:background 0.12s;
}
.cf-wiz-field-check:hover { background:rgba(123,104,238,0.12); }
.cf-wiz-field-check input[type=checkbox] { accent-color:var(--cf-primary,#7b68ee); }

/* 复选框组 */
.cf-checkbox-group {
    display:flex; align-items:center; gap:8px;
    font-size:13px; color:var(--cf-text,#eee);
    cursor:pointer; padding:4px 0;
}
.cf-checkbox-group input[type=checkbox] { accent-color:var(--cf-primary,#7b68ee); }

/* 摘要 */
.cf-wiz-summary-row { display:flex; gap:8px; align-items:baseline; line-height:1.8; }
.cf-wiz-summary-key {
    font-size:11px; font-weight:700;
    color:var(--cf-text-muted,#aaa);
    text-transform:uppercase; letter-spacing:0.5px;
    min-width:80px; flex-shrink:0;
}
.cf-wiz-summary-val { font-size:13px; color:var(--cf-text,#eee); flex:1; }

/* 字段状态点 */
.cf-wiz-field-dot {
    display:inline-flex; align-items:center; gap:4px;
    padding:3px 8px; border-radius:8px;
    font-size:11px; font-weight:600;
    background:rgba(255,255,255,0.06);
    color:var(--cf-text-muted,#aaa);
    transition:all 0.2s;
}
.cf-wiz-field-dot.generating {
    background:rgba(243,156,18,0.15); color:var(--cf-warning,#f39c12);
    animation:cf-pulse 0.8s ease infinite;
}
.cf-wiz-field-dot.done { background:rgba(46,204,113,0.15); color:var(--cf-success,#2ecc71); }

@keyframes cf-pulse { 0%,100% { opacity:1 } 50% { opacity:0.5 } }
`;
        document.head.appendChild(style);
    }

    // ── 动态内容渲染 ─────────────────────────────────────────────

    _renderDynamicContent() {
        this._renderStepTabs();
        this._renderGenreGrid();
        this._renderTraitsGrid();
        this._renderStyleGrid();
        this._renderFieldsChecklist();
    }

    _renderStepTabs() {
        const el = this._rootEl.querySelector('#cf-wiz-steps');
        if (!el) return;
        el.innerHTML = STEPS_META.map(s => `
            <div class="cf-wiz-step-tab ${s.num === 1 ? 'active' : ''}" data-step="${s.num}">
                <span class="cf-wiz-tab-num">${s.icon}</span>
                <span>${s.label}</span>
            </div>
        `).join('');

        // 点击标签直接跳步
        el.querySelectorAll('.cf-wiz-step-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const target = parseInt(tab.dataset.step);
                if (target < this._step) this._goToStep(target);
            });
        });
    }

    _renderGenreGrid() {
        const el = this._rootEl.querySelector('#cf-wiz-genre-grid');
        if (!el) return;
        el.innerHTML = GENRES.map(g => `
            <div class="cf-wiz-genre-btn" data-value="${g.value}">
                <span>${g.icon}</span><span>${g.label}</span>
            </div>
        `).join('');
        el.querySelectorAll('.cf-wiz-genre-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                el.querySelectorAll('.cf-wiz-genre-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                this._data.genre = btn.dataset.value;
            });
        });
    }

    _renderTraitsGrid() {
        const el = this._rootEl.querySelector('#cf-wiz-traits-grid');
        if (!el) return;
        el.innerHTML = TRAITS.map(t => `
            <span class="cf-wiz-trait-tag" data-trait="${t}">${t}</span>
        `).join('');
        el.querySelectorAll('.cf-wiz-trait-tag').forEach(tag => {
            tag.addEventListener('click', () => {
                tag.classList.toggle('selected');
                const selected = [...el.querySelectorAll('.cf-wiz-trait-tag.selected')]
                    .map(t => t.dataset.trait);
                this._data.traits = selected;
            });
        });
    }

    _renderStyleGrid() {
        const el = this._rootEl.querySelector('#cf-wiz-style-grid');
        if (!el) return;
        el.innerHTML = SPEECH_STYLES.map(s => `
            <div class="cf-wiz-style-btn" data-value="${s.value}">
                <span>${s.icon}</span>
                <div>
                    <div style="font-weight:700">${s.label}</div>
                    <div style="font-size:10px;opacity:0.65;font-weight:400">${s.desc}</div>
                </div>
            </div>
        `).join('');
        el.querySelectorAll('.cf-wiz-style-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                el.querySelectorAll('.cf-wiz-style-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                this._data.speechStyle = btn.dataset.value;
            });
        });
    }

    _renderFieldsChecklist() {
        const el = this._rootEl.querySelector('#cf-wiz-fields-checklist');
        if (!el) return;
        el.innerHTML = CARD_FIELDS.map(f => `
            <label class="cf-wiz-field-check">
                <input type="checkbox" data-field-key="${f.key}" ${f.checked ? 'checked' : ''}>
                <span>${f.label}</span>
            </label>
        `).join('');
    }

    // ── 步骤导航 ─────────────────────────────────────────────────

    _goToStep(n) {
        const prev = this._step;
        this._step = Math.max(1, Math.min(n, this._total));

        // 收集上一步数据
        if (prev !== this._step) this._collectCurrentStepData();

        // 切换面板
        this._rootEl.querySelectorAll('.cf-wiz-step-panel').forEach(panel => {
            panel.style.display = panel.dataset.step == this._step ? 'block' : 'none';
        });

        // 更新步骤标签
        this._rootEl.querySelectorAll('.cf-wiz-step-tab').forEach(tab => {
            const n = parseInt(tab.dataset.step);
            tab.classList.toggle('active', n === this._step);
            tab.classList.toggle('done',   n < this._step);
        });

        // 更新底部状态
        const stepLabel  = this._rootEl.querySelector('#cf-wiz-step-label');
        const prevBtn    = this._rootEl.querySelector('#cf-wiz-prev');
        const nextBtn    = this._rootEl.querySelector('#cf-wiz-next');
        const genBtn     = this._rootEl.querySelector('#cf-wiz-generate');
        const isLast     = this._step === this._total;

        if (stepLabel) stepLabel.textContent = `第 ${this._step} 步 / 共 ${this._total} 步`;
        if (prevBtn)   prevBtn.disabled = this._step === 1;
        if (nextBtn)   nextBtn.style.display = isLast ? 'none' : 'inline-flex';
        if (genBtn)    genBtn.style.display  = isLast ? 'inline-flex' : 'none';

        // 第6步：渲染摘要
        if (this._step === this._total) this._renderSummary();
    }

    // ── 数据收集 ─────────────────────────────────────────────────

    _collectCurrentStepData() {
        // 普通 input/textarea/select
        this._rootEl.querySelectorAll(`.cf-wiz-step-panel[data-step="${this._step}"] .cf-wiz-field`)
            .forEach(el => {
                const field = el.dataset.field;
                if (!field) return;
                if (el.type === 'range') {
                    this._data[field] = parseInt(el.value);
                } else {
                    this._data[field] = el.value;
                }
            });

        // 选中的字段列表（Step 5）
        if (this._step === 5) {
            const checked = [...this._rootEl.querySelectorAll('#cf-wiz-fields-checklist input:checked')]
                .map(el => el.dataset.fieldKey);
            this._data.selectedFields = checked;
            this._data.genWorldBook     = this._rootEl.querySelector('#cf-wiz-gen-wb')?.checked ?? false;
            this._data.genAltGreetings  = this._rootEl.querySelector('#cf-wiz-gen-alt-greetings')?.checked ?? true;
            this._data.genMesExample    = this._rootEl.querySelector('#cf-wiz-gen-mes-example')?.checked ?? true;
        }
    }

    _collectAllData() {
        const saved = this._step;
        for (let i = 1; i <= this._total; i++) {
            this._step = i;
            this._collectCurrentStepData();
        }
        this._step = saved;
    }

    // ── 摘要渲染 ─────────────────────────────────────────────────

    _renderSummary() {
        this._collectAllData();
        const d = this._data;
        const rows = [
            { key: '角色名称', val: d.name        || '（未填写）' },
            { key: '核心概念', val: d.concept      || '（未填写）' },
            { key: '风格类型', val: d.genre        || '（未设定）' },
            { key: '性别',     val: d.gender       || '（未设定）' },
            { key: '语言',     val: d.outputLanguage || 'zh-CN'  },
            { key: '性格特质', val: (d.traits?.join('、') || '（未选择）') },
            { key: '对话风格', val: d.speechStyle  || '（未选择）' },
            { key: '开场情景', val: d.greetingScenario || '初次相遇' },
            { key: '开场白字数', val: d.greetingWordCount ? `约 ${d.greetingWordCount} 字` : '约 200 字' },
        ];

        const el = this._rootEl.querySelector('#cf-wiz-summary-content');
        if (el) {
            el.innerHTML = rows.map(r => `
                <div class="cf-wiz-summary-row">
                    <span class="cf-wiz-summary-key">${r.key}</span>
                    <span class="cf-wiz-summary-val">${_escapeHTML(String(r.val))}</span>
                </div>
            `).join('');
        }

        // 渲染字段状态点
        const fieldsEl = this._rootEl.querySelector('#cf-wiz-progress-fields');
        if (fieldsEl) {
            const fields = d.selectedFields || CARD_FIELDS.filter(f => f.checked).map(f => f.key);
            fieldsEl.innerHTML = fields.map(k => {
                const meta = CARD_FIELDS.find(f => f.key === k);
                return `<span class="cf-wiz-field-dot" data-field="${k}">${meta?.label || k}</span>`;
            }).join('');
        }
    }

    // ── 生成 ─────────────────────────────────────────────────────

    async _startGenerate() {
        if (this._generating) return;
        this._generating = true;

        this._collectAllData();

        // 验证必填项
        if (!this._data.name?.trim()) {
            alert('请填写角色名称（第 1 步）');
            this._goToStep(1);
            this._generating = false;
            return;
        }
        if (!this._data.concept?.trim()) {
            alert('请填写核心概念（第 1 步）');
            this._goToStep(1);
            this._generating = false;
            return;
        }

        // 显示进度区域
        const progressArea  = this._rootEl.querySelector('#cf-wiz-progress-area');
        const progressLabel = this._rootEl.querySelector('#cf-wiz-progress-label');
        const progressFill  = this._rootEl.querySelector('#cf-wiz-progress-fill');
        const genBtn        = this._rootEl.querySelector('#cf-wiz-generate');

        if (progressArea)  progressArea.style.display  = 'block';
        if (genBtn)        genBtn.disabled = true;

        const fields = this._data.selectedFields
            || CARD_FIELDS.filter(f => f.checked).map(f => f.key);

        const setProgress = (pct, label) => {
            if (progressFill)  progressFill.style.width = `${pct}%`;
            if (progressLabel) progressLabel.textContent = label;
        };

        const setFieldDot = (key, state) => {
            const dot = this._rootEl.querySelector(`.cf-wiz-field-dot[data-field="${key}"]`);
            if (dot) dot.className = `cf-wiz-field-dot ${state}`;
        };

        try {
            setProgress(5, '正在准备生成参数…');
            this._bus?.emit?.(EVENTS.LOADING_START, { message: '向导：正在生成角色卡…' });

            // 调用 CardGenerator 生成
            if (this._cardGen?.generateAll) {
                const total = fields.length;
                let done = 0;

                // 先设置角色名
                this._cardGen.setField?.('name', this._data.name);

                for (const field of fields) {
                    setFieldDot(field, 'generating');
                    setProgress(10 + Math.round((done / total) * 80), `正在生成：${field}…`);

                    try {
                        await this._cardGen.generateField?.(field, this._data);
                        setFieldDot(field, 'done');
                    } catch (e) {
                        console.warn(`[Wizard] 字段 ${field} 生成失败：`, e);
                        setFieldDot(field, '');
                    }

                    done++;
                }

                setProgress(100, '✅ 生成完成！');
            } else {
                // 降级：只填充基础字段
                setProgress(50, '正在填充基础数据…');
                await new Promise(r => setTimeout(r, 800));
                setProgress(100, '✅ 已填充基础数据');
            }

            this._bus?.emit?.(EVENTS.CARD_UPDATED, this._data);

            // 延迟关闭向导
            await new Promise(r => setTimeout(r, 1200));
            this.hide();

        } catch (error) {
            console.error('[Wizard] 生成失败：', error);
            if (progressLabel) progressLabel.textContent = `❌ 生成失败：${error.message}`;
        } finally {
            this._generating = false;
            if (genBtn) genBtn.disabled = false;
            this._bus?.emit?.(EVENTS.LOADING_END);
        }
    }

    // ── 草稿 ─────────────────────────────────────────────────────

    _saveDraft() {
        this._collectAllData();
        try {
            localStorage.setItem('cf_wizard_draft', JSON.stringify(this._data));
            console.log('[Wizard] 草稿已保存');
            // 简易 toast 提示
            const toast = document.createElement('div');
            toast.textContent = '💾 草稿已保存';
            toast.style.cssText = `
                position:fixed;bottom:20px;left:50%;transform:translateX(-50%);
                background:var(--cf-success,#2ecc71);color:#fff;
                padding:8px 20px;border-radius:20px;font-size:13px;
                z-index:99999;animation:cf-pulse 0.3s ease;
            `;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 2000);
        } catch {}
    }

    _loadDraft() {
        try {
            const raw = localStorage.getItem('cf_wizard_draft');
            if (raw) {
                this._data = JSON.parse(raw);
                this._restoreFormValues();
            }
        } catch {}
    }

    _restoreFormValues() {
        const d = this._data;
        const setVal = (selector, value) => {
            const el = this._rootEl?.querySelector(selector);
            if (el && value !== undefined) el.value = value;
        };

        setVal('[data-field="name"]',            d.name);
        setVal('[data-field="concept"]',         d.concept);
        setVal('[data-field="outputLanguage"]',  d.outputLanguage);
        setVal('[data-field="appearance"]',      d.appearance);
        setVal('[data-field="personalityNote"]', d.personalityNote);
        setVal('[data-field="age"]',             d.age);
        setVal('[data-field="worldBackground"]', d.worldBackground);
        setVal('[data-field="backstory"]',       d.backstory);
        setVal('[data-field="motivation"]',      d.motivation);
        setVal('[data-field="speechHabits"]',    d.speechHabits);
        setVal('[data-field="extraRequirements"]', d.extraRequirements);

        if (d.genre) {
            this._rootEl?.querySelector(`[data-value="${d.genre}"].cf-wiz-genre-btn`)?.classList.add('selected');
        }
        if (d.speechStyle) {
            this._rootEl?.querySelector(`[data-value="${d.speechStyle}"].cf-wiz-style-btn`)?.classList.add('selected');
        }
        if (Array.isArray(d.traits)) {
            d.traits.forEach(t => {
                this._rootEl?.querySelector(`[data-trait="${t}"]`)?.classList.add('selected');
            });
        }
    }

    // ── 事件绑定 ─────────────────────────────────────────────────

    _bindEvents() {
        const q = id => this._rootEl.querySelector(id);

        // 关闭
        q('#cf-wiz-close')?.addEventListener('click', () => this.hide());

        // 上一步 / 下一步 / 生成
        q('#cf-wiz-prev')?.addEventListener('click', () => this._goToStep(this._step - 1));
        q('#cf-wiz-next')?.addEventListener('click', () => {
            if (this._validateCurrentStep()) this._goToStep(this._step + 1);
        });
        q('#cf-wiz-generate')?.addEventListener('click', () => this._startGenerate());

        // 保存草稿
        q('#cf-wiz-save-draft')?.addEventListener('click', () => this._saveDraft());

        // 点击背景关闭
        this._rootEl.addEventListener('click', e => {
            if (e.target === this._rootEl) this.hide();
        });

        // ESC 关闭
        const escHandler = e => { if (e.key === 'Escape') this.hide(); };
        document.addEventListener('keydown', escHandler);
        this._unsubs.push(() => document.removeEventListener('keydown', escHandler));

        // 单选按钮组（radio-btn 样式）
        this._rootEl.querySelectorAll('.cf-wiz-radio-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const field = btn.dataset.field;
                this._rootEl.querySelectorAll(`.cf-wiz-radio-btn[data-field="${field}"]`)
                    .forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                this._data[field] = btn.dataset.value;

                // 自定义关系输入框联动
                if (field === 'relationship') {
                    const customInput = q('#cf-wiz-rel-custom');
                    if (customInput) {
                        customInput.style.display = btn.dataset.value === 'custom' ? 'block' : 'none';
                    }
                }
            });
        });

        // 开场白情景下拉联动
        q('#cf-wiz-scenario-select')?.addEventListener('change', e => {
            const customWrap = q('#cf-wiz-scenario-custom-wrap');
            if (customWrap) {
                customWrap.style.display = e.target.value === 'custom' ? 'block' : 'none';
            }
        });

        // 字数滑块联动
        q('#cf-wiz-wc-range')?.addEventListener('input', e => {
            const label = q('#cf-wiz-wc-label');
            if (label) label.textContent = `约 ${e.target.value} 字`;
        });

        // 创意程度滑块联动
        const creativityLabels = ['精确严谨', '平衡', '天马行空'];
        q('#cf-wiz-creativity-range')?.addEventListener('input', e => {
            const label = q('#cf-wiz-temp-label');
            if (label) label.textContent = creativityLabels[parseInt(e.target.value)] || '平衡';
        });

        // AI 建议按钮
        q('#cf-wiz-ai-suggest-step2')?.addEventListener('click', async () => {
            const btn = q('#cf-wiz-ai-suggest-step2');
            if (!btn || !this._cardGen?._ai) return;
            btn.disabled = true;
            btn.textContent = '⏳ 生成中…';
            try {
                const concept = this._data.concept || this._rootEl.querySelector('[data-field="concept"]')?.value || '';
                if (!concept) {
                    alert('请先在第 1 步填写核心概念');
                    return;
                }
                // 简单调用 AI 生成建议
                const suggestion = await this._cardGen?._ai?.generateCard?.(
                    '你是角色设计师��根据角色概念生成简短的外貌和性格建议（各一段，中文，100字内）',
                    `角色概念：${concept}`
                );
                if (suggestion) {
                    const appearanceEl = this._rootEl.querySelector('[data-field="appearance"]');
                    if (appearanceEl && !appearanceEl.value) {
                        appearanceEl.value = suggestion.slice(0, 200);
                    }
                }
            } catch (e) {
                console.warn('[Wizard] AI 建议失败：', e);
            } finally {
                btn.disabled = false;
                btn.textContent = '✨ AI 建议';
            }
        });

        // 尝试恢复草稿
        this._loadDraft();
    }

    // ── 步骤验证 ─────────────────────────────────────────────────

    _validateCurrentStep() {
        if (this._step === 1) {
            const name    = this._rootEl.querySelector('[data-field="name"]')?.value?.trim();
            const concept = this._rootEl.querySelector('[data-field="concept"]')?.value?.trim();
            if (!name) {
                alert('请填写角色名称');
                this._rootEl.querySelector('[data-field="name"]')?.focus();
                return false;
            }
            if (!concept) {
                alert('请填写核心概念');
                this._rootEl.querySelector('[data-field="concept"]')?.focus();
                return false;
            }
        }
        return true;
    }
}

// ── 工具函数 ─────────────────────────────────────────────────────

function _escapeHTML(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}