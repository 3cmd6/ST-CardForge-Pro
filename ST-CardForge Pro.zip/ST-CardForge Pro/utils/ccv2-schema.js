/**
 * @file utils/ccv2-schema.js
 * @description CCv2（Character Card v2）数据结构校验与构建工具
 *
 *   提供：
 *     - CCv2 格式的完整性校验（validateCCv2）
 *     - 从内部 CardData 构建标准 CCv2 导出对象（buildCCv2）
 *     - CCv2 → CCv3 格式升级迁移（migrateCCv2ToCCv3）
 *     - 字段清理与默认值填充（sanitizeCCv2）
 *
 *   CCv2 规范参考：
 *     https://github.com/malfoyslastname/character-card-spec-v2
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { createEmptyCard } from '../contracts.js';
import { estimateTokens, TOKEN_LIMITS } from './token-counter.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  CCv2 规范常量
// ═══════════════════════════════════════════════════════════════════

/** CCv2 固定 spec 标识符 */
export const CCv2_SPEC             = 'chara_card_v2';
export const CCv2_SPEC_VERSION     = '2.0';

/**
 * CCv2 必填字段列表
 * 缺少这些字段将产生 ERROR 级别的校验结果
 * @readonly
 */
export const CCv2_REQUIRED_FIELDS = Object.freeze([
    'name',
]);

/**
 * CCv2 建议填写字段列表
 * 缺少这些字段将产生 WARNING 级别的校验结果
 * @readonly
 */
export const CCv2_RECOMMENDED_FIELDS = Object.freeze([
    'description',
    'personality',
    'first_mes',
    'mes_example',
]);

/**
 * CCv2 data 对象的所有合法字段
 * 导出时只保留此列表中的字段，其余字段放入 extensions
 * @readonly
 */
export const CCv2_DATA_FIELDS = Object.freeze([
    'name',
    'description',
    'personality',
    'scenario',
    'first_mes',
    'mes_example',
    'creator_notes',
    'system_prompt',
    'post_history_instructions',
    'alternate_greetings',
    'tags',
    'creator',
    'character_version',
    'extensions',
]);


// ═══════════════════════════════════════════════════════════════════
// § 2  校验函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 校验一个对象是否符合 CCv2 规范
 *
 * @param   {Object} data   待校验的角色卡对象（应为完整 CCv2 结构）
 * @returns {ValidationResult}
 *
 * @typedef  {Object}   ValidationResult
 * @property {boolean}  valid       是否通过全部必填项校验（无 ERROR）
 * @property {string[]} errors      ERROR 级别问题（必须修复）
 * @property {string[]} warnings    WARNING 级别问题（建议修复）
 * @property {string[]} infos       INFO 级别建议（可忽略）
 *
 * @example
 * const result = validateCCv2(myCard);
 * if (!result.valid) console.error(result.errors);
 */
export function validateCCv2(data) {
    const errors   = [];
    const warnings = [];
    const infos    = [];

    // ── 顶层结构校验 ──────────────────────────────────────────────
    if (!data || typeof data !== 'object') {
        errors.push('❌ 数据格式错误：根对象必须是一个 Object');
        return { valid: false, errors, warnings, infos };
    }

    if (data.spec !== CCv2_SPEC) {
        warnings.push(`⚠️ spec 字段值为 "${data.spec}"，CCv2 规范要求为 "${CCv2_SPEC}"`);
    }

    if (!data.data || typeof data.data !== 'object') {
        errors.push('❌ 缺少 data 字段，或 data 不是 Object');
        return { valid: false, errors, warnings, infos };
    }

    const d = data.data;

    // ── 必填字段校验 ──────────────────────────────────────────────
    for (const field of CCv2_REQUIRED_FIELDS) {
        if (!d[field] || (typeof d[field] === 'string' && d[field].trim() === '')) {
            errors.push(`❌ 缺少必填字段：data.${field}`);
        }
    }

    // ── 建议字段校验 ──────────────────────────────────────────────
    for (const field of CCv2_RECOMMENDED_FIELDS) {
        if (!d[field] || (typeof d[field] === 'string' && d[field].trim() === '')) {
            warnings.push(`⚠️ 建议填写字段：data.${field}（留空会影响角色表现）`);
        }
    }

    // ── 字段类型校验 ──────────────────────────────────────────────
    const stringFields = [
        'name', 'description', 'personality', 'scenario',
        'first_mes', 'mes_example', 'creator_notes',
        'system_prompt', 'post_history_instructions',
        'creator', 'character_version',
    ];

    for (const field of stringFields) {
        if (d[field] !== undefined && typeof d[field] !== 'string') {
            errors.push(`❌ data.${field} 必须是字符串，当前类型：${typeof d[field]}`);
        }
    }

    if (d.alternate_greetings !== undefined) {
        if (!Array.isArray(d.alternate_greetings)) {
            errors.push('❌ data.alternate_greetings 必须是数组');
        } else {
            d.alternate_greetings.forEach((item, i) => {
                if (typeof item !== 'string') {
                    errors.push(`❌ data.alternate_greetings[${i}] 必须是字符串`);
                }
            });
        }
    }

    if (d.tags !== undefined) {
        if (!Array.isArray(d.tags)) {
            errors.push('❌ data.tags 必须是数组');
        } else {
            d.tags.forEach((item, i) => {
                if (typeof item !== 'string') {
                    errors.push(`❌ data.tags[${i}] 必须是字符串`);
                }
            });
        }
    }

    // ── Token 数量检查 ────────────────────────────────────────────
    _checkFieldTokens(d, 'description',    TOKEN_LIMITS.DESCRIPTION_WARN,    TOKEN_LIMITS.DESCRIPTION_HARD,    warnings, errors);
    _checkFieldTokens(d, 'personality',    TOKEN_LIMITS.PERSONALITY_WARN,    TOKEN_LIMITS.PERSONALITY_HARD,    warnings, errors);
    _checkFieldTokens(d, 'scenario',       TOKEN_LIMITS.SCENARIO_WARN,       TOKEN_LIMITS.SCENARIO_HARD,       warnings, errors);
    _checkFieldTokens(d, 'first_mes',      TOKEN_LIMITS.FIRST_MES_WARN,      TOKEN_LIMITS.FIRST_MES_HARD,      warnings, errors);
    _checkFieldTokens(d, 'mes_example',    TOKEN_LIMITS.MES_EXAMPLE_WARN,    TOKEN_LIMITS.MES_EXAMPLE_HARD,    warnings, errors);
    _checkFieldTokens(d, 'system_prompt',  TOKEN_LIMITS.SYSTEM_PROMPT_WARN,  TOKEN_LIMITS.SYSTEM_PROMPT_HARD,  warnings, errors);

    // ── 非法字段提示 ──────────────────────────────────────────────
    const unknownFields = Object.keys(d).filter(k => !CCv2_DATA_FIELDS.includes(k));
    if (unknownFields.length > 0) {
        infos.push(`ℹ️ data 中存在非标准字段：${unknownFields.join(', ')}（建议移至 data.extensions）`);
    }

    // ── name 长度检查 ─────────────────────────────────────────────
    if (d.name && d.name.length > 100) {
        warnings.push(`⚠️ data.name 长度为 ${d.name.length}，建议不超过 100 个字符`);
    }

    // ── alternate_greetings 数量建议 ──────────────────────────────
    if (Array.isArray(d.alternate_greetings) && d.alternate_greetings.length > 10) {
        infos.push(`ℹ️ alternate_greetings 共 ${d.alternate_greetings.length} 条，过多可能影响加载性能`);
    }

    return {
        valid: errors.length === 0,
        errors,
        warnings,
        infos,
    };
}

/**
 * 检查单个字段的 Token 数并向对应数组推入提示
 * @private
 */
function _checkFieldTokens(d, fieldName, warnLimit, hardLimit, warnings, errors) {
    if (!d[fieldName]) return;
    const count = estimateTokens(d[fieldName]);
    if (count >= hardLimit) {
        errors.push(
            `❌ data.${fieldName} 估算 Token 数（${count}）超出强制上限 ${hardLimit}，` +
            '可能导致上下文溢出，请压缩内容'
        );
    } else if (count >= warnLimit) {
        warnings.push(
            `⚠️ data.${fieldName} 估算 Token 数（${count}）超出警告线 ${warnLimit}，` +
            '建议精简'
        );
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 3  构建函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 从内部 CardData 对象构建标准 CCv2 导出格式
 *
 * @param   {import('../contracts.js').CardData} cardData  内部角色卡数据
 * @returns {Object}  符合 CCv2 规范的导出对象
 *
 * @example
 * const ccv2 = buildCCv2(cardData);
 * const json = JSON.stringify(ccv2, null, 2);
 */
export function buildCCv2(cardData) {
    const d = cardData?.data ?? {};

    return {
        spec:         CCv2_SPEC,
        spec_version: CCv2_SPEC_VERSION,
        data: {
            name:                       _safeString(d.name),
            description:                _safeString(d.description),
            personality:                _safeString(d.personality),
            scenario:                   _safeString(d.scenario),
            first_mes:                  _safeString(d.first_mes),
            mes_example:                _safeString(d.mes_example),
            creator_notes:              _safeString(d.creator_notes),
            system_prompt:              _safeString(d.system_prompt),
            post_history_instructions:  _safeString(d.post_history_instructions),
            alternate_greetings:        _safeArray(d.alternate_greetings),
            tags:                       _safeArray(d.tags),
            creator:                    _safeString(d.creator),
            character_version:          _safeString(d.character_version),
            extensions:                 _buildV2Extensions(d.extensions),
        }
    };
}

/**
 * 清理并规范化一个 CCv2 对象（补全缺失字段、清理非法值）
 *
 * @param   {Object} data  原始 CCv2 对象（可能来自外部导入）
 * @returns {Object}       清理后的 CCv2 对象
 */
export function sanitizeCCv2(data) {
    if (!data || typeof data !== 'object') {
        return buildCCv2(createEmptyCard());
    }

    const d = data.data ?? {};

    return {
        spec:         CCv2_SPEC,
        spec_version: CCv2_SPEC_VERSION,
        data: {
            name:                       _safeString(d.name),
            description:                _safeString(d.description),
            personality:                _safeString(d.personality),
            scenario:                   _safeString(d.scenario),
            first_mes:                  _safeString(d.first_mes),
            mes_example:                _safeString(d.mes_example),
            creator_notes:              _safeString(d.creator_notes),
            system_prompt:              _safeString(d.system_prompt),
            post_history_instructions:  _safeString(d.post_history_instructions),
            alternate_greetings:        _safeArray(d.alternate_greetings),
            tags:                       _safeArray(d.tags),
            creator:                    _safeString(d.creator),
            character_version:          _safeString(d.character_version),
            extensions:                 typeof d.extensions === 'object' && d.extensions
                                            ? d.extensions
                                            : {},
        }
    };
}


// ═══════════════════════════════════════════════════════════════════
// § 4  格式迁移
// ═══════════════════════════════════════════════════════════════════

/**
 * 将 CCv2 格式对象升级迁移为 CCv3 兼容的内部 CardData 结构
 * 注意：此函数只做格式转换，不做 Schema 校验
 *
 * @param   {Object} v2data  CCv2 格式的对象（含 spec / data）
 * @returns {import('../contracts.js').CardData}  内部 CardData 格式
 */
export function migrateCCv2ToCCv3(v2data) {
    const d       = v2data?.data ?? {};
    const card    = createEmptyCard();
    const cardData = card.data;

    // 直接映射字段（CCv2 与 CCv3 完全兼容的字段）
    const directFields = [
        'name', 'description', 'personality', 'scenario',
        'first_mes', 'mes_example', 'creator_notes',
        'system_prompt', 'post_history_instructions',
        'alternate_greetings', 'tags', 'creator', 'character_version',
    ];

    for (const field of directFields) {
        if (d[field] !== undefined) {
            cardData[field] = d[field];
        }
    }

    // 迁移 extensions
    if (d.extensions && typeof d.extensions === 'object') {
        // 保留原有第三方 extensions，将 cardforge 私有数据挂在下面
        cardData.extensions = {
            ...d.extensions,
            cardforge: {
                ...(d.extensions.cardforge ?? {}),
                version: '1.0.0',
            }
        };
    }

    // 记录迁移来源
    cardData.extensions.cardforge.meta = {
        ...cardData.extensions.cardforge.meta,
        migrated_from:  'ccv2',
        migrated_at:    new Date().toISOString(),
    };

    return card;
}

/**
 * 检测一个对象是否是 CCv2 格式（宽松检测）
 *
 * @param   {*} data
 * @returns {boolean}
 */
export function isCCv2(data) {
    if (!data || typeof data !== 'object') return false;
    if (data.spec === CCv2_SPEC) return true;
    // 宽松检测：有 data.name 且没有 spec 字段（可能是老版本 CCv1）
    if (!data.spec && data.data && typeof data.data.name === 'string') return true;
    return false;
}


// ═══════════════════════════════════════════════════════════════════
// § 5  内部工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 安全地将值转为字符串，非字符串返回空字符串
 * @private
 * @param   {*}      value
 * @returns {string}
 */
function _safeString(value) {
    if (typeof value === 'string') return value;
    if (value == null) return '';
    return String(value);
}

/**
 * 安全地将值转为字符串数组，过滤掉非字符串元素
 * @private
 * @param   {*}       value
 * @returns {string[]}
 */
function _safeArray(value) {
    if (!Array.isArray(value)) return [];
    return value.filter(item => typeof item === 'string');
}

/**
 * 构建 CCv2 的 extensions 字段
 * 保留外部数据中的 extensions，并注入 cardforge 私有字段
 * @private
 * @param   {Object} extensions  内部 CardData 的 extensions 对象
 * @returns {Object}
 */
function _buildV2Extensions(extensions) {
    if (!extensions || typeof extensions !== 'object') {
        return { cardforge: { version: '1.0.0' } };
    }

    // 在 CCv2 中只保留精简的 cardforge 数据（避免体积过大）
    const { cardforge, ...otherExtensions } = extensions;

    return {
        ...otherExtensions,
        cardforge: {
            version:    cardforge?.version ?? '1.0.0',
            // CCv2 中不存储完整分支树和世界书，保持体积精简
            meta:       cardforge?.meta ?? {},
        }
    };
}