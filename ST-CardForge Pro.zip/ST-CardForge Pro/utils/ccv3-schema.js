/**
 * @file utils/ccv3-schema.js
 * @description CCv3（Character Card v3）数据结构校验与构建工具
 *
 *   提供：
 *     - CCv3 格式的完整性校验（validateCCv3）
 *     - 从内部 CardData 构建标准 CCv3 导出对象（buildCCv3）
 *     - CCv3 对象清理与字段规范化（sanitizeCCv3）
 *     - CCv3 格式检测（isCCv3）
 *
 *   CCv3 规范说明：
 *     - CCv3 是 CCv2 的向后兼容扩展
 *     - 新增 assets 字段（支持多表情图片等资源）
 *     - 新增 group_only_greetings 字段
 *     - spec 固定为 'chara_card_v3'，spec_version 固定为 '3.0'
 *     - 导出 PNG 时必须写入 'ccv3' tEXt chunk，同时回填 'chara' chunk 保持兼容
 *
 *   CCv3 规范参考：
 *     https://github.com/kwaroran/character-card-spec-v3
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { createEmptyCard, CARD_DATA_SCHEMA } from '../contracts.js';
import { estimateTokens, TOKEN_LIMITS }       from './token-counter.js';
import { buildCCv2, CCv2_SPEC }               from './ccv2-schema.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  CCv3 规范常量
// ═══════════════════════════════════════════════════════════════════

/** CCv3 固定 spec 标识符 */
export const CCv3_SPEC         = 'chara_card_v3';
export const CCv3_SPEC_VERSION = '3.0';

/**
 * CCv3 必填字段
 * @readonly
 */
export const CCv3_REQUIRED_FIELDS = Object.freeze([
    'name',
]);

/**
 * CCv3 建议填写字段
 * @readonly
 */
export const CCv3_RECOMMENDED_FIELDS = Object.freeze([
    'description',
    'personality',
    'first_mes',
    'mes_example',
    'system_prompt',
]);

/**
 * CCv3 data 对象的所有合法字段
 * @readonly
 */
export const CCv3_DATA_FIELDS = Object.freeze([
    'name',
    'description',
    'personality',
    'scenario',
    'first_mes',
    'mes_example',
    'creator_notes',
    'system_prompt',
    'post_history_instructions',
    'alternate_greetings',
    'group_only_greetings',
    'tags',
    'creator',
    'character_version',
    'assets',
    'extensions',
]);

/**
 * CCv3 assets 条目的合法类型
 * @readonly
 * @enum {string}
 */
export const CCv3_ASSET_TYPES = Object.freeze({
    ICON:       'icon',         // 角色头像
    BACKGROUND: 'background',   // 背景图
    USER_ICON:  'user_icon',    // 用户头像
    EMOTION:    'emotion',      // 表情图（多表情系统）
    OTHER:      'other',        // 其他资产
});

/**
 * assets 条目结构说明
 *
 * @typedef  {Object} CCv3Asset
 * @property {string} type    资产类型（见 CCv3_ASSET_TYPES）
 * @property {string} uri     资产 URI（相对路径或 data: URL 或 https: URL）
 * @property {string} name    资产名称（emotion 类型时作为表情 key）
 * @property {string} [ext]   文件扩展名（可选，如 'png' 'jpg'）
 */


// ═══════════════════════════════════════════════════════════════════
// § 2  校验函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 校验一个对象是否符合 CCv3 规范
 *
 * @param   {Object} data   待校验的角色卡对象
 * @returns {ValidationResult}
 *
 * @typedef  {Object}   ValidationResult
 * @property {boolean}  valid
 * @property {string[]} errors    ERROR 级别（必须修复）
 * @property {string[]} warnings  WARNING 级别（建议修复）
 * @property {string[]} infos     INFO 级别（可忽略）
 */
export function validateCCv3(data) {
    const errors   = [];
    const warnings = [];
    const infos    = [];

    // ── 顶层结构校验 ──────────────────────────────────────────────
    if (!data || typeof data !== 'object') {
        errors.push('❌ 数据格式错误：根对象必须是一个 Object');
        return { valid: false, errors, warnings, infos };
    }

    if (data.spec !== CCv3_SPEC) {
        warnings.push(
            `⚠️ spec 字段值为 "${data.spec}"，` +
            `CCv3 规范要求为 "${CCv3_SPEC}"`
        );
    }

    if (data.spec_version !== CCv3_SPEC_VERSION) {
        warnings.push(
            `⚠️ spec_version 字段值为 "${data.spec_version}"，` +
            `CCv3 规范要求为 "${CCv3_SPEC_VERSION}"`
        );
    }

    if (!data.data || typeof data.data !== 'object') {
        errors.push('❌ 缺少 data 字段，或 data 不是 Object');
        return { valid: false, errors, warnings, infos };
    }

    const d = data.data;

    // ── 必填字段校验 ──────────────────────────────────────────────
    for (const field of CCv3_REQUIRED_FIELDS) {
        if (!d[field] || (typeof d[field] === 'string' && d[field].trim() === '')) {
            errors.push(`❌ 缺少必填字段：data.${field}`);
        }
    }

    // ── 建议字段校验 ──────────────────────────────────────────────
    for (const field of CCv3_RECOMMENDED_FIELDS) {
        if (!d[field] || (typeof d[field] === 'string' && d[field].trim() === '')) {
            warnings.push(`⚠️ 建议填写字段：data.${field}（留空会影响角色表现）`);
        }
    }

    // ── 字符串字段类型校验 ───────────────────────────────────────
    const stringFields = [
        'name', 'description', 'personality', 'scenario',
        'first_mes', 'mes_example', 'creator_notes',
        'system_prompt', 'post_history_instructions',
        'creator', 'character_version',
    ];

    for (const field of stringFields) {
        if (d[field] !== undefined && typeof d[field] !== 'string') {
            errors.push(
                `❌ data.${field} 必须是字符串，` +
                `当前类型：${typeof d[field]}`
            );
        }
    }

    // ── 数组字段类型校验 ──────────────────────────────────────────
    const arrayFields = [
        'alternate_greetings',
        'group_only_greetings',
        'tags',
    ];

    for (const field of arrayFields) {
        if (d[field] !== undefined) {
            if (!Array.isArray(d[field])) {
                errors.push(`❌ data.${field} 必须是数组`);
            } else if (field !== 'tags') {
                // greetings 数组每个元素必须是字符串
                d[field].forEach((item, i) => {
                    if (typeof item !== 'string') {
                        errors.push(
                            `❌ data.${field}[${i}] 必须是字符串，` +
                            `当前类型：${typeof item}`
                        );
                    }
                });
            } else {
                // tags 数组每个元素必须是字符串
                d[field].forEach((item, i) => {
                    if (typeof item !== 'string') {
                        errors.push(`❌ data.tags[${i}] 必须是字符串`);
                    }
                });
            }
        }
    }

    // ── assets 字段校验（CCv3 新增）─────────────────────────────
    if (d.assets !== undefined) {
        if (!Array.isArray(d.assets)) {
            errors.push('❌ data.assets 必须是数组');
        } else {
            d.assets.forEach((asset, i) => {
                _validateAsset(asset, i, errors, warnings, infos);
            });

            // 检查 emotion 类型资产的 name 唯一性
            const emotionNames = d.assets
                .filter(a => a.type === CCv3_ASSET_TYPES.EMOTION)
                .map(a => a.name);
            const duplicates = emotionNames.filter(
                (n, idx) => emotionNames.indexOf(n) !== idx
            );
            if (duplicates.length > 0) {
                warnings.push(
                    `⚠️ assets 中存在重复的 emotion name：${[...new Set(duplicates)].join(', ')}`
                );
            }
        }
    }

    // ── Token 数量检查 ────────────────────────────────────────────
    _checkFieldTokens(d, 'description',
        TOKEN_LIMITS.DESCRIPTION_WARN,   TOKEN_LIMITS.DESCRIPTION_HARD,   warnings, errors);
    _checkFieldTokens(d, 'personality',
        TOKEN_LIMITS.PERSONALITY_WARN,   TOKEN_LIMITS.PERSONALITY_HARD,   warnings, errors);
    _checkFieldTokens(d, 'scenario',
        TOKEN_LIMITS.SCENARIO_WARN,      TOKEN_LIMITS.SCENARIO_HARD,      warnings, errors);
    _checkFieldTokens(d, 'first_mes',
        TOKEN_LIMITS.FIRST_MES_WARN,     TOKEN_LIMITS.FIRST_MES_HARD,     warnings, errors);
    _checkFieldTokens(d, 'mes_example',
        TOKEN_LIMITS.MES_EXAMPLE_WARN,   TOKEN_LIMITS.MES_EXAMPLE_HARD,   warnings, errors);
    _checkFieldTokens(d, 'system_prompt',
        TOKEN_LIMITS.SYSTEM_PROMPT_WARN, TOKEN_LIMITS.SYSTEM_PROMPT_HARD, warnings, errors);
    _checkFieldTokens(d, 'post_history_instructions',
        TOKEN_LIMITS.POST_HISTORY_WARN,  TOKEN_LIMITS.POST_HISTORY_HARD,  warnings, errors);

    // ── 整卡 Token 汇总 ───────────────────────────────────────────
    const totalTokens = _estimateTotalTokens(d);
    if (totalTokens >= TOKEN_LIMITS.TOTAL_CARD_HARD) {
        errors.push(
            `❌ 整卡估算 Token 总量（${totalTokens}）超出强制上限 ` +
            `${TOKEN_LIMITS.TOTAL_CARD_HARD}，请精简各字段内容`
        );
    } else if (totalTokens >= TOKEN_LIMITS.TOTAL_CARD_WARN) {
        warnings.push(
            `⚠️ 整卡估算 Token 总量（${totalTokens}）超出警告线 ` +
            `${TOKEN_LIMITS.TOTAL_CARD_WARN}，建议适当压缩`
        );
    }

    // ── name 长度建议 ─────────────────────────────────────────────
    if (d.name && d.name.length > 100) {
        warnings.push(
            `⚠️ data.name 长度为 ${d.name.length} 字符，` +
            '建议不超过 100 个字符'
        );
    }

    // ── 非标准字段提示 ────────────────────────────────────────────
    const unknownFields = Object.keys(d).filter(
        k => !CCv3_DATA_FIELDS.includes(k)
    );
    if (unknownFields.length > 0) {
        infos.push(
            `ℹ️ data 中存在非 CCv3 标准字段：${unknownFields.join(', ')}` +
            '（建议移至 data.extensions）'
        );
    }

    // ── group_only_greetings 数量建议 ────────────────────────────
    if (Array.isArray(d.group_only_greetings) && d.group_only_greetings.length > 5) {
        infos.push(
            `ℹ️ group_only_greetings 共 ${d.group_only_greetings.length} 条，` +
            '较多时建议精选'
        );
    }

    return {
        valid: errors.length === 0,
        errors,
        warnings,
        infos,
    };
}

/**
 * 校验单个 asset 条目的结构合法性
 * @private
 *
 * @param {CCv3Asset} asset
 * @param {number}    index
 * @param {string[]}  errors
 * @param {string[]}  warnings
 * @param {string[]}  infos
 */
function _validateAsset(asset, index, errors, warnings, infos) {
    const prefix = `data.assets[${index}]`;

    if (!asset || typeof asset !== 'object') {
        errors.push(`❌ ${prefix} 必须是 Object`);
        return;
    }

    // type 字段
    if (!asset.type) {
        errors.push(`❌ ${prefix}.type 为必填项`);
    } else if (!Object.values(CCv3_ASSET_TYPES).includes(asset.type)) {
        warnings.push(
            `⚠️ ${prefix}.type 值 "${asset.type}" 不在已知类型中` +
            `（${Object.values(CCv3_ASSET_TYPES).join(' / ')}）`
        );
    }

    // uri 字段
    if (!asset.uri) {
        errors.push(`❌ ${prefix}.uri 为必填项`);
    } else if (typeof asset.uri !== 'string') {
        errors.push(`❌ ${prefix}.uri 必须是字符串`);
    } else {
        // URI 格式初步检查
        const validPrefixes = ['data:', 'http://', 'https://', './', '../', '/'];
        const isValidUri = validPrefixes.some(p => asset.uri.startsWith(p));
        if (!isValidUri) {
            warnings.push(
                `⚠️ ${prefix}.uri 格式可能不合法：` +
                `"${asset.uri.slice(0, 40)}..."`
            );
        }
    }

    // name 字段
    if (!asset.name) {
        warnings.push(`⚠️ ${prefix}.name 为空，emotion 类型必须设置唯一 name`);
    } else if (typeof asset.name !== 'string') {
        errors.push(`❌ ${prefix}.name 必须是字符串`);
    }

    // emotion 类型：name 不能含空格
    if (asset.type === CCv3_ASSET_TYPES.EMOTION && asset.name && /\s/.test(asset.name)) {
        warnings.push(
            `⚠️ ${prefix}.name "${asset.name}" 含有空格，` +
            'emotion key 建议使用下划线或驼峰命名'
        );
    }
}

/**
 * 检查单个字段的 Token 数
 * @private
 */
function _checkFieldTokens(d, fieldName, warnLimit, hardLimit, warnings, errors) {
    if (!d[fieldName]) return;
    const count = estimateTokens(d[fieldName]);
    if (count >= hardLimit) {
        errors.push(
            `❌ data.${fieldName} 估算 Token 数（${count}）` +
            `超出强制上限 ${hardLimit}，请压缩内容`
        );
    } else if (count >= warnLimit) {
        warnings.push(
            `⚠️ data.${fieldName} 估算 Token 数（${count}）` +
            `超出警告线 ${warnLimit}，建议精简`
        );
    }
}

/**
 * 粗略估算整卡 Token 总量
 * @private
 * @param   {Object} d  cardData.data
 * @returns {number}
 */
function _estimateTotalTokens(d) {
    const textFields = [
        'description', 'personality', 'scenario',
        'first_mes', 'mes_example', 'system_prompt',
        'post_history_instructions', 'creator_notes',
    ];
    let total = textFields.reduce(
        (sum, f) => sum + estimateTokens(d[f] ?? ''), 0
    );

    // alternate_greetings
    if (Array.isArray(d.alternate_greetings)) {
        total += d.alternate_greetings.reduce(
            (sum, g) => sum + estimateTokens(g), 0
        );
    }

    // group_only_greetings
    if (Array.isArray(d.group_only_greetings)) {
        total += d.group_only_greetings.reduce(
            (sum, g) => sum + estimateTokens(g), 0
        );
    }

    return total;
}


// ═══════════════════════════════════════════════════════════════════
// § 3  构建函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 从内部 CardData 对象构建标准 CCv3 导出格式
 *
 * @param   {import('../contracts.js').CardData} cardData  内部角色卡数据
 * @param   {Object}  [options={}]
 * @param   {boolean} [options.includeAssets=true]   是否包含 assets 字段
 * @param   {boolean} [options.includeExtensions=true] 是否包含 extensions
 * @returns {Object}  符合 CCv3 规范的导出对象
 *
 * @example
 * const ccv3 = buildCCv3(cardData);
 * const json = JSON.stringify(ccv3, null, 2);
 */
export function buildCCv3(cardData, options = {}) {
    const {
        includeAssets     = true,
        includeExtensions = true,
    } = options;

    const d = cardData?.data ?? {};

    const output = {
        spec:         CCv3_SPEC,
        spec_version: CCv3_SPEC_VERSION,
        data: {
            // ── CCv2 兼容字段 ──────────────────────────────────
            name:                       _safeString(d.name),
            description:                _safeString(d.description),
            personality:                _safeString(d.personality),
            scenario:                   _safeString(d.scenario),
            first_mes:                  _safeString(d.first_mes),
            mes_example:                _safeString(d.mes_example),
            creator_notes:              _safeString(d.creator_notes),
            system_prompt:              _safeString(d.system_prompt),
            post_history_instructions:  _safeString(d.post_history_instructions),
            alternate_greetings:        _safeStringArray(d.alternate_greetings),
            tags:                       _safeStringArray(d.tags),
            creator:                    _safeString(d.creator),
            character_version:          _safeString(d.character_version),

            // ── CCv3 新增字段 ──────────────────────────────────
            group_only_greetings:       _safeStringArray(d.group_only_greetings),
        }
    };

    // assets 字段
    if (includeAssets) {
        output.data.assets = _buildAssets(d.extensions?.cardforge);
    }

    // extensions 字段
    if (includeExtensions) {
        output.data.extensions = _buildV3Extensions(d.extensions);
    }

    return output;
}

/**
 * 清理并规范化一个 CCv3 对象
 * 用于处理外部导入的、可能不规范的 CCv3 数据
 *
 * @param   {Object} data  原始 CCv3 对象
 * @returns {Object}       规范化后的 CCv3 对象
 */
export function sanitizeCCv3(data) {
    if (!data || typeof data !== 'object') {
        return buildCCv3(createEmptyCard());
    }

    const d = data.data ?? {};

    return {
        spec:         CCv3_SPEC,
        spec_version: CCv3_SPEC_VERSION,
        data: {
            name:                       _safeString(d.name),
            description:                _safeString(d.description),
            personality:                _safeString(d.personality),
            scenario:                   _safeString(d.scenario),
            first_mes:                  _safeString(d.first_mes),
            mes_example:                _safeString(d.mes_example),
            creator_notes:              _safeString(d.creator_notes),
            system_prompt:              _safeString(d.system_prompt),
            post_history_instructions:  _safeString(d.post_history_instructions),
            alternate_greetings:        _safeStringArray(d.alternate_greetings),
            group_only_greetings:       _safeStringArray(d.group_only_greetings),
            tags:                       _safeStringArray(d.tags),
            creator:                    _safeString(d.creator),
            character_version:          _safeString(d.character_version),
            assets:                     Array.isArray(d.assets)
                                            ? d.assets.filter(_isValidAsset)
                                            : [],
            extensions:                 (d.extensions && typeof d.extensions === 'object')
                                            ? d.extensions
                                            : {},
        }
    };
}


// ═══════════════════════════════════════════════════════════════════
// § 4  格式检测与辅助
// ═══════════════════════════════════════════════════════════════════

/**
 * 检测一个对象是否是 CCv3 格式
 *
 * @param   {*} data
 * @returns {boolean}
 */
export function isCCv3(data) {
    if (!data || typeof data !== 'object') return false;
    return data.spec === CCv3_SPEC && data.spec_version === CCv3_SPEC_VERSION;
}

/**
 * 自动检测角色卡格式版本
 *
 * @param   {*}      data
 * @returns {'v3'|'v2'|'v1'|'unknown'}
 */
export function detectCardVersion(data) {
    if (!data || typeof data !== 'object') return 'unknown';
    if (isCCv3(data))                       return 'v3';
    if (data.spec === CCv2_SPEC)            return 'v2';
    // CCv1：没有 spec 字段但有 name（字符串，旧格式）
    if (!data.spec && typeof data.name === 'string') return 'v1';
    return 'unknown';
}

/**
 * 将任意版本的角色卡对象规范化为内部 CardData 格式
 * 自动检测版本并调用对应的迁移路径
 *
 * @param   {Object} rawData  任意版本的原始角色卡数据
 * @returns {{ cardData: import('../contracts.js').CardData, version: string }}
 */
export function normalizeToCardData(rawData) {
    const version = detectCardVersion(rawData);

    switch (version) {
        case 'v3': {
            // CCv3 → 直接转换为内部 CardData
            const card     = createEmptyCard();
            const d        = rawData.data ?? {};
            const cardData = card.data;

            const fields = [
                'name', 'description', 'personality', 'scenario',
                'first_mes', 'mes_example', 'creator_notes',
                'system_prompt', 'post_history_instructions',
                'alternate_greetings', 'group_only_greetings',
                'tags', 'creator', 'character_version',
                'assets', 'extensions',
            ];

            for (const field of fields) {
                if (d[field] !== undefined) {
                    cardData[field] = d[field];
                }
            }

            // 确保 cardforge 扩展存在
            if (!cardData.extensions.cardforge) {
                cardData.extensions.cardforge = { version: '1.0.0' };
            }

            return { cardData: card, version };
        }

        case 'v2': {
            // CCv2 → 使用 ccv2-schema 的迁移函数
            const { migrateCCv2ToCCv3 } = require('./ccv2-schema.js');
            return { cardData: migrateCCv2ToCCv3(rawData), version };
        }

        case 'v1': {
            // CCv1（极老格式）→ 手动映射
            const card     = createEmptyCard();
            const cardData = card.data;
            cardData.name        = _safeString(rawData.name);
            cardData.description = _safeString(rawData.description);
            cardData.first_mes   = _safeString(rawData.first_mes ?? rawData.first_message);
            cardData.extensions.cardforge.meta.migrated_from = 'ccv1';
            cardData.extensions.cardforge.meta.migrated_at   = new Date().toISOString();
            return { cardData: card, version };
        }

        default:
            return { cardData: createEmptyCard(), version: 'unknown' };
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 5  内部工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 安全地将值转为字符串
 * @private
 */
function _safeString(value) {
    if (typeof value === 'string') return value;
    if (value == null)            return '';
    return String(value);
}

/**
 * 安全地将值转为字符串数组
 * @private
 */
function _safeStringArray(value) {
    if (!Array.isArray(value)) return [];
    return value.filter(item => typeof item === 'string');
}

/**
 * 从 cardforge 扩展数据中构建 assets 数组
 * 目前仅处理已存储的 assets，未来可扩展
 * @private
 *
 * @param   {Object} cardforgeExt  cardData.data.extensions.cardforge
 * @returns {CCv3Asset[]}
 */
function _buildAssets(cardforgeExt) {
    if (!cardforgeExt || !Array.isArray(cardforgeExt.assets)) {
        return [];
    }
    return cardforgeExt.assets.filter(_isValidAsset);
}

/**
 * 检查一个 asset 对象是否具备最低限度的合法性
 * @private
 *
 * @param   {*} asset
 * @returns {boolean}
 */
function _isValidAsset(asset) {
    return (
        asset &&
        typeof asset === 'object' &&
        typeof asset.type === 'string' &&
        typeof asset.uri  === 'string' &&
        asset.uri.length  > 0
    );
}

/**
 * 构建 CCv3 的 extensions 导出字段
 * 保留所有第三方 extensions，将 cardforge 私有数据精简后写入
 * @private
 *
 * @param   {Object} extensions  cardData.data.extensions
 * @returns {Object}
 */
function _buildV3Extensions(extensions) {
    if (!extensions || typeof extensions !== 'object') {
        return { cardforge: { version: '1.0.0' } };
    }

    const { cardforge, ...otherExtensions } = extensions;

    // CCv3 导出时携带完整 cardforge 数据（分支树、世界书、正则等）
    return {
        ...otherExtensions,
        cardforge: {
            version:    cardforge?.version ?? '1.0.0',
            stats:      cardforge?.stats   ?? {},
            branches:   cardforge?.branches ?? [],
            worldbook:  cardforge?.worldbook ?? null,
            regex:      cardforge?.regex    ?? [],
            meta:       cardforge?.meta     ?? {},
        }
    };
}