/**
 * @file utils/indexeddb-store.js
 * @description IndexedDB 本地持久化存储工具（修复版）
 *
 *  修复内容：
 *  1. 构造函数支持两种模式：
 *     - 单 Store 模式：new IndexedDBStore('CardForgeProDB', 'drafts', 1)
 *       → get(key) / set(key, value) 直接操作绑定的 store
 *     - 全库模式：new IndexedDBStore()
 *       → get(storeName, key) / set(storeName, record) 手动指定 store
 *  2. 数据库版本号强制为正整数，防止 "Value is not of type 'unsigned long long'"
 *  3. 所有公共方法均不抛出异常，内部 catch 后返回 null / false / []
 *
 * @version 1.1.0
 */

'use strict';

// ═══════════════════════════════════════════════
// § 1  数据库常量
// ═══════════════════════════════════════════════

export const DB_NAME    = 'CardForgeProDB';
export const DB_VERSION = 1;

export const STORES = Object.freeze({
    DRAFTS:   'drafts',
    HISTORY:  'history',
    CACHE:    'cache',
    RPG_LOG:  'rpg_log',
    SETTINGS: 'settings',
});

// ═══════════════════════════════════════════════
// § 2  核心类
// ═══════════════════════════════════════════════

export class IndexedDBStore {

    /**
     * 支持两种构造方式：
     *
     * ① 单 Store 模式（推荐，index.js 里用这种）：
     *    new IndexedDBStore('CardForgeProDB', 'drafts', 1)
     *    → this.get(key) / this.set(key, value) 自动操作 'drafts' store
     *
     * ② 全库模式（兼容旧代码）：
     *    new IndexedDBStore() 或 new IndexedDBStore('CardForgeProDB', 1)
     *    → this.get('drafts', key) / this.set('drafts', record) 手动指定 store
     *
     * @param {string} [dbName=DB_NAME]
     * @param {string|number} [storeNameOrVersion]
     *        传字符串 → 单 Store 模式的 storeName
     *        传数字   → 全库模式的 dbVersion
     * @param {number} [version=1]  单 Store 模式下的版本号
     */
    constructor(dbName = DB_NAME, storeNameOrVersion, version) {
        this._dbName = dbName;

        if (typeof storeNameOrVersion === 'string') {
            // ① 单 Store 模式：IndexedDBStore('CardForgeProDB', 'drafts', 1)
            this._storeName = storeNameOrVersion;
            this._dbVersion = _safeVersion(version);
            this._singleStoreMode = true;
        } else {
            // ② 全库模式：IndexedDBStore() 或 IndexedDBStore('name', 1)
            this._storeName = null;
            this._dbVersion = _safeVersion(storeNameOrVersion);
            this._singleStoreMode = false;
        }

        /** @private @type {IDBDatabase|null} */
        this._db = null;

        /** @private @type {Promise<IDBDatabase>|null} */
        this._openPromise = null;
    }

    // ─────────────────────────────────────────
    // § 2.1  数据库连接
    // ─────────────────────────────────────────

    async open() {
        if (this._db) return this._db;
        if (this._openPromise) return this._openPromise;

        this._openPromise = new Promise((resolve, reject) => {
            let request;
            try {
                request = indexedDB.open(this._dbName, this._dbVersion);
            } catch (e) {
                this._openPromise = null;
                reject(e);
                return;
            }

            request.onupgradeneeded = (event) => {
                this._onUpgradeNeeded(event);
            };

            request.onsuccess = (event) => {
                this._db = event.target.result;
                this._openPromise = null;

                this._db.onclose = () => {
                    this._db = null;
                    console.warn('[CardForge] IndexedDB 连接意外关闭');
                };

                this._db.onerror = (e) => {
                    console.error('[CardForge] IndexedDB 错误：', e.target.error);
                };

                resolve(this._db);
            };

            request.onerror = (event) => {
                this._openPromise = null;
                reject(new Error(
                    `IndexedDB 打开失败：${event.target.error?.message ?? '未知错误'}`
                ));
            };

            request.onblocked = () => {
                console.warn('[CardForge] IndexedDB 被阻塞，请关闭其他标签页');
            };
        });

        return this._openPromise;
    }

    close() {
        if (this._db) {
            this._db.close();
            this._db = null;
        }
    }

    /** @private */
    _onUpgradeNeeded(event) {
        const db     = event.target.result;
        const oldVer = event.oldVersion;

        console.log(`[CardForge] IndexedDB 升级：${oldVer} → ${this._dbVersion}`);

        if (oldVer < 1) {
            // 全库模式：建全部 store
            _createStore(db, STORES.DRAFTS, { keyPath: 'id' }, [
                { name: 'updatedAt', keyPath: 'updatedAt' },
                { name: 'name',      keyPath: 'name'      },
            ]);

            _createStore(db, STORES.HISTORY, { keyPath: 'id' }, [
                { name: 'fieldName',           keyPath: 'fieldName'              },
                { name: 'timestamp',           keyPath: 'timestamp'              },
                { name: 'draftId',             keyPath: 'draftId'                },
                { name: 'fieldName_timestamp', keyPath: ['fieldName', 'timestamp'] },
            ]);

            _createStore(db, STORES.CACHE, { keyPath: 'key' }, [
                { name: 'expiresAt', keyPath: 'expiresAt' },
                { name: 'type',      keyPath: 'type'      },
            ]);

            _createStore(db, STORES.RPG_LOG, { keyPath: 'id' }, [
                { name: 'statKey',           keyPath: 'statKey'              },
                { name: 'timestamp',         keyPath: 'timestamp'            },
                { name: 'draftId',           keyPath: 'draftId'              },
                { name: 'statKey_timestamp', keyPath: ['statKey', 'timestamp'] },
            ]);

            _createStore(db, STORES.SETTINGS, { keyPath: 'key' }, []);
        }

        // 单 Store 模式：只建自己这个 store（如果不存在）
        if (this._singleStoreMode && this._storeName) {
            if (!db.objectStoreNames.contains(this._storeName)) {
                db.createObjectStore(this._storeName);
                console.log(`[CardForge] IndexedDB 创建 store：${this._storeName}`);
            }
        }
    }

    // ─────────────────────────────────────────
    // § 2.2  核心 CRUD（自动适配两种模式）
    // ─────────────────────────────────────────

    /**
     * 读取一条记录
     *
     * 单 Store 模式：get(key)
     * 全库模式：     get(storeName, key)
     */
    async get(storeNameOrKey, key) {
        const [sn, k] = this._resolveArgs(storeNameOrKey, key);
        if (!sn) { console.warn('[CardForge] IndexedDB get: 未指定 storeName'); return null; }

        try {
            const db = await this.open();
            const result = await _idbRequest(
                db.transaction(sn, 'readonly').objectStore(sn).get(k)
            );
            return result ?? null;
        } catch (e) {
            console.error(`[CardForge] IndexedDB get 失败（${k}）:`, e);
            return null;
        }
    }

    /**
     * 写入一条记录
     *
     * 单 Store 模式：set(key, value)
     * 全库模式：     set(storeName, record)  record 必须含 keyPath 字段
     */
    async set(storeNameOrKey, valueOrRecord, value) {
        if (this._singleStoreMode) {
            // 单 store 模式：set(key, value) → 以 key 作外部键存储
            const sn  = this._storeName;
            const key = storeNameOrKey;
            const val = valueOrRecord;
            try {
                const db = await this.open();
                await _idbRequest(
                    db.transaction(sn, 'readwrite').objectStore(sn).put(val, key)
                );
                return true;
            } catch (e) {
                console.error(`[CardForge] IndexedDB set 失败（${key}）:`, e);
                return false;
            }
        } else {
            // 全库模式：set(storeName, record)
            const sn     = storeNameOrKey;
            const record = valueOrRecord;
            try {
                const db = await this.open();
                await _idbRequest(
                    db.transaction(sn, 'readwrite').objectStore(sn).put(record)
                );
                return true;
            } catch (e) {
                console.error(`[CardForge] IndexedDB set 失败（${sn}）:`, e);
                return false;
            }
        }
    }

    /**
     * 删除一条记录
     *
     * 单 Store 模式：delete(key)
     * 全库模式：     delete(storeName, key)
     */
    async delete(storeNameOrKey, key) {
        const [sn, k] = this._resolveArgs(storeNameOrKey, key);
        if (!sn) return false;
        try {
            const db = await this.open();
            await _idbRequest(
                db.transaction(sn, 'readwrite').objectStore(sn).delete(k)
            );
            return true;
        } catch (e) {
            console.error(`[CardForge] IndexedDB delete 失败（${k}）:`, e);
            return false;
        }
    }

    /**
     * 获取所有记录
     *
     * 单 Store 模式：getAll()
     * 全库模式：     getAll(storeName)
     */
    async getAll(storeName) {
        const sn = this._singleStoreMode ? this._storeName : storeName;
        if (!sn) return [];
        try {
            const db = await this.open();
            const result = await _idbRequest(
                db.transaction(sn, 'readonly').objectStore(sn).getAll()
            );
            return result ?? [];
        } catch (e) {
            console.error(`[CardForge] IndexedDB getAll 失败（${sn}）:`, e);
            return [];
        }
    }

    /**
     * 获取所有主键
     *
     * 单 Store 模式：getAllKeys()
     * 全库模式：     getAllKeys(storeName)
     */
    async getAllKeys(storeName) {
        const sn = this._singleStoreMode ? this._storeName : storeName;
        if (!sn) return [];
        try {
            const db = await this.open();
            const result = await _idbRequest(
                db.transaction(sn, 'readonly').objectStore(sn).getAllKeys()
            );
            return result ?? [];
        } catch (e) {
            console.error(`[CardForge] IndexedDB getAllKeys 失败（${sn}）:`, e);
            return [];
        }
    }

    /**
     * 清空一个 store
     *
     * 单 Store 模式：clearStore()
     * 全库模式：     clearStore(storeName)
     */
    async clearStore(storeName) {
        const sn = this._singleStoreMode ? this._storeName : storeName;
        if (!sn) return false;
        try {
            const db = await this.open();
            await _idbRequest(
                db.transaction(sn, 'readwrite').objectStore(sn).clear()
            );
            return true;
        } catch (e) {
            console.error(`[CardForge] IndexedDB clearStore 失败（${sn}）:`, e);
            return false;
        }
    }

    /**
     * 统计记录数
     *
     * 单 Store 模式：count()
     * 全库模式：     count(storeName)
     */
    async count(storeName) {
        const sn = this._singleStoreMode ? this._storeName : storeName;
        if (!sn) return 0;
        try {
            const db = await this.open();
            const result = await _idbRequest(
                db.transaction(sn, 'readonly').objectStore(sn).count()
            );
            return result ?? 0;
        } catch (e) {
            console.error(`[CardForge] IndexedDB count 失败（${sn}）:`, e);
            return 0;
        }
    }

    /**
     * 通过索引查询（仅全库模式有意义）
     */
    async getByIndex(storeName, indexName, value) {
        const sn = this._singleStoreMode ? this._storeName : storeName;
        const idxName = this._singleStoreMode ? storeName : indexName;
        const val     = this._singleStoreMode ? indexName : value;
        if (!sn) return [];
        try {
            const db = await this.open();
            const result = await _idbRequest(
                db.transaction(sn, 'readonly')
                  .objectStore(sn)
                  .index(idxName)
                  .getAll(val)
            );
            return result ?? [];
        } catch (e) {
            console.error(`[CardForge] IndexedDB getByIndex 失败（${sn}.${idxName}）:`, e);
            return [];
        }
    }

    // ─────────────────────────────────────────
    // § 2.3  草稿专用方法（全库模式）
    // ─────────────────────────────────────────

    async saveDraft(draftId, cardData, meta = {}) {
        const now      = Date.now();
        const existing = await this.get(STORES.DRAFTS, draftId);
        const draft    = {
            id:        draftId,
            name:      meta.name      ?? cardData?.data?.name ?? '未命名草稿',
            cardData:  cardData,
            thumbnail: meta.thumbnail ?? existing?.thumbnail ?? null,
            createdAt: existing?.createdAt ?? now,
            updatedAt: now,
        };
        const ok = await this.set(STORES.DRAFTS, draft);
        return ok ? draft : null;
    }

    async loadDraft(draftId) {
        return this.get(STORES.DRAFTS, draftId);
    }

    async listDrafts() {
        const all = await this.getAll(STORES.DRAFTS);
        return all
            .map(({ id, name, createdAt, updatedAt, thumbnail }) =>
                ({ id, name, createdAt, updatedAt, thumbnail }))
            .sort((a, b) => b.updatedAt - a.updatedAt);
    }

    async deleteDraft(draftId) {
        const ok = await this.delete(STORES.DRAFTS, draftId);
        if (ok) {
            const hist = await this.getByIndex(STORES.HISTORY, 'draftId', draftId);
            for (const e of hist) await this.delete(STORES.HISTORY, e.id);
            const rpg  = await this.getByIndex(STORES.RPG_LOG, 'draftId', draftId);
            for (const e of rpg)  await this.delete(STORES.RPG_LOG, e.id);
        }
        return ok;
    }

    // ─────────────────────────────────────────
    // § 2.4  历史版本专用方法
    // ─────────────────────────────────────────

    async saveHistory(fieldName, content, meta = {}) {
        const entry = {
            id:         generateId(),
            fieldName,
            content,
            mode:       meta.mode       ?? 'manual',
            intensity:  meta.intensity  ?? 0,
            timestamp:  Date.now(),
            isOriginal: meta.isOriginal ?? false,
            draftId:    meta.draftId    ?? null,
        };
        const ok = await this.set(STORES.HISTORY, entry);
        return ok ? entry : null;
    }

    async getFieldHistory(fieldName, limit = 20) {
        const all = await this.getByIndex(STORES.HISTORY, 'fieldName', fieldName);
        return all.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    }

    async clearFieldHistory(fieldName) {
        const entries = await this.getByIndex(STORES.HISTORY, 'fieldName', fieldName);
        let count = 0;
        for (const e of entries) {
            const ok = await this.delete(STORES.HISTORY, e.id);
            if (ok) count++;
        }
        return count;
    }

    // ─────────────────────────────────────────
    // § 2.5  缓存专用方法
    // ─────────────────────────────────────────

    async getCache(key) {
        const entry = await this.get(STORES.CACHE, key);
        if (!entry) return null;
        if (entry.expiresAt && entry.expiresAt < Date.now()) {
            await this.delete(STORES.CACHE, key);
            return null;
        }
        return entry.value;
    }

    async setCache(key, value, ttlMs = 300_000, type = 'general') {
        const now   = Date.now();
        const entry = { key, value, createdAt: now, expiresAt: now + ttlMs, type };
        return this.set(STORES.CACHE, entry);
    }

    async purgeExpiredCache() {
        const all   = await this.getAll(STORES.CACHE);
        const now   = Date.now();
        let   count = 0;
        for (const e of all) {
            if (e.expiresAt && e.expiresAt < now) {
                const ok = await this.delete(STORES.CACHE, e.key);
                if (ok) count++;
            }
        }
        return count;
    }

    // ─────────────────────────────────────────
    // § 2.6  RPG 日志专用方法
    // ─────────────────────────────────────────

    async logRPGChange(statKey, oldValue, newValue, reason, draftId = null) {
        const entry = {
            id:        generateId(),
            statKey,
            oldValue,
            newValue,
            reason:    reason ?? '',
            timestamp: Date.now(),
            draftId,
        };
        const ok = await this.set(STORES.RPG_LOG, entry);
        return ok ? entry : null;
    }

    async getRPGHistory(statKey, limit = 50) {
        const all = await this.getByIndex(STORES.RPG_LOG, 'statKey', statKey);
        return all.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    }

    // ─────────────────────────────────────────
    // § 2.7  设置专用方法
    // ─────────────────────────────────────────

    async getSetting(key, defaultValue = null) {
        const record = await this.get(STORES.SETTINGS, key);
        return record?.value ?? defaultValue;
    }

    async setSetting(key, value) {
        return this.set(STORES.SETTINGS, { key, value, updatedAt: Date.now() });
    }

    // ─────────────────────────────────────────
    // § 2.8  内部工具
    // ─────────────────────────────────────────

    /**
     * 根据模式解析 (storeNameOrKey, key) 参数
     * @private
     * @returns {[string, *]}  [storeName, key]
     */
    _resolveArgs(storeNameOrKey, key) {
        if (this._singleStoreMode) {
            return [this._storeName, storeNameOrKey];
        } else {
            return [storeNameOrKey, key];
        }
    }
}

// ═══════════════════════════════════════════════
// § 3  工具函数
// ═══════════════════════════════════════════════

/**
 * 确保版本号是合法的正整数（防止 undefined 报错）
 * @param {*} v
 * @returns {number}
 */
function _safeVersion(v) {
    const n = parseInt(v, 10);
    return (Number.isInteger(n) && n >= 1) ? n : DB_VERSION;
}

/**
 * 建 objectStore 的辅助函数
 * @private
 */
function _createStore(db, name, options, indexes) {
    if (db.objectStoreNames.contains(name)) return;
    const store = db.createObjectStore(name, options);
    for (const idx of indexes) {
        store.createIndex(
            idx.name,
            idx.keyPath,
            { unique: idx.unique ?? false }
        );
    }
}

/**
 * 将 IDBRequest 包装为 Promise
 * @private
 */
function _idbRequest(request) {
    return new Promise((resolve, reject) => {
        request.onsuccess = (e) => resolve(e.target.result);
        request.onerror   = (e) => reject(e.target.error);
    });
}

/**
 * 生成 UUID v4
 */
export function generateId() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}

/**
 * 全库单例（全库模式使用）
 */
export const dbStore = new IndexedDBStore();