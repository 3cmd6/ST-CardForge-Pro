/**
 * @file utils/png-metadata.js
 * @description PNG tEXt chunk 读写工具
 *
 *   提供对 PNG 文件的 tEXt chunk 进行读写的能力，用于：
 *     - 从角色卡 PNG 中读取 CCv2（chara chunk）和 CCv3（ccv3 chunk）
 *     - 将角色卡数据嵌入 PNG 的 tEXt chunk
 *     - 支持 UTF-8 + 中文内容的 Base64 编解码
 *
 *   PNG tEXt chunk 格式：
 *     - 每个 chunk 由 4字节长度 + 4字节类型 + 数据 + 4字节CRC 组成
 *     - tEXt chunk 数据格式：keyword + \0 + text（ISO-8859-1 编码）
 *     - 由于中文不能直接用 ISO-8859-1 编码，角色卡数据先 JSON → UTF-8 → Base64
 *
 *   CCv2 PNG 规范：
 *     - tEXt chunk keyword：'chara'
 *     - 值：CharacterCardV2 JSON → UTF-8 → Base64
 *
 *   CCv3 PNG 规范：
 *     - tEXt chunk keyword：'ccv3'
 *     - 值：CharacterCardV3 JSON → UTF-8 → Base64
 *     - 同时必须回填 'chara' chunk（向后兼容）
 *
 *   ST 规范补充：
 *     - ST 将角色头像标准化为 400×600 像素
 *     - PNG tEXt chunk 在图像数据之后写入
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════
// § 1  常量定义
// ═══════════════════════════════════════════════════════════════════

/** PNG 文件魔数（8字节） */
const PNG_SIGNATURE = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]);

/** 角色卡相关的 tEXt chunk keyword */
export const CHUNK_KEYWORDS = Object.freeze({
    CHARA:  'chara',    // CCv2 兼容 chunk
    CCv3:   'ccv3',     // CCv3 专用 chunk
});

/** PNG chunk 类型的 ASCII 编码（4字节） */
const CHUNK_TYPE = Object.freeze({
    IHDR: [73, 72, 68, 82],
    IDAT: [73, 68, 65, 84],
    IEND: [73, 69, 78, 68],
    tEXt: [116, 69, 88, 116],
    iTXt: [105, 84, 88, 116],
});


// ═══════════════════════════════════════════════════════════════════
// § 2  主要导出函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 从 PNG 文件的 ArrayBuffer 中读取角色卡数据
 *
 * @param   {ArrayBuffer} buffer  PNG 文件的二进制数据
 * @returns {PNGReadResult}
 *
 * @typedef  {Object}       PNGReadResult
 * @property {Object|null}  v2          CCv2 格式数据（来自 'chara' chunk），解析失败为 null
 * @property {Object|null}  v3          CCv3 格式数据（来自 'ccv3' chunk），解析失败为 null
 * @property {Object}       raw         所有 tEXt chunk 的原始键值对
 * @property {boolean}      isPNG       是否是合法的 PNG 文件
 * @property {string|null}  error       读取过程中的错误信息
 *
 * @example
 * const buffer = await file.arrayBuffer();
 * const result = await readCardFromPNG(buffer);
 * if (result.v3) console.log('找到 CCv3 数据', result.v3);
 */
export async function readCardFromPNG(buffer) {
    const result = {
        v2:    null,
        v3:    null,
        raw:   {},
        isPNG: false,
        error: null,
    };

    try {
        const bytes = new Uint8Array(buffer);

        // 校验 PNG 魔数
        if (!_isPNG(bytes)) {
            result.error = '文件不是合法的 PNG 格式（魔数不匹配）';
            return result;
        }
        result.isPNG = true;

        // 解析所有 tEXt chunk
        const textChunks = _parseTextChunks(bytes);
        result.raw = textChunks;

        // 解析 CCv2（chara chunk）
        if (textChunks[CHUNK_KEYWORDS.CHARA]) {
            try {
                result.v2 = _decodeCardJSON(textChunks[CHUNK_KEYWORDS.CHARA]);
            } catch (e) {
                result.error = `解析 'chara' chunk 失败：${e.message}`;
            }
        }

        // 解析 CCv3（ccv3 chunk），优先级高于 v2
        if (textChunks[CHUNK_KEYWORDS.CCv3]) {
            try {
                result.v3 = _decodeCardJSON(textChunks[CHUNK_KEYWORDS.CCv3]);
            } catch (e) {
                result.error = `解析 'ccv3' chunk 失败：${e.message}`;
            }
        }

    } catch (error) {
        result.error = `读取 PNG 时发生错误：${error.message}`;
    }

    return result;
}

/**
 * 将角色卡数据嵌入 PNG 文件，返回新的 PNG 二进制数据
 *
 * @param   {ArrayBuffer} imageBuffer     PNG 图片的二进制数据
 * @param   {Object}      cardData        内部 CardData 对象
 * @param   {Object}      [options={}]
 * @param   {'v2'|'v3'|'both'} [options.spec='both']   嵌入的规范版本
 * @param   {Function}    [options.buildCCv2]           CCv2 构建函数（避免循环依赖时注入）
 * @param   {Function}    [options.buildCCv3]           CCv3 构建函数
 * @returns {Promise<Uint8Array>}         嵌入数据后的新 PNG 二进制
 *
 * @example
 * const newPNG = await embedCardInPNG(imageBuffer, cardData, { spec: 'both' });
 * const blob   = new Blob([newPNG], { type: 'image/png' });
 */
export async function embedCardInPNG(imageBuffer, cardData, options = {}) {
    const {
        spec      = 'both',
        buildCCv2 = null,
        buildCCv3 = null,
    } = options;

    const bytes = new Uint8Array(imageBuffer);

    if (!_isPNG(bytes)) {
        throw new Error('提供的图片不是合法的 PNG 文件');
    }

    // 收集需要写入的 tEXt chunk
    const chunksToWrite = {};

    if ((spec === 'v2' || spec === 'both') && buildCCv2) {
        const v2Data = buildCCv2(cardData);
        chunksToWrite[CHUNK_KEYWORDS.CHARA] = _encodeCardJSON(v2Data);
    }

    if ((spec === 'v3' || spec === 'both') && buildCCv3) {
        const v3Data = buildCCv3(cardData);
        chunksToWrite[CHUNK_KEYWORDS.CCv3]  = _encodeCardJSON(v3Data);

        // CCv3 规范要求同时回填 chara chunk 保持兼容
        if (!chunksToWrite[CHUNK_KEYWORDS.CHARA] && buildCCv2) {
            const v2Data = buildCCv2(cardData);
            chunksToWrite[CHUNK_KEYWORDS.CHARA] = _encodeCardJSON(v2Data);
        }
    }

    // 将新 chunk 写入 PNG
    return _injectTextChunks(bytes, chunksToWrite);
}

/**
 * 从 PNG 中读取指定 keyword 的 tEXt chunk 原始值（Base64 字符串）
 *
 * @param   {ArrayBuffer} buffer
 * @param   {string}      keyword  chunk 关键字
 * @returns {Promise<string|null>} Base64 字符串，不存在时返回 null
 */
export async function readTextChunk(buffer, keyword) {
    const bytes  = new Uint8Array(buffer);
    if (!_isPNG(bytes)) return null;

    const chunks = _parseTextChunks(bytes);
    return chunks[keyword] ?? null;
}

/**
 * 向 PNG 中写入指定 keyword 的 tEXt chunk
 * 如果该 keyword 已存在，将替换原有 chunk
 *
 * @param   {ArrayBuffer} buffer
 * @param   {string}      keyword
 * @param   {string}      value   Base64 字符串
 * @returns {Promise<Uint8Array>}  新的 PNG 二进制
 */
export async function writeTextChunk(buffer, keyword, value) {
    const bytes = new Uint8Array(buffer);
    if (!_isPNG(bytes)) {
        throw new Error('提供的数据不是合法的 PNG 文件');
    }
    return _injectTextChunks(bytes, { [keyword]: value });
}


// ═══════════════════════════════════════════════════════════════════
// § 3  Base64 编解码（支持 UTF-8 / 中文）
// ═══════════════════════════════════════════════════════════════════

/**
 * 将字符串编码为 Base64（支持 UTF-8 多字节字符）
 * 流程：string → UTF-8 bytes → Base64
 *
 * @param   {string} str  原始字符串（可含中文）
 * @returns {string}      Base64 编码结果
 *
 * @example
 * encodeBase64UTF8('你好世界');  // → 'JTU0JTk5JTk0JTU5JTk3JUE0...'
 */
export function encodeBase64UTF8(str) {
    try {
        // 使用 TextEncoder 将字符串转为 UTF-8 字节数组
        const encoder = new TextEncoder();
        const bytes   = encoder.encode(str);

        // 将 Uint8Array 转为 Base64
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    } catch (error) {
        // 兜底：使用传统 encodeURIComponent 方案
        return btoa(unescape(encodeURIComponent(str)));
    }
}

/**
 * 将 Base64 字符串解码为原始字符串（支持 UTF-8 多字节字符）
 * 流程：Base64 → UTF-8 bytes → string
 *
 * @param   {string} b64  Base64 字符串
 * @returns {string}      解码后的原始字符串
 */
export function decodeBase64UTF8(b64) {
    try {
        // 标准 Base64 → 二进制字符串 → Uint8Array → UTF-8 解码
        const binary  = atob(b64);
        const bytes   = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        const decoder = new TextDecoder('utf-8');
        return decoder.decode(bytes);
    } catch (error) {
        // 兜底：传统方案
        try {
            return decodeURIComponent(escape(atob(b64)));
        } catch {
            throw new Error(`Base64 解码失败：${error.message}`);
        }
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 4  PNG 解析工具（内部使用）
// ═══════════════════════════════════════════════════════════════════

/**
 * 校验字节数组是否以 PNG 魔数开头
 * @private
 *
 * @param   {Uint8Array} bytes
 * @returns {boolean}
 */
function _isPNG(bytes) {
    if (bytes.length < 8) return false;
    return PNG_SIGNATURE.every((b, i) => bytes[i] === b);
}

/**
 * 解析 PNG 文件中所有的 tEXt chunk，返回 keyword → value 映射
 * value 为原始字符串（通常是 Base64）
 * @private
 *
 * @param   {Uint8Array} bytes
 * @returns {Object.<string, string>}  { keyword: value }
 */
function _parseTextChunks(bytes) {
    const chunks = {};
    let   offset = 8; // 跳过 PNG 魔数

    while (offset < bytes.length - 12) {
        // 读取 chunk 长度（4 字节，大端序）
        const length = _readUint32BE(bytes, offset);
        offset += 4;

        // 读取 chunk 类型（4 字节 ASCII）
        const type = String.fromCharCode(
            bytes[offset],
            bytes[offset + 1],
            bytes[offset + 2],
            bytes[offset + 3]
        );
        offset += 4;

        if (type === 'tEXt') {
            // 读取 chunk 数据
            const data = bytes.slice(offset, offset + length);

            // tEXt 格式：keyword\0text
            // 找到 \0 分隔符
            let separatorIdx = -1;
            for (let i = 0; i < data.length; i++) {
                if (data[i] === 0) {
                    separatorIdx = i;
                    break;
                }
            }

            if (separatorIdx !== -1) {
                // keyword：分隔符前的部分（ASCII）
                const keyword = String.fromCharCode(
                    ...data.slice(0, separatorIdx)
                );
                // value：分隔符后的部分（ISO-8859-1，但角色卡用 Base64）
                const value = String.fromCharCode(
                    ...data.slice(separatorIdx + 1)
                );
                chunks[keyword] = value;
            }
        }

        // 跳过数据区 + 4字节 CRC
        offset += length + 4;

        // IEND chunk 表示文件结束
        if (type === 'IEND') break;
    }

    return chunks;
}

/**
 * 将指定的 tEXt chunk 注入 PNG 字节数组
 * 写入位置：IEND chunk 之前（替换已有的同名 chunk）
 * @private
 *
 * @param   {Uint8Array}             bytes         原始 PNG 字节
 * @param   {Object.<string,string>} chunksToWrite { keyword: base64Value }
 * @returns {Uint8Array}                           新的 PNG 字节
 */
function _injectTextChunks(bytes, chunksToWrite) {
    // 将原始 PNG 拆分为：PNG魔数 + 所有chunk（不含已存在的同名chunk）
    const segments    = [];
    let   offset      = 8;
    let   iendSegment = null;

    segments.push(bytes.slice(0, 8)); // PNG 魔数

    while (offset < bytes.length - 12) {
        const length    = _readUint32BE(bytes, offset);
        const chunkEnd  = offset + 4 + 4 + length + 4;
        const type      = String.fromCharCode(
            bytes[offset + 4],
            bytes[offset + 5],
            bytes[offset + 6],
            bytes[offset + 7]
        );

        if (type === 'IEND') {
            iendSegment = bytes.slice(offset, chunkEnd);
            offset = chunkEnd;
            break;
        }

        if (type === 'tEXt') {
            // 检查是否是需要替换的 keyword
            const data         = bytes.slice(offset + 8, offset + 8 + length);
            let   separatorIdx = -1;
            for (let i = 0; i < data.length; i++) {
                if (data[i] === 0) { separatorIdx = i; break; }
            }

            if (separatorIdx !== -1) {
                const keyword = String.fromCharCode(...data.slice(0, separatorIdx));
                // 如果该 keyword 需要被替换，跳过原有 chunk
                if (chunksToWrite.hasOwnProperty(keyword)) {
                    offset = chunkEnd;
                    continue;
                }
            }
        }

        segments.push(bytes.slice(offset, chunkEnd));
        offset = chunkEnd;
    }

    // 构建新的 tEXt chunk 并追加
    for (const [keyword, value] of Object.entries(chunksToWrite)) {
        segments.push(_buildTextChunk(keyword, value));
    }

    // 最后写入 IEND
    if (iendSegment) {
        segments.push(iendSegment);
    }

    // 合并所有片段
    return _concatUint8Arrays(segments);
}

/**
 * 构建一个 PNG tEXt chunk 的字节数据
 * @private
 *
 * @param   {string} keyword   chunk 关键字（ASCII）
 * @param   {string} value     chunk 值（Base64 字符串）
 * @returns {Uint8Array}
 */
function _buildTextChunk(keyword, value) {
    // tEXt 数据：keyword + \0 + value（ISO-8859-1 编码）
    const keyBytes  = _asciiToBytes(keyword);
    const valBytes  = _asciiToBytes(value);
    const dataBytes = new Uint8Array(keyBytes.length + 1 + valBytes.length);

    dataBytes.set(keyBytes, 0);
    dataBytes[keyBytes.length] = 0; // 分隔符 \0
    dataBytes.set(valBytes, keyBytes.length + 1);

    const length    = dataBytes.length;
    const typeBytes = new Uint8Array(CHUNK_TYPE.tEXt);

    // 计算 CRC32（覆盖 type + data）
    const crcInput  = new Uint8Array(4 + length);
    crcInput.set(typeBytes, 0);
    crcInput.set(dataBytes, 4);
    const crc       = _crc32(crcInput);

    // 组装：length(4) + type(4) + data(n) + crc(4)
    const chunk     = new Uint8Array(4 + 4 + length + 4);
    _writeUint32BE(chunk, 0, length);
    chunk.set(typeBytes, 4);
    chunk.set(dataBytes, 8);
    _writeUint32BE(chunk, 8 + length, crc);

    return chunk;
}


// ═══════════════════════════════════════════════════════════════════
// § 5  JSON 编解码（角色卡专用）
// ═══════════════════════════════════════════════════════════════════

/**
 * 将角色卡 JSON 对象编码为 Base64 字符串（用于写入 tEXt chunk）
 * @private
 *
 * @param   {Object} cardJSON  角色卡 JSON 对象
 * @returns {string}           Base64 字符串
 */
function _encodeCardJSON(cardJSON) {
    const jsonStr = JSON.stringify(cardJSON);
    return encodeBase64UTF8(jsonStr);
}

/**
 * 将 tEXt chunk 中的 Base64 字符串解码为角色卡 JSON 对象
 * @private
 *
 * @param   {string} base64  Base64 字符串
 * @returns {Object}         解析后的角色卡 JSON 对象
 */
function _decodeCardJSON(base64) {
    const jsonStr = decodeBase64UTF8(base64);
    return JSON.parse(jsonStr);
}


// ═══════════════════════════════════════════════════════════════════
// § 6  二进制工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 以大端序读取 Uint8Array 中偏移 offset 处的 32 位无符号整数
 * @private
 */
function _readUint32BE(bytes, offset) {
    return (
        (bytes[offset]     << 24 |
         bytes[offset + 1] << 16 |
         bytes[offset + 2] << 8  |
         bytes[offset + 3]) >>> 0
    );
}

/**
 * 以大端序向 Uint8Array 中偏移 offset 处写入 32 位无符号整数
 * @private
 */
function _writeUint32BE(bytes, offset, value) {
    bytes[offset]     = (value >>> 24) & 0xff;
    bytes[offset + 1] = (value >>> 16) & 0xff;
    bytes[offset + 2] = (value >>> 8)  & 0xff;
    bytes[offset + 3] =  value         & 0xff;
}

/**
 * 将 ASCII 字符串转为 Uint8Array
 * @private
 */
function _asciiToBytes(str) {
    const bytes = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) {
        bytes[i] = str.charCodeAt(i) & 0xff;
    }
    return bytes;
}

/**
 * 合并多个 Uint8Array 为一个
 * @private
 *
 * @param   {Uint8Array[]} arrays
 * @returns {Uint8Array}
 */
function _concatUint8Arrays(arrays) {
    const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
    const result      = new Uint8Array(totalLength);
    let   offset      = 0;
    for (const arr of arrays) {
        result.set(arr, offset);
        offset += arr.length;
    }
    return result;
}

/**
 * 计算 CRC32 校验值（PNG chunk 完整性校验）
 * 使用标准 CRC32 多项式 0xEDB88320（IEEE 802.3）
 * @private
 *
 * @param   {Uint8Array} bytes
 * @returns {number}            32 位无符号整数
 */
function _crc32(bytes) {
    // 预计算 CRC 查找表（首次调用时初始化）
    if (!_crc32.table) {
        _crc32.table = new Uint32Array(256);
        for (let i = 0; i < 256; i++) {
            let c = i;
            for (let j = 0; j < 8; j++) {
                c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
            }
            _crc32.table[i] = c;
        }
    }

    let crc = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) {
        crc = _crc32.table[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
}