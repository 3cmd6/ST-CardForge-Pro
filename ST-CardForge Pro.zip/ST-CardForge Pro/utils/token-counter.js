/**
 * @file utils/token-counter.js
 * @description Token 数量估算工具
 *
 *   提供多模型 Token 估算、角色卡整体 Token 分析、
 *   预算检查和智能截断功能。
 *
 *   估算策略（近似值，非精确计数）：
 *     - 中文字符：约 1 字 / token（实际约 0.6~1.5，取中间值��
 *     - 英文单词：约 1 词 / 0.75 token
 *     - 标点/空格：约 4 字符 / token
 *     - 代码/特殊符号：约 3 字符 / token
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

import { CARD_DATA_SCHEMA } from '../contracts.js';

// ═══════════════════════════════════════════════════════════════════
// § 1  Token 限制常量
// ═══════════════════════════════════════════════════════════════════

/**
 * 各字段与整卡的 Token 限制阈值
 * WARNING 为警告线（黄色提示），HARD 为强制截断线（红色提示）
 *
 * @readonly
 * @enum {number}
 */
export const TOKEN_LIMITS = Object.freeze({
    // 单字段警告阈值
    DESCRIPTION_WARN:           2000,
    DESCRIPTION_HARD:           3000,
    PERSONALITY_WARN:           500,
    PERSONALITY_HARD:           800,
    SCENARIO_WARN:              500,
    SCENARIO_HARD:              800,
    FIRST_MES_WARN:             1000,
    FIRST_MES_HARD:             1500,
    MES_EXAMPLE_WARN:           1500,
    MES_EXAMPLE_HARD:           2000,
    SYSTEM_PROMPT_WARN:         500,
    SYSTEM_PROMPT_HARD:         800,
    POST_HISTORY_WARN:          300,
    POST_HISTORY_HARD:          500,
    WB_ENTRY_WARN:              400,
    WB_ENTRY_HARD:              600,
    SINGLE_GREETING_WARN:       800,
    SINGLE_GREETING_HARD:       1200,

    // 整卡汇总阈值
    TOTAL_CARD_WARN:            4096,
    TOTAL_CARD_HARD:            8192,
});

/**
 * 支持估算的模型类型
 * 不同模型的 tokenizer 略有差异，此处提供近似修正系数
 *
 * @readonly
 * @enum {string}
 */
export const MODEL_TYPES = Object.freeze({
    AUTO:       'auto',     // 自动检测（默认）
    GPT:        'gpt',      // GPT 系列（cl100k_base）
    CLAUDE:     'claude',   // Claude 系列
    LLAMA:      'llama',    // LLaMA / Mistral 系列
    GEMINI:     'gemini',   // Gemini 系列
});

/**
 * 各模型相对于基准估算的修正系数
 * 基准：中文1字/token，英文0.75词/token
 *
 * @private
 */
const MODEL_CORRECTION = Object.freeze({
    [MODEL_TYPES.AUTO]:     1.00,
    [MODEL_TYPES.GPT]:      1.00,
    [MODEL_TYPES.CLAUDE]:   1.05,   // Claude 对中文略多消耗
    [MODEL_TYPES.LLAMA]:    1.10,   // LLaMA 中文效率较低
    [MODEL_TYPES.GEMINI]:   0.95,   // Gemini 对中文处理较好
});


// ═══════════════════════════════════════════════════════════════════
// § 2  核心估算函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 估算一段文本的 Token 数量
 *
 * @param   {string} text           待估算文本
 * @param   {string} [model='auto'] 模型类型（见 MODEL_TYPES）
 * @returns {number}                估算的 Token 数量（向上取整）
 *
 * @example
 * estimateTokens('你好世界');         // → 4
 * estimateTokens('Hello world');     // → 3
 * estimateTokens('你好 Hello', 'claude'); // → 带修正系数的结果
 */
export function estimateTokens(text, model = MODEL_TYPES.AUTO) {
    if (!text || typeof text !== 'string') {
        return 0;
    }

    const correction = MODEL_CORRECTION[model] ?? MODEL_CORRECTION[MODEL_TYPES.AUTO];

    // 分离中文字符
    const chineseChars = (text.match(/[\u4e00-\u9fa5\u3000-\u303f\uff00-\uffef]/g) || []).length;

    // 分离日文字符（平假名、片假名）
    const japaneseChars = (text.match(/[\u3040-\u309f\u30a0-\u30ff]/g) || []).length;

    // 分离韩文字符
    const koreanChars = (text.match(/[\uac00-\ud7af]/g) || []).length;

    // 分离英文单词
    const englishWords = (text.match(/[a-zA-Z]+(?:'[a-zA-Z]+)*/g) || []).length;

    // 分离数字串
    const numberGroups = (text.match(/\d+\.?\d*/g) || []).length;

    // 其余字符（标点、空格、符号等）
    const otherChars = text.length
        - chineseChars
        - japaneseChars
        - koreanChars
        - (text.match(/[a-zA-Z0-9'.,-]/g) || []).length;

    // Token 估算公式
    const rawTokens =
        chineseChars  * 1.0    +   // 中文：1字≈1token
        japaneseChars * 1.0    +   // 日文：1字≈1token
        koreanChars   * 1.2    +   // 韩文：略多
        englishWords  * 1.3    +   // 英文单词（含子词分割余量）
        numberGroups  * 0.5    +   // 数字
        otherChars    * 0.25;      // 标点/空白

    return Math.ceil(rawTokens * correction);
}

/**
 * 估算一个字符串数组（如 alternate_greetings）的总 Token 数
 *
 * @param   {string[]} arr
 * @param   {string}   [model='auto']
 * @returns {number}
 */
export function estimateTokensArray(arr, model = MODEL_TYPES.AUTO) {
    if (!Array.isArray(arr)) return 0;
    return arr.reduce((sum, item) => sum + estimateTokens(item, model), 0);
}


// ═══════════════════════════════════════════════════════════════════
// § 3  角色卡整体 Token 分析
// ═══════════════════════════════════════════════════════════════════

/**
 * 计算角色卡各字段的 Token 占用及汇总
 *
 * @param   {import('../contracts.js').CardData} cardData  角色卡数据对象
 * @param   {string} [model='auto']                        模型类型
 * @returns {CardTokenStats}
 *
 * @typedef  {Object} CardTokenStats
 * @property {number} total                  整卡 Token 合计
 * @property {Object} fields                 各字段 Token 明细
 * @property {number} fields.name
 * @property {number} fields.description
 * @property {number} fields.personality
 * @property {number} fields.scenario
 * @property {number} fields.first_mes
 * @property {number} fields.mes_example
 * @property {number} fields.system_prompt
 * @property {number} fields.post_history_instructions
 * @property {number} fields.alternate_greetings
 * @property {number} fields.tags
 * @property {Object} warnings               超出警告线的字段
 * @property {Object} overLimit              超出强制线的字段
 */
export function estimateCardTokens(cardData, model = MODEL_TYPES.AUTO) {
    const d = cardData?.data ?? {};

    const fields = {
        name:                       estimateTokens(d.name, model),
        description:                estimateTokens(d.description, model),
        personality:                estimateTokens(d.personality, model),
        scenario:                   estimateTokens(d.scenario, model),
        first_mes:                  estimateTokens(d.first_mes, model),
        mes_example:                estimateTokens(d.mes_example, model),
        system_prompt:              estimateTokens(d.system_prompt, model),
        post_history_instructions:  estimateTokens(d.post_history_instructions, model),
        alternate_greetings:        estimateTokensArray(d.alternate_greetings, model),
        tags:                       estimateTokens((d.tags ?? []).join(' '), model),
        creator_notes:              estimateTokens(d.creator_notes, model),
    };

    const total = Object.values(fields).reduce((s, v) => s + v, 0);

    // 检测超出警告线的字段
    const warnings = {};
    const overLimit = {};

    const fieldLimitMap = {
        description:                { warn: TOKEN_LIMITS.DESCRIPTION_WARN,  hard: TOKEN_LIMITS.DESCRIPTION_HARD },
        personality:                { warn: TOKEN_LIMITS.PERSONALITY_WARN,   hard: TOKEN_LIMITS.PERSONALITY_HARD },
        scenario:                   { warn: TOKEN_LIMITS.SCENARIO_WARN,      hard: TOKEN_LIMITS.SCENARIO_HARD },
        first_mes:                  { warn: TOKEN_LIMITS.FIRST_MES_WARN,     hard: TOKEN_LIMITS.FIRST_MES_HARD },
        mes_example:                { warn: TOKEN_LIMITS.MES_EXAMPLE_WARN,   hard: TOKEN_LIMITS.MES_EXAMPLE_HARD },
        system_prompt:              { warn: TOKEN_LIMITS.SYSTEM_PROMPT_WARN, hard: TOKEN_LIMITS.SYSTEM_PROMPT_HARD },
        post_history_instructions:  { warn: TOKEN_LIMITS.POST_HISTORY_WARN,  hard: TOKEN_LIMITS.POST_HISTORY_HARD },
    };

    for (const [fieldName, limits] of Object.entries(fieldLimitMap)) {
        const count = fields[fieldName];
        if (count >= limits.hard) {
            overLimit[fieldName] = { count, limit: limits.hard };
        } else if (count >= limits.warn) {
            warnings[fieldName] = { count, limit: limits.warn };
        }
    }

    // 整卡总量检测
    if (total >= TOKEN_LIMITS.TOTAL_CARD_HARD) {
        overLimit['_total'] = { count: total, limit: TOKEN_LIMITS.TOTAL_CARD_HARD };
    } else if (total >= TOKEN_LIMITS.TOTAL_CARD_WARN) {
        warnings['_total'] = { count: total, limit: TOKEN_LIMITS.TOTAL_CARD_WARN };
    }

    return { total, fields, warnings, overLimit };
}


// ═══════════════════════════════════════════════════════════════════
// § 4  预算检查
// ═══════════════════════════════════════════════════════════════════

/**
 * 检查一段文本是否超出 Token 预算
 *
 * @param   {string} text           待检查文本
 * @param   {number} limit          Token 上限
 * @param   {string} [model='auto'] 模型类型
 * @returns {BudgetResult}
 *
 * @typedef  {Object}  BudgetResult
 * @property {boolean} ok           是否在预算内
 * @property {number}  used         已使用 Token 数
 * @property {number}  remaining    剩余 Token 数（可为负）
 * @property {number}  percentage   使用百分比（0~100+）
 * @property {string}  status       'ok' | 'warning' | 'over'
 */
export function checkBudget(text, limit, model = MODEL_TYPES.AUTO) {
    const used       = estimateTokens(text, model);
    const remaining  = limit - used;
    const percentage = Math.round((used / limit) * 100);

    let status;
    if (percentage >= 100) {
        status = 'over';
    } else if (percentage >= 80) {
        status = 'warning';
    } else {
        status = 'ok';
    }

    return {
        ok:         remaining >= 0,
        used,
        remaining,
        percentage,
        status,
    };
}


// ═══════════════════════════════════════════════════════════════════
// § 5  智能截断
// ═══════════════════════════════════════════════════════════════════

/**
 * 将文本截断到指定 Token 上限以内
 *
 * @param   {string} text               待截断文本
 * @param   {number} limit              Token 上限
 * @param   {Object} [options={}]
 * @param   {string} [options.strategy='end']   截断策略
 *            'end'    从末尾截断（保留开头）
 *            'middle' 从中间截断（保留两端）
 *            'smart'  按句子边界截断（避免句子断裂）
 * @param   {string} [options.ellipsis='…']     截断后追加的省略标记
 * @param   {string} [options.model='auto']     模型类型
 * @returns {string}                    截断后的文本
 */
export function truncateToLimit(text, limit, options = {}) {
    const {
        strategy = 'end',
        ellipsis = '…',
        model    = MODEL_TYPES.AUTO,
    } = options;

    if (!text) return '';

    // 已在限制内，直接返回
    if (estimateTokens(text, model) <= limit) {
        return text;
    }

    switch (strategy) {
        case 'end':
            return _truncateFromEnd(text, limit, ellipsis, model);
        case 'middle':
            return _truncateFromMiddle(text, limit, ellipsis, model);
        case 'smart':
            return _truncateSmart(text, limit, ellipsis, model);
        default:
            return _truncateFromEnd(text, limit, ellipsis, model);
    }
}

/**
 * 从末尾截断
 * @private
 */
function _truncateFromEnd(text, limit, ellipsis, model) {
    // 预留省略号的 Token
    const ellipsisTokens = estimateTokens(ellipsis, model);
    const targetLimit    = limit - ellipsisTokens;

    // 二分查找最优截断点
    let lo  = 0;
    let hi  = text.length;
    let mid = 0;

    while (lo < hi) {
        mid = Math.floor((lo + hi + 1) / 2);
        if (estimateTokens(text.slice(0, mid), model) <= targetLimit) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }

    return text.slice(0, lo) + ellipsis;
}

/**
 * 从中间截断（保留首尾各一半）
 * @private
 */
function _truncateFromMiddle(text, limit, ellipsis, model) {
    const ellipsisTokens = estimateTokens(ellipsis, model);
    const halfLimit      = Math.floor((limit - ellipsisTokens) / 2);

    const head = _truncateFromEnd(text, halfLimit, '', model);
    const tail = text.slice(text.length - Math.floor(text.length / 2));

    // 确保 tail 部分也不超出剩余预算
    const headTokens  = estimateTokens(head, model);
    const tailAllowed = limit - ellipsisTokens - headTokens;

    let lo = 0;
    let hi = tail.length;
    while (lo < hi) {
        const mid = Math.floor((lo + hi + 1) / 2);
        if (estimateTokens(tail.slice(tail.length - mid), model) <= tailAllowed) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }

    return head + ellipsis + tail.slice(tail.length - lo);
}

/**
 * 按句子边界智能截断
 * 尽量保证最后一个完整句子不被切断
 * @private
 */
function _truncateSmart(text, limit, ellipsis, model) {
    const ellipsisTokens = estimateTokens(ellipsis, model);
    const targetLimit    = limit - ellipsisTokens;

    // 中文句子分隔符：。！？；…  英文：. ! ?
    const sentenceEnds = /[。！？；…\.!\?]/g;
    const matches      = [];
    let   match;

    while ((match = sentenceEnds.exec(text)) !== null) {
        matches.push(match.index + 1); // 包含句尾标点
    }

    // 找到最后一个不超出 targetLimit 的句子边界
    let bestEnd = 0;
    for (const pos of matches) {
        const slice = text.slice(0, pos);
        if (estimateTokens(slice, model) <= targetLimit) {
            bestEnd = pos;
        } else {
            break;
        }
    }

    if (bestEnd === 0) {
        // 找不到合适的句子边界，退回到 end 策略
        return _truncateFromEnd(text, limit, ellipsis, model);
    }

    return text.slice(0, bestEnd) + ellipsis;
}


// ═══════════════════════════════════════════════════════════════════
// § 6  格式化工具
// ═══════════════════════════════════════════════════════════════════

/**
 * 将 Token 数格式化为带单位的可读字符串
 *
 * @param   {number} count
 * @returns {string}
 *
 * @example
 * formatTokenCount(1234);   // → '1,234'
 * formatTokenCount(12345);  // → '12.3k'
 */
export function formatTokenCount(count) {
    if (count >= 10000) {
        return (count / 1000).toFixed(1) + 'k';
    }
    return count.toLocaleString('en-US');
}

/**
 * 生成用于 UI 显示的 Token 状态对象
 *
 * @param   {number} used    已用 Token
 * @param   {number} limit   总限制
 * @returns {TokenUIState}
 *
 * @typedef  {Object} TokenUIState
 * @property {string} text      显示文本，如 '1,234 / 4,096'
 * @property {string} status    'ok' | 'warning' | 'over'
 * @property {string} color     对应 CSS 变量名
 * @property {number} barWidth  进度条宽度百分比（0~100）
 */
export function getTokenUIState(used, limit) {
    const percentage = Math.min(Math.round((used / limit) * 100), 100);

    let status, color;
    if (used >= limit) {
        status = 'over';
        color  = 'var(--cf-danger)';
    } else if (used >= limit * 0.8) {
        status = 'warning';
        color  = 'var(--cf-warning)';
    } else {
        status = 'ok';
        color  = 'var(--cf-success)';
    }

    return {
        text:     `${formatTokenCount(used)} / ${formatTokenCount(limit)}`,
        status,
        color,
        barWidth: percentage,
    };
}

/**
 * 获取字段级别的 Token 状态（含警告线判断）
 *
 * @param   {string} fieldName  字段名（见 fieldLimitMap）
 * @param   {number} tokenCount 该字段的 Token 数量
 * @returns {{ status: string, warnAt: number, hardAt: number }}
 */
export function getFieldTokenStatus(fieldName, tokenCount) {
    const fieldLimitMap = {
        description:                { warn: TOKEN_LIMITS.DESCRIPTION_WARN,  hard: TOKEN_LIMITS.DESCRIPTION_HARD },
        personality:                { warn: TOKEN_LIMITS.PERSONALITY_WARN,   hard: TOKEN_LIMITS.PERSONALITY_HARD },
        scenario:                   { warn: TOKEN_LIMITS.SCENARIO_WARN,      hard: TOKEN_LIMITS.SCENARIO_HARD },
        first_mes:                  { warn: TOKEN_LIMITS.FIRST_MES_WARN,     hard: TOKEN_LIMITS.FIRST_MES_HARD },
        mes_example:                { warn: TOKEN_LIMITS.MES_EXAMPLE_WARN,   hard: TOKEN_LIMITS.MES_EXAMPLE_HARD },
        system_prompt:              { warn: TOKEN_LIMITS.SYSTEM_PROMPT_WARN, hard: TOKEN_LIMITS.SYSTEM_PROMPT_HARD },
        post_history_instructions:  { warn: TOKEN_LIMITS.POST_HISTORY_WARN,  hard: TOKEN_LIMITS.POST_HISTORY_HARD },
    };

    const limits = fieldLimitMap[fieldName];
    if (!limits) return { status: 'ok', warnAt: Infinity, hardAt: Infinity };

    let status;
    if (tokenCount >= limits.hard) {
        status = 'over';
    } else if (tokenCount >= limits.warn) {
        status = 'warning';
    } else {
        status = 'ok';
    }

    return { status, warnAt: limits.warn, hardAt: limits.hard };
}