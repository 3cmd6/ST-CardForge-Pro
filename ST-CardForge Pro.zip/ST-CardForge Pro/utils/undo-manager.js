/**
 * @file utils/undo-manager.js
 * @description 全局撤销 / 重做管理器
 *
 *   提供基于快照（Snapshot）的撤销 / 重做功能，用于：
 *     - 角色卡字段编辑的撤销 / 重做
 *     - 世界书条目增删的撤销 / 重做
 *     - 字段增强操作的撤销 / 重做
 *     - 分支树结构变更的撤销 / 重做
 *
 *   设计说明：
 *     - 基于「状态快照」而非「操作逆向」，实现简单可靠
 *     - 快照内容由调用方决定（支持任意可序列化对象）
 *     - 支持命名操作（description），用于 UI 显示操作历史
 *     - 支持「批量操作」合并为单步撤销（transaction）
 *     - 最大历史条数可配置，超出时自动丢弃最旧的快照
 *     - 支持多个独立 namespace，各模块使用独立的撤销栈
 *
 * @version 1.0.0
 * @author  YourName
 * @license MIT
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════
// § 1  类型定义
// ═══════════════════════════════════════════════════════════════════

/**
 * 快照条目结构
 * @typedef  {Object} SnapshotEntry
 * @property {string}  id           快照唯一 ID
 * @property {*}       snapshot     状态快照（深拷贝，由调用方决定内容）
 * @property {string}  description  操作描述（用于 UI 显示，如「修改描述字段」）
 * @property {number}  timestamp    快照创建时间戳（ms）
 * @property {string}  namespace    所属命名空间
 */

/**
 * 撤销管理器状态
 * @typedef  {Object} UndoManagerState
 * @property {boolean} canUndo      是否可撤销
 * @property {boolean} canRedo      是否可重做
 * @property {number}  undoCount    撤销栈深度
 * @property {number}  redoCount    重做栈深度
 * @property {string|null}  nextUndo  下一步撤销的操作描述
 * @property {string|null}  nextRedo  下一步重做的操作描述
 */


// ═══════════════════════════════════════════════════════════════════
// § 2  UndoManager 类
// ═══════════════════════════════════════════════════════════════════

export class UndoManager {

    /**
     * @param {Object}  [options={}]
     * @param {number}  [options.maxSize=50]       每个命名空间的最大历史条数
     * @param {boolean} [options.deepClone=true]   是否对快照做深拷贝（防止引用污染）
     * @param {Function}[options.onChange]          状态变化时的回调 (state) => void
     */
    constructor(options = {}) {
        const {
            maxSize   = 50,
            deepClone = true,
            onChange  = null,
        } = options;

        /** @private 每个 namespace 的最大历史条数 */
        this._maxSize   = maxSize;

        /** @private 是否深拷贝快照 */
        this._deepClone = deepClone;

        /** @private 状态变化回调 */
        this._onChange  = onChange;

        /**
         * @private
         * 各 namespace 的撤销栈
         * @type {Map<string, SnapshotEntry[]>}
         */
        this._undoStacks = new Map();

        /**
         * @private
         * 各 namespace 的重做栈
         * @type {Map<string, SnapshotEntry[]>}
         */
        this._redoStacks = new Map();

        /**
         * @private
         * 当前是否处于批量事务中
         * @type {Map<string, SnapshotEntry[]>}
         */
        this._transactions = new Map();
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.1  核心操作
    // ─────────────────────────────────────────────────────────────

    /**
     * 推入一个新快照（记录当前状态）
     * 推入后重做栈将被清空（符合标准撤销语义）
     *
     * @param   {*}      snapshot     当前状态快照（任意可序列化对象）
     * @param   {string} description  操作描述，用于 UI 显示
     * @param   {string} [namespace='default']  命名空间
     * @returns {string}  快照 ID
     *
     * @example
     * // 在修改字段前先记录快照
     * undoManager.push(
     *   JSON.parse(JSON.stringify(cardData)),
     *   '修改 description 字段'
     * );
     * cardData.data.description = newValue;
     */
    push(snapshot, description, namespace = 'default') {
        // 处于批量事务中时，快照加入事务缓冲
        if (this._transactions.has(namespace)) {
            this._transactions.get(namespace).push(
                this._buildEntry(snapshot, description, namespace)
            );
            return;
        }

        const entry = this._buildEntry(snapshot, description, namespace);
        const stack = this._getUndoStack(namespace);

        stack.push(entry);

        // 超出最大历史时，丢弃最旧的快照
        if (stack.length > this._maxSize) {
            stack.shift();
        }

        // 推入新快照后，清空重做栈
        this._getRedoStack(namespace).length = 0;

        this._notify(namespace);
        return entry.id;
    }

    /**
     * 执行撤销操作
     * 将当前状态从撤销栈弹出，推入重做栈，并返回上一个快照
     *
     * @param   {string} [namespace='default']
     * @returns {SnapshotEntry|null}  上一个快照条目，无法撤销时返回 null
     *
     * @example
     * const prev = undoManager.undo();
     * if (prev) {
     *   cardData = prev.snapshot; // 恢复到上一个状态
     * }
     */
    undo(namespace = 'default') {
        const undoStack = this._getUndoStack(namespace);
        const redoStack = this._getRedoStack(namespace);

        if (undoStack.length === 0) return null;

        // 从撤销栈弹出最后一个快照
        const entry = undoStack.pop();

        // 将其推入重做栈
        redoStack.push(entry);

        this._notify(namespace);
        return entry;
    }

    /**
     * 执行重做操作
     * 将快照从重做栈弹出，推回撤销栈，并返回该快照
     *
     * @param   {string} [namespace='default']
     * @returns {SnapshotEntry|null}  重做的快照条目，无法重做时返回 null
     */
    redo(namespace = 'default') {
        const undoStack = this._getUndoStack(namespace);
        const redoStack = this._getRedoStack(namespace);

        if (redoStack.length === 0) return null;

        // 从重做栈弹出最后一个快照
        const entry = redoStack.pop();

        // 将其推回撤销栈
        undoStack.push(entry);

        this._notify(namespace);
        return entry;
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.2  状态查询
    // ─────────────────────────────────────────────────────────────

    /**
     * 是否可以撤销
     *
     * @param   {string} [namespace='default']
     * @returns {boolean}
     */
    canUndo(namespace = 'default') {
        return this._getUndoStack(namespace).length > 0;
    }

    /**
     * 是否可以重做
     *
     * @param   {string} [namespace='default']
     * @returns {boolean}
     */
    canRedo(namespace = 'default') {
        return this._getRedoStack(namespace).length > 0;
    }

    /**
     * 获取指定命名空间的撤销管理器状态摘要
     *
     * @param   {string} [namespace='default']
     * @returns {UndoManagerState}
     */
    getState(namespace = 'default') {
        const undoStack = this._getUndoStack(namespace);
        const redoStack = this._getRedoStack(namespace);

        return {
            canUndo:   undoStack.length > 0,
            canRedo:   redoStack.length > 0,
            undoCount: undoStack.length,
            redoCount: redoStack.length,
            nextUndo:  undoStack.length > 0
                           ? undoStack[undoStack.length - 1].description
                           : null,
            nextRedo:  redoStack.length > 0
                           ? redoStack[redoStack.length - 1].description
                           : null,
        };
    }

    /**
     * 获取指定命名空间的完整操作历史列表（不含快照数据，仅元信息）
     * 列表按从旧到新排列
     *
     * @param   {string} [namespace='default']
     * @returns {Array<{id, description, timestamp}>}
     */
    getHistory(namespace = 'default') {
        return this._getUndoStack(namespace).map(({ id, description, timestamp }) => ({
            id,
            description,
            timestamp,
        }));
    }

    /**
     * 查看撤销栈栈顶的快照（不弹出）
     *
     * @param   {string} [namespace='default']
     * @returns {SnapshotEntry|null}
     */
    peekUndo(namespace = 'default') {
        const stack = this._getUndoStack(namespace);
        return stack.length > 0 ? stack[stack.length - 1] : null;
    }

    /**
     * 查看重做栈栈顶的快照（不弹出）
     *
     * @param   {string} [namespace='default']
     * @returns {SnapshotEntry|null}
     */
    peekRedo(namespace = 'default') {
        const stack = this._getRedoStack(namespace);
        return stack.length > 0 ? stack[stack.length - 1] : null;
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.3  清理操作
    // ─────────────────────────────────────────────────────────────

    /**
     * 清空指定命名空间的撤销和重做栈
     *
     * @param   {string} [namespace='default']
     * @returns {void}
     */
    clear(namespace = 'default') {
        this._getUndoStack(namespace).length = 0;
        this._getRedoStack(namespace).length = 0;
        this._notify(namespace);
    }

    /**
     * 清空所有命名空间的历史
     * @returns {void}
     */
    clearAll() {
        this._undoStacks.clear();
        this._redoStacks.clear();
        this._transactions.clear();
    }

    /**
     * 获取所有已注册的命名空间列表
     * @returns {string[]}
     */
    getNamespaces() {
        return [...new Set([
            ...this._undoStacks.keys(),
            ...this._redoStacks.keys(),
        ])];
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.4  批量事务（将多步操作合并为单步撤销）
    // ─────────────────────────────────────────────────────────────

    /**
     * 开始一个批量事务
     * 事务期间的所有 push() 操作将被缓冲，
     * 调用 commitTransaction() 后合并为一条历史记录
     *
     * @param   {string} [namespace='default']
     * @returns {void}
     *
     * @example
     * undoManager.beginTransaction();
     * undoManager.push(snapshot1, '步骤1');
     * undoManager.push(snapshot2, '步骤2');
     * undoManager.commitTransaction('批量生成所有字段');
     * // 之后 undo() 一次即可撤销以上所有步骤
     */
    beginTransaction(namespace = 'default') {
        if (this._transactions.has(namespace)) {
            console.warn(`[CardForge] UndoManager: namespace "${namespace}" 已有进行中的事务`);
            return;
        }
        this._transactions.set(namespace, []);
    }

    /**
     * 提交批量事务
     * 将事务期间的所有快照合并，只保留最后一个快照（最终状态）
     *
     * @param   {string}  description  合并后的操作描述
     * @param   {string}  [namespace='default']
     * @returns {string|null}  合并后的快照 ID，事务为空时返回 null
     */
    commitTransaction(description, namespace = 'default') {
        const buffer = this._transactions.get(namespace);
        this._transactions.delete(namespace);

        if (!buffer || buffer.length === 0) return null;

        // 只保留最后一个快照（最终状态），使用合并后的描述
        const lastEntry     = buffer[buffer.length - 1];
        lastEntry.description = description;

        const stack = this._getUndoStack(namespace);
        stack.push(lastEntry);

        if (stack.length > this._maxSize) {
            stack.shift();
        }

        // 提交后清空重做栈
        this._getRedoStack(namespace).length = 0;

        this._notify(namespace);
        return lastEntry.id;
    }

    /**
     * 回滚批量事务（丢弃事务期间的所有快照）
     *
     * @param   {string} [namespace='default']
     * @returns {void}
     */
    rollbackTransaction(namespace = 'default') {
        this._transactions.delete(namespace);
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.5  回调注册
    // ─────────────────────────────────────────────────────────────

    /**
     * 注册状态变化回调
     * 每次 push / undo / redo / clear 后触发
     *
     * @param   {Function} callback  (state: UndoManagerState, namespace: string) => void
     * @returns {Function}           取消注册函数
     *
     * @example
     * const unsubscribe = undoManager.onChange((state, ns) => {
     *     updateUndoButton(state.canUndo);
     *     updateRedoButton(state.canRedo);
     * });
     * // 不再需要时：
     * unsubscribe();
     */
    onChange(callback) {
        this._onChange = callback;
        return () => {
            if (this._onChange === callback) {
                this._onChange = null;
            }
        };
    }


    // ─────────────────────────────────────────────────────────────
    // § 2.6  私有方法
    // ─────────────────────────────────────────────────────────────

    /**
     * 获取指定命名空间的撤销栈（不存在时自动创建）
     * @private
     *
     * @param   {string} namespace
     * @returns {SnapshotEntry[]}
     */
    _getUndoStack(namespace) {
        if (!this._undoStacks.has(namespace)) {
            this._undoStacks.set(namespace, []);
        }
        return this._undoStacks.get(namespace);
    }

    /**
     * 获取指定命名空间的重做栈（不存在时自动创建）
     * @private
     *
     * @param   {string} namespace
     * @returns {SnapshotEntry[]}
     */
    _getRedoStack(namespace) {
        if (!this._redoStacks.has(namespace)) {
            this._redoStacks.set(namespace, []);
        }
        return this._redoStacks.get(namespace);
    }

    /**
     * 构建一个快照条目对象
     * @private
     *
     * @param   {*}      snapshot
     * @param   {string} description
     * @param   {string} namespace
     * @returns {SnapshotEntry}
     */
    _buildEntry(snapshot, description, namespace) {
        return {
            id:          _generateSnapshotId(),
            snapshot:    this._deepClone ? _deepClone(snapshot) : snapshot,
            description: description ?? '未知操作',
            timestamp:   Date.now(),
            namespace,
        };
    }

    /**
     * 触发状态变化回调
     * @private
     *
     * @param {string} namespace
     */
    _notify(namespace) {
        if (typeof this._onChange === 'function') {
            try {
                this._onChange(this.getState(namespace), namespace);
            } catch (error) {
                console.error('[CardForge] UndoManager onChange 回调抛出异常：', error);
            }
        }
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 3  工具函数
// ═══════════════════════════════════════════════════════════════════

/**
 * 生成快照 ID（短 ID，无需 UUID 级别的全局唯一性）
 * @private
 *
 * @returns {string}  格式：snap_xxxxxxxx
 */
function _generateSnapshotId() {
    return 'snap_' + Math.random().toString(36).slice(2, 10);
}

/**
 * 对任意可序列化对象进行深拷贝
 * 优先使用 structuredClone（现代浏览器），兜底使用 JSON 序列化
 * @private
 *
 * @param   {*} obj
 * @returns {*}
 */
function _deepClone(obj) {
    if (obj === null || obj === undefined) return obj;

    // structuredClone 支持更多类型（Date / Map / Set 等）
    if (typeof structuredClone === 'function') {
        try {
            return structuredClone(obj);
        } catch {
            // 若对象含不可克隆的属性（如 Function），退回 JSON
        }
    }

    // JSON 序列化兜底（Function / Symbol / undefined 字段会丢失）
    try {
        return JSON.parse(JSON.stringify(obj));
    } catch (error) {
        console.warn('[CardForge] UndoManager 深拷贝失败，将使用引用：', error);
        return obj;
    }
}


// ═══════════════════════════════════════════════════════════════════
// § 4  模块级单例
// ═══════════════════════════════════════════════════════════════════

/**
 * 模块级 UndoManager 单例
 * 各功能模块通过 namespace 隔离各自的撤销栈：
 *
 *   'card'     → 角色卡编辑器
 *   'worldbook'→ 世界书编辑器
 *   'branch'   → 分支树编辑器
 *   'regex'    → 正则规则编辑器
 *
 * @type {UndoManager}
 *
 * @example
 * import { undoManager } from '../../utils/undo-manager.js';
 *
 * // 保存快照
 * undoManager.push(cardData, '修改 description', 'card');
 *
 * // 撤销
 * const prev = undoManager.undo('card');
 * if (prev) restoreCard(prev.snapshot);
 */
export const undoManager = new UndoManager({
    maxSize:   50,
    deepClone: true,
});

/**
 * 各模块使用的标准 namespace 常量
 * @readonly
 * @enum {string}
 */
export const UNDO_NAMESPACES = Object.freeze({
    CARD:       'card',
    WORLDBOOK:  'worldbook',
    BRANCH:     'branch',
    REGEX:      'regex',
    ENHANCER:   'enhancer',
});